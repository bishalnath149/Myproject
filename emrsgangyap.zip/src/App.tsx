import React, { useEffect, useRef, useState } from 'react';
import {
  LayoutDashboard,
  Users,
  GraduationCap,
  BookOpen,
  UserCheck,
  Calendar,
  ClipboardCheck,
  BarChart3,
  ShieldAlert,
  Settings,
  ClipboardList,
  Layers,
  LogOut,
  Menu,
  X,
  KeyRound,
  FileText,
  UserRound,
} from 'lucide-react';
import type { AuthUser, ExaminationRecord, SchoolInfo } from './types';
import { apiFetch, extractErrorMessage, setStoredToken } from './lib/api';
import { formatClassSectionLabel } from './lib/grading';
import { LoginView } from './components/LoginView';
import { AdminDashboard, type AdminSection } from './components/AdminDashboard';
import { TeacherMarksWorkspace } from './components/TeacherMarksWorkspace';
import { ClassTeacherWorkspace } from './components/ClassTeacherWorkspace';
import { SchoolLogo } from './components/SchoolLogo';

interface TeacherWorkspaceData {
  subjectAssignments: any[];
  classTeacherAssignments: Array<{
    id: number;
    class_id: number;
    class_name: string;
    has_sections?: number | boolean;
    section_id: number;
    section_name: string;
    academic_year: string;
    student_count: number;
  }>;
}

const NAV_STATE_KEYS = {
  adminSection: 'portal_admin_section',
  selectedYear: 'portal_selected_year',
  teacherMode: 'portal_teacher_mode',
  subjectSubTab: 'portal_subject_tab',
  ctSubTab: 'portal_ct_tab',
} as const;

function readSessionValue(key: string, fallback = ''): string {
  try {
    return window.sessionStorage?.getItem(key) || fallback;
  } catch {
    return fallback;
  }
}

function writeSessionValue(key: string, value: string | null) {
  try {
    if (value) window.sessionStorage?.setItem(key, value);
    else window.sessionStorage?.removeItem(key);
  } catch {
    // ignore storage errors
  }
}

function pickValidAcademicYear(info: SchoolInfo, candidate?: string | null): string {
  const activeYears = (info.academicYears || []).map((ay) => ay.name);
  if (candidate && (activeYears.length === 0 || activeYears.includes(candidate))) {
    return candidate;
  }
  return info.currentAcademicYear || activeYears[0] || '';
}

export default function App() {
  const [schoolInfo, setSchoolInfo] = useState<SchoolInfo | null>(null);
  const [user, setUser] = useState<AuthUser | null>(null);
  const [examinations, setExaminations] = useState<ExaminationRecord[]>([]);
  const [teacherData, setTeacherData] = useState<TeacherWorkspaceData>({
    subjectAssignments: [],
    classTeacherAssignments: [],
  });
  const [initializing, setInitializing] = useState(true);
  const [initError, setInitError] = useState<string | null>(null);
  const [sessionWarning, setSessionWarning] = useState<string | null>(null);

  const [adminSection, setAdminSection] = useState<AdminSection>(
    () => readSessionValue(NAV_STATE_KEYS.adminSection, 'overview') || 'overview'
  );
  const [selectedAcademicYear, setSelectedAcademicYear] = useState<string>(
    () => readSessionValue(NAV_STATE_KEYS.selectedYear, '')
  );
  const [teacherMode, setTeacherMode] = useState<'subject' | 'class-teacher'>(() => {
    const v = readSessionValue(NAV_STATE_KEYS.teacherMode, 'subject');
    return v === 'class-teacher' ? 'class-teacher' : 'subject';
  });
  const [subjectSubTab, setSubjectSubTab] = useState<'entry' | 'assignments' | 'history'>(() => {
    const v = readSessionValue(NAV_STATE_KEYS.subjectSubTab, 'entry');
    return v === 'assignments' || v === 'history' ? v : 'entry';
  });
  const [ctSubTab, setCtSubTab] = useState<
    | 'consolidated'
    | 'students'
    | 'student-details'
    | 'co-scholastic'
    | 'analysis'
    | 'comparison'
    | 'promotion'
  >(() => {
    const v = readSessionValue(NAV_STATE_KEYS.ctSubTab, 'consolidated');
    return v === 'students' ||
      v === 'student-details' ||
      v === 'co-scholastic' ||
      v === 'analysis' ||
      v === 'comparison' ||
      v === 'promotion'
      ? v
      : 'consolidated';
  });
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const [changePassOpen, setChangePassOpen] = useState(false);
  const [passForm, setPassForm] = useState({ currentPassword: '', newPassword: '' });
  const [passFeedback, setPassFeedback] = useState<string | null>(null);
  const refreshSeqRef = useRef(0);

  useEffect(() => {
    writeSessionValue(NAV_STATE_KEYS.adminSection, adminSection);
  }, [adminSection]);

  useEffect(() => {
    if (selectedAcademicYear) {
      writeSessionValue(NAV_STATE_KEYS.selectedYear, selectedAcademicYear);
    }
  }, [selectedAcademicYear]);

  useEffect(() => {
    writeSessionValue(NAV_STATE_KEYS.teacherMode, teacherMode);
  }, [teacherMode]);

  useEffect(() => {
    writeSessionValue(NAV_STATE_KEYS.subjectSubTab, subjectSubTab);
  }, [subjectSubTab]);

  useEffect(() => {
    writeSessionValue(NAV_STATE_KEYS.ctSubTab, ctSubTab);
  }, [ctSubTab]);

  const hydrateUserSession = async (loggedInUser: AuthUser) => {
    const seq = ++refreshSeqRef.current;
    setUser(loggedInUser);
    setSessionWarning(null);

    const isAdminUser = Array.isArray(loggedInUser.roles) && loggedInUser.roles.includes('admin');
    const results = await Promise.allSettled([
      apiFetch<SchoolInfo>('/api/school/info'),
      apiFetch<ExaminationRecord[]>('/api/examinations'),
      !isAdminUser
        ? apiFetch<TeacherWorkspaceData>('/api/teacher/workspace')
        : Promise.resolve<TeacherWorkspaceData>({ subjectAssignments: [], classTeacherAssignments: [] }),
    ]);

    if (seq !== refreshSeqRef.current) return;

    const warnings: string[] = [];
    if (results[0].status === 'fulfilled' && results[0].value) {
      const freshInfo = results[0].value;
      setSchoolInfo(freshInfo);
      setSelectedAcademicYear((prev) =>
        pickValidAcademicYear(freshInfo, prev || readSessionValue(NAV_STATE_KEYS.selectedYear, ''))
      );
    } else if (results[0].status === 'rejected') {
      warnings.push(extractErrorMessage(results[0].reason, 'Could not refresh school configuration.'));
    }

    if (results[1].status === 'fulfilled' && Array.isArray(results[1].value)) {
      setExaminations(results[1].value);
    } else if (results[1].status === 'rejected') {
      warnings.push(extractErrorMessage(results[1].reason, 'Could not load examinations list.'));
    }

    if (results[2].status === 'fulfilled' && !isAdminUser) {
      const tw = results[2].value;
      setTeacherData(tw);
      if (tw.classTeacherAssignments.length > 0 && tw.subjectAssignments.length === 0) {
        setTeacherMode('class-teacher');
      } else if (tw.subjectAssignments.length > 0 && tw.classTeacherAssignments.length === 0) {
        setTeacherMode('subject');
      }
    } else if (results[2].status === 'rejected' && !isAdminUser) {
      warnings.push(extractErrorMessage(results[2].reason, 'Could not load teacher assignments.'));
    }

    if (warnings.length > 0) {
      setSessionWarning(warnings.join(' '));
    }
  };

  const loadSchoolAndAuth = async () => {
    setInitializing(true);
    setInitError(null);
    try {
      const info = await apiFetch<SchoolInfo>('/api/school/info');
      if (!info || typeof info !== 'object' || !Array.isArray(info.classes)) {
        throw new Error('Server returned invalid school configuration data.');
      }
      setSchoolInfo(info);
      setSelectedAcademicYear((prev) =>
        pickValidAcademicYear(info, prev || readSessionValue(NAV_STATE_KEYS.selectedYear, ''))
      );

      try {
        const me = await apiFetch<{ user: AuthUser }>('/api/auth/me');
        if (me?.user) {
          await hydrateUserSession(me.user);
        } else {
          setUser(null);
        }
      } catch {
        setStoredToken(null);
        setUser(null);
      }
    } catch (err: unknown) {
      setSchoolInfo(null);
      setInitError(
        extractErrorMessage(err, 'Unable to connect to the School Examination Portal server.')
      );
    } finally {
      setInitializing(false);
    }
  };

  const refreshSchoolData = async (nextSelectedYear?: string) => {
    const seq = ++refreshSeqRef.current;
    const isAdminUser = Boolean(user && Array.isArray(user.roles) && user.roles.includes('admin'));
    try {
      const results = await Promise.allSettled([
        apiFetch<SchoolInfo>('/api/school/info'),
        apiFetch<ExaminationRecord[]>('/api/examinations'),
        user && !isAdminUser
          ? apiFetch<TeacherWorkspaceData>('/api/teacher/workspace')
          : Promise.resolve(null),
      ]);

      if (seq !== refreshSeqRef.current) return;

      const warnings: string[] = [];
      let latestInfo: SchoolInfo | null = null;

      if (results[0].status === 'fulfilled' && results[0].value) {
        latestInfo = results[0].value;
        setSchoolInfo(latestInfo);
        if (nextSelectedYear) {
          setSelectedAcademicYear(pickValidAcademicYear(latestInfo, nextSelectedYear));
        } else {
          setSelectedAcademicYear((prev) => pickValidAcademicYear(latestInfo!, prev));
        }
      } else if (results[0].status === 'rejected') {
        warnings.push(extractErrorMessage(results[0].reason, 'Could not refresh school configuration.'));
      }

      if (results[1].status === 'fulfilled' && Array.isArray(results[1].value)) {
        setExaminations(results[1].value);
      } else if (results[1].status === 'rejected') {
        warnings.push(extractErrorMessage(results[1].reason, 'Could not refresh examinations.'));
      }

      if (user && !isAdminUser) {
        if (results[2].status === 'fulfilled' && results[2].value) {
          setTeacherData(results[2].value);
        } else if (results[2].status === 'rejected') {
          warnings.push(extractErrorMessage(results[2].reason, 'Could not refresh teacher assignments.'));
        }
      }

      setSessionWarning(warnings.length > 0 ? warnings.join(' ') : null);
    } catch (err: unknown) {
      if (seq === refreshSeqRef.current) {
        setSessionWarning(extractErrorMessage(err, 'Could not refresh portal data.'));
      }
    }
  };

  useEffect(() => {
    loadSchoolAndAuth();
  }, []);

  useEffect(() => {
    if (!schoolInfo) return;
    const root = document.documentElement;
    if (schoolInfo.themeConfig?.primaryColor) {
      root.style.setProperty('--brand-primary', schoolInfo.themeConfig.primaryColor);
    }
    if (schoolInfo.themeConfig?.accentColor) {
      root.style.setProperty('--brand-accent', schoolInfo.themeConfig.accentColor);
    }
    if (schoolInfo.themeConfig?.secondaryColor) {
      root.style.setProperty('--brand-secondary', schoolInfo.themeConfig.secondaryColor);
    }
    const title = `${schoolInfo.schoolName || 'EMRS Gangyap'} — ${
      schoolInfo.siteContent?.portalTitle || 'Examination & Marks Portal'
    }`;
    document.title = title;
  }, [schoolInfo]);

  const handleLogout = async () => {
    try {
      await apiFetch('/api/auth/logout', { method: 'POST' });
    } catch {
      // ignore
    }
    setStoredToken(null);
    setUser(null);
    setExaminations([]);
    setTeacherData({ subjectAssignments: [], classTeacherAssignments: [] });
    setAdminSection('overview');
    setSelectedAcademicYear('');
    setSessionWarning(null);
    setMobileMenuOpen(false);
    Object.values(NAV_STATE_KEYS).forEach((k) => writeSessionValue(k, null));
  };

  const handleChangePassword = async (e: React.FormEvent) => {
    e.preventDefault();
    setPassFeedback(null);
    try {
      await apiFetch('/api/auth/change-password', {
        method: 'POST',
        body: JSON.stringify(passForm),
      });
      setChangePassOpen(false);
      setPassForm({ currentPassword: '', newPassword: '' });
      if (user) setUser({ ...user, mustChangePassword: false });
    } catch (err: any) {
      setPassFeedback(err.message);
    }
  };

  if (initializing) {
    return (
      <div className="min-h-screen min-h-[100dvh] flex flex-col items-center justify-center bg-slate-50 px-4 text-center gap-3">
        <div className="w-8 h-8 rounded-full border-3 border-slate-200 border-t-sky-600 animate-spin" />
        <div className="text-sm font-medium text-slate-600">
          Loading {schoolInfo?.schoolName || 'School Examination Portal'}...
        </div>
      </div>
    );
  }

  if (initError || !schoolInfo) {
    return (
      <div className="min-h-screen min-h-[100dvh] flex items-center justify-center bg-slate-50 px-4">
        <div className="max-w-md w-full bg-white border border-red-200 rounded-2xl shadow-sm p-6 space-y-4">
          <div className="space-y-1">
            <h1 className="text-base font-bold text-slate-900">Unable to Open School Portal</h1>
            <p className="text-xs text-red-700 bg-red-50 border border-red-100 rounded-lg p-3 leading-relaxed">
              {initError || 'School configuration could not be loaded from the server.'}
            </p>
          </div>
          <div className="flex flex-wrap items-center gap-2">
            <button
              type="button"
              onClick={loadSchoolAndAuth}
              className="px-4 py-2 text-xs font-semibold text-white bg-sky-700 hover:bg-sky-800 rounded-lg transition-colors cursor-pointer"
            >
              Retry Connection
            </button>
            <button
              type="button"
              onClick={() => window.location.reload()}
              className="px-4 py-2 text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors cursor-pointer"
            >
              Reload Page
            </button>
          </div>
        </div>
      </div>
    );
  }

  if (!user) {
    return <LoginView schoolInfo={schoolInfo} onLoginSuccess={hydrateUserSession} />;
  }

  const isAdmin = user.roles.includes('admin');
  const effectiveAcademicYear = selectedAcademicYear || schoolInfo.currentAcademicYear;
  const isViewingArchivedYear = isAdmin && effectiveAcademicYear !== schoolInfo.currentAcademicYear;
  const academicYearList =
    schoolInfo.academicYears && schoolInfo.academicYears.length > 0
      ? schoolInfo.academicYears
      : [
          {
            name: schoolInfo.currentAcademicYear,
            isCurrent: true,
            studentCount: 0,
            graduatedCount: 0,
            examCount: 0,
            assignmentCount: 0,
          },
        ];
  const hasSubjectAssignments = teacherData.subjectAssignments.length > 0;
  const hasClassTeacherAssignments = teacherData.classTeacherAssignments.length > 0;

  const sectionIcons: Record<string, React.ReactNode> = {
    overview: <LayoutDashboard className="w-4 h-4 shrink-0" />,
    students: <GraduationCap className="w-4 h-4 shrink-0" />,
    users: <Users className="w-4 h-4 shrink-0" />,
    'classes-subjects': <BookOpen className="w-4 h-4 shrink-0" />,
    'teacher-assignments': <UserCheck className="w-4 h-4 shrink-0" />,
    examinations: <Calendar className="w-4 h-4 shrink-0" />,
    monitoring: <ClipboardCheck className="w-4 h-4 shrink-0" />,
    results: <BarChart3 className="w-4 h-4 shrink-0" />,
    'audit-logs': <ShieldAlert className="w-4 h-4 shrink-0" />,
    settings: <Settings className="w-4 h-4 shrink-0" />,
  };

  const configuredSections = (schoolInfo.portalSections || [])
    .filter((s) => s.enabled)
    .sort((a, b) => a.order - b.order);

  const adminNavItems: Array<{ id: AdminSection; label: string; icon: React.ReactNode }> =
    configuredSections.length > 0
      ? configuredSections.map((s) => ({
          id: s.id as AdminSection,
          label: s.label,
          icon: sectionIcons[s.id] || <FileText className="w-4 h-4 shrink-0" />,
        }))
      : [
          { id: 'overview', label: 'Dashboard Analytics', icon: sectionIcons.overview },
          { id: 'settings', label: 'Website & System Settings', icon: sectionIcons.settings },
        ];

  const primaryColor = schoolInfo.themeConfig?.primaryColor || '#1E3A5F';
  const settingsVisibleInNav = adminNavItems.some((i) => i.id === 'settings');

  const classTeacherSectionOptions = teacherData.classTeacherAssignments.map((ct) => ({
    classId: ct.class_id,
    className: ct.class_name,
    hasSections: ct.has_sections !== 0 && ct.has_sections !== false,
    sectionId: ct.section_id,
    sectionName: ct.section_name,
  }));

  const SidebarContent = (
    <div className="flex flex-col h-full bg-white border-r border-slate-200">
      {/* Brand Block */}
      <div className="p-4 border-b border-slate-200 flex items-center gap-3">
        <SchoolLogo
          src={schoolInfo.schoolLogo}
          alt={schoolInfo.schoolName}
          className="w-10 h-10 object-contain rounded-lg border border-slate-200 p-0.5 shrink-0 bg-white"
        />
        <div className="min-w-0">
          <div className="text-sm font-bold text-slate-900 truncate font-display">
            {schoolInfo.schoolName}
          </div>
          <div className="text-[11px] text-slate-500 font-mono">
            AY {isAdmin ? effectiveAcademicYear : schoolInfo.currentAcademicYear}
          </div>
        </div>
      </div>

      {/* Navigation Links */}
      <nav className="flex-1 overflow-y-auto p-3 space-y-1">
        {isAdmin ? (
          <>
            <div className="px-2.5 py-1.5 text-[11px] font-semibold text-slate-400">Administration</div>
            {adminNavItems.map((item) => {
              const active = adminSection === item.id;
              return (
                <button
                  key={item.id}
                  type="button"
                  onClick={() => {
                    setAdminSection(item.id);
                    setMobileMenuOpen(false);
                  }}
                  style={active ? { backgroundColor: primaryColor } : undefined}
                  className={`w-full min-h-[42px] flex items-center gap-2.5 px-3 py-2 text-xs font-medium rounded-lg transition-colors whitespace-nowrap cursor-pointer ${
                    active
                      ? 'text-white shadow-xs'
                      : 'text-slate-700 hover:bg-slate-100 hover:text-slate-900'
                  }`}
                >
                  {item.icon}
                  <span className="truncate">{item.label}</span>
                </button>
              );
            })}
            {!settingsVisibleInNav && (
              <button
                type="button"
                onClick={() => {
                  setAdminSection('settings');
                  setMobileMenuOpen(false);
                }}
                className="w-full min-h-[42px] flex items-center gap-2.5 px-3 py-2 text-xs font-medium rounded-lg text-slate-500 hover:bg-slate-100 hover:text-slate-900 mt-2 border-t border-slate-100 pt-2.5 cursor-pointer"
              >
                <Settings className="w-4 h-4 shrink-0" />
                <span className="truncate">Restore Sections / Settings</span>
              </button>
            )}
          </>
        ) : (
          <>
            {hasSubjectAssignments && (
              <div className="space-y-1">
                <div className="px-2.5 py-1.5 text-[11px] font-semibold text-slate-400">
                  Subject Teacher
                </div>
                <button
                  type="button"
                  onClick={() => {
                    setTeacherMode('subject');
                    setSubjectSubTab('entry');
                    setMobileMenuOpen(false);
                  }}
                  className={`w-full min-h-[42px] flex items-center gap-2.5 px-3 py-2 text-xs font-medium rounded-lg transition-colors cursor-pointer ${
                    teacherMode === 'subject' && subjectSubTab === 'entry'
                      ? 'bg-[#1E3A5F] text-white'
                      : 'text-slate-700 hover:bg-slate-100'
                  }`}
                >
                  <ClipboardList className="w-4 h-4" />
                  Enter &amp; Submit Marks
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setTeacherMode('subject');
                    setSubjectSubTab('assignments');
                    setMobileMenuOpen(false);
                  }}
                  className={`w-full min-h-[42px] flex items-center gap-2.5 px-3 py-2 text-xs font-medium rounded-lg transition-colors cursor-pointer ${
                    teacherMode === 'subject' && subjectSubTab === 'assignments'
                      ? 'bg-[#1E3A5F] text-white'
                      : 'text-slate-700 hover:bg-slate-100'
                  }`}
                >
                  <BookOpen className="w-4 h-4" />
                  My Assigned Subjects
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setTeacherMode('subject');
                    setSubjectSubTab('history');
                    setMobileMenuOpen(false);
                  }}
                  className={`w-full min-h-[42px] flex items-center gap-2.5 px-3 py-2 text-xs font-medium rounded-lg transition-colors cursor-pointer ${
                    teacherMode === 'subject' && subjectSubTab === 'history'
                      ? 'bg-[#1E3A5F] text-white'
                      : 'text-slate-700 hover:bg-slate-100'
                  }`}
                >
                  <ClipboardCheck className="w-4 h-4" />
                  Submission History
                </button>
              </div>
            )}

            {hasClassTeacherAssignments && (
              <div className="space-y-1 pt-3">
                <div className="px-2.5 py-1.5 text-[11px] font-semibold text-slate-400">
                  Class Teacher (
                  {teacherData.classTeacherAssignments
                    .map((c) =>
                      formatClassSectionLabel(
                        c.class_name,
                        c.section_name,
                        c.has_sections !== 0 && c.has_sections !== false
                      )
                    )
                    .join(', ')}
                  )
                </div>
                <button
                  type="button"
                  onClick={() => {
                    setTeacherMode('class-teacher');
                    setCtSubTab('consolidated');
                    setMobileMenuOpen(false);
                  }}
                  className={`w-full min-h-[42px] flex items-center gap-2.5 px-3 py-2 text-xs font-medium rounded-lg transition-colors cursor-pointer ${
                    teacherMode === 'class-teacher' && ctSubTab === 'consolidated'
                      ? 'bg-[#1E3A5F] text-white'
                      : 'text-slate-700 hover:bg-slate-100'
                  }`}
                >
                  <Layers className="w-4 h-4" />
                  Consolidated Marks
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setTeacherMode('class-teacher');
                    setCtSubTab('students');
                    setMobileMenuOpen(false);
                  }}
                  className={`w-full min-h-[42px] flex items-center gap-2.5 px-3 py-2 text-xs font-medium rounded-lg transition-colors cursor-pointer ${
                    teacherMode === 'class-teacher' && ctSubTab === 'students'
                      ? 'bg-[#1E3A5F] text-white'
                      : 'text-slate-700 hover:bg-slate-100'
                  }`}
                >
                  <GraduationCap className="w-4 h-4" />
                  Student Mark Sheets
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setTeacherMode('class-teacher');
                    setCtSubTab('student-details');
                    setMobileMenuOpen(false);
                  }}
                  className={`w-full min-h-[42px] flex items-center gap-2.5 px-3 py-2 text-xs font-medium rounded-lg transition-colors cursor-pointer ${
                    teacherMode === 'class-teacher' && ctSubTab === 'student-details'
                      ? 'bg-[#1E3A5F] text-white'
                      : 'text-slate-700 hover:bg-slate-100'
                  }`}
                >
                  <UserRound className="w-4 h-4" />
                  Student Details
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setTeacherMode('class-teacher');
                    setCtSubTab('co-scholastic');
                    setMobileMenuOpen(false);
                  }}
                  className={`w-full min-h-[42px] flex items-center gap-2.5 px-3 py-2 text-xs font-medium rounded-lg transition-colors cursor-pointer ${
                    teacherMode === 'class-teacher' && ctSubTab === 'co-scholastic'
                      ? 'bg-[#1E3A5F] text-white'
                      : 'text-slate-700 hover:bg-slate-100'
                  }`}
                >
                  <ClipboardCheck className="w-4 h-4" />
                  Co-Scholastic Grades
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setTeacherMode('class-teacher');
                    setCtSubTab('analysis');
                    setMobileMenuOpen(false);
                  }}
                  className={`w-full min-h-[42px] flex items-center gap-2.5 px-3 py-2 text-xs font-medium rounded-lg transition-colors cursor-pointer ${
                    teacherMode === 'class-teacher' && ctSubTab === 'analysis'
                      ? 'bg-[#1E3A5F] text-white'
                      : 'text-slate-700 hover:bg-slate-100'
                  }`}
                >
                  <BarChart3 className="w-4 h-4" />
                  Performance Analysis
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setTeacherMode('class-teacher');
                    setCtSubTab('comparison');
                    setMobileMenuOpen(false);
                  }}
                  className={`w-full min-h-[42px] flex items-center gap-2.5 px-3 py-2 text-xs font-medium rounded-lg transition-colors cursor-pointer ${
                    teacherMode === 'class-teacher' && ctSubTab === 'comparison'
                      ? 'bg-[#1E3A5F] text-white'
                      : 'text-slate-700 hover:bg-slate-100'
                  }`}
                >
                  <Calendar className="w-4 h-4" />
                  Exam Comparison
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setTeacherMode('class-teacher');
                    setCtSubTab('promotion');
                    setMobileMenuOpen(false);
                  }}
                  className={`w-full min-h-[42px] flex items-center gap-2.5 px-3 py-2 text-xs font-medium rounded-lg transition-colors cursor-pointer ${
                    teacherMode === 'class-teacher' && ctSubTab === 'promotion'
                      ? 'bg-[#1E3A5F] text-white'
                      : 'text-slate-700 hover:bg-slate-100'
                  }`}
                >
                  <GraduationCap className="w-4 h-4" />
                  Promote Students
                </button>
              </div>
            )}
          </>
        )}
      </nav>

      {/* Account Footer */}
      <div className="p-3 border-t border-slate-200 space-y-2 bg-slate-50/70">
        <div className="px-2">
          <div className="text-xs font-semibold text-slate-900 truncate">{user.fullName}</div>
          <div className="text-[11px] text-slate-500">
            {isAdmin
              ? 'Administrator'
              : [
                  hasClassTeacherAssignments ? 'Class Teacher' : '',
                  hasSubjectAssignments ? 'Subject Teacher' : '',
                ]
                  .filter(Boolean)
                  .join(' · ')}
          </div>
        </div>
        <div className="flex items-center gap-1.5">
          <button
            type="button"
            onClick={() => setChangePassOpen(true)}
            className="flex-1 min-h-[38px] inline-flex items-center justify-center gap-1 px-2 py-1.5 text-[11px] font-medium text-slate-700 bg-white border border-slate-300 rounded-lg hover:bg-slate-100 cursor-pointer"
          >
            <KeyRound className="w-3 h-3" />
            Password
          </button>
          <button
            type="button"
            onClick={handleLogout}
            className="flex-1 min-h-[38px] inline-flex items-center justify-center gap-1 px-2 py-1.5 text-[11px] font-medium text-red-700 bg-white border border-slate-300 rounded-lg hover:bg-red-50 cursor-pointer"
          >
            <LogOut className="w-3 h-3" />
            Sign Out
          </button>
        </div>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen min-h-[100dvh] bg-slate-50 flex overflow-x-hidden">
      {/* Desktop Sidebar */}
      <aside className="hidden lg:block w-64 shrink-0 sticky top-0 h-screen">{SidebarContent}</aside>

      {/* Mobile & Tablet Drawer Sidebar */}
      {mobileMenuOpen && (
        <div className="fixed inset-0 z-50 lg:hidden flex">
          <div className="w-72 max-w-[85vw] h-full bg-white shadow-xl">{SidebarContent}</div>
          <div className="flex-1 bg-slate-900/40" onClick={() => setMobileMenuOpen(false)} />
        </div>
      )}

      {/* Main Content Shell */}
      <div className="flex-1 min-w-0 flex flex-col">
        {/* Top Institutional Header (compact <= 56px) */}
        <header className="sticky top-0 z-30 bg-white border-b border-slate-200 px-3 sm:px-6 h-14 flex items-center justify-between gap-2 sm:gap-4 no-print">
          <div className="flex items-center gap-2 sm:gap-3 min-w-0">
            <button
              type="button"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="lg:hidden min-w-[44px] min-h-[44px] flex items-center justify-center -ml-1.5 text-slate-700 hover:text-slate-900 rounded-lg hover:bg-slate-100 cursor-pointer"
              aria-label="Toggle navigation menu"
            >
              {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
            <SchoolLogo
              src={schoolInfo.schoolLogo}
              alt={schoolInfo.schoolName}
              className="w-8 h-8 object-contain rounded-md border border-slate-200 p-0.5 shrink-0 bg-white lg:hidden"
            />
            <span className="text-sm font-semibold text-slate-900 truncate lg:hidden">
              {schoolInfo.schoolName}
            </span>
            <span className="hidden lg:inline text-xs text-slate-500">
              {schoolInfo.siteContent?.portalTitle || 'Examination & Marks Portal'} · {isAdmin ? effectiveAcademicYear : schoolInfo.currentAcademicYear}
            </span>
          </div>

          <div className="flex items-center gap-2 sm:gap-3 shrink-0">
            {isAdmin && (
              <div className="flex items-center gap-1.5 sm:gap-2">
                <label htmlFor="admin-ay-select" className="hidden md:inline text-[11px] font-semibold text-slate-500">
                  Academic Year:
                </label>
                <select
                  id="admin-ay-select"
                  value={effectiveAcademicYear}
                  onChange={(e) => setSelectedAcademicYear(e.target.value)}
                  className={`min-h-[36px] px-2 sm:px-2.5 py-1 text-xs font-mono font-semibold rounded-lg border focus:outline-none ${
                    isViewingArchivedYear
                      ? 'bg-amber-50 border-amber-300 text-amber-900'
                      : 'bg-slate-50 border-slate-300 text-slate-800'
                  }`}
                >
                  {academicYearList.map((ay) => (
                    <option key={ay.name} value={ay.name}>
                      {ay.name} {ay.isCurrent ? '(Current)' : '(Archived)'}
                    </option>
                  ))}
                </select>
              </div>
            )}
            {!isAdmin && hasSubjectAssignments && hasClassTeacherAssignments && (
              <div className="hidden sm:flex items-center gap-1 p-1 bg-slate-100 rounded-lg">
                <button
                  type="button"
                  onClick={() => setTeacherMode('subject')}
                  className={`px-2.5 py-1 text-xs font-medium rounded-md transition-colors whitespace-nowrap ${
                    teacherMode === 'subject'
                      ? 'bg-white text-slate-900 shadow-sm'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  Subject Marks Entry
                </button>
                <button
                  type="button"
                  onClick={() => setTeacherMode('class-teacher')}
                  className={`px-2.5 py-1 text-xs font-medium rounded-md transition-colors whitespace-nowrap ${
                    teacherMode === 'class-teacher'
                      ? 'bg-white text-slate-900 shadow-sm'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  Class Teacher View
                </button>
              </div>
            )}
            <div className="hidden sm:block text-xs text-slate-600 whitespace-nowrap">
              Signed in as <span className="font-semibold text-slate-900">{user.fullName}</span>
            </div>
          </div>
        </header>

        {/* Workspace Viewport */}
        <main className="flex-1 min-w-0 p-3 sm:p-6 lg:p-8 max-w-7xl w-full mx-auto">
          {sessionWarning && (
            <div className="mb-6 flex flex-wrap items-center justify-between gap-3 p-3.5 bg-red-50 border border-red-200 rounded-xl text-xs text-red-900 no-print">
              <span>{sessionWarning}</span>
              <button
                type="button"
                onClick={() => hydrateUserSession(user)}
                className="px-3 py-1.5 font-semibold bg-red-800 text-white rounded-lg hover:bg-red-900 whitespace-nowrap cursor-pointer"
              >
                Retry Loading Data
              </button>
            </div>
          )}
          {isAdmin && schoolInfo.storageMode === 'ephemeral-serverless' && (
            <div className="mb-6 p-3.5 bg-amber-50 border border-amber-300 rounded-xl text-xs text-amber-950 no-print leading-relaxed">
              <span className="font-bold">Ephemeral Serverless Storage Warning:</span>{' '}
              This Vercel deployment is using local container <code className="font-mono">/tmp/school.db</code> without external sync, which can cause newly added students or teachers to split across serverless instances or reset. Configure{' '}
              <code className="font-mono font-semibold">KV_REST_API_URL</code> &amp;{' '}
              <code className="font-mono font-semibold">KV_REST_API_TOKEN</code> (Vercel KV / Upstash Redis) in project environment variables or run on a persistent Node host for instant cross-instance sync.
            </div>
          )}
          {isViewingArchivedYear && (
            <div className="mb-6 flex flex-wrap items-center justify-between gap-3 p-3.5 bg-amber-50 border border-amber-200 rounded-xl text-xs text-amber-950 no-print">
              <div>
                <span className="font-bold font-mono">Archived Academic Year ({effectiveAcademicYear}):</span>{' '}
                Viewing historical student records, teacher assignments, examinations, and consolidated results.
                Current active session is <span className="font-mono font-semibold">{schoolInfo.currentAcademicYear}</span>.
              </div>
              <button
                type="button"
                onClick={() => setSelectedAcademicYear(schoolInfo.currentAcademicYear)}
                className="px-3 py-1.5 font-semibold bg-amber-900 text-white rounded-lg hover:bg-amber-950 whitespace-nowrap"
              >
                Return to {schoolInfo.currentAcademicYear}
              </button>
            </div>
          )}

          {user.mustChangePassword && (
            <div className="mb-6 flex flex-wrap items-center justify-between gap-3 p-3.5 bg-amber-50 border border-amber-200 rounded-xl text-xs text-amber-900">
              <span>
                You are currently using a temporary password assigned by the administrator. Please set a personal
                password.
              </span>
              <button
                type="button"
                onClick={() => setChangePassOpen(true)}
                className="px-3 py-1 font-semibold bg-amber-900 text-white rounded-lg"
              >
                Update Password
              </button>
            </div>
          )}

          {isAdmin ? (
            <AdminDashboard
              activeSection={adminSection}
              onNavigate={setAdminSection}
              schoolInfo={schoolInfo}
              examinations={examinations}
              selectedAcademicYear={effectiveAcademicYear}
              onSelectAcademicYear={setSelectedAcademicYear}
              onRefreshSchoolData={refreshSchoolData}
            />
          ) : teacherMode === 'class-teacher' && hasClassTeacherAssignments ? (
            <ClassTeacherWorkspace
              allowedSections={classTeacherSectionOptions}
              classTeacherAssignments={teacherData.classTeacherAssignments}
              examinations={examinations}
              schoolInfo={schoolInfo}
              activeTab={ctSubTab}
              onTabChange={setCtSubTab}
              onPromotionChanged={() => refreshSchoolData()}
            />
          ) : (
            <TeacherMarksWorkspace
              assignments={teacherData.subjectAssignments}
              examinations={examinations}
              activeSubTab={subjectSubTab}
              onSubTabChange={setSubjectSubTab}
            />
          )}
        </main>
      </div>

      {/* Change Password Modal */}
      {changePassOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/50 p-4">
          <form
            onSubmit={handleChangePassword}
            className="bg-white border border-slate-200 rounded-xl w-full max-w-sm p-6 space-y-4 shadow-xl text-xs"
          >
            <h3 className="text-base font-bold text-slate-900">Change Account Password</h3>
            {passFeedback && (
              <div className="p-2.5 bg-red-50 border border-red-200 rounded text-red-800">{passFeedback}</div>
            )}
            <div>
              <label className="block font-semibold text-slate-700 mb-1">Current Password</label>
              <input
                type="password"
                required
                value={passForm.currentPassword}
                onChange={(e) => setPassForm({ ...passForm, currentPassword: e.target.value })}
                className="w-full px-3 py-2 border border-slate-300 rounded-lg"
              />
            </div>
            <div>
              <label className="block font-semibold text-slate-700 mb-1">New Password (min 6 chars)</label>
              <input
                type="password"
                required
                minLength={6}
                value={passForm.newPassword}
                onChange={(e) => setPassForm({ ...passForm, newPassword: e.target.value })}
                className="w-full px-3 py-2 border border-slate-300 rounded-lg"
              />
            </div>
            <div className="flex justify-end gap-2">
              <button
                type="button"
                onClick={() => setChangePassOpen(false)}
                className="px-3.5 py-2 border border-slate-300 rounded-lg"
              >
                Cancel
              </button>
              <button type="submit" className="px-4 py-2 font-semibold text-white bg-[#1E3A5F] rounded-lg">
                Save Password
              </button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
}
