import { db } from '../db/database.ts';
import {
  STANDARD_GRADING_SCALE,
  calculateGradeFromPercentage,
  calculateSubjectGrade,
  doesSubjectApplyToClass,
} from '../lib/grading.ts';
import {
  type CoScholasticGrade,
  CO_SCHOLASTIC_ITEM_KEYS,
  isValidCoScholasticGrade,
  summarizeCoScholasticGrades,
} from '../lib/coScholastic.ts';

export interface GradeRule {
  grade: string;
  minPct: number;
  maxPct: number;
  remark: string;
}

export type ComponentMode = 'single' | 'combined' | 'elective';

export type AttendanceStatus = 'present' | 'absent' | 'pending';

export interface ConsolidatedComponentResult {
  examComponentId: number;
  componentId: number;
  componentName: string;
  maxMarks: number;
  passingMarks: number;
  obtainedMarks: number | null;
  attendanceStatus: AttendanceStatus;
  status: 'submitted' | 'draft' | 'pending';
}

export interface ConsolidatedSubjectResult {
  examSubjectId: number;
  subjectId: number;
  subjectCode: string;
  subjectName: string;
  hasComponents: boolean;
  componentMode: ComponentMode;
  selectedComponentName?: string | null;
  hasInternalAssessment: boolean;
  hasPractical?: boolean;
  streamCategory?: string;
  isEnrolled?: boolean;
  writtenMaxMarks: number;
  writtenObtainedMarks: number | null;
  iaNotebookMax: number;
  iaUnitTestMax: number;
  iaPracticalMax: number;
  iaParticipationMax: number;
  iaMaxMarks: number;
  iaNotebookMarks: number | null;
  iaUnitTestMarks: number | null;
  iaPracticalMarks: number | null;
  iaParticipationMarks: number | null;
  iaTotalMarks: number | null;
  iaStatus: 'submitted' | 'draft' | 'pending' | 'na';
  maxMarks: number;
  passingMarks: number;
  isRequired: boolean;
  obtainedMarks: number | null;
  submittedSubtotal: number;
  isComplete: boolean;
  isPassed: boolean | null;
  grade: string | null;
  gradeRemark?: string | null;
  gradeStatus?: 'graded' | 'absent' | 'pending' | 'not_submitted' | 'not_applicable';
  components: ConsolidatedComponentResult[];
}

export interface StudentCoScholasticData {
  term1: Record<string, CoScholasticGrade>;
  term2: Record<string, CoScholasticGrade>;
  term1TotalPoints: number | null;
  term2TotalPoints: number | null;
}

export interface CoScholasticTermMeta {
  examinationId: number;
  examinationName: string;
  academicYear: string;
  eligible: boolean;
  term: 1 | 2 | null;
  termLabel: 'Grade Term I' | 'Grade Term II' | null;
  reason: string;
  eligibleExams: Array<{
    id: number;
    name: string;
    term: 1 | 2;
    termLabel: 'Grade Term I' | 'Grade Term II';
  }>;
}

export interface TermAttendanceRemark {
  daysAttended: number | null;
  totalDays: number | null;
  remarks: string;
}

export interface StudentTermData {
  term1: TermAttendanceRemark;
  term2: TermAttendanceRemark;
  totalDaysAttended: number | null;
  totalWorkingDays: number | null;
}

export interface StudentExtendedProfile {
  fatherName: string;
  motherName: string;
  residentialAddress: string;
  contactNo: string;
  aapaarId: string;
  photoUrl: string;
}

export interface ConsolidatedStudentResult {
  studentId: number;
  studentCode: string;
  studentName: string;
  rollNumber: number;
  classId: number;
  className: string;
  hasSections?: boolean;
  sectionId: number;
  sectionName: string;
  stream?: '' | 'Science' | 'Humanities';
  fatherName?: string;
  motherName?: string;
  residentialAddress?: string;
  contactNo?: string;
  aapaarId?: string;
  photoUrl?: string;
  subjects: ConsolidatedSubjectResult[];
  grandTotal: number | null;
  totalMaxMarks: number;
  percentage: number | null;
  grade: string | null;
  gradeRemark: string | null;
  resultStatus: 'Pass' | 'Fail' | 'Incomplete';
  classRank: number | null;
  missingComponents: string[];
  coScholastic?: StudentCoScholasticData;
  termRecords?: StudentTermData;
}

export interface CombinedTermSubjectRow {
  subjectId: number;
  subjectCode: string;
  subjectName: string;
  componentMode: ComponentMode;
  term1: ConsolidatedSubjectResult | null;
  term2: ConsolidatedSubjectResult | null;
  averageMarks: number | null;
  combinedObtainedMarks: number | null;
  combinedMaxMarks: number;
  combinedGrade: string | null;
  combinedPassed: boolean | null;
}

export interface CombinedTermSummary {
  examinationId: number;
  examinationName: string;
  grandTotal: number | null;
  totalMaxMarks: number;
  percentage: number | null;
  grade: string | null;
  gradeRemark: string | null;
  resultStatus: 'Pass' | 'Fail' | 'Incomplete';
  classRank: number | null;
  missingComponents: string[];
}

export interface CombinedTermStudentResult {
  studentId: number;
  studentCode: string;
  studentName: string;
  rollNumber: number;
  classId: number;
  className: string;
  hasSections?: boolean;
  sectionId: number;
  sectionName: string;
  stream?: '' | 'Science' | 'Humanities';
  fatherName?: string;
  motherName?: string;
  residentialAddress?: string;
  contactNo?: string;
  aapaarId?: string;
  photoUrl?: string;
  subjects: CombinedTermSubjectRow[];
  term1Summary: CombinedTermSummary | null;
  term2Summary: CombinedTermSummary | null;
  overall: {
    combinedTotal: number | null;
    combinedMaxMarks: number;
    averageObtained: number | null;
    averageMaxMarks: number | null;
    finalPercentage: number | null;
    finalGrade: string | null;
    finalGradeRemark: string | null;
    resultStatus: 'Pass' | 'Fail' | 'Incomplete';
  };
  termRecords: StudentTermData;
  coScholastic: StudentCoScholasticData;
}

export interface CombinedTermClassReport {
  academicYear: string;
  classInfo: ConsolidatedClassReport['classInfo'];
  gradingScale: GradeRule[];
  term1Exam: ConsolidatedClassReport['examination'] | null;
  term2Exam: ConsolidatedClassReport['examination'] | null;
  term1Report: ConsolidatedClassReport | null;
  term2Report: ConsolidatedClassReport | null;
  students: CombinedTermStudentResult[];
}

export interface SubjectPerformanceStat {
  subjectId: number;
  subjectName: string;
  subjectCode: string;
  maxMarks: number;
  averageMarks: number | null;
  averagePercentage: number | null;
  highestMarks: number | null;
  lowestMarks: number | null;
  completedStudents: number;
  passedStudents: number;
  passRate: number | null;
}

export interface ConsolidatedClassReport {
  examination: {
    id: number;
    name: string;
    academicYear: string;
    startDate: string;
    endDate: string;
    status: string;
    marksEntryOpen: boolean;
    passingPercentage: number;
  };
  classInfo: {
    classId: number;
    className: string;
    hasSections?: boolean;
    sectionId: number;
    sectionName: string;
    classTeacherName: string | null;
    resultDate?: string | null;
  };
  gradingScale: GradeRule[];
  subjects: Array<{
    examSubjectId: number;
    subjectId: number;
    subjectCode: string;
    subjectName: string;
    hasComponents: boolean;
    componentMode: ComponentMode;
    hasInternalAssessment: boolean;
    hasPractical?: boolean;
    streamCategory?: string;
    writtenMaxMarks: number;
    iaNotebookMax: number;
    iaUnitTestMax: number;
    iaPracticalMax: number;
    iaParticipationMax: number;
    iaMaxMarks: number;
    maxMarks: number;
    passingMarks: number;
    isRequired: boolean;
    components: Array<{
      examComponentId: number;
      componentId: number;
      componentName: string;
      maxMarks: number;
      passingMarks: number;
    }>;
  }>;
  students: ConsolidatedStudentResult[];
  summary: {
    totalStudents: number;
    completedCount: number;
    incompleteCount: number;
    passCount: number;
    failCount: number;
    highestTotal: number | null;
    lowestTotal: number | null;
    classAverageTotal: number | null;
    classAveragePercentage: number | null;
    totalMaxMarks: number;
  };
  subjectPerformance: SubjectPerformanceStat[];
  coScholasticMeta?: CoScholasticTermMeta & {
    hasAnyGradesForYear: boolean;
  };
}

export function getStudentExtendedProfilesMap(studentIds: number[]): Map<number, StudentExtendedProfile> {
  const map = new Map<number, StudentExtendedProfile>();
  if (studentIds.length === 0) return map;
  const uniqueIds = Array.from(new Set(studentIds));
  const ph = uniqueIds.map(() => '?').join(',');
  const rows = db
    .prepare(
      `SELECT id,
              COALESCE(father_name, '') as father_name,
              COALESCE(mother_name, '') as mother_name,
              COALESCE(residential_address, '') as residential_address,
              COALESCE(NULLIF(contact_no, ''), guardian_phone, '') as contact_no,
              COALESCE(aapaar_id, '') as aapaar_id,
              COALESCE(photo_url, '') as photo_url
       FROM students
       WHERE id IN (${ph})`
    )
    .all(...uniqueIds) as Array<{
    id: number;
    father_name: string;
    mother_name: string;
    residential_address: string;
    contact_no: string;
    aapaar_id: string;
    photo_url: string;
  }>;
  for (const r of rows) {
    map.set(r.id, {
      fatherName: r.father_name || '',
      motherName: r.mother_name || '',
      residentialAddress: r.residential_address || '',
      contactNo: r.contact_no || '',
      aapaarId: r.aapaar_id || '',
      photoUrl: r.photo_url || '',
    });
  }
  return map;
}

export function getClassResultDate(
  classId: number,
  sectionId: number,
  academicYear: string
): string | null {
  if (!classId || !sectionId || !academicYear) return null;
  const row = db
    .prepare(
      `SELECT COALESCE(result_date, '') as result_date
       FROM class_result_dates
       WHERE class_id = ? AND section_id = ? AND academic_year = ?`
    )
    .get(classId, sectionId, academicYear) as { result_date: string } | undefined;
  const val = (row?.result_date || '').trim();
  return val ? val : null;
}

export function createEmptyTermData(): StudentTermData {
  return {
    term1: { daysAttended: null, totalDays: null, remarks: '' },
    term2: { daysAttended: null, totalDays: null, remarks: '' },
    totalDaysAttended: null,
    totalWorkingDays: null,
  };
}

export function getStudentTermRecordsMap(academicYear: string, studentIds: number[]): Map<number, StudentTermData> {
  const map = new Map<number, StudentTermData>();
  if (!academicYear || studentIds.length === 0) return map;
  const idSet = new Set(studentIds);
  const rows = db
    .prepare(
      `SELECT student_id, term, days_attended, total_days, COALESCE(remarks, '') as remarks
       FROM student_term_records
       WHERE academic_year = ?`
    )
    .all(academicYear) as Array<{
    student_id: number;
    term: number;
    days_attended: number | null;
    total_days: number | null;
    remarks: string;
  }>;

  const grouped = new Map<number, { t1?: (typeof rows)[number]; t2?: (typeof rows)[number] }>();
  for (const r of rows) {
    if (!idSet.has(r.student_id)) continue;
    let entry = grouped.get(r.student_id);
    if (!entry) {
      entry = {};
      grouped.set(r.student_id, entry);
    }
    if (r.term === 1) entry.t1 = r;
    else if (r.term === 2) entry.t2 = r;
  }

  for (const [sid, entry] of grouped.entries()) {
    const t1Att = entry.t1?.days_attended ?? null;
    const t1Tot = entry.t1?.total_days ?? null;
    const t2Att = entry.t2?.days_attended ?? null;
    const t2Tot = entry.t2?.total_days ?? null;
    map.set(sid, {
      term1: {
        daysAttended: t1Att,
        totalDays: t1Tot,
        remarks: entry.t1?.remarks || '',
      },
      term2: {
        daysAttended: t2Att,
        totalDays: t2Tot,
        remarks: entry.t2?.remarks || '',
      },
      totalDaysAttended: t1Att !== null || t2Att !== null ? (t1Att ?? 0) + (t2Att ?? 0) : null,
      totalWorkingDays: t1Tot !== null || t2Tot !== null ? (t1Tot ?? 0) + (t2Tot ?? 0) : null,
    });
  }
  return map;
}

export function resolveYearTermExams(academicYear: string): {
  yearExams: Array<{
    id: number;
    name: string;
    academic_year: string;
    exam_type: string;
    start_date: string;
    sub_count: number;
    max_sub_total: number;
  }>;
  assignedByExamId: Map<number, 1 | 2>;
  term1ExamId: number | null;
  term2ExamId: number | null;
  eligibleExams: Array<{
    id: number;
    name: string;
    term: 1 | 2;
    termLabel: 'Grade Term I' | 'Grade Term II';
  }>;
} {
  const yearExams = db
    .prepare(
      `SELECT e.id, e.name, e.academic_year, COALESCE(e.exam_type, 'Regular') as exam_type,
              COALESCE(e.start_date, '') as start_date,
              COUNT(es.id) as sub_count,
              COALESCE(MAX(es.max_marks + CASE WHEN COALESCE(es.has_internal_assessment, 0) = 1
                THEN COALESCE(es.ia_notebook_max, 0) + COALESCE(es.ia_unit_test_max, 0) +
                     COALESCE(es.ia_practical_max, 0) + COALESCE(es.ia_participation_max, 0)
                ELSE 0 END), 0) as max_sub_total
       FROM examinations e
       LEFT JOIN examination_subjects es ON es.examination_id = e.id
       WHERE e.academic_year = ? AND COALESCE(e.is_deleted, 0) = 0
       GROUP BY e.id
       ORDER BY COALESCE(e.start_date, '') ASC, e.id ASC`
    )
    .all(academicYear) as Array<{
    id: number;
    name: string;
    academic_year: string;
    exam_type: string;
    start_date: string;
    sub_count: number;
    max_sub_total: number;
  }>;

  const explicitTerm1Re = /(half[\s-]?yearly|mid[\s-]?term|1st[\s-]*term|first[\s-]*term|term[\s-]*(i\b|1\b))/i;
  const explicitTerm2Re = /(annual|final|2nd[\s-]*term|second[\s-]*term|term[\s-]*(ii\b|2\b)|year[\s-]*end)/i;
  const unitPeriodicRe = /(unit|periodic|weekly|monthly|class\s*test|quiz|surprise)/i;

  const isExplicitTermExam = (name: string) => explicitTerm1Re.test(name) || explicitTerm2Re.test(name);
  const isCandidateEligible = (row: (typeof yearExams)[number]) => {
    if (row.sub_count <= 0 || row.max_sub_total < 100) return false;
    if (unitPeriodicRe.test(`${row.exam_type} ${row.name}`) && !isExplicitTermExam(row.name)) return false;
    return true;
  };

  const candidates = yearExams.filter(isCandidateEligible);
  const assignedByExamId = new Map<number, 1 | 2>();
  let slot1ExamId: number | null = null;
  let slot2ExamId: number | null = null;

  // Pass 1: honor explicit Term II and Term I naming
  for (const ex of candidates) {
    if (explicitTerm2Re.test(ex.name) && slot2ExamId === null) {
      slot2ExamId = ex.id;
      assignedByExamId.set(ex.id, 2);
    } else if (explicitTerm1Re.test(ex.name) && slot1ExamId === null) {
      slot1ExamId = ex.id;
      assignedByExamId.set(ex.id, 1);
    }
  }

  // Pass 2: fill remaining chronological slots (1st then 2nd 100-mark exam)
  for (const ex of candidates) {
    if (assignedByExamId.has(ex.id)) continue;
    if (slot1ExamId === null) {
      slot1ExamId = ex.id;
      assignedByExamId.set(ex.id, 1);
    } else if (slot2ExamId === null) {
      slot2ExamId = ex.id;
      assignedByExamId.set(ex.id, 2);
    }
  }

  const eligibleExams = candidates
    .filter((ex) => assignedByExamId.has(ex.id))
    .map((ex) => {
      const t = assignedByExamId.get(ex.id)!;
      return {
        id: ex.id,
        name: ex.name,
        term: t,
        termLabel: (t === 1 ? 'Grade Term I' : 'Grade Term II') as 'Grade Term I' | 'Grade Term II',
      };
    });

  return {
    yearExams,
    assignedByExamId,
    term1ExamId: slot1ExamId,
    term2ExamId: slot2ExamId,
    eligibleExams,
  };
}

export function getExamCoScholasticTerm(examinationId: number): CoScholasticTermMeta {
  const target = db
    .prepare(
      `SELECT id, name, academic_year, COALESCE(exam_type, 'Regular') as exam_type, COALESCE(is_deleted, 0) as is_deleted
       FROM examinations WHERE id = ?`
    )
    .get(examinationId) as
    | { id: number; name: string; academic_year: string; exam_type: string; is_deleted: number }
    | undefined;

  if (!target || target.is_deleted) {
    return {
      examinationId,
      examinationName: '',
      academicYear: '',
      eligible: false,
      term: null,
      termLabel: null,
      reason: 'Examination not found.',
      eligibleExams: [],
    };
  }

  const { yearExams, assignedByExamId, eligibleExams } = resolveYearTermExams(target.academic_year);
  const unitPeriodicRe = /(unit|periodic|weekly|monthly|class\s*test|quiz|surprise)/i;

  const targetRow = yearExams.find((ex) => ex.id === examinationId);
  const assignedTerm = assignedByExamId.get(examinationId) ?? null;

  if (assignedTerm) {
    return {
      examinationId: target.id,
      examinationName: target.name,
      academicYear: target.academic_year,
      eligible: true,
      term: assignedTerm,
      termLabel: assignedTerm === 1 ? 'Grade Term I' : 'Grade Term II',
      reason:
        assignedTerm === 1
          ? '1st 100-mark term examination — editing Grade Term I.'
          : '2nd 100-mark term examination — editing Grade Term II.',
      eligibleExams,
    };
  }

  let reason =
    'Co-scholastic & discipline grades can only be entered in the 1st (Term I) and 2nd (Term II) 100-mark term examinations.';
  if (targetRow && (targetRow.sub_count <= 0 || targetRow.max_sub_total < 100)) {
    reason =
      'Only 100-mark term examinations (Half-Yearly / 1st Term and Annual / Final Term) allow co-scholastic & discipline grade entry.';
  } else if (targetRow && unitPeriodicRe.test(`${targetRow.exam_type} ${targetRow.name}`)) {
    reason =
      'Unit / Periodic tests do not include co-scholastic & discipline grades. Select a 100-mark Half-Yearly or Annual term examination.';
  }

  return {
    examinationId: target.id,
    examinationName: target.name,
    academicYear: target.academic_year,
    eligible: false,
    term: null,
    termLabel: null,
    reason,
    eligibleExams,
  };
}

export function getGradingScale(): GradeRule[] {
  const row = db.prepare(`SELECT value FROM system_settings WHERE key = 'grading_scale'`).get() as
    | { value: string }
    | undefined;
  if (!row) {
    return STANDARD_GRADING_SCALE;
  }
  try {
    const parsed = JSON.parse(row.value) as GradeRule[];
    return Array.isArray(parsed) && parsed.length > 0 ? parsed : STANDARD_GRADING_SCALE;
  } catch {
    return STANDARD_GRADING_SCALE;
  }
}

export function calculateGrade(percentage: number, scale: GradeRule[]): { grade: string; remark: string } {
  return calculateGradeFromPercentage(percentage, scale);
}

export function getConsolidatedResults(
  examinationId: number,
  classId: number,
  sectionId: number
): ConsolidatedClassReport {
  const exam = db
    .prepare(
      `SELECT id, name, academic_year, start_date, end_date, status, marks_entry_open, passing_percentage
       FROM examinations WHERE id = ?`
    )
    .get(examinationId) as
    | {
        id: number;
        name: string;
        academic_year: string;
        start_date: string;
        end_date: string;
        status: string;
        marks_entry_open: number;
        passing_percentage: number;
      }
    | undefined;

  if (!exam) {
    throw new Error('Examination not found');
  }

  const classSection = db
    .prepare(
      `SELECT c.id as class_id, c.name as class_name, COALESCE(c.has_sections, 1) as has_sections,
              s.id as section_id, s.name as section_name
       FROM classes c
       JOIN sections s ON s.class_id = c.id
       WHERE c.id = ? AND s.id = ?`
    )
    .get(classId, sectionId) as
    | { class_id: number; class_name: string; has_sections: number; section_id: number; section_name: string }
    | undefined;

  if (!classSection) {
    throw new Error('Class or Section not found');
  }

  const classHasSections = Boolean(classSection.has_sections ?? 1);

  const ctRow = db
    .prepare(
      `SELECT u.full_name
       FROM class_teacher_assignments cta
       JOIN users u ON u.id = cta.teacher_id
       WHERE cta.class_id = ? AND cta.section_id = ? AND cta.academic_year = ?`
    )
    .get(classId, sectionId, exam.academic_year) as { full_name: string } | undefined;

  const examSubjects = (
    db
      .prepare(
        `SELECT es.id as exam_subject_id, es.subject_id, es.max_marks, es.passing_marks, es.is_required,
                es.has_internal_assessment, es.ia_notebook_max, es.ia_unit_test_max, es.ia_practical_max, es.ia_participation_max,
                COALESCE(es.target_class_ids, '') as target_class_ids,
                sub.code as subject_code, sub.name as subject_name, sub.has_components, sub.component_mode,
                COALESCE(sub.applicable_class_ids, '') as applicable_class_ids,
                COALESCE(sub.stream_category, '') as stream_category,
                COALESCE(sub.has_practical, 0) as has_practical
         FROM examination_subjects es
         JOIN subjects sub ON sub.id = es.subject_id
         WHERE es.examination_id = ?
         ORDER BY es.display_order ASC, sub.display_order ASC`
      )
      .all(examinationId) as Array<{
      exam_subject_id: number;
      subject_id: number;
      max_marks: number;
      passing_marks: number;
      is_required: number;
      has_internal_assessment: number;
      ia_notebook_max: number;
      ia_unit_test_max: number;
      ia_practical_max: number;
      ia_participation_max: number;
      target_class_ids: string;
      subject_code: string;
      subject_name: string;
      has_components: number;
      component_mode: string | null;
      applicable_class_ids: string;
      stream_category: string;
      has_practical: number;
    }>
  ).filter((es) => doesSubjectApplyToClass(es.target_class_ids || es.applicable_class_ids, classId));

  const examComponents = db
    .prepare(
      `SELECT id as exam_component_id, examination_subject_id, subject_id, component_id,
              component_name, max_marks, passing_marks
       FROM examination_components
       WHERE examination_id = ?
       ORDER BY display_order ASC, id ASC`
    )
    .all(examinationId) as Array<{
    exam_component_id: number;
    examination_subject_id: number;
    subject_id: number;
    component_id: number;
    component_name: string;
    max_marks: number;
    passing_marks: number;
  }>;

  const subjectsStructure = examSubjects.map((es) => {
    const comps = examComponents
      .filter((ec) => ec.examination_subject_id === es.exam_subject_id)
      .map((ec) => ({
        examComponentId: ec.exam_component_id,
        componentId: ec.component_id,
        componentName: ec.component_name,
        maxMarks: ec.max_marks,
        passingMarks: ec.passing_marks,
      }));
    const componentMode: ComponentMode =
      es.component_mode === 'elective'
        ? 'elective'
        : es.component_mode === 'combined' || Boolean(es.has_components) || comps.length > 1
          ? 'combined'
          : 'single';
    const writtenMaxMarks =
      comps.length > 0
        ? componentMode === 'elective'
          ? comps[0].maxMarks
          : comps.reduce((sum, c) => sum + c.maxMarks, 0)
        : es.max_marks;
    const hasIa = Boolean(es.has_internal_assessment);
    const nbMax = hasIa ? Number(es.ia_notebook_max || 0) : 0;
    const utMax = hasIa ? Number(es.ia_unit_test_max || 0) : 0;
    const prMax = hasIa ? Number(es.ia_practical_max || 0) : 0;
    const opMax = hasIa ? Number(es.ia_participation_max || 0) : 0;
    const iaMaxMarks = nbMax + utMax + prMax + opMax;
    const totalMax = writtenMaxMarks + iaMaxMarks;
    return {
      examSubjectId: es.exam_subject_id,
      subjectId: es.subject_id,
      subjectCode: es.subject_code,
      subjectName: es.subject_name,
      hasComponents: Boolean(es.has_components) || comps.length > 1,
      componentMode,
      hasInternalAssessment: hasIa,
      hasPractical: Boolean(es.has_practical),
      streamCategory: es.stream_category || '',
      writtenMaxMarks,
      iaNotebookMax: nbMax,
      iaUnitTestMax: utMax,
      iaPracticalMax: prMax,
      iaParticipationMax: opMax,
      iaMaxMarks,
      maxMarks: totalMax,
      passingMarks: es.passing_marks,
      isRequired: Boolean(es.is_required),
      components: comps,
    };
  });

  const hasYearEnrollments =
    (
      db
        .prepare(`SELECT COUNT(*) as cnt FROM student_enrollments WHERE academic_year = ?`)
        .get(exam.academic_year) as { cnt: number }
    ).cnt > 0;

  const students = (
    hasYearEnrollments
      ? db
          .prepare(
            `SELECT st.id, st.student_code, st.full_name, se.roll_number,
                    COALESCE(NULLIF(se.stream, ''), st.stream, '') as stream
             FROM student_enrollments se
             JOIN students st ON st.id = se.student_id
             WHERE se.academic_year = ? AND se.class_id = ? AND se.section_id = ?
               AND (
                 (se.status = 'active' AND COALESCE(st.is_deleted, 0) = 0)
                 OR EXISTS (SELECT 1 FROM marks m WHERE m.student_id = st.id AND m.examination_id = ?)
                 OR EXISTS (SELECT 1 FROM internal_assessment_marks ia WHERE ia.student_id = st.id AND ia.examination_id = ?)
               )
             ORDER BY se.roll_number ASC, st.student_code ASC`
          )
          .all(exam.academic_year, classId, sectionId, examinationId, examinationId)
      : db
          .prepare(
            `SELECT id, student_code, full_name, roll_number, COALESCE(stream, '') as stream
             FROM students
             WHERE class_id = ? AND section_id = ?
               AND (
                 (status = 'active' AND COALESCE(is_deleted, 0) = 0)
                 OR EXISTS (SELECT 1 FROM marks m WHERE m.student_id = students.id AND m.examination_id = ?)
                 OR EXISTS (SELECT 1 FROM internal_assessment_marks ia WHERE ia.student_id = students.id AND ia.examination_id = ?)
               )
             ORDER BY roll_number ASC, student_code ASC`
          )
          .all(classId, sectionId, examinationId, examinationId)
  ) as Array<{
    id: number;
    student_code: string;
    full_name: string;
    roll_number: number;
    stream: string;
  }>;

  const studentIdSet = new Set(students.map((s) => s.id));

  const markRows = (
    db
      .prepare(
        `SELECT student_id, examination_component_id, obtained_marks, attendance_status, status
         FROM marks
         WHERE examination_id = ?`
      )
      .all(examinationId) as Array<{
      student_id: number;
      examination_component_id: number;
      obtained_marks: number | null;
      attendance_status: AttendanceStatus | null;
      status: 'draft' | 'submitted';
    }>
  ).filter((m) => studentIdSet.has(m.student_id));

  const markMap = new Map<
    string,
    { obtainedMarks: number | null; attendanceStatus: AttendanceStatus; status: 'draft' | 'submitted' }
  >();
  for (const m of markRows) {
    const att: AttendanceStatus =
      m.attendance_status === 'absent'
        ? 'absent'
        : m.obtained_marks !== null
          ? 'present'
          : m.attendance_status === 'present'
            ? 'present'
            : 'pending';
    markMap.set(`${m.student_id}:${m.examination_component_id}`, {
      obtainedMarks: att === 'absent' ? null : m.obtained_marks,
      attendanceStatus: att,
      status: m.status,
    });
  }

  const iaRows = (
    db
      .prepare(
        `SELECT student_id, subject_id, notebook_marks, unit_test_marks, practical_marks, participation_marks, status,
                nb_status, ut_status, pr_status, op_status
         FROM internal_assessment_marks
         WHERE examination_id = ?`
      )
      .all(examinationId) as Array<{
      student_id: number;
      subject_id: number;
      notebook_marks: number | null;
      unit_test_marks: number | null;
      practical_marks: number | null;
      participation_marks: number | null;
      status: 'draft' | 'submitted';
      nb_status: string | null;
      ut_status: string | null;
      pr_status: string | null;
      op_status: string | null;
    }>
  ).filter((r) => studentIdSet.has(r.student_id));

  const iaMap = new Map<
    string,
    {
      nb: number | null;
      ut: number | null;
      pr: number | null;
      op: number | null;
      status: 'draft' | 'submitted';
      nbStatus: string;
      utStatus: string;
      prStatus: string;
      opStatus: string;
    }
  >();
  for (const r of iaRows) {
    iaMap.set(`${r.student_id}:${r.subject_id}`, {
      nb: r.notebook_marks,
      ut: r.unit_test_marks,
      pr: r.practical_marks,
      op: r.participation_marks,
      status: r.status,
      nbStatus: r.nb_status || (r.notebook_marks !== null ? r.status : 'pending'),
      utStatus: r.ut_status || (r.unit_test_marks !== null ? r.status : 'pending'),
      prStatus: r.pr_status || (r.practical_marks !== null ? r.status : 'pending'),
      opStatus: r.op_status || (r.participation_marks !== null ? r.status : 'pending'),
    });
  }

  const electiveMap = new Map<string, number>();
  const baseElectiveRows = (
    db.prepare(`SELECT student_id, subject_id, component_id FROM student_electives`).all() as Array<{
      student_id: number;
      subject_id: number;
      component_id: number;
    }>
  ).filter((er) => studentIdSet.has(er.student_id));
  for (const er of baseElectiveRows) {
    electiveMap.set(`${er.student_id}:${er.subject_id}`, er.component_id);
  }
  const yearElectiveRows = (
    db
      .prepare(`SELECT student_id, subject_id, component_id FROM student_year_electives WHERE academic_year = ?`)
      .all(exam.academic_year) as Array<{ student_id: number; subject_id: number; component_id: number }>
  ).filter((er) => studentIdSet.has(er.student_id));
  for (const er of yearElectiveRows) {
    electiveMap.set(`${er.student_id}:${er.subject_id}`, er.component_id);
  }

  // Per-student custom subjects & elective opt-outs
  const customSubjectsMap = new Map<number, Set<number>>();
  const yearSubRows = (
    db
      .prepare(`SELECT student_id, subject_id FROM student_year_subjects WHERE academic_year = ?`)
      .all(exam.academic_year) as Array<{ student_id: number; subject_id: number }>
  ).filter((r) => studentIdSet.has(r.student_id));
  for (const r of yearSubRows) {
    if (!customSubjectsMap.has(r.student_id)) customSubjectsMap.set(r.student_id, new Set());
    customSubjectsMap.get(r.student_id)!.add(r.subject_id);
  }
  const baseSubRows = (
    db.prepare(`SELECT student_id, subject_id FROM student_subjects`).all() as Array<{
      student_id: number;
      subject_id: number;
    }>
  ).filter((r) => studentIdSet.has(r.student_id) && !customSubjectsMap.has(r.student_id));
  for (const r of baseSubRows) {
    if (!customSubjectsMap.has(r.student_id)) customSubjectsMap.set(r.student_id, new Set());
    customSubjectsMap.get(r.student_id)!.add(r.subject_id);
  }

  const optOutSet = new Set<string>();
  const optOutRows = (
    db
      .prepare(`SELECT student_id, subject_id FROM student_elective_opt_outs WHERE academic_year = ?`)
      .all(exam.academic_year) as Array<{ student_id: number; subject_id: number }>
  ).filter((r) => studentIdSet.has(r.student_id));
  for (const r of optOutRows) {
    optOutSet.add(`${r.student_id}:${r.subject_id}`);
  }

  const coScholasticRows = (
    db
      .prepare(
        `SELECT student_id, term, item_key, grade
         FROM student_co_scholastic_grades
         WHERE academic_year = ?`
      )
      .all(exam.academic_year) as Array<{
      student_id: number;
      term: number;
      item_key: string;
      grade: string;
    }>
  ).filter((r) => studentIdSet.has(r.student_id) && CO_SCHOLASTIC_ITEM_KEYS.has(r.item_key) && isValidCoScholasticGrade(r.grade));

  const coScholasticMap = new Map<
    number,
    { term1: Record<string, CoScholasticGrade>; term2: Record<string, CoScholasticGrade> }
  >();
  for (const r of coScholasticRows) {
    let bucket = coScholasticMap.get(r.student_id);
    if (!bucket) {
      bucket = { term1: {}, term2: {} };
      coScholasticMap.set(r.student_id, bucket);
    }
    if (r.term === 1) bucket.term1[r.item_key] = r.grade as CoScholasticGrade;
    else if (r.term === 2) bucket.term2[r.item_key] = r.grade as CoScholasticGrade;
  }
  const coScholasticMeta = {
    ...getExamCoScholasticTerm(examinationId),
    hasAnyGradesForYear: coScholasticRows.length > 0,
  };

  const studentIdArr = Array.from(studentIdSet);
  const profileMap = getStudentExtendedProfilesMap(studentIdArr);
  const termRecordsMap = getStudentTermRecordsMap(exam.academic_year, studentIdArr);

  const gradingScale = getGradingScale();
  const totalExamMax = subjectsStructure.reduce((sum, s) => sum + s.maxMarks, 0);

  const studentResults: ConsolidatedStudentResult[] = students.map((st) => {
    const missingComponents: string[] = [];
    const customSubs = customSubjectsMap.get(st.id);
    const hasCustomSubs = Boolean(customSubs && customSubs.size > 0);
    let enrolledSubjectsCount = 0;
    let allRequiredComplete = subjectsStructure.length > 0;
    let grandTotalAcc = 0;
    let studentTotalMaxAcc = 0;
    let allSubjectsPassed = true;

    const subjectResults: ConsolidatedSubjectResult[] = subjectsStructure.map((sub) => {
      const isOptedOut = sub.componentMode === 'elective' && optOutSet.has(`${st.id}:${sub.subjectId}`);
      const isExcludedByCustom = hasCustomSubs && !customSubs!.has(sub.subjectId);
      const isEnrolled = !isOptedOut && !isExcludedByCustom;

      if (!isEnrolled) {
        return {
          examSubjectId: sub.examSubjectId,
          subjectId: sub.subjectId,
          subjectCode: sub.subjectCode,
          subjectName: sub.subjectName,
          hasComponents: sub.hasComponents,
          componentMode: sub.componentMode,
          selectedComponentName: null,
          hasInternalAssessment: sub.hasInternalAssessment,
          hasPractical: sub.hasPractical,
          streamCategory: sub.streamCategory,
          isEnrolled: false,
          writtenMaxMarks: 0,
          writtenObtainedMarks: null,
          iaNotebookMax: sub.iaNotebookMax,
          iaUnitTestMax: sub.iaUnitTestMax,
          iaPracticalMax: sub.iaPracticalMax,
          iaParticipationMax: sub.iaParticipationMax,
          iaMaxMarks: 0,
          iaNotebookMarks: null,
          iaUnitTestMarks: null,
          iaPracticalMarks: null,
          iaParticipationMarks: null,
          iaTotalMarks: null,
          iaStatus: 'na',
          maxMarks: 0,
          passingMarks: 0,
          isRequired: false,
          obtainedMarks: null,
          submittedSubtotal: 0,
          isComplete: true,
          isPassed: null,
          grade: null,
          gradeRemark: 'Not Applicable',
          gradeStatus: 'not_applicable',
          components: [],
        };
      }

      enrolledSubjectsCount++;

      let activeComponents = sub.components;
      let selectedComponentName: string | null = null;
      if (sub.componentMode === 'elective' && sub.components.length > 0) {
        const mappedCompId = electiveMap.get(`${st.id}:${sub.subjectId}`);
        let chosen = mappedCompId ? sub.components.find((c) => c.componentId === mappedCompId) : undefined;
        if (!chosen) {
          chosen = sub.components.find((c) => {
            const m = markMap.get(`${st.id}:${c.examComponentId}`);
            return m && (m.obtainedMarks !== null || m.attendanceStatus === 'absent');
          });
        }
        if (!chosen) chosen = sub.components[0];
        activeComponents = [chosen];
        selectedComponentName = chosen.componentName;
      }

      let subjectComplete = activeComponents.length > 0;
      let writtenAcc = 0;
      let allWrittenSubmitted = activeComponents.length > 0;
      let submittedSubtotal = 0;
      let hasAbsentComponent = false;

      const compResults: ConsolidatedComponentResult[] = activeComponents.map((comp) => {
        const entry = markMap.get(`${st.id}:${comp.examComponentId}`);
        const attStatus: AttendanceStatus = entry?.attendanceStatus ?? 'pending';
        const obtained =
          attStatus === 'present' && entry && entry.obtainedMarks !== null ? entry.obtainedMarks : null;
        const isRecorded = attStatus === 'absent' || (attStatus === 'present' && obtained !== null);
        const status: 'submitted' | 'draft' | 'pending' = !entry || !isRecorded ? 'pending' : entry.status;

        if (status !== 'submitted' || !isRecorded) {
          subjectComplete = false;
          allWrittenSubmitted = false;
          if (sub.isRequired) {
            missingComponents.push(
              sub.hasComponents ? `${sub.subjectName} (${comp.componentName})` : `${sub.subjectName} (Written)`
            );
          }
        } else if (attStatus === 'absent') {
          hasAbsentComponent = true;
        } else if (obtained !== null) {
          writtenAcc += obtained;
          submittedSubtotal += obtained;
        }

        return {
          examComponentId: comp.examComponentId,
          componentId: comp.componentId,
          componentName: comp.componentName,
          maxMarks: comp.maxMarks,
          passingMarks: comp.passingMarks,
          obtainedMarks: obtained,
          attendanceStatus: attStatus,
          status,
        };
      });

      let iaNb: number | null = null;
      let iaUt: number | null = null;
      let iaPr: number | null = null;
      let iaOp: number | null = null;
      let iaTotal: number | null = null;
      let iaStatus: 'submitted' | 'draft' | 'pending' | 'na' = sub.hasInternalAssessment ? 'pending' : 'na';

      if (sub.hasInternalAssessment) {
        const iaEntry = iaMap.get(`${st.id}:${sub.subjectId}`);
        if (iaEntry) {
          iaNb = iaEntry.nb;
          iaUt = iaEntry.ut;
          iaPr = iaEntry.pr;
          iaOp = iaEntry.op;
          const nbOk = sub.iaNotebookMax <= 0 || iaNb !== null;
          const utOk = sub.iaUnitTestMax <= 0 || iaUt !== null;
          const prOk = sub.iaPracticalMax <= 0 || iaPr !== null;
          const opOk = sub.iaParticipationMax <= 0 || iaOp !== null;
          const allFilled = nbOk && utOk && prOk && opOk;

          const nbSub = sub.iaNotebookMax <= 0 || (iaNb !== null && iaEntry.nbStatus === 'submitted');
          const utSub = sub.iaUnitTestMax <= 0 || (iaUt !== null && iaEntry.utStatus === 'submitted');
          const prSub = sub.iaPracticalMax <= 0 || (iaPr !== null && iaEntry.prStatus === 'submitted');
          const opSub = sub.iaParticipationMax <= 0 || (iaOp !== null && iaEntry.opStatus === 'submitted');
          const allSub = nbSub && utSub && prSub && opSub;

          const anyEntered = iaNb !== null || iaUt !== null || iaPr !== null || iaOp !== null;
          if (!anyEntered && !(sub.iaNotebookMax === 0 && sub.iaUnitTestMax === 0 && sub.iaPracticalMax === 0 && sub.iaParticipationMax === 0)) {
            iaStatus = 'pending';
          } else if (allFilled && (allSub || iaEntry.status === 'submitted')) {
            iaStatus = 'submitted';
          } else {
            iaStatus = 'draft';
          }

          if (allFilled) {
            iaTotal = Number(
              ((iaNb ?? 0) + (iaUt ?? 0) + (iaPr ?? 0) + (iaOp ?? 0)).toFixed(2)
            );
            if (iaStatus === 'submitted') {
              submittedSubtotal += iaTotal;
            }
          }
        }
        if (iaStatus !== 'submitted' || iaTotal === null) {
          subjectComplete = false;
          if (sub.isRequired) {
            missingComponents.push(
              selectedComponentName
                ? `${sub.subjectName} — ${selectedComponentName} (Internal Assessment)`
                : `${sub.subjectName} (Internal Assessment)`
            );
          }
        }
      }

      if (sub.isRequired && !subjectComplete) {
        allRequiredComplete = false;
      }

      const studentWrittenMax =
        sub.componentMode === 'elective' && activeComponents.length > 0
          ? activeComponents[0].maxMarks
          : sub.writtenMaxMarks;
      const studentMaxMarks =
        sub.componentMode === 'elective' ? studentWrittenMax + sub.iaMaxMarks : sub.maxMarks;

      studentTotalMaxAcc += studentMaxMarks;

      const writtenObtainedMarks = allWrittenSubmitted ? Number(writtenAcc.toFixed(2)) : null;
      const finalSubjectMarks = subjectComplete
        ? Number((writtenAcc + (sub.hasInternalAssessment ? iaTotal ?? 0 : 0)).toFixed(2))
        : null;
      const isPassed =
        subjectComplete && finalSubjectMarks !== null
          ? !hasAbsentComponent && finalSubjectMarks >= sub.passingMarks
          : null;

      if (subjectComplete && finalSubjectMarks !== null) {
        grandTotalAcc += finalSubjectMarks;
        if (isPassed === false) {
          allSubjectsPassed = false;
        }
      }

      const anySubmittedOrEntered =
        compResults.some((c) => c.status !== 'pending' || c.obtainedMarks !== null || c.attendanceStatus === 'absent') ||
        (sub.hasInternalAssessment && (iaStatus === 'submitted' || iaStatus === 'draft'));

      const subjectGradeEval = calculateSubjectGrade(finalSubjectMarks, studentMaxMarks, {
        isAbsent: hasAbsentComponent,
        isPending: !subjectComplete || finalSubjectMarks === null,
        isNotSubmitted: !anySubmittedOrEntered,
      });

      return {
        examSubjectId: sub.examSubjectId,
        subjectId: sub.subjectId,
        subjectCode: sub.subjectCode,
        subjectName: sub.subjectName,
        hasComponents: sub.hasComponents,
        componentMode: sub.componentMode,
        selectedComponentName,
        hasInternalAssessment: sub.hasInternalAssessment,
        hasPractical: sub.hasPractical,
        streamCategory: sub.streamCategory,
        isEnrolled: true,
        writtenMaxMarks: studentWrittenMax,
        writtenObtainedMarks,
        iaNotebookMax: sub.iaNotebookMax,
        iaUnitTestMax: sub.iaUnitTestMax,
        iaPracticalMax: sub.iaPracticalMax,
        iaParticipationMax: sub.iaParticipationMax,
        iaMaxMarks: sub.iaMaxMarks,
        iaNotebookMarks: iaNb,
        iaUnitTestMarks: iaUt,
        iaPracticalMarks: iaPr,
        iaParticipationMarks: iaOp,
        iaTotalMarks: iaTotal,
        iaStatus,
        maxMarks: studentMaxMarks,
        passingMarks: sub.passingMarks,
        isRequired: sub.isRequired,
        obtainedMarks: finalSubjectMarks,
        submittedSubtotal: Number(submittedSubtotal.toFixed(2)),
        isComplete: subjectComplete,
        isPassed,
        grade: subjectGradeEval.grade,
        gradeRemark: subjectGradeEval.remark,
        gradeStatus: subjectGradeEval.status,
        components: compResults,
      };
    });

    const studentStream =
      st.stream === 'Science' || st.stream === 'Humanities' ? st.stream : '';
    const csBucket = coScholasticMap.get(st.id) || { term1: {}, term2: {} };
    const t1Summary = summarizeCoScholasticGrades(csBucket.term1);
    const t2Summary = summarizeCoScholasticGrades(csBucket.term2);
    const studentCoScholastic: StudentCoScholasticData = {
      term1: csBucket.term1,
      term2: csBucket.term2,
      term1TotalPoints: t1Summary.totalPoints,
      term2TotalPoints: t2Summary.totalPoints,
    };

    const extProfile = profileMap.get(st.id);
    const termRec = termRecordsMap.get(st.id) || createEmptyTermData();

    if (!allRequiredComplete || enrolledSubjectsCount === 0 || studentTotalMaxAcc === 0) {
      return {
        studentId: st.id,
        studentCode: st.student_code,
        studentName: st.full_name,
        rollNumber: st.roll_number,
        classId: classSection.class_id,
        className: classSection.class_name,
        hasSections: classHasSections,
        sectionId: classSection.section_id,
        sectionName: classSection.section_name,
        stream: studentStream,
        fatherName: extProfile?.fatherName || '',
        motherName: extProfile?.motherName || '',
        residentialAddress: extProfile?.residentialAddress || '',
        contactNo: extProfile?.contactNo || '',
        aapaarId: extProfile?.aapaarId || '',
        photoUrl: extProfile?.photoUrl || '',
        subjects: subjectResults,
        grandTotal: null,
        totalMaxMarks: studentTotalMaxAcc,
        percentage: null,
        grade: null,
        gradeRemark: null,
        resultStatus: 'Incomplete',
        classRank: null,
        missingComponents,
        coScholastic: studentCoScholastic,
        termRecords: termRec,
      };
    }

    const grandTotal = Number(grandTotalAcc.toFixed(2));
    const percentage = Number(((grandTotal / studentTotalMaxAcc) * 100).toFixed(2));
    const { grade, remark } = calculateGrade(percentage, gradingScale);
    const overallPass = percentage >= exam.passing_percentage && allSubjectsPassed;

    return {
      studentId: st.id,
      studentCode: st.student_code,
      studentName: st.full_name,
      rollNumber: st.roll_number,
      classId: classSection.class_id,
      className: classSection.class_name,
      hasSections: classHasSections,
      sectionId: classSection.section_id,
      sectionName: classSection.section_name,
      stream: studentStream,
      fatherName: extProfile?.fatherName || '',
      motherName: extProfile?.motherName || '',
      residentialAddress: extProfile?.residentialAddress || '',
      contactNo: extProfile?.contactNo || '',
      aapaarId: extProfile?.aapaarId || '',
      photoUrl: extProfile?.photoUrl || '',
      subjects: subjectResults,
      grandTotal,
      totalMaxMarks: studentTotalMaxAcc,
      percentage,
      grade: overallPass ? grade : 'E',
      gradeRemark: overallPass ? remark : 'Needs Improvement',
      resultStatus: overallPass ? 'Pass' : 'Fail',
      classRank: null,
      missingComponents: [],
      coScholastic: studentCoScholastic,
      termRecords: termRec,
    };
  });

  // Assign ranks only to completed students (rank by percentage when maxMarks differ, tiebreak by grandTotal)
  const completedStudents = studentResults
    .filter((s) => s.resultStatus !== 'Incomplete' && s.grandTotal !== null)
    .sort((a, b) => {
      const pctDiff = (b.percentage ?? 0) - (a.percentage ?? 0);
      if (Math.abs(pctDiff) > 0.001) return pctDiff;
      return (b.grandTotal ?? 0) - (a.grandTotal ?? 0);
    });

  let currentRank = 0;
  let lastScoreKey: string | null = null;
  completedStudents.forEach((st, idx) => {
    const scoreKey = `${st.percentage ?? 0}:${st.grandTotal ?? 0}`;
    if (scoreKey !== lastScoreKey) {
      currentRank = idx + 1;
      lastScoreKey = scoreKey;
    }
    st.classRank = currentRank;
  });

  const totals = completedStudents.map((s) => s.grandTotal as number);
  const passCount = completedStudents.filter((s) => s.resultStatus === 'Pass').length;
  const failCount = completedStudents.filter((s) => s.resultStatus === 'Fail').length;

  const highestTotal = totals.length > 0 ? Math.max(...totals) : null;
  const lowestTotal = totals.length > 0 ? Math.min(...totals) : null;
  const avgTotal =
    totals.length > 0 ? Number((totals.reduce((a, b) => a + b, 0) / totals.length).toFixed(2)) : null;
  const avgPct =
    completedStudents.length > 0
      ? Number(
          (
            completedStudents.reduce((a, s) => a + (s.percentage ?? 0), 0) / completedStudents.length
          ).toFixed(2)
        )
      : null;

  const subjectPerformance: SubjectPerformanceStat[] = subjectsStructure.map((sub) => {
    const completedForSub = studentResults
      .map((st) => st.subjects.find((sr) => sr.subjectId === sub.subjectId))
      .filter((sr): sr is ConsolidatedSubjectResult =>
        Boolean(sr && sr.isEnrolled !== false && sr.isComplete && sr.obtainedMarks !== null)
      );

    const vals = completedForSub.map((sr) => sr.obtainedMarks as number);
    const passed = completedForSub.filter((sr) => sr.isPassed === true).length;
    const avg = vals.length > 0 ? Number((vals.reduce((a, b) => a + b, 0) / vals.length).toFixed(2)) : null;

    return {
      subjectId: sub.subjectId,
      subjectName: sub.subjectName,
      subjectCode: sub.subjectCode,
      maxMarks: sub.maxMarks,
      averageMarks: avg,
      averagePercentage: avg !== null && sub.maxMarks > 0 ? Number(((avg / sub.maxMarks) * 100).toFixed(2)) : null,
      highestMarks: vals.length > 0 ? Math.max(...vals) : null,
      lowestMarks: vals.length > 0 ? Math.min(...vals) : null,
      completedStudents: vals.length,
      passedStudents: passed,
      passRate: vals.length > 0 ? Number(((passed / vals.length) * 100).toFixed(1)) : null,
    };
  });

  return {
    examination: {
      id: exam.id,
      name: exam.name,
      academicYear: exam.academic_year,
      startDate: exam.start_date,
      endDate: exam.end_date,
      status: exam.status,
      marksEntryOpen: Boolean(exam.marks_entry_open),
      passingPercentage: exam.passing_percentage,
    },
    classInfo: {
      classId: classSection.class_id,
      className: classSection.class_name,
      hasSections: classHasSections,
      sectionId: classSection.section_id,
      sectionName: classSection.section_name,
      classTeacherName: ctRow?.full_name ?? null,
      resultDate: getClassResultDate(classSection.class_id, classSection.section_id, exam.academic_year),
    },
    gradingScale,
    subjects: subjectsStructure,
    students: studentResults,
    summary: {
      totalStudents: studentResults.length,
      completedCount: completedStudents.length,
      incompleteCount: studentResults.length - completedStudents.length,
      passCount,
      failCount,
      highestTotal,
      lowestTotal,
      classAverageTotal: avgTotal,
      classAveragePercentage: avgPct,
      totalMaxMarks: totalExamMax,
    },
    subjectPerformance,
    coScholasticMeta,
  };
}

export function getCombinedTermResults(
  academicYear: string,
  classId: number,
  sectionId: number,
  explicitTerm1ExamId?: number | null,
  explicitTerm2ExamId?: number | null
): CombinedTermClassReport {
  const classSection = db
    .prepare(
      `SELECT c.id as class_id, c.name as class_name, COALESCE(c.has_sections, 1) as has_sections,
              s.id as section_id, s.name as section_name
       FROM classes c
       JOIN sections s ON s.class_id = c.id
       WHERE c.id = ? AND s.id = ?`
    )
    .get(classId, sectionId) as
    | { class_id: number; class_name: string; has_sections: number; section_id: number; section_name: string }
    | undefined;

  if (!classSection) {
    throw new Error('Class or Section not found');
  }

  const classHasSections = Boolean(classSection.has_sections ?? 1);
  const ctRow = db
    .prepare(
      `SELECT u.full_name
       FROM class_teacher_assignments cta
       JOIN users u ON u.id = cta.teacher_id
       WHERE cta.class_id = ? AND cta.section_id = ? AND cta.academic_year = ?`
    )
    .get(classId, sectionId, academicYear) as { full_name: string } | undefined;

  const resolved = resolveYearTermExams(academicYear);
  const term1ExamId = explicitTerm1ExamId || resolved.term1ExamId || null;
  let term2ExamId = explicitTerm2ExamId || resolved.term2ExamId || null;
  if (term1ExamId && term2ExamId === term1ExamId) {
    term2ExamId = null;
  }

  const term1Report = term1ExamId ? getConsolidatedResults(term1ExamId, classId, sectionId) : null;
  const term2Report = term2ExamId ? getConsolidatedResults(term2ExamId, classId, sectionId) : null;
  const gradingScale = getGradingScale();

  const t1ByStudent = new Map<number, ConsolidatedStudentResult>();
  if (term1Report) {
    for (const s of term1Report.students) t1ByStudent.set(s.studentId, s);
  }
  const t2ByStudent = new Map<number, ConsolidatedStudentResult>();
  if (term2Report) {
    for (const s of term2Report.students) t2ByStudent.set(s.studentId, s);
  }

  // Merge students from Term 1, Term 2, and active enrollments in this year/section
  const hasYearEnrollments =
    (
      db
        .prepare(`SELECT COUNT(*) as cnt FROM student_enrollments WHERE academic_year = ?`)
        .get(academicYear) as { cnt: number }
    ).cnt > 0;

  const activeRoster = (
    hasYearEnrollments
      ? db
          .prepare(
            `SELECT st.id, st.student_code, st.full_name, se.roll_number,
                    COALESCE(NULLIF(se.stream, ''), st.stream, '') as stream
             FROM student_enrollments se
             JOIN students st ON st.id = se.student_id
             WHERE se.academic_year = ? AND se.class_id = ? AND se.section_id = ?
               AND se.status = 'active' AND COALESCE(st.is_deleted, 0) = 0
             ORDER BY se.roll_number ASC, st.student_code ASC`
          )
          .all(academicYear, classId, sectionId)
      : db
          .prepare(
            `SELECT id, student_code, full_name, roll_number, COALESCE(stream, '') as stream
             FROM students
             WHERE class_id = ? AND section_id = ? AND status = 'active' AND COALESCE(is_deleted, 0) = 0
             ORDER BY roll_number ASC, student_code ASC`
          )
          .all(classId, sectionId)
  ) as Array<{ id: number; student_code: string; full_name: string; roll_number: number; stream: string }>;

  const studentBaseMap = new Map<
    number,
    { studentId: number; studentCode: string; studentName: string; rollNumber: number; stream: '' | 'Science' | 'Humanities' }
  >();
  for (const r of activeRoster) {
    studentBaseMap.set(r.id, {
      studentId: r.id,
      studentCode: r.student_code,
      studentName: r.full_name,
      rollNumber: r.roll_number,
      stream: r.stream === 'Science' || r.stream === 'Humanities' ? r.stream : '',
    });
  }
  for (const s of [...(term1Report?.students || []), ...(term2Report?.students || [])]) {
    if (!studentBaseMap.has(s.studentId)) {
      studentBaseMap.set(s.studentId, {
        studentId: s.studentId,
        studentCode: s.studentCode,
        studentName: s.studentName,
        rollNumber: s.rollNumber,
        stream: s.stream || '',
      });
    }
  }

  const orderedBases = Array.from(studentBaseMap.values()).sort((a, b) => {
    if (a.rollNumber !== b.rollNumber) return a.rollNumber - b.rollNumber;
    return a.studentCode.localeCompare(b.studentCode);
  });

  const allIds = orderedBases.map((b) => b.studentId);
  const profileMap = getStudentExtendedProfilesMap(allIds);
  const termRecordsMap = getStudentTermRecordsMap(academicYear, allIds);

  // Co-scholastic fallback in case neither term1Report nor term2Report existed
  const coScholasticRows =
    allIds.length > 0
      ? (
          db
            .prepare(
              `SELECT student_id, term, item_key, grade
               FROM student_co_scholastic_grades
               WHERE academic_year = ?`
            )
            .all(academicYear) as Array<{ student_id: number; term: number; item_key: string; grade: string }>
        ).filter((r) => studentBaseMap.has(r.student_id) && CO_SCHOLASTIC_ITEM_KEYS.has(r.item_key) && isValidCoScholasticGrade(r.grade))
      : [];
  const coScholMap = new Map<number, { term1: Record<string, CoScholasticGrade>; term2: Record<string, CoScholasticGrade> }>();
  for (const r of coScholasticRows) {
    let bucket = coScholMap.get(r.student_id);
    if (!bucket) {
      bucket = { term1: {}, term2: {} };
      coScholMap.set(r.student_id, bucket);
    }
    if (r.term === 1) bucket.term1[r.item_key] = r.grade as CoScholasticGrade;
    else if (r.term === 2) bucket.term2[r.item_key] = r.grade as CoScholasticGrade;
  }

  // Master ordered subject catalog across Term 1 & Term 2
  const masterSubjects: Array<{ subjectId: number; subjectCode: string; subjectName: string; componentMode: ComponentMode }> = [];
  const seenSubIds = new Set<number>();
  for (const s of term1Report?.subjects || []) {
    if (!seenSubIds.has(s.subjectId)) {
      seenSubIds.add(s.subjectId);
      masterSubjects.push({
        subjectId: s.subjectId,
        subjectCode: s.subjectCode,
        subjectName: s.subjectName,
        componentMode: s.componentMode,
      });
    }
  }
  for (const s of term2Report?.subjects || []) {
    if (!seenSubIds.has(s.subjectId)) {
      seenSubIds.add(s.subjectId);
      masterSubjects.push({
        subjectId: s.subjectId,
        subjectCode: s.subjectCode,
        subjectName: s.subjectName,
        componentMode: s.componentMode,
      });
    }
  }

  const students: CombinedTermStudentResult[] = orderedBases.map((base) => {
    const t1 = t1ByStudent.get(base.studentId) || null;
    const t2 = t2ByStudent.get(base.studentId) || null;
    const extProfile = profileMap.get(base.studentId);
    const termRecords = termRecordsMap.get(base.studentId) || t2?.termRecords || t1?.termRecords || createEmptyTermData();

    const coScholRaw = coScholMap.get(base.studentId) || { term1: {}, term2: {} };
    const coScholastic: StudentCoScholasticData = t2?.coScholastic ||
      t1?.coScholastic || {
        term1: coScholRaw.term1,
        term2: coScholRaw.term2,
        term1TotalPoints: summarizeCoScholasticGrades(coScholRaw.term1).totalPoints,
        term2TotalPoints: summarizeCoScholasticGrades(coScholRaw.term2).totalPoints,
      };

    const t1SubMap = new Map<number, ConsolidatedSubjectResult>();
    if (t1) for (const sub of t1.subjects) t1SubMap.set(sub.subjectId, sub);
    const t2SubMap = new Map<number, ConsolidatedSubjectResult>();
    if (t2) for (const sub of t2.subjects) t2SubMap.set(sub.subjectId, sub);

    const subjectRows: CombinedTermSubjectRow[] = [];
    for (const meta of masterSubjects) {
      const s1Raw = t1SubMap.get(meta.subjectId) || null;
      const s2Raw = t2SubMap.get(meta.subjectId) || null;
      const s1 = s1Raw && s1Raw.isEnrolled !== false && s1Raw.gradeStatus !== 'not_applicable' ? s1Raw : null;
      const s2 = s2Raw && s2Raw.isEnrolled !== false && s2Raw.gradeStatus !== 'not_applicable' ? s2Raw : null;
      if (!s1 && !s2) continue;

      const combinedMaxMarks = (s1?.maxMarks ?? 0) + (s2?.maxMarks ?? 0);
      let averageMarks: number | null = null;
      let combinedObtainedMarks: number | null = null;
      let combinedGrade: string | null = null;
      let combinedPassed: boolean | null = null;

      if (s1 && s2 && s1.isComplete && s2.isComplete && s1.obtainedMarks !== null && s2.obtainedMarks !== null) {
        combinedObtainedMarks = Number((s1.obtainedMarks + s2.obtainedMarks).toFixed(2));
        averageMarks = Number((combinedObtainedMarks / 2).toFixed(2));
        const combPct = combinedMaxMarks > 0 ? (combinedObtainedMarks / combinedMaxMarks) * 100 : 0;
        combinedGrade = calculateGrade(combPct, gradingScale).grade;
        const combinedPassing = (s1.passingMarks ?? 0) + (s2.passingMarks ?? 0);
        const bothAbsent =
          s1.components.some((c) => c.attendanceStatus === 'absent') &&
          s2.components.some((c) => c.attendanceStatus === 'absent');
        combinedPassed = !bothAbsent && combinedObtainedMarks >= combinedPassing;
      }

      const displaySubName =
        s2?.componentMode === 'elective' && s2.selectedComponentName
          ? `${meta.subjectName} (${s2.selectedComponentName})`
          : s1?.componentMode === 'elective' && s1.selectedComponentName
            ? `${meta.subjectName} (${s1.selectedComponentName})`
            : meta.subjectName;

      subjectRows.push({
        subjectId: meta.subjectId,
        subjectCode: meta.subjectCode,
        subjectName: displaySubName,
        componentMode: meta.componentMode,
        term1: s1,
        term2: s2,
        averageMarks,
        combinedObtainedMarks,
        combinedMaxMarks,
        combinedGrade,
        combinedPassed,
      });
    }

    const term1Summary: CombinedTermSummary | null =
      term1Report && t1
        ? {
            examinationId: term1Report.examination.id,
            examinationName: term1Report.examination.name,
            grandTotal: t1.grandTotal,
            totalMaxMarks: t1.totalMaxMarks,
            percentage: t1.percentage,
            grade: t1.grade,
            gradeRemark: t1.gradeRemark,
            resultStatus: t1.resultStatus,
            classRank: t1.classRank,
            missingComponents: t1.missingComponents,
          }
        : null;

    const term2Summary: CombinedTermSummary | null =
      term2Report && t2
        ? {
            examinationId: term2Report.examination.id,
            examinationName: term2Report.examination.name,
            grandTotal: t2.grandTotal,
            totalMaxMarks: t2.totalMaxMarks,
            percentage: t2.percentage,
            grade: t2.grade,
            gradeRemark: t2.gradeRemark,
            resultStatus: t2.resultStatus,
            classRank: t2.classRank,
            missingComponents: t2.missingComponents,
          }
        : null;

    const bothTermsComplete = Boolean(
      term1Summary &&
        term2Summary &&
        term1Summary.resultStatus !== 'Incomplete' &&
        term2Summary.resultStatus !== 'Incomplete' &&
        term1Summary.grandTotal !== null &&
        term2Summary.grandTotal !== null
    );

    const combinedMaxMarks = (term1Summary?.totalMaxMarks ?? 0) + (term2Summary?.totalMaxMarks ?? 0);
    let combinedTotal: number | null = null;
    let averageObtained: number | null = null;
    let averageMaxMarks: number | null = combinedMaxMarks > 0 && term1Summary && term2Summary ? Number((combinedMaxMarks / 2).toFixed(2)) : null;
    let finalPercentage: number | null = null;
    let finalGrade: string | null = null;
    let finalGradeRemark: string | null = null;
    let overallStatus: 'Pass' | 'Fail' | 'Incomplete' = 'Incomplete';

    if (bothTermsComplete && term1Summary && term2Summary && combinedMaxMarks > 0) {
      combinedTotal = Number(((term1Summary.grandTotal ?? 0) + (term2Summary.grandTotal ?? 0)).toFixed(2));
      averageObtained = Number((combinedTotal / 2).toFixed(2));
      finalPercentage = Number(((combinedTotal / combinedMaxMarks) * 100).toFixed(2));
      const passingThreshold = term2Report?.examination.passingPercentage ?? term1Report?.examination.passingPercentage ?? 33;
      const allSubsPassed = subjectRows
        .filter((r) => r.combinedPassed !== null)
        .every((r) => r.combinedPassed === true);
      const passedOverall = finalPercentage >= passingThreshold && allSubsPassed;
      const gInfo = calculateGrade(finalPercentage, gradingScale);
      finalGrade = passedOverall ? gInfo.grade : 'E';
      finalGradeRemark = passedOverall ? gInfo.remark : 'Needs Improvement';
      overallStatus = passedOverall ? 'Pass' : 'Fail';
    }

    return {
      studentId: base.studentId,
      studentCode: base.studentCode,
      studentName: base.studentName,
      rollNumber: base.rollNumber,
      classId: classSection.class_id,
      className: classSection.class_name,
      hasSections: classHasSections,
      sectionId: classSection.section_id,
      sectionName: classSection.section_name,
      stream: base.stream,
      fatherName: extProfile?.fatherName || t2?.fatherName || t1?.fatherName || '',
      motherName: extProfile?.motherName || t2?.motherName || t1?.motherName || '',
      residentialAddress: extProfile?.residentialAddress || t2?.residentialAddress || t1?.residentialAddress || '',
      contactNo: extProfile?.contactNo || t2?.contactNo || t1?.contactNo || '',
      aapaarId: extProfile?.aapaarId || t2?.aapaarId || t1?.aapaarId || '',
      photoUrl: extProfile?.photoUrl || '',
      subjects: subjectRows,
      term1Summary,
      term2Summary,
      overall: {
        combinedTotal,
        combinedMaxMarks,
        averageObtained,
        averageMaxMarks,
        finalPercentage,
        finalGrade,
        finalGradeRemark,
        resultStatus: overallStatus,
      },
      termRecords,
      coScholastic,
    };
  });

  return {
    academicYear,
    classInfo: {
      classId: classSection.class_id,
      className: classSection.class_name,
      hasSections: classHasSections,
      sectionId: classSection.section_id,
      sectionName: classSection.section_name,
      classTeacherName: ctRow?.full_name ?? null,
      resultDate: getClassResultDate(classSection.class_id, classSection.section_id, academicYear),
    },
    gradingScale,
    term1Exam: term1Report?.examination ?? null,
    term2Exam: term2Report?.examination ?? null,
    term1Report,
    term2Report,
    students,
  };
}

export interface MonitoringRow {
  examinationId: number;
  examinationName: string;
  classId: number;
  className: string;
  hasSections?: boolean;
  sectionId: number;
  sectionName: string;
  subjectId: number;
  subjectName: string;
  examComponentId: number;
  componentId: number;
  componentName: string;
  maxMarks: number;
  teacherId: number | null;
  teacherName: string | null;
  totalStudents: number;
  enteredCount: number;
  presentCount: number;
  absentCount: number;
  submittedCount: number;
  draftCount: number;
  missingCount: number;
  submissionStatus: 'Submitted' | 'Draft' | 'Pending';
  hasInternalAssessment: boolean;
  iaStatus: 'Submitted' | 'Draft' | 'Pending' | 'N/A';
  lastUpdatedAt: string | null;
}

export function getSubmissionMonitoring(
  examinationId: number,
  classId?: number,
  sectionId?: number
): MonitoringRow[] {
  const exam = db
    .prepare(`SELECT id, name, academic_year FROM examinations WHERE id = ?`)
    .get(examinationId) as { id: number; name: string; academic_year: string } | undefined;

  if (!exam) return [];

  const sectionFilter =
    classId && sectionId
      ? `WHERE COALESCE(c.is_deleted, 0) = 0 AND COALESCE(s.is_deleted, 0) = 0 AND c.id = ? AND s.id = ?`
      : classId
        ? `WHERE COALESCE(c.is_deleted, 0) = 0 AND COALESCE(s.is_deleted, 0) = 0 AND c.id = ?`
        : `WHERE COALESCE(c.is_deleted, 0) = 0 AND COALESCE(s.is_deleted, 0) = 0`;
  const params: Array<number | string> = [];
  if (classId && sectionId) params.push(classId, sectionId);
  else if (classId) params.push(classId);

  const sections = db
    .prepare(
      `SELECT c.id as class_id, c.name as class_name, COALESCE(c.has_sections, 1) as has_sections,
              s.id as section_id, s.name as section_name
       FROM classes c
       JOIN sections s ON s.class_id = c.id
       ${sectionFilter}
       ORDER BY c.numeric_order ASC, s.name ASC`
    )
    .all(...params) as Array<{
    class_id: number;
    class_name: string;
    has_sections: number;
    section_id: number;
    section_name: string;
  }>;

  const examComponents = db
    .prepare(
      `SELECT ec.id as exam_component_id, ec.subject_id, sub.name as subject_name, sub.component_mode,
              COALESCE(es.target_class_ids, '') as target_class_ids,
              COALESCE(sub.applicable_class_ids, '') as applicable_class_ids,
              ec.component_id, ec.component_name, ec.max_marks, es.has_internal_assessment,
              es.ia_notebook_max, es.ia_unit_test_max, es.ia_practical_max, es.ia_participation_max
       FROM examination_components ec
       JOIN subjects sub ON sub.id = ec.subject_id
       JOIN examination_subjects es ON es.id = ec.examination_subject_id
       WHERE ec.examination_id = ? AND COALESCE(sub.is_deleted, 0) = 0
       ORDER BY es.display_order ASC, ec.display_order ASC`
    )
    .all(examinationId) as Array<{
    exam_component_id: number;
    subject_id: number;
    subject_name: string;
    component_mode: string | null;
    target_class_ids: string;
    applicable_class_ids: string;
    component_id: number;
    component_name: string;
    max_marks: number;
    has_internal_assessment: number;
    ia_notebook_max: number;
    ia_unit_test_max: number;
    ia_practical_max: number;
    ia_participation_max: number;
  }>;

  const assignments = db
    .prepare(
      `SELECT ta.subject_id, ta.component_id, ta.class_id, ta.section_id, u.id as teacher_id, u.full_name as teacher_name
       FROM teacher_assignments ta
       JOIN users u ON u.id = ta.teacher_id
       WHERE ta.academic_year = ?`
    )
    .all(exam.academic_year) as Array<{
    subject_id: number;
    component_id: number;
    class_id: number;
    section_id: number;
    teacher_id: number;
    teacher_name: string;
  }>;

  const assignMap = new Map<string, { teacherId: number; teacherName: string }>();
  for (const a of assignments) {
    assignMap.set(`${a.class_id}:${a.section_id}:${a.component_id}`, {
      teacherId: a.teacher_id,
      teacherName: a.teacher_name,
    });
  }

  const hasYearEnrollments =
    (
      db
        .prepare(`SELECT COUNT(*) as cnt FROM student_enrollments WHERE academic_year = ?`)
        .get(exam.academic_year) as { cnt: number }
    ).cnt > 0;

  const activeStudents = (
    hasYearEnrollments
      ? db
          .prepare(
            `SELECT se.student_id, se.class_id, se.section_id
             FROM student_enrollments se
             JOIN students st ON st.id = se.student_id
             WHERE se.academic_year = ? AND se.status = 'active' AND COALESCE(st.is_deleted, 0) = 0`
          )
          .all(exam.academic_year)
      : db
          .prepare(
            `SELECT id as student_id, class_id, section_id
             FROM students
             WHERE status = 'active' AND COALESCE(is_deleted, 0) = 0`
          )
          .all()
  ) as Array<{ student_id: number; class_id: number; section_id: number }>;

  const studentsBySection = new Map<string, number[]>();
  const activeStudentSet = new Set<number>();
  for (const st of activeStudents) {
    activeStudentSet.add(st.student_id);
    const key = `${st.class_id}:${st.section_id}`;
    if (!studentsBySection.has(key)) studentsBySection.set(key, []);
    studentsBySection.get(key)!.push(st.student_id);
  }

  // Per-student custom subjects + opt-outs + electives
  const customSubsMap = new Map<number, Set<number>>();
  const yearSubRows = db
    .prepare(`SELECT student_id, subject_id FROM student_year_subjects WHERE academic_year = ?`)
    .all(exam.academic_year) as Array<{ student_id: number; subject_id: number }>;
  for (const r of yearSubRows) {
    if (!activeStudentSet.has(r.student_id)) continue;
    if (!customSubsMap.has(r.student_id)) customSubsMap.set(r.student_id, new Set());
    customSubsMap.get(r.student_id)!.add(r.subject_id);
  }
  const baseSubRows = db
    .prepare(`SELECT student_id, subject_id FROM student_subjects`)
    .all() as Array<{ student_id: number; subject_id: number }>;
  for (const r of baseSubRows) {
    if (!activeStudentSet.has(r.student_id) || customSubsMap.has(r.student_id)) continue;
    if (!customSubsMap.has(r.student_id)) customSubsMap.set(r.student_id, new Set());
    customSubsMap.get(r.student_id)!.add(r.subject_id);
  }

  const optOutSet = new Set<string>();
  const optOutRows = db
    .prepare(`SELECT student_id, subject_id FROM student_elective_opt_outs WHERE academic_year = ?`)
    .all(exam.academic_year) as Array<{ student_id: number; subject_id: number }>;
  for (const r of optOutRows) {
    optOutSet.add(`${r.student_id}:${r.subject_id}`);
  }

  const electiveMap = new Map<string, number>();
  const baseElectives = db
    .prepare(`SELECT student_id, subject_id, component_id FROM student_electives`)
    .all() as Array<{ student_id: number; subject_id: number; component_id: number }>;
  for (const er of baseElectives) {
    if (activeStudentSet.has(er.student_id)) {
      electiveMap.set(`${er.student_id}:${er.subject_id}`, er.component_id);
    }
  }
  const yearElectives = db
    .prepare(`SELECT student_id, subject_id, component_id FROM student_year_electives WHERE academic_year = ?`)
    .all(exam.academic_year) as Array<{ student_id: number; subject_id: number; component_id: number }>;
  for (const er of yearElectives) {
    if (activeStudentSet.has(er.student_id)) {
      electiveMap.set(`${er.student_id}:${er.subject_id}`, er.component_id);
    }
  }

  // Raw marks & IA rows for exact matching with enrolled roster
  const rawMarks = db
    .prepare(
      `SELECT student_id, examination_component_id, obtained_marks, attendance_status, status, updated_at
       FROM marks
       WHERE examination_id = ?`
    )
    .all(examinationId) as Array<{
    student_id: number;
    examination_component_id: number;
    obtained_marks: number | null;
    attendance_status: string | null;
    status: 'draft' | 'submitted';
    updated_at: string | null;
  }>;
  const markLookup = new Map<string, (typeof rawMarks)[number]>();
  for (const m of rawMarks) {
    markLookup.set(`${m.student_id}:${m.examination_component_id}`, m);
  }

  const rawIa = db
    .prepare(
      `SELECT student_id, subject_id, notebook_marks, unit_test_marks, practical_marks, participation_marks,
              status, nb_status, ut_status, pr_status, op_status
       FROM internal_assessment_marks
       WHERE examination_id = ?`
    )
    .all(examinationId) as Array<{
    student_id: number;
    subject_id: number;
    notebook_marks: number | null;
    unit_test_marks: number | null;
    practical_marks: number | null;
    participation_marks: number | null;
    status: string;
    nb_status: string | null;
    ut_status: string | null;
    pr_status: string | null;
    op_status: string | null;
  }>;
  const iaLookup = new Map<string, (typeof rawIa)[number]>();
  for (const r of rawIa) {
    iaLookup.set(`${r.student_id}:${r.subject_id}`, r);
  }

  const rows: MonitoringRow[] = [];
  for (const sec of sections) {
    const secStudents = studentsBySection.get(`${sec.class_id}:${sec.section_id}`) || [];
    for (const ec of examComponents) {
      if (!doesSubjectApplyToClass(ec.target_class_ids || ec.applicable_class_ids, sec.class_id)) {
        continue;
      }

      const assigned = assignMap.get(`${sec.class_id}:${sec.section_id}:${ec.component_id}`);
      const isElective = ec.component_mode === 'elective';

      // Determine enrolled student subset for this (section, component)
      const subjectStudents = secStudents.filter((sid) => {
        const cset = customSubsMap.get(sid);
        if (cset && cset.size > 0 && !cset.has(ec.subject_id)) return false;
        if (isElective && optOutSet.has(`${sid}:${ec.subject_id}`)) return false;
        return true;
      });

      const hasAnyElectiveChoiceInSection =
        isElective && subjectStudents.some((sid) => electiveMap.has(`${sid}:${ec.subject_id}`));

      const eligibleStudents = hasAnyElectiveChoiceInSection
        ? subjectStudents.filter((sid) => electiveMap.get(`${sid}:${ec.subject_id}`) === ec.component_id)
        : subjectStudents;

      const totalStudents = eligibleStudents.length;
      let entered = 0;
      let present = 0;
      let absent = 0;
      let submitted = 0;
      let draft = 0;
      let lastUpdatedAt: string | null = null;

      let iaSubmittedCount = 0;
      let iaAnyCount = 0;
      const hasIa = Boolean(ec.has_internal_assessment);

      for (const sid of eligibleStudents) {
        const m = markLookup.get(`${sid}:${ec.exam_component_id}`);
        if (m) {
          const isAbsent = m.attendance_status === 'absent';
          const isPresent = m.obtained_marks !== null && !isAbsent;
          if (isAbsent || isPresent) {
            entered++;
            if (isAbsent) absent++;
            else present++;
            if (m.status === 'submitted') submitted++;
            else if (m.status === 'draft') draft++;
          }
          if (m.updated_at && (!lastUpdatedAt || m.updated_at > lastUpdatedAt)) {
            lastUpdatedAt = m.updated_at;
          }
        }

        if (hasIa) {
          const ia = iaLookup.get(`${sid}:${ec.subject_id}`);
          if (ia) {
            const anyEntered =
              ia.notebook_marks !== null ||
              ia.unit_test_marks !== null ||
              ia.practical_marks !== null ||
              ia.participation_marks !== null;
            if (anyEntered) iaAnyCount++;
            const nbSub =
              ec.ia_notebook_max <= 0 ||
              (ia.notebook_marks !== null && (ia.nb_status === 'submitted' || ia.status === 'submitted'));
            const utSub =
              ec.ia_unit_test_max <= 0 ||
              (ia.unit_test_marks !== null && (ia.ut_status === 'submitted' || ia.status === 'submitted'));
            const prSub =
              ec.ia_practical_max <= 0 ||
              (ia.practical_marks !== null && (ia.pr_status === 'submitted' || ia.status === 'submitted'));
            const opSub =
              ec.ia_participation_max <= 0 ||
              (ia.participation_marks !== null && (ia.op_status === 'submitted' || ia.status === 'submitted'));
            if (nbSub && utSub && prSub && opSub) {
              iaSubmittedCount++;
            }
          }
        }
      }

      const missing = Math.max(0, totalStudents - entered);

      let submissionStatus: 'Submitted' | 'Draft' | 'Pending' = 'Pending';
      if (totalStudents > 0 && submitted >= totalStudents) {
        submissionStatus = 'Submitted';
      } else if (entered > 0 || submitted > 0) {
        submissionStatus = 'Draft';
      }

      let iaStatus: 'Submitted' | 'Draft' | 'Pending' | 'N/A' = 'N/A';
      if (hasIa) {
        if (totalStudents > 0 && iaSubmittedCount >= totalStudents) {
          iaStatus = 'Submitted';
        } else if (iaAnyCount > 0) {
          iaStatus = 'Draft';
        } else {
          iaStatus = 'Pending';
        }
      }

      rows.push({
        examinationId: exam.id,
        examinationName: exam.name,
        classId: sec.class_id,
        className: sec.class_name,
        hasSections: Boolean(sec.has_sections ?? 1),
        sectionId: sec.section_id,
        sectionName: sec.section_name,
        subjectId: ec.subject_id,
        subjectName: ec.subject_name,
        examComponentId: ec.exam_component_id,
        componentId: ec.component_id,
        componentName: ec.component_name,
        maxMarks: ec.max_marks,
        teacherId: assigned?.teacherId ?? null,
        teacherName: assigned?.teacherName ?? null,
        totalStudents,
        enteredCount: entered,
        presentCount: present,
        absentCount: absent,
        submittedCount: submitted,
        draftCount: draft,
        missingCount: missing,
        submissionStatus,
        hasInternalAssessment: hasIa,
        iaStatus,
        lastUpdatedAt,
      });
    }
  }

  return rows;
}
