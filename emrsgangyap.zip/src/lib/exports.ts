import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';
import ExcelJS from 'exceljs';
import type {
  AdminSubjectExcelPayload,
  CombinedTermClassReport,
  CombinedTermStudentResult,
  CombinedTermSubjectRow,
  ConsolidatedClassReport,
  ConsolidatedStudentResult,
  ConsolidatedSubjectResult,
  MonitoringRow,
  SchoolInfo,
  TeacherExcelExportPayload,
} from '../types';
import {
  STANDARD_GRADING_SCALE,
  buildExcelGradeFormula,
  calculateStandardGrade,
  formatClassSectionLabel,
} from './grading';
import { CO_SCHOLASTIC_SECTIONS } from './coScholastic';
import { formatResultDateDisplay } from './photoUpload';
import { resolveLogoSource } from '../components/SchoolLogo';

// ==========================================
// EXCEL HELPER UTILITIES (ExcelJS)
// ==========================================

function colLetter(colNumber: number): string {
  let n = colNumber;
  let result = '';
  while (n > 0) {
    const rem = (n - 1) % 26;
    result = String.fromCharCode(65 + rem) + result;
    n = Math.floor((n - 1) / 26);
  }
  return result;
}

function makeUniqueSheetName(raw: string, usedNames: Set<string>): string {
  const cleaned = raw.replace(/[\\/?*[\]:]/g, ' ').replace(/\s+/g, ' ').trim() || 'Sheet';
  let candidate = cleaned.slice(0, 31).trim();
  if (!usedNames.has(candidate.toLowerCase())) {
    usedNames.add(candidate.toLowerCase());
    return candidate;
  }
  let counter = 2;
  while (true) {
    const suffix = ` (${counter})`;
    const base = cleaned.slice(0, Math.max(1, 31 - suffix.length)).trim();
    candidate = `${base}${suffix}`;
    if (!usedNames.has(candidate.toLowerCase())) {
      usedNames.add(candidate.toLowerCase());
      return candidate;
    }
    counter++;
  }
}

const THIN_BORDER: Partial<ExcelJS.Borders> = {
  top: { style: 'thin', color: { argb: 'FFCBD5E1' } },
  left: { style: 'thin', color: { argb: 'FFCBD5E1' } },
  bottom: { style: 'thin', color: { argb: 'FFCBD5E1' } },
  right: { style: 'thin', color: { argb: 'FFCBD5E1' } },
};

function styleAndFinalizeWorksheet(
  ws: ExcelJS.Worksheet,
  headers: string[],
  options?: {
    freezeHeader?: boolean;
    autoFilter?: boolean;
    rightAlignCols?: Set<number>;
    centerAlignCols?: Set<number>;
    gradeCols?: Set<number>;
  }
) {
  const freezeHeader = options?.freezeHeader !== false;
  const autoFilter = options?.autoFilter !== false;
  const colCount = headers.length;

  const headerRow = ws.getRow(1);
  headerRow.height = 26;
  headerRow.eachCell({ includeEmpty: false }, (cell) => {
    cell.font = { name: 'Calibri', size: 11, bold: true, color: { argb: 'FFFFFFFF' } };
    cell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FF1E3A5F' } };
    cell.alignment = { vertical: 'middle', horizontal: 'center', wrapText: true };
    cell.border = THIN_BORDER;
  });

  const maxLengths = headers.map((h) => Math.max(10, ...h.split('\n').map((l) => l.length)));

  ws.eachRow({ includeEmpty: false }, (row, rowNumber) => {
    if (rowNumber === 1) return;
    row.height = 20;
    const isEven = rowNumber % 2 === 0;
    row.eachCell({ includeEmpty: true }, (cell, colNumber) => {
      if (colNumber > colCount) return;
      cell.border = THIN_BORDER;

      const rawVal = cell.value;
      const resolvedVal =
        rawVal && typeof rawVal === 'object' && 'result' in rawVal ? (rawVal as any).result : rawVal;
      const textStr = resolvedVal !== null && resolvedVal !== undefined ? String(resolvedVal) : '';

      maxLengths[colNumber - 1] = Math.max(maxLengths[colNumber - 1], Math.min(40, textStr.length));

      let fillColor = isEven ? 'FFFFFFFF' : 'FFF8FAFC';
      let fontColor = 'FF0F172A';
      let isBold = false;

      if (options?.gradeCols?.has(colNumber)) {
        isBold = true;
        if (textStr === 'A1' || textStr === 'A2') {
          fillColor = 'FFECFDF5';
          fontColor = 'FF065F46';
        } else if (textStr === 'B1' || textStr === 'B2') {
          fillColor = 'FFF0F9FF';
          fontColor = 'FF075985';
        } else if (textStr === 'C1' || textStr === 'C2') {
          fillColor = 'FFEEF2FF';
          fontColor = 'FF3730A3';
        } else if (textStr === 'E' || textStr === 'AB' || textStr === 'Fail') {
          fillColor = 'FFFEF2F2';
          fontColor = 'FF991B1B';
        } else if (textStr === 'Pending' || textStr === 'Not Submitted' || textStr === 'Incomplete') {
          fillColor = 'FFFFFBEB';
          fontColor = 'FF92400E';
        }
      } else if (textStr === 'AB' || textStr === 'Absent' || textStr === 'Fail') {
        fillColor = 'FFFEF2F2';
        fontColor = 'FF991B1B';
        isBold = true;
      } else if (textStr === 'Pending' || textStr === 'Not Submitted' || textStr === 'Incomplete') {
        fillColor = 'FFFFFBEB';
        fontColor = 'FF92400E';
      }

      cell.font = { name: 'Calibri', size: 10.5, bold: isBold, color: { argb: fontColor } };
      cell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: fillColor } };

      if (typeof resolvedVal === 'number') {
        cell.numFmt = '0.##';
      }

      const horizontal = options?.centerAlignCols?.has(colNumber)
        ? 'center'
        : options?.rightAlignCols?.has(colNumber) || typeof resolvedVal === 'number'
          ? 'right'
          : 'left';
      cell.alignment = { vertical: 'middle', horizontal };
    });
  });

  for (let i = 0; i < colCount; i++) {
    const col = ws.getColumn(i + 1);
    col.width = Math.min(44, Math.max(12, maxLengths[i] + 4));
  }

  if (freezeHeader) {
    ws.views = [{ state: 'frozen', ySplit: 1 }];
  }
  if (autoFilter && colCount > 0) {
    ws.autoFilter = {
      from: { row: 1, column: 1 },
      to: { row: 1, column: colCount },
    };
  }
}

async function triggerExcelDownload(wb: ExcelJS.Workbook, filename: string) {
  const buffer = await wb.xlsx.writeBuffer();
  const blob = new Blob([buffer], {
    type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
  });
  const url = URL.createObjectURL(blob);
  const anchor = document.createElement('a');
  anchor.href = url;
  anchor.download = filename;
  document.body.appendChild(anchor);
  anchor.click();
  anchor.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}

function getSubjectExternalDisplay(sub: ConsolidatedSubjectResult): number | string {
  const isAbsent = sub.components.some((c) => c.attendanceStatus === 'absent');
  if (isAbsent) return 'AB';
  if (sub.writtenObtainedMarks !== null && sub.writtenObtainedMarks !== undefined) {
    return sub.writtenObtainedMarks;
  }
  return 'Pending';
}

function getSubjectIaDisplay(sub: ConsolidatedSubjectResult): number | string {
  if (!sub.hasInternalAssessment) return 'N/A';
  if (sub.iaTotalMarks !== null && sub.iaTotalMarks !== undefined) {
    return sub.iaTotalMarks;
  }
  return 'Pending';
}

function getSubjectDisplayGrade(sub: ConsolidatedSubjectResult): string {
  if (sub.grade) return sub.grade;
  if (sub.gradeStatus === 'absent' || sub.components.some((c) => c.attendanceStatus === 'absent')) return 'AB';
  if (sub.gradeStatus === 'not_submitted') return 'Not Submitted';
  return 'Pending';
}

// ==========================================
// TEACHER SUBJECT EXCEL EXPORT
// ==========================================

export function buildTeacherMarksWorkbook(
  payload: TeacherExcelExportPayload,
  schoolInfo?: Pick<SchoolInfo, 'schoolName'>
): ExcelJS.Workbook {
  const wb = new ExcelJS.Workbook();
  wb.creator = schoolInfo?.schoolName || 'EMRS Gangyap Portal';
  wb.created = new Date();
  const usedNames = new Set<string>();

  for (const sheet of payload.sheets) {
    const classShort =
      sheet.hasSections === false
        ? sheet.className.replace('Class ', 'C')
        : `${sheet.className.replace('Class ', 'C')}-${sheet.sectionName}`;
    const rawTab =
      payload.sheets.length === 1
        ? `${sheet.subjectName}`
        : `${classShort} ${
            sheet.hasComponents && sheet.componentMode === 'combined'
              ? sheet.componentName
              : sheet.subjectCode || sheet.subjectName
          }`;
    const ws = wb.addWorksheet(makeUniqueSheetName(rawTab, usedNames));

    const isCombinedSubPart = sheet.hasComponents && sheet.componentMode === 'combined';
    const headers: string[] = [
      'Roll No',
      'Student ID',
      'Student Name',
      'Class & Section',
      'Subject Name',
      `External Marks (/${sheet.subjectWrittenMaxMarks})`,
      sheet.iaEnabled ? `Internal Assessment (/${sheet.iaMaxMarks})` : 'Internal Assessment',
      `Total Marks (/${sheet.subjectTotalMaxMarks})`,
      'Grade',
      'Status',
      'Academic Year',
      'Examination Name',
    ];

    if (isCombinedSubPart) {
      headers.push(`${sheet.componentName} Marks (/${sheet.writtenMaxMarks})`);
    }
    if (sheet.iaEnabled) {
      if (sheet.iaNotebookMax > 0) headers.push(`Notebook (/${sheet.iaNotebookMax})`);
      if (sheet.iaUnitTestMax > 0) headers.push(`Unit Test (/${sheet.iaUnitTestMax})`);
      if (sheet.iaPracticalMax > 0) headers.push(`Practical (/${sheet.iaPracticalMax})`);
      if (sheet.iaParticipationMax > 0) headers.push(`Participation (/${sheet.iaParticipationMax})`);
    }

    ws.addRow(headers);

    sheet.rows.forEach((r, idx) => {
      const excelRowNum = idx + 2; // Row 1 is headers
      const extCellVal: number | string =
        r.attendanceStatus === 'absent'
          ? 'AB'
          : r.subjectExternalMarks !== null
            ? r.subjectExternalMarks
            : r.submissionStatus === 'Not Submitted'
              ? 'Not Submitted'
              : 'Pending';

      const iaCellVal: number | string = !sheet.iaEnabled
        ? 'N/A'
        : r.iaTotalMarks !== null
          ? r.iaTotalMarks
          : r.submissionStatus === 'Not Submitted'
            ? 'Not Submitted'
            : 'Pending';

      const missingText = r.submissionStatus === 'Not Submitted' ? 'Not Submitted' : 'Pending';

      const totalCached: number | string =
        r.gradeStatus === 'absent' ? 'AB' : r.totalMarks !== null ? r.totalMarks : missingText;

      const totalFormula = sheet.iaEnabled
        ? `=IF(OR(F${excelRowNum}="AB",G${excelRowNum}="AB"),"AB",IF(AND(ISNUMBER(F${excelRowNum}),ISNUMBER(G${excelRowNum})),F${excelRowNum}+G${excelRowNum},"${missingText}"))`
        : `=IF(F${excelRowNum}="AB","AB",IF(ISNUMBER(F${excelRowNum}),F${excelRowNum},"${missingText}"))`;

      const gradeCached =
        r.gradeStatus === 'absent'
          ? 'AB'
          : r.grade
            ? r.grade
            : r.gradeStatus === 'not_submitted'
              ? 'Not Submitted'
              : 'Pending';

      const gradeFormula = buildExcelGradeFormula(`H${excelRowNum}`, sheet.subjectTotalMaxMarks, missingText);

      const rowValues: any[] = [
        r.rollNumber,
        r.studentCode,
        r.studentName,
        formatClassSectionLabel(r.className, r.sectionName, r.hasSections ?? sheet.hasSections ?? true),
        r.hasOwnProperty('componentName') && sheet.hasComponents && sheet.componentMode === 'elective'
          ? `${r.subjectName} (${r.componentName})`
          : r.subjectName,
        extCellVal,
        iaCellVal,
        { formula: totalFormula, result: totalCached },
        { formula: gradeFormula, result: gradeCached },
        r.submissionStatus,
        sheet.academicYear,
        sheet.examinationName,
      ];

      if (isCombinedSubPart) {
        rowValues.push(
          r.attendanceStatus === 'absent' ? 'AB' : r.writtenMarks !== null ? r.writtenMarks : missingText
        );
      }
      if (sheet.iaEnabled) {
        if (sheet.iaNotebookMax > 0) rowValues.push(r.iaNotebookMarks ?? missingText);
        if (sheet.iaUnitTestMax > 0) rowValues.push(r.iaUnitTestMarks ?? missingText);
        if (sheet.iaPracticalMax > 0) rowValues.push(r.iaPracticalMarks ?? missingText);
        if (sheet.iaParticipationMax > 0) rowValues.push(r.iaParticipationMarks ?? missingText);
      }

      ws.addRow(rowValues);
    });

    styleAndFinalizeWorksheet(ws, headers, {
      freezeHeader: true,
      autoFilter: true,
      rightAlignCols: new Set([6, 7, 8]),
      centerAlignCols: new Set([1, 9, 10, 11]),
      gradeCols: new Set([9]),
    });
  }

  // Add Grading Scale & Metadata Reference Sheet
  const infoWs = wb.addWorksheet(makeUniqueSheetName('Report Info & Scale', usedNames));
  const infoHeaders = ['Field / Grade', 'Details / Range', 'Remark'];
  infoWs.addRow(infoHeaders);
  infoWs.addRow(['School Name', schoolInfo?.schoolName || 'EMRS Gangyap', '']);
  infoWs.addRow(['Teacher', payload.teacherName, '']);
  infoWs.addRow(['Examination', payload.examinationName, '']);
  infoWs.addRow(['Academic Year', payload.academicYear, '']);
  infoWs.addRow(['Generated At', new Date(payload.generatedAt).toLocaleString(), '']);
  infoWs.addRow(['', '', '']);
  infoWs.addRow(['Grade', 'Marks Range (Out of 100)', 'Remark']);
  for (const g of STANDARD_GRADING_SCALE) {
    infoWs.addRow([g.grade, `${g.minPct} - ${Math.round(g.maxPct)}`, g.remark]);
  }
  styleAndFinalizeWorksheet(infoWs, infoHeaders, { freezeHeader: true, autoFilter: false });

  return wb;
}

export async function exportTeacherMarksExcel(
  payload: TeacherExcelExportPayload,
  schoolInfo?: Pick<SchoolInfo, 'schoolName'>
): Promise<string> {
  const wb = buildTeacherMarksWorkbook(payload, schoolInfo);
  const first = payload.sheets[0];
  const safeExam = payload.examinationName.replace(/\s+/g, '_');
  const classFilePart = first
    ? first.hasSections === false
      ? first.className.replace(/\s+/g, '')
      : `${first.className.replace(/\s+/g, '')}_${first.sectionName}`
    : '';
  const filename =
    payload.sheets.length === 1 && first
      ? `${first.subjectName.replace(/\s+/g, '_')}_${classFilePart}_${safeExam}.xlsx`
      : `Teacher_Marks_${payload.academicYear}_${safeExam}.xlsx`;
  await triggerExcelDownload(wb, filename);
  return filename;
}

// ==========================================
// CLASS TEACHER / ADMIN CONSOLIDATED EXCEL
// ==========================================

function populateSubjectDetailWorksheet(
  ws: ExcelJS.Worksheet,
  subjectMeta: ConsolidatedClassReport['subjects'][number],
  report: ConsolidatedClassReport
) {
  const headers: string[] = [
    'Roll No',
    'Student ID',
    'Student Name',
    'Class & Section',
    'Subject Name',
    `External Marks (/${subjectMeta.writtenMaxMarks})`,
    subjectMeta.hasInternalAssessment
      ? `Internal Assessment (/${subjectMeta.iaMaxMarks})`
      : 'Internal Assessment',
    `Total Marks (/${subjectMeta.maxMarks})`,
    'Grade',
    'Result Status',
    'Academic Year',
    'Examination Name',
  ];

  if (subjectMeta.componentMode === 'combined' && subjectMeta.components.length > 1) {
    for (const c of subjectMeta.components) {
      headers.push(`${c.componentName} (/${c.maxMarks})`);
    }
  }
  if (subjectMeta.hasInternalAssessment) {
    if (subjectMeta.iaNotebookMax > 0) headers.push(`Notebook (/${subjectMeta.iaNotebookMax})`);
    if (subjectMeta.iaUnitTestMax > 0) headers.push(`Unit Test (/${subjectMeta.iaUnitTestMax})`);
    if (subjectMeta.iaPracticalMax > 0) headers.push(`Practical (/${subjectMeta.iaPracticalMax})`);
    if (subjectMeta.iaParticipationMax > 0) headers.push(`Participation (/${subjectMeta.iaParticipationMax})`);
  }

  ws.addRow(headers);

  let excelRowNum = 2;
  for (const st of report.students) {
    const sub = st.subjects.find((s) => s.subjectId === subjectMeta.subjectId);
    if (!sub || sub.isEnrolled === false || sub.gradeStatus === 'not_applicable') continue;

    const isAbsent = sub.components.some((c) => c.attendanceStatus === 'absent');
    const missingLabel: 'Pending' | 'Not Submitted' =
      sub.gradeStatus === 'not_submitted' ? 'Not Submitted' : 'Pending';
    const extVal = getSubjectExternalDisplay(sub);
    const iaVal = getSubjectIaDisplay(sub);

    const totalFormula = sub.hasInternalAssessment
      ? `=IF(OR(F${excelRowNum}="AB",G${excelRowNum}="AB"),"AB",IF(AND(ISNUMBER(F${excelRowNum}),ISNUMBER(G${excelRowNum})),F${excelRowNum}+G${excelRowNum},"${missingLabel}"))`
      : `=IF(F${excelRowNum}="AB","AB",IF(ISNUMBER(F${excelRowNum}),F${excelRowNum},"${missingLabel}"))`;

    const totalCached = isAbsent
      ? 'AB'
      : sub.isComplete && sub.obtainedMarks !== null
        ? sub.obtainedMarks
        : missingLabel;

    const gradeFormula = buildExcelGradeFormula(`H${excelRowNum}`, sub.maxMarks, missingLabel);
    const gradeCached = getSubjectDisplayGrade(sub);
    const resultLabel = isAbsent
      ? 'Absent'
      : sub.isComplete
        ? sub.isPassed
          ? 'Pass'
          : 'Fail'
        : missingLabel;

    const rowValues: any[] = [
      st.rollNumber,
      st.studentCode,
      st.studentName,
      formatClassSectionLabel(
        report.classInfo.className,
        report.classInfo.sectionName,
        report.classInfo.hasSections ?? true
      ),
      sub.selectedComponentName ? `${sub.subjectName} (${sub.selectedComponentName})` : sub.subjectName,
      extVal === 'Pending' ? missingLabel : extVal,
      iaVal === 'Pending' ? missingLabel : iaVal,
      { formula: totalFormula, result: totalCached },
      { formula: gradeFormula, result: gradeCached },
      resultLabel,
      report.examination.academicYear,
      report.examination.name,
    ];

    if (subjectMeta.componentMode === 'combined' && subjectMeta.components.length > 1) {
      for (const c of sub.components) {
        rowValues.push(
          c.attendanceStatus === 'absent' ? 'AB' : c.obtainedMarks !== null ? c.obtainedMarks : missingLabel
        );
      }
    }
    if (subjectMeta.hasInternalAssessment) {
      if (subjectMeta.iaNotebookMax > 0) rowValues.push(sub.iaNotebookMarks ?? missingLabel);
      if (subjectMeta.iaUnitTestMax > 0) rowValues.push(sub.iaUnitTestMarks ?? missingLabel);
      if (subjectMeta.iaPracticalMax > 0) rowValues.push(sub.iaPracticalMarks ?? missingLabel);
      if (subjectMeta.iaParticipationMax > 0) rowValues.push(sub.iaParticipationMarks ?? missingLabel);
    }

    ws.addRow(rowValues);
    excelRowNum++;
  }

  styleAndFinalizeWorksheet(ws, headers, {
    freezeHeader: true,
    autoFilter: true,
    rightAlignCols: new Set([6, 7, 8]),
    centerAlignCols: new Set([1, 9, 10, 11]),
    gradeCols: new Set([9]),
  });
}

export function buildConsolidatedWorkbook(
  report: ConsolidatedClassReport,
  schoolInfo: SchoolInfo
): ExcelJS.Workbook {
  const wb = new ExcelJS.Workbook();
  wb.creator = schoolInfo.schoolName || 'EMRS Gangyap Portal';
  wb.created = new Date();
  const usedNames = new Set<string>();

  // ---------------------------------------------------
  // Sheet 1: Consolidated Class Result (All Subjects + Grades + Excel Formulas)
  // ---------------------------------------------------
  const ws1 = wb.addWorksheet(makeUniqueSheetName('Consolidated Class Result', usedNames));
  const headers1: string[] = [
    'Roll No',
    'Student ID',
    'Student Name',
    'Class & Section',
    'Academic Year',
    'Examination',
  ];

  // Track column indices (1-based) for each subject so Excel formulas reference exact cells
  interface SubColMeta {
    extCol: number;
    iaCol: number | null;
    totalCol: number;
    gradeCol: number;
    hasIa: boolean;
    maxMarks: number;
  }
  const subColMetas: SubColMeta[] = [];
  const rightCols1 = new Set<number>();
  const centerCols1 = new Set<number>([1, 5]);
  const gradeCols1 = new Set<number>();

  for (const sub of report.subjects) {
    const extCol = headers1.length + 1;
    headers1.push(`${sub.subjectCode} Ext (/${sub.writtenMaxMarks})`);
    rightCols1.add(extCol);

    let iaCol: number | null = null;
    if (sub.hasInternalAssessment) {
      iaCol = headers1.length + 1;
      headers1.push(`${sub.subjectCode} IA (/${sub.iaMaxMarks})`);
      rightCols1.add(iaCol);
    }

    const totalCol = headers1.length + 1;
    headers1.push(`${sub.subjectName} Total (/${sub.maxMarks})`);
    rightCols1.add(totalCol);

    const gradeCol = headers1.length + 1;
    headers1.push(`${sub.subjectCode} Grade`);
    centerCols1.add(gradeCol);
    gradeCols1.add(gradeCol);

    subColMetas.push({
      extCol,
      iaCol,
      totalCol,
      gradeCol,
      hasIa: sub.hasInternalAssessment,
      maxMarks: sub.maxMarks,
    });
  }

  const grandTotalCol = headers1.length + 1;
  headers1.push(`Grand Total (/${report.summary.totalMaxMarks})`);
  rightCols1.add(grandTotalCol);

  const pctCol = headers1.length + 1;
  headers1.push('Percentage (%)');
  rightCols1.add(pctCol);

  const overallGradeCol = headers1.length + 1;
  headers1.push('Overall Grade');
  centerCols1.add(overallGradeCol);
  gradeCols1.add(overallGradeCol);

  const rankCol = headers1.length + 1;
  headers1.push('Class Rank');
  centerCols1.add(rankCol);

  const resultCol = headers1.length + 1;
  headers1.push('Result Status');
  centerCols1.add(resultCol);

  ws1.addRow(headers1);

  report.students.forEach((st, idx) => {
    const rowNum = idx + 2;
    const rowValues: any[] = [
      st.rollNumber,
      st.studentCode,
      st.studentName,
      formatClassSectionLabel(
        report.classInfo.className,
        report.classInfo.sectionName,
        report.classInfo.hasSections ?? true
      ),
      report.examination.academicYear,
      report.examination.name,
    ];

    const totalColRefs: string[] = [];

    report.subjects.forEach((subMeta, sIdx) => {
      const sub = st.subjects.find((s) => s.subjectId === subMeta.subjectId);
      const colMeta = subColMetas[sIdx];
      const extRef = `${colLetter(colMeta.extCol)}${rowNum}`;
      const totRef = `${colLetter(colMeta.totalCol)}${rowNum}`;

      if (!sub || sub.isEnrolled === false || sub.gradeStatus === 'not_applicable') {
        const placeholder = !sub ? 'Pending' : '—';
        if (!sub) totalColRefs.push(totRef);
        rowValues.push(placeholder);
        if (colMeta.iaCol !== null) rowValues.push(placeholder);
        rowValues.push(placeholder, placeholder);
        return;
      }
      totalColRefs.push(totRef);

      const isAbsent = sub.components.some((c) => c.attendanceStatus === 'absent');
      const missingText: 'Pending' | 'Not Submitted' =
        sub.gradeStatus === 'not_submitted' ? 'Not Submitted' : 'Pending';

      const extVal = getSubjectExternalDisplay(sub);
      rowValues.push(extVal === 'Pending' ? missingText : extVal);

      if (colMeta.iaCol !== null) {
        const iaRef = `${colLetter(colMeta.iaCol)}${rowNum}`;
        const iaVal = getSubjectIaDisplay(sub);
        rowValues.push(iaVal === 'Pending' ? missingText : iaVal);

        const subTotFormula = `=IF(OR(${extRef}="AB",${iaRef}="AB"),"AB",IF(AND(ISNUMBER(${extRef}),ISNUMBER(${iaRef})),${extRef}+${iaRef},"${missingText}"))`;
        const subTotCached = isAbsent
          ? 'AB'
          : sub.isComplete && sub.obtainedMarks !== null
            ? sub.obtainedMarks
            : missingText;
        rowValues.push({ formula: subTotFormula, result: subTotCached });
      } else {
        const subTotFormula = `=IF(${extRef}="AB","AB",IF(ISNUMBER(${extRef}),${extRef},"${missingText}"))`;
        const subTotCached = isAbsent
          ? 'AB'
          : sub.isComplete && sub.obtainedMarks !== null
            ? sub.obtainedMarks
            : missingText;
        rowValues.push({ formula: subTotFormula, result: subTotCached });
      }

      const subGradeFormula = buildExcelGradeFormula(totRef, sub.maxMarks, missingText);
      rowValues.push({ formula: subGradeFormula, result: getSubjectDisplayGrade(sub) });
    });

    const grandTotRef = `${colLetter(grandTotalCol)}${rowNum}`;
    const pctRef = `${colLetter(pctCol)}${rowNum}`;
    const allNumericCond = totalColRefs.map((ref) => `ISNUMBER(${ref})`).join(',');
    const grandTotalFormula =
      totalColRefs.length > 0
        ? `=IF(AND(${allNumericCond}),SUM(${totalColRefs.join(',')}),"Pending")`
        : 0;
    const grandTotalCached = st.grandTotal !== null ? st.grandTotal : 'Pending';
    rowValues.push({ formula: grandTotalFormula, result: grandTotalCached });

    const maxSum = st.totalMaxMarks > 0 ? st.totalMaxMarks : report.summary.totalMaxMarks || 100;
    const pctFormula = `=IF(ISNUMBER(${grandTotRef}),ROUND(${grandTotRef}/${maxSum}*100,2),"Pending")`;
    const pctCached = st.percentage !== null ? st.percentage : 'Pending';
    rowValues.push({ formula: pctFormula, result: pctCached });

    const overallGradeFormula = buildExcelGradeFormula(pctRef, 100, 'Pending');
    const overallGradeCached = st.grade ?? 'Pending';
    rowValues.push({ formula: overallGradeFormula, result: overallGradeCached });

    rowValues.push(st.classRank ?? '—');
    rowValues.push(st.resultStatus);

    ws1.addRow(rowValues);
  });

  styleAndFinalizeWorksheet(ws1, headers1, {
    freezeHeader: true,
    autoFilter: true,
    rightAlignCols: rightCols1,
    centerAlignCols: centerCols1,
    gradeCols: gradeCols1,
  });

  // ---------------------------------------------------
  // Separate Worksheet for Each Subject
  // ---------------------------------------------------
  for (const subjectMeta of report.subjects) {
    const subWs = wb.addWorksheet(makeUniqueSheetName(subjectMeta.subjectName, usedNames));
    populateSubjectDetailWorksheet(subWs, subjectMeta, report);
  }

  // ---------------------------------------------------
  // Subject Analysis Sheet
  // ---------------------------------------------------
  const wsSummary = wb.addWorksheet(makeUniqueSheetName('Subject Analysis', usedNames));
  const summaryHeaders = [
    'Subject',
    'Max Marks',
    'Completed Students',
    'Average Marks',
    'Average (%)',
    'Class Avg Grade',
    'Highest Marks',
    'Lowest Marks',
    'Pass Rate (%)',
  ];
  wsSummary.addRow(summaryHeaders);

  report.subjectPerformance.forEach((sp, idx) => {
    const rowNum = idx + 2;
    const avgPctVal = sp.averagePercentage ?? 'Pending';
    const avgGradeCached =
      sp.averagePercentage !== null ? calculateStandardGrade(sp.averagePercentage).grade : 'Pending';
    const avgGradeFormula = buildExcelGradeFormula(`E${rowNum}`, 100, 'Pending');

    wsSummary.addRow([
      sp.subjectName,
      sp.maxMarks,
      `${sp.completedStudents}/${report.summary.totalStudents}`,
      sp.averageMarks ?? 'Pending',
      avgPctVal,
      { formula: avgGradeFormula, result: avgGradeCached },
      sp.highestMarks ?? '—',
      sp.lowestMarks ?? '—',
      sp.passRate ?? '—',
    ]);
  });

  styleAndFinalizeWorksheet(wsSummary, summaryHeaders, {
    freezeHeader: true,
    autoFilter: true,
    rightAlignCols: new Set([2, 4, 5, 7, 8, 9]),
    centerAlignCols: new Set([3, 6]),
    gradeCols: new Set([6]),
  });

  // ---------------------------------------------------
  // Report Metadata & Grading Scale Sheet
  // ---------------------------------------------------
  const wsMeta = wb.addWorksheet(makeUniqueSheetName('Report Info & Scale', usedNames));
  const metaHeaders = ['Field / Grade', 'Value / Range', 'Remark'];
  wsMeta.addRow(metaHeaders);
  wsMeta.addRow(['School Name', schoolInfo.schoolName, '']);
  wsMeta.addRow(['Examination', report.examination.name, '']);
  wsMeta.addRow(['Academic Year', report.examination.academicYear, '']);
  wsMeta.addRow([
    'Class & Section',
    formatClassSectionLabel(
      report.classInfo.className,
      report.classInfo.sectionName,
      report.classInfo.hasSections ?? true
    ),
    '',
  ]);
  wsMeta.addRow(['Class Teacher', report.classInfo.classTeacherName || 'Unassigned', '']);
  wsMeta.addRow(['Total Students', report.summary.totalStudents, '']);
  wsMeta.addRow(['Pass / Fail / Incomplete', `${report.summary.passCount} / ${report.summary.failCount} / ${report.summary.incompleteCount}`, '']);
  wsMeta.addRow(['', '', '']);
  wsMeta.addRow(['Grade', 'Percentage Range', 'Remark']);
  for (const g of STANDARD_GRADING_SCALE) {
    wsMeta.addRow([g.grade, `${g.minPct} - ${Math.round(g.maxPct)}`, g.remark]);
  }
  styleAndFinalizeWorksheet(wsMeta, metaHeaders, { freezeHeader: true, autoFilter: false });

  return wb;
}

export async function exportConsolidatedExcel(
  report: ConsolidatedClassReport,
  schoolInfo: SchoolInfo
): Promise<string> {
  const wb = buildConsolidatedWorkbook(report, schoolInfo);
  const classPart =
    report.classInfo.hasSections === false
      ? report.classInfo.className.replace(/\s+/g, '')
      : `${report.classInfo.className.replace(/\s+/g, '')}_${report.classInfo.sectionName}`;
  const filename = `${classPart}_${report.examination.name.replace(/\s+/g, '_')}_Class_Result.xlsx`;
  await triggerExcelDownload(wb, filename);
  return filename;
}

export function buildSubjectWiseWorkbook(
  report: ConsolidatedClassReport,
  subjectId: number,
  schoolInfo: SchoolInfo
): ExcelJS.Workbook | null {
  const subjectMeta = report.subjects.find((s) => s.subjectId === subjectId);
  if (!subjectMeta) return null;

  const wb = new ExcelJS.Workbook();
  wb.creator = schoolInfo.schoolName || 'EMRS Gangyap Portal';
  wb.created = new Date();
  const usedNames = new Set<string>();

  const ws = wb.addWorksheet(makeUniqueSheetName(subjectMeta.subjectName, usedNames));
  populateSubjectDetailWorksheet(ws, subjectMeta, report);
  return wb;
}

export async function exportSubjectWiseExcel(
  report: ConsolidatedClassReport,
  subjectId: number,
  schoolInfo: SchoolInfo
): Promise<string | null> {
  const subjectMeta = report.subjects.find((s) => s.subjectId === subjectId);
  const wb = buildSubjectWiseWorkbook(report, subjectId, schoolInfo);
  if (!wb || !subjectMeta) return null;

  const classPart =
    report.classInfo.hasSections === false
      ? report.classInfo.className.replace(/\s+/g, '')
      : `${report.classInfo.className.replace(/\s+/g, '')}_${report.classInfo.sectionName}`;
  const filename = `${subjectMeta.subjectCode}_${classPart}_${report.examination.name.replace(/\s+/g, '_')}.xlsx`;
  await triggerExcelDownload(wb, filename);
  return filename;
}

export function buildAdminSubjectReportWorkbook(
  payload: AdminSubjectExcelPayload,
  schoolInfo: SchoolInfo
): ExcelJS.Workbook {
  const wb = new ExcelJS.Workbook();
  wb.creator = schoolInfo.schoolName || 'EMRS Gangyap Portal';
  wb.created = new Date();
  const usedNames = new Set<string>();

  // Summary worksheet combining all matching sections
  const summaryWs = wb.addWorksheet(makeUniqueSheetName('All Classes Summary', usedNames));
  const summaryHeaders = [
    'Roll No',
    'Student ID',
    'Student Name',
    'Class & Section',
    'Subject Name',
    'External Marks',
    'Internal Assessment',
    'Total Marks',
    'Grade',
    'Result Status',
    'Academic Year',
    'Examination Name',
  ];
  summaryWs.addRow(summaryHeaders);

  let summaryRowIdx = 2;
  for (const sec of payload.sections) {
    for (const st of sec.students) {
      const sub = st.result;
      if (!sub || sub.isEnrolled === false || sub.gradeStatus === 'not_applicable') continue;
      const isAbsent = sub.components.some((c) => c.attendanceStatus === 'absent');
      const missingLabel: 'Pending' | 'Not Submitted' =
        sub.gradeStatus === 'not_submitted' ? 'Not Submitted' : 'Pending';
      const extVal = getSubjectExternalDisplay(sub);
      const iaVal = getSubjectIaDisplay(sub);
      const totFormula = sub.hasInternalAssessment
        ? `=IF(OR(F${summaryRowIdx}="AB",G${summaryRowIdx}="AB"),"AB",IF(AND(ISNUMBER(F${summaryRowIdx}),ISNUMBER(G${summaryRowIdx})),F${summaryRowIdx}+G${summaryRowIdx},"${missingLabel}"))`
        : `=IF(F${summaryRowIdx}="AB","AB",IF(ISNUMBER(F${summaryRowIdx}),F${summaryRowIdx},"${missingLabel}"))`;
      const totCached = isAbsent ? 'AB' : sub.isComplete && sub.obtainedMarks !== null ? sub.obtainedMarks : missingLabel;
      const gradeFormula = buildExcelGradeFormula(`H${summaryRowIdx}`, sub.maxMarks, missingLabel);
      const gradeCached = getSubjectDisplayGrade(sub);
      const resultLabel = isAbsent ? 'Absent' : sub.isComplete ? (sub.isPassed ? 'Pass' : 'Fail') : missingLabel;

      summaryWs.addRow([
        st.rollNumber,
        st.studentCode,
        st.studentName,
        formatClassSectionLabel(sec.className, sec.sectionName, sec.hasSections ?? true),
        sub.selectedComponentName ? `${sub.subjectName} (${sub.selectedComponentName})` : sub.subjectName,
        extVal === 'Pending' ? missingLabel : extVal,
        iaVal === 'Pending' ? missingLabel : iaVal,
        { formula: totFormula, result: totCached },
        { formula: gradeFormula, result: gradeCached },
        resultLabel,
        payload.academicYear,
        payload.examinationName,
      ]);
      summaryRowIdx++;
    }
  }

  styleAndFinalizeWorksheet(summaryWs, summaryHeaders, {
    freezeHeader: true,
    autoFilter: true,
    rightAlignCols: new Set([6, 7, 8]),
    centerAlignCols: new Set([1, 9, 10, 11]),
    gradeCols: new Set([9]),
  });

  // Separate sheet per class/section/subject
  for (const sec of payload.sections) {
    const enrolledStudents = sec.students.filter(
      (st) => st.result && st.result.isEnrolled !== false && st.result.gradeStatus !== 'not_applicable'
    );
    if (enrolledStudents.length === 0) continue;
    const classPrefix =
      sec.hasSections === false
        ? sec.className.replace('Class ', 'C')
        : `${sec.className.replace('Class ', 'C')}-${sec.sectionName}`;
    const tabTitle = payload.subjectId
      ? classPrefix
      : `${classPrefix} ${sec.subject.subjectCode}`;
    const ws = wb.addWorksheet(makeUniqueSheetName(tabTitle, usedNames));
    const subMeta = sec.subject;
    const headers = [
      'Roll No',
      'Student ID',
      'Student Name',
      'Class & Section',
      'Subject Name',
      `External Marks (/${subMeta.writtenMaxMarks})`,
      subMeta.hasInternalAssessment ? `Internal Assessment (/${subMeta.iaMaxMarks})` : 'Internal Assessment',
      `Total Marks (/${subMeta.maxMarks})`,
      'Grade',
      'Result Status',
      'Academic Year',
      'Examination Name',
    ];
    ws.addRow(headers);

    let rNum = 2;
    for (const st of enrolledStudents) {
      const sub = st.result;
      const isAbsent = sub.components.some((c) => c.attendanceStatus === 'absent');
      const missingLabel: 'Pending' | 'Not Submitted' =
        sub.gradeStatus === 'not_submitted' ? 'Not Submitted' : 'Pending';
      const extVal = getSubjectExternalDisplay(sub);
      const iaVal = getSubjectIaDisplay(sub);
      const totFormula = sub.hasInternalAssessment
        ? `=IF(OR(F${rNum}="AB",G${rNum}="AB"),"AB",IF(AND(ISNUMBER(F${rNum}),ISNUMBER(G${rNum})),F${rNum}+G${rNum},"${missingLabel}"))`
        : `=IF(F${rNum}="AB","AB",IF(ISNUMBER(F${rNum}),F${rNum},"${missingLabel}"))`;
      const totCached = isAbsent ? 'AB' : sub.isComplete && sub.obtainedMarks !== null ? sub.obtainedMarks : missingLabel;
      const gradeFormula = buildExcelGradeFormula(`H${rNum}`, sub.maxMarks, missingLabel);
      const gradeCached = getSubjectDisplayGrade(sub);
      const resultLabel = isAbsent ? 'Absent' : sub.isComplete ? (sub.isPassed ? 'Pass' : 'Fail') : missingLabel;

      ws.addRow([
        st.rollNumber,
        st.studentCode,
        st.studentName,
        formatClassSectionLabel(sec.className, sec.sectionName, sec.hasSections ?? true),
        sub.selectedComponentName ? `${sub.subjectName} (${sub.selectedComponentName})` : sub.subjectName,
        extVal === 'Pending' ? missingLabel : extVal,
        iaVal === 'Pending' ? missingLabel : iaVal,
        { formula: totFormula, result: totCached },
        { formula: gradeFormula, result: gradeCached },
        resultLabel,
        payload.academicYear,
        payload.examinationName,
      ]);
      rNum++;
    }

    styleAndFinalizeWorksheet(ws, headers, {
      freezeHeader: true,
      autoFilter: true,
      rightAlignCols: new Set([6, 7, 8]),
      centerAlignCols: new Set([1, 9, 10, 11]),
      gradeCols: new Set([9]),
    });
  }

  return wb;
}

export async function exportAdminSubjectReportExcel(
  payload: AdminSubjectExcelPayload,
  schoolInfo: SchoolInfo
): Promise<string> {
  const wb = buildAdminSubjectReportWorkbook(payload, schoolInfo);
  const safeSub = payload.subjectName.replace(/\s+/g, '_');
  const safeExam = payload.examinationName.replace(/\s+/g, '_');
  const filename = `${safeSub}_Report_${payload.academicYear}_${safeExam}.xlsx`;
  await triggerExcelDownload(wb, filename);
  return filename;
}

// ==========================================
// PDF EXPORTS (Updated with Subject-Wise Grades)
// ==========================================

export const CBSE_LOGO_PATH = '/assets/aistudio/CBSE_new_logo.svg_bbab51d4.png';

interface PdfLogoAsset {
  dataUrl: string;
  aspect: number;
}

async function loadPdfLogoAsset(
  logoSrc?: string | null,
  allowDefaultWhenEmpty = true
): Promise<PdfLogoAsset | null> {
  if (typeof window === 'undefined' || typeof Image === 'undefined') return null;
  const resolved = allowDefaultWhenEmpty
    ? resolveLogoSource(logoSrc, true)
    : (logoSrc || '').trim() || null;
  if (!resolved) return null;
  try {
    const img = await new Promise<HTMLImageElement>((resolve, reject) => {
      const el = new Image();
      if (!resolved.startsWith('data:')) {
        el.crossOrigin = 'anonymous';
      }
      el.onload = () => resolve(el);
      el.onerror = () => reject(new Error('Logo image failed to load'));
      el.src = resolved;
    });
    const w = img.naturalWidth || img.width || 160;
    const h = img.naturalHeight || img.height || 160;
    const canvas = document.createElement('canvas');
    canvas.width = w;
    canvas.height = h;
    const ctx = canvas.getContext('2d');
    if (!ctx) return null;
    ctx.fillStyle = '#FFFFFF';
    ctx.fillRect(0, 0, w, h);
    ctx.drawImage(img, 0, 0, w, h);
    return {
      dataUrl: canvas.toDataURL('image/png'),
      aspect: w > 0 && h > 0 ? w / h : 1,
    };
  } catch {
    return null;
  }
}

async function loadPdfLogoDataUrl(logoSrc?: string | null): Promise<string | null> {
  const asset = await loadPdfLogoAsset(logoSrc, true);
  return asset ? asset.dataUrl : null;
}

function drawBoxedPdfLogo(
  doc: jsPDF,
  asset: PdfLogoAsset | null,
  boxX: number,
  boxY: number,
  boxSize: number
): void {
  if (!asset) return;
  doc.setFillColor(255, 255, 255);
  doc.roundedRect(boxX, boxY, boxSize, boxSize, 1.5, 1.5, 'F');
  const innerMax = boxSize - 1.6;
  let drawW = innerMax;
  let drawH = innerMax;
  if (asset.aspect >= 1) {
    drawH = innerMax / asset.aspect;
  } else {
    drawW = innerMax * asset.aspect;
  }
  const drawX = boxX + (boxSize - drawW) / 2;
  const drawY = boxY + (boxSize - drawH) / 2;
  try {
    doc.addImage(asset.dataUrl, 'PNG', drawX, drawY, drawW, drawH);
  } catch {
    // ignore invalid image buffer
  }
}

function drawMarksheetHeaderPDF(
  doc: jsPDF,
  subtitleText: string,
  assets: { cbseLogo: PdfLogoAsset | null; schoolLogo: PdfLogoAsset | null }
): number {
  // Top navy school banner (24.5mm)
  doc.setFillColor(30, 58, 95);
  doc.rect(0, 0, 210, 24.5, 'F');

  // Top-left: Uploaded CBSE logo; Top-right: Earlier school emblem logo
  drawBoxedPdfLogo(doc, assets.cbseLogo, 6.5, 2.25, 20);
  drawBoxedPdfLogo(doc, assets.schoolLogo, 183.5, 2.25, 20);

  // Official Center Header Lines — larger & bold
  doc.setTextColor(255, 255, 255);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(12.8);
  doc.text('Eklavya Model Residential School Gangyap', 105, 5.7, { align: 'center', maxWidth: 150 });

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(8.5);
  doc.text('(NESTS, Ministry of Tribal Affairs, Govt. of India)', 105, 9.9, { align: 'center', maxWidth: 150 });

  doc.setFontSize(8.2);
  doc.text('CBSE School No. 37406. Affiliation No.: 1820172.', 105, 13.9, { align: 'center', maxWidth: 150 });
  doc.text('UDISE: 11020800203', 105, 17.8, { align: 'center', maxWidth: 150 });
  doc.text('estd: 2007.', 105, 21.7, { align: 'center', maxWidth: 150 });

  // Crisp subtitle strip right below header
  doc.setFillColor(22, 78, 99);
  doc.rect(0, 24.5, 210, 5.8, 'F');
  doc.setTextColor(255, 255, 255);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(8.8);
  doc.text(subtitleText, 105, 28.4, { align: 'center', maxWidth: 194 });

  return 31.8;
}

async function loadPdfStudentPhotoDataUrl(photoSrc?: string | null): Promise<string | null> {
  const src = (photoSrc || '').trim();
  if (!src) return null;
  if (typeof window === 'undefined' || typeof Image === 'undefined') {
    if (/^data:image\/(jpeg|jpg|png);base64,/i.test(src)) return src;
    return null;
  }
  try {
    const img = await new Promise<HTMLImageElement>((resolve, reject) => {
      const el = new Image();
      if (!src.startsWith('data:')) {
        el.crossOrigin = 'anonymous';
      }
      el.onload = () => resolve(el);
      el.onerror = () => reject(new Error('Student photo failed to load'));
      el.src = src;
    });
    const w = img.naturalWidth || img.width || 240;
    const h = img.naturalHeight || img.height || 300;
    const canvas = document.createElement('canvas');
    canvas.width = w;
    canvas.height = h;
    const ctx = canvas.getContext('2d');
    if (!ctx) return null;
    ctx.fillStyle = '#FFFFFF';
    ctx.fillRect(0, 0, w, h);
    ctx.drawImage(img, 0, 0, w, h);
    return canvas.toDataURL('image/jpeg', 0.88);
  } catch {
    return /^data:image\/(jpeg|jpg|png);base64,/i.test(src) ? src : null;
  }
}

function formatAttendanceRatio(
  daysAttended?: number | null,
  totalDays?: number | null,
  includePct = false
): string {
  if (daysAttended === null || daysAttended === undefined) {
    if (totalDays !== null && totalDays !== undefined) return `—/${totalDays}`;
    return '—';
  }
  if (totalDays === null || totalDays === undefined) return `${daysAttended}`;
  if (includePct && totalDays > 0) {
    return `${daysAttended}/${totalDays} (${((daysAttended / totalDays) * 100).toFixed(1)}%)`;
  }
  return `${daysAttended}/${totalDays}`;
}

function getScholasticBreakdown(sub: ConsolidatedSubjectResult | null): {
  enrolled: boolean;
  internalTest: string;
  practical: string;
  participation: string;
  termExam: string;
  total: string;
  grade: string;
} {
  if (!sub || sub.isEnrolled === false || sub.gradeStatus === 'not_applicable') {
    return {
      enrolled: false,
      internalTest: '—',
      practical: '—',
      participation: '—',
      termExam: '—',
      total: '—',
      grade: '—',
    };
  }

  const isAbsent = sub.components.some((c) => c.attendanceStatus === 'absent');
  const hasInternalTest = sub.hasInternalAssessment && sub.iaNotebookMax + sub.iaUnitTestMax > 0;
  const internalTest = !hasInternalTest
    ? '—'
    : sub.iaNotebookMarks === null && sub.iaUnitTestMarks === null
      ? '—'
      : String(Number(((sub.iaNotebookMarks ?? 0) + (sub.iaUnitTestMarks ?? 0)).toFixed(2)));

  const practical =
    !sub.hasInternalAssessment || sub.iaPracticalMax <= 0
      ? '—'
      : sub.iaPracticalMarks !== null && sub.iaPracticalMarks !== undefined
        ? String(sub.iaPracticalMarks)
        : '—';

  const participation =
    !sub.hasInternalAssessment || sub.iaParticipationMax <= 0
      ? '—'
      : sub.iaParticipationMarks !== null && sub.iaParticipationMarks !== undefined
        ? String(sub.iaParticipationMarks)
        : '—';

  let termExam = '—';
  if (isAbsent) {
    termExam = 'AB';
  } else if (sub.writtenObtainedMarks !== null && sub.writtenObtainedMarks !== undefined) {
    termExam = String(sub.writtenObtainedMarks);
  } else if (sub.components.length > 0 && sub.components.every((c) => c.obtainedMarks !== null)) {
    termExam = String(
      Number(sub.components.reduce((acc, c) => acc + (c.obtainedMarks ?? 0), 0).toFixed(2))
    );
  } else if (sub.gradeStatus === 'not_submitted') {
    termExam = 'N/S';
  }

  const total = isAbsent
    ? 'AB'
    : sub.isComplete && sub.obtainedMarks !== null
      ? String(sub.obtainedMarks)
      : sub.gradeStatus === 'not_submitted'
        ? 'N/S'
        : 'Pend.';

  const grade = isAbsent
    ? 'AB'
    : sub.isComplete && sub.grade
      ? sub.grade
      : sub.gradeStatus === 'not_submitted'
        ? 'N/S'
        : 'Pend.';

  return {
    enrolled: true,
    internalTest,
    practical,
    participation,
    termExam,
    total,
    grade,
  };
}

function drawCompactStudentDetailsBoxPDF(
  doc: jsPDF,
  startY: number,
  info: {
    studentName: string;
    studentCode: string;
    className: string;
    sectionName: string;
    hasSections: boolean;
    stream?: string;
    rollNumber: number;
    academicYear: string;
    fatherName?: string;
    motherName?: string;
    contactNo?: string;
    aapaarId?: string;
    residentialAddress?: string;
    photoDataUrl?: string | null;
  }
): number {
  const hasPhoto = Boolean(info.photoDataUrl);
  const fullClassText = `${formatClassSectionLabel(info.className, info.sectionName, info.hasSections)}${
    info.stream ? ` (${info.stream})` : ''
  }`;
  const addressText = (info.residentialAddress || '').trim() || '—';
  const addrLines = (doc.splitTextToSize(addressText, hasPhoto ? 132 : 156) as string[]).slice(0, 2);
  const extraAddrHeight = Math.max(0, (addrLines.length - 1) * 3.5);
  const boxHeight = Math.max(hasPhoto ? 27.5 : 25.0, 25.0 + extraAddrHeight);

  doc.setTextColor(15, 23, 42);
  doc.setDrawColor(148, 163, 184);
  doc.setLineWidth(0.3);
  doc.setFillColor(248, 250, 252);
  doc.rect(8, startY, 194, boxHeight, 'FD');

  doc.setFontSize(8.7);
  const drawPair = (label: string, val: string, xLabel: number, xVal: number, y: number, maxW: number) => {
    doc.setFont('helvetica', 'bold');
    doc.setTextColor(51, 65, 85);
    doc.text(label, xLabel, y);
    doc.setFont('helvetica', 'bold');
    doc.setTextColor(15, 23, 42);
    doc.text(val || '—', xVal, y, { maxWidth: maxW });
  };

  const rightLabelX = hasPhoto ? 100 : 110;
  const rightValX = hasPhoto ? 124 : 134;
  const rightValXMother = hasPhoto ? 126 : 136;
  const leftMaxW = hasPhoto ? 60 : 70;
  const rightMaxW = hasPhoto ? 50 : 65;

  drawPair('Student Name:', info.studentName, 11, 38, startY + 4.8, leftMaxW);
  drawPair('Student ID:', info.studentCode, rightLabelX, rightValX, startY + 4.8, rightMaxW);

  drawPair('Class & Section:', fullClassText, 11, 38, startY + 9.5, leftMaxW);
  drawPair(
    'Roll / Year:',
    `${String(info.rollNumber).padStart(2, '0')} · ${info.academicYear}`,
    rightLabelX,
    rightValX,
    startY + 9.5,
    rightMaxW
  );

  drawPair("Father's Name:", (info.fatherName || '').trim() || '—', 11, 38, startY + 14.2, leftMaxW);
  drawPair(
    "Mother's Name:",
    (info.motherName || '').trim() || '—',
    rightLabelX,
    rightValXMother,
    startY + 14.2,
    hasPhoto ? 48 : 63
  );

  drawPair('Contact No.:', (info.contactNo || '').trim() || '—', 11, 38, startY + 18.9, leftMaxW);
  drawPair('AAPAAR ID:', (info.aapaarId || '').trim() || '—', rightLabelX, rightValX, startY + 18.9, rightMaxW);

  doc.setFont('helvetica', 'bold');
  doc.setTextColor(51, 65, 85);
  doc.text('Address:', 11, startY + 23.6);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(15, 23, 42);
  doc.text(addrLines, 38, startY + 23.6);

  if (info.photoDataUrl) {
    const imgFormat = /^data:image\/png/i.test(info.photoDataUrl) ? 'PNG' : 'JPEG';
    const frameX = 179.4;
    const frameY = startY + 1.8;
    const frameW = 20.4;
    const frameH = 23.6;
    doc.setFillColor(255, 255, 255);
    doc.setDrawColor(148, 163, 184);
    doc.setLineWidth(0.25);
    doc.rect(frameX, frameY, frameW, frameH, 'FD');
    try {
      doc.addImage(info.photoDataUrl, imgFormat, frameX + 0.5, frameY + 0.5, frameW - 1.0, frameH - 1.0);
    } catch {
      // ignore invalid image buffer without breaking PDF export
    }
  }

  return startY + boxHeight;
}

function drawUnifiedCoScholasticTablePDF(
  doc: jsPDF,
  startY: number,
  term1: Record<string, string>,
  term2: Record<string, string>,
  sizing: {
    fontSize: number;
    sectionFontSize: number;
    cellPadV: number;
    sectionPadV: number;
    scaleGap: number;
  }
): number {
  const bodyRows: any[] = [];

  for (const section of CO_SCHOLASTIC_SECTIONS) {
    bodyRows.push([
      {
        content: section.title,
        colSpan: 3,
        styles: {
          fillColor: [226, 232, 240],
          textColor: [15, 23, 42],
          fontStyle: 'bold',
          halign: 'left',
          fontSize: sizing.sectionFontSize,
          cellPadding: { top: sizing.sectionPadV, bottom: sizing.sectionPadV, left: 2, right: 2 },
        },
      },
    ]);
    bodyRows.push([
      {
        content: section.columnHeader,
        styles: {
          fillColor: [248, 250, 252],
          textColor: [15, 23, 42],
          fontStyle: 'bold',
          halign: 'left',
        },
      },
      {
        content: 'Grade Term I',
        styles: {
          fillColor: [248, 250, 252],
          textColor: [15, 23, 42],
          fontStyle: 'bold',
          halign: 'center',
        },
      },
      {
        content: 'Grade Term II',
        styles: {
          fillColor: [248, 250, 252],
          textColor: [15, 23, 42],
          fontStyle: 'bold',
          halign: 'center',
        },
      },
    ]);
    for (const item of section.items) {
      bodyRows.push([item.label, term1[item.key] || '—', term2[item.key] || '—']);
    }
  }

  autoTable(doc, {
    startY,
    margin: { left: 8, right: 8, bottom: 10 },
    pageBreak: 'avoid',
    rowPageBreak: 'avoid',
    body: bodyRows,
    theme: 'grid',
    styles: {
      fontSize: sizing.fontSize,
      fontStyle: 'bold',
      cellPadding: {
        top: sizing.cellPadV,
        bottom: sizing.cellPadV,
        left: 2.2,
        right: 2.2,
      },
      textColor: [15, 23, 42],
      lineWidth: 0.25,
      lineColor: [100, 116, 139],
      valign: 'middle',
    },
    columnStyles: {
      0: { cellWidth: 138, halign: 'left', fontStyle: 'bold' },
      1: { cellWidth: 28, halign: 'center', fontStyle: 'bold' },
      2: { cellWidth: 28, halign: 'center', fontStyle: 'bold' },
    },
  });

  const nextY = (doc as any).lastAutoTable?.finalY
    ? (doc as any).lastAutoTable.finalY + sizing.scaleGap
    : startY + 60;

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(8.0);
  doc.setTextColor(51, 65, 85);
  doc.text('3-Point Grading Scale: Grades A, B, C', 8, nextY);

  return nextY + 2.8;
}

const PDF_REMARKS_MAX_BOTTOM_Y = 266.5;

function drawPdfResultDateAndSignatures(
  doc: jsPDF,
  schoolInfo: SchoolInfo,
  resultDate?: string | null
): void {
  // Signatures near bottom of single 297mm A4 page, with Result Date strictly below Class Teacher in bottom-left corner
  const sigY = 278.0;
  const sigLabelY = 282.5;
  const resultDateY = 290.2;

  doc.setTextColor(15, 23, 42);
  doc.setDrawColor(100, 116, 139);
  doc.setLineWidth(0.3);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(9.0);
  doc.line(14, sigY, 64, sigY);
  doc.line(80, sigY, 130, sigY);
  doc.line(146, sigY, 196, sigY);
  doc.text(schoolInfo.siteContent?.reportCardFooterLeft || 'Class Teacher', 39, sigLabelY, {
    align: 'center',
  });
  doc.text(schoolInfo.siteContent?.reportCardFooterCenter || 'Examination Controller', 105, sigLabelY, {
    align: 'center',
  });
  doc.text(schoolInfo.siteContent?.reportCardFooterRight || 'Principal', 171, sigLabelY, {
    align: 'center',
  });

  // Result Date placed directly below Class Teacher in the bottom-left corner of the page
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(9.0);
  doc.setTextColor(30, 58, 95);
  doc.text('Result Date:', 14, resultDateY);
  doc.setTextColor(15, 23, 42);
  doc.text(formatResultDateDisplay(resultDate), 35.5, resultDateY);
}

function getAdaptivePdfLayout(subjectCount: number, showCoScholastic: boolean, isCombined = false) {
  if (!showCoScholastic) {
    return {
      scholasticHeadFont: 9.2,
      scholasticHeadPadV: 2.2,
      scholasticBodyFont: subjectCount <= 7 ? 10.6 : subjectCount <= 10 ? 9.8 : 8.8,
      scholasticBodyPadV: subjectCount <= 6 ? 4.2 : subjectCount <= 8 ? 3.2 : subjectCount <= 10 ? 2.4 : 1.6,
      coFont: 8.6,
      coSectionFont: 8.8,
      coPadV: 1.4,
      coSectionPadV: 1.45,
      coScaleGap: 3.6,
      stripHeight: 15.0,
      sectionGap: 4.0,
      minRemarkH: 14,
    };
  }

  if (subjectCount <= 6) {
    return {
      scholasticHeadFont: isCombined ? 7.4 : 8.6,
      scholasticHeadPadV: isCombined ? 1.05 : 1.2,
      scholasticBodyFont: isCombined ? 8.8 : 9.5,
      scholasticBodyPadV: isCombined ? 1.2 : 1.5,
      coFont: isCombined ? 8.4 : 8.5,
      coSectionFont: isCombined ? 8.6 : 8.7,
      coPadV: isCombined ? 0.92 : 0.98,
      coSectionPadV: isCombined ? 0.96 : 1.02,
      coScaleGap: 3.1,
      stripHeight: 12.6,
      sectionGap: 2.6,
      minRemarkH: 14,
    };
  }
  if (subjectCount <= 8) {
    return {
      scholasticHeadFont: isCombined ? 7.2 : 8.2,
      scholasticHeadPadV: isCombined ? 0.95 : 1.05,
      scholasticBodyFont: isCombined ? 8.4 : 9.0,
      scholasticBodyPadV: isCombined ? 1.0 : 1.15,
      coFont: isCombined ? 8.1 : 8.2,
      coSectionFont: isCombined ? 8.3 : 8.4,
      coPadV: isCombined ? 0.84 : 0.88,
      coSectionPadV: isCombined ? 0.88 : 0.92,
      coScaleGap: 2.9,
      stripHeight: 12.2,
      sectionGap: 2.4,
      minRemarkH: 14,
    };
  }
  if (subjectCount <= 10) {
    return {
      scholasticHeadFont: isCombined ? 6.9 : 7.8,
      scholasticHeadPadV: isCombined ? 0.88 : 0.92,
      scholasticBodyFont: isCombined ? 7.9 : 8.5,
      scholasticBodyPadV: isCombined ? 0.96 : 0.98,
      coFont: isCombined ? 7.7 : 7.9,
      coSectionFont: isCombined ? 7.9 : 8.1,
      coPadV: isCombined ? 0.8 : 0.82,
      coSectionPadV: isCombined ? 0.84 : 0.86,
      coScaleGap: 2.8,
      stripHeight: 12.0,
      sectionGap: 2.2,
      minRemarkH: 13.5,
    };
  }
  // High subject density (11-15 subjects): strictly single A4 page with bold, readable fonts
  return {
    scholasticHeadFont: isCombined ? 6.5 : 7.4,
    scholasticHeadPadV: 0.78,
    scholasticBodyFont: isCombined ? 7.4 : 8.0,
    scholasticBodyPadV: 0.78,
    coFont: 7.4,
    coSectionFont: 7.6,
    coPadV: 0.68,
    coSectionPadV: 0.72,
    coScaleGap: 2.6,
    stripHeight: 11.5,
    sectionGap: 2.0,
    minRemarkH: 13,
  };
}

function renderIndividualReportCardPage(
  doc: jsPDF,
  student: ConsolidatedStudentResult,
  report: ConsolidatedClassReport,
  schoolInfo: SchoolInfo,
  assets: { cbseLogo: PdfLogoAsset | null; schoolLogo: PdfLogoAsset | null; photoDataUrl: string | null }
): void {
  const reportTitle = (schoolInfo.siteContent?.reportCardTitle || 'PROGRESS REPORT CARD').toUpperCase();
  const detailsStartY = drawMarksheetHeaderPDF(
    doc,
    `${reportTitle} · ${report.examination.name.toUpperCase()} (${report.examination.academicYear})`,
    assets
  );

  const infoBottomY = drawCompactStudentDetailsBoxPDF(doc, detailsStartY, {
    studentName: student.studentName,
    studentCode: student.studentCode,
    className: student.className,
    sectionName: student.sectionName,
    hasSections: report.classInfo.hasSections ?? student.hasSections ?? true,
    stream: student.stream,
    rollNumber: student.rollNumber,
    academicYear: report.examination.academicYear,
    fatherName: student.fatherName,
    motherName: student.motherName,
    contactNo: student.contactNo,
    aapaarId: student.aapaarId,
    residentialAddress: student.residentialAddress,
    photoDataUrl: assets.photoDataUrl,
  });

  const enrolledSubjects = student.subjects.filter(
    (sub) => sub.isEnrolled !== false && sub.gradeStatus !== 'not_applicable'
  );

  const term1 = student.coScholastic?.term1 || {};
  const term2 = student.coScholastic?.term2 || {};
  const showCoScholastic =
    Boolean(report.coScholasticMeta?.eligible) ||
    Boolean(report.coScholasticMeta?.hasAnyGradesForYear) ||
    Object.keys(term1).length > 0 ||
    Object.keys(term2).length > 0;

  const layout = getAdaptivePdfLayout(enrolledSubjects.length, showCoScholastic);

  const sampleWithIa = enrolledSubjects.find((s) => s.hasInternalAssessment) || enrolledSubjects[0];
  const iaMaxDisplay = sampleWithIa?.iaMaxMarks || 20;
  const writtenMaxDisplay = sampleWithIa?.writtenMaxMarks || 80;
  const totalMaxDisplay = sampleWithIa?.maxMarks || 100;

  const activeTermNum = report.coScholasticMeta?.term === 2 ? 2 : 1;
  const activeTermLabel = activeTermNum === 2 ? 'TERM II' : 'TERM I';
  const activeTermRec = activeTermNum === 2 ? student.termRecords?.term2 : student.termRecords?.term1;
  const attendanceVal = formatAttendanceRatio(activeTermRec?.daysAttended, activeTermRec?.totalDays);
  const pctVal = student.percentage !== null ? `${student.percentage.toFixed(1)}%` : 'Incomplete';
  const gradeVal = student.grade || 'Pending';
  const resultVal = student.resultStatus.toUpperCase();

  const bodyRows: any[] = enrolledSubjects.map((sub) => {
    const b = getScholasticBreakdown(sub);
    const subjectLabel =
      sub.componentMode === 'elective' && sub.selectedComponentName
        ? `${sub.subjectName} (${sub.selectedComponentName})`
        : sub.subjectName;
    return [subjectLabel, b.internalTest, b.practical, b.participation, b.termExam, b.total, b.grade];
  });

  bodyRows.push([
    { content: 'Attendance', colSpan: 2, styles: { fillColor: [241, 245, 249], fontStyle: 'bold', halign: 'center' } },
    { content: 'Percentage', colSpan: 2, styles: { fillColor: [241, 245, 249], fontStyle: 'bold', halign: 'center' } },
    { content: 'Grade', colSpan: 1, styles: { fillColor: [241, 245, 249], fontStyle: 'bold', halign: 'center' } },
    { content: 'Result', colSpan: 2, styles: { fillColor: [241, 245, 249], fontStyle: 'bold', halign: 'center' } },
  ]);
  bodyRows.push([
    { content: attendanceVal, colSpan: 2, styles: { fillColor: [255, 255, 255], fontStyle: 'bold', halign: 'center' } },
    { content: pctVal, colSpan: 2, styles: { fillColor: [255, 255, 255], fontStyle: 'bold', halign: 'center' } },
    { content: gradeVal, colSpan: 1, styles: { fillColor: [255, 255, 255], fontStyle: 'bold', halign: 'center' } },
    { content: resultVal, colSpan: 2, styles: { fillColor: [255, 255, 255], fontStyle: 'bold', halign: 'center' } },
  ]);

  autoTable(doc, {
    startY: infoBottomY + layout.sectionGap,
    margin: { left: 8, right: 8, bottom: 10 },
    pageBreak: 'avoid',
    rowPageBreak: 'avoid',
    head: [
      [
        {
          content: 'Part-1 (A): Scholastic Area:',
          colSpan: 1,
          styles: { halign: 'left', fillColor: [226, 232, 240], textColor: [15, 23, 42], fontStyle: 'bold' },
        },
        {
          content: `${activeTermLabel} — ${report.examination.name}`,
          colSpan: 6,
          styles: { halign: 'center', fillColor: [30, 58, 95], textColor: [255, 255, 255], fontStyle: 'bold' },
        },
      ],
      [
        {
          content: 'Subjects',
          rowSpan: 2,
          styles: { valign: 'middle', halign: 'left', fillColor: [241, 245, 249], textColor: [15, 23, 42] },
        },
        {
          content: `Internal Assessment (${iaMaxDisplay} marks)`,
          colSpan: 3,
          styles: { halign: 'center', fillColor: [241, 245, 249], textColor: [15, 23, 42] },
        },
        {
          content: `Term Exam\n(${writtenMaxDisplay})`,
          rowSpan: 2,
          styles: { valign: 'middle', halign: 'center', fillColor: [241, 245, 249], textColor: [15, 23, 42] },
        },
        {
          content: `Total\n(${totalMaxDisplay})`,
          rowSpan: 2,
          styles: { valign: 'middle', halign: 'center', fillColor: [241, 245, 249], textColor: [15, 23, 42] },
        },
        {
          content: 'Grade',
          rowSpan: 2,
          styles: { valign: 'middle', halign: 'center', fillColor: [241, 245, 249], textColor: [15, 23, 42] },
        },
      ],
      [
        { content: 'Internal\nTest', styles: { valign: 'middle', halign: 'center', fillColor: [248, 250, 252], textColor: [15, 23, 42] } },
        { content: 'PPT/Project/\nAssignment/Practical', styles: { valign: 'middle', halign: 'center', fillColor: [248, 250, 252], textColor: [15, 23, 42] } },
        { content: 'Overall\nParticipation', styles: { valign: 'middle', halign: 'center', fillColor: [248, 250, 252], textColor: [15, 23, 42] } },
      ],
    ],
    body: bodyRows,
    theme: 'grid',
    headStyles: {
      fontSize: layout.scholasticHeadFont,
      fontStyle: 'bold',
      lineColor: [100, 116, 139],
      lineWidth: 0.25,
      cellPadding: { top: layout.scholasticHeadPadV, bottom: layout.scholasticHeadPadV, left: 1.2, right: 1.2 },
    },
    styles: {
      fontSize: layout.scholasticBodyFont,
      fontStyle: 'bold',
      cellPadding: { top: layout.scholasticBodyPadV, bottom: layout.scholasticBodyPadV, left: 1.5, right: 1.5 },
      textColor: [15, 23, 42],
      lineColor: [100, 116, 139],
      lineWidth: 0.25,
      valign: 'middle',
    },
    columnStyles: {
      0: { cellWidth: 62, halign: 'left', fontStyle: 'bold' },
      1: { cellWidth: 20, halign: 'center', fontStyle: 'bold' },
      2: { cellWidth: 28, halign: 'center', fontStyle: 'bold' },
      3: { cellWidth: 22, halign: 'center', fontStyle: 'bold' },
      4: { cellWidth: 22, halign: 'center', fontStyle: 'bold' },
      5: { cellWidth: 22, halign: 'center', fontStyle: 'bold' },
      6: { cellWidth: 18, halign: 'center', fontStyle: 'bold' },
    },
  });

  let currentY = (doc as any).lastAutoTable?.finalY
    ? (doc as any).lastAutoTable.finalY + layout.sectionGap
    : 120;

  // Compact Grand Total & Rank strip (larger & bold)
  const grandStripH = 10.5;
  doc.setDrawColor(100, 116, 139);
  doc.setFillColor(241, 245, 249);
  doc.rect(8, currentY, 194, grandStripH, 'FD');
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(9.0);
  doc.setTextColor(15, 23, 42);
  doc.text(
    `Grand Total: ${
      student.grandTotal !== null ? `${student.grandTotal} / ${student.totalMaxMarks}` : `Incomplete / ${student.totalMaxMarks}`
    }`,
    11,
    currentY + 6.8
  );
  doc.text(
    `Percentage: ${student.percentage !== null ? `${student.percentage.toFixed(2)}%` : 'Incomplete'}`,
    72,
    currentY + 6.8
  );
  doc.text(`Grade: ${student.grade || 'Pending'}`, 127, currentY + 6.8);
  doc.text(`Class Rank: ${student.classRank ? `#${student.classRank}` : 'N/A'}`, 164, currentY + 6.8);

  currentY += grandStripH + layout.sectionGap;

  if (showCoScholastic) {
    currentY = drawUnifiedCoScholasticTablePDF(doc, currentY, term1, term2, {
      fontSize: layout.coFont,
      sectionFontSize: layout.coSectionFont,
      cellPadV: layout.coPadV,
      sectionPadV: layout.coSectionPadV,
      scaleGap: layout.coScaleGap,
    });
  }

  // Small, readable & bold Remarks Box (sized for 1 sentence, never overlapping signatures or Result Date)
  const remarkText = (activeTermRec?.remarks || '').trim() || '—';
  const availableUntilFooter = PDF_REMARKS_MAX_BOTTOM_Y - currentY;
  const remarkBoxH = Math.min(14.0, Math.max(10.5, availableUntilFooter));
  const remarkLines = (doc.splitTextToSize(remarkText, 188) as string[]).slice(0, 1);

  doc.setDrawColor(100, 116, 139);
  doc.setFillColor(255, 255, 255);
  doc.rect(8, currentY, 194, remarkBoxH, 'FD');
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(9.2);
  doc.setTextColor(30, 58, 95);
  doc.text(`Remarks (${activeTermNum === 2 ? 'Annual / Term II' : '1st Term'}):`, 11, currentY + 4.8);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(9.6);
  doc.setTextColor(15, 23, 42);
  doc.text(remarkLines, 11, currentY + 10.6);

  drawPdfResultDateAndSignatures(doc, schoolInfo, report.classInfo.resultDate);
}

export async function exportIndividualReportCardPDF(
  student: ConsolidatedStudentResult,
  report: ConsolidatedClassReport,
  schoolInfo: SchoolInfo
): Promise<void> {
  const doc = new jsPDF({ orientation: 'portrait', unit: 'mm', format: 'a4' });
  const [cbseLogo, schoolLogo, photoDataUrl] = await Promise.all([
    loadPdfLogoAsset(CBSE_LOGO_PATH, false),
    loadPdfLogoAsset(schoolInfo.schoolLogo, true),
    loadPdfStudentPhotoDataUrl(student.photoUrl),
  ]);
  renderIndividualReportCardPage(doc, student, report, schoolInfo, {
    cbseLogo,
    schoolLogo,
    photoDataUrl,
  });
  doc.save(
    `${student.studentCode}_${student.studentName.replace(/\s+/g, '_')}_${report.examination.name.replace(/\s+/g, '_')}.pdf`
  );
}

function renderCombinedReportCardPage(
  doc: jsPDF,
  student: CombinedTermStudentResult,
  combinedReport: CombinedTermClassReport,
  schoolInfo: SchoolInfo,
  assets: { cbseLogo: PdfLogoAsset | null; schoolLogo: PdfLogoAsset | null; photoDataUrl: string | null }
): void {
  const reportTitle = (schoolInfo.siteContent?.reportCardTitle || 'PROGRESS REPORT CARD').toUpperCase();
  const detailsStartY = drawMarksheetHeaderPDF(
    doc,
    `${reportTitle} — TERM I & TERM II COMBINED (${combinedReport.academicYear})`,
    assets
  );

  // Top Student Profile Box (Full Class Name, Parents, Address, Contact, AAPAAR ID & Final Marksheet Photo)
  const infoBottomY = drawCompactStudentDetailsBoxPDF(doc, detailsStartY, {
    studentName: student.studentName,
    studentCode: student.studentCode,
    className: student.className,
    sectionName: student.sectionName,
    hasSections: combinedReport.classInfo.hasSections ?? student.hasSections ?? true,
    stream: student.stream,
    rollNumber: student.rollNumber,
    academicYear: combinedReport.academicYear,
    fatherName: student.fatherName,
    motherName: student.motherName,
    contactNo: student.contactNo,
    aapaarId: student.aapaarId,
    residentialAddress: student.residentialAddress,
    photoDataUrl: assets.photoDataUrl,
  });

  // Filter strictly to subjects the student is actually enrolled in (excludes extra un-enrolled subjects)
  const enrolledRows = student.subjects.filter((row) => {
    const t1Ok = row.term1 && row.term1.isEnrolled !== false && row.term1.gradeStatus !== 'not_applicable';
    const t2Ok = row.term2 && row.term2.isEnrolled !== false && row.term2.gradeStatus !== 'not_applicable';
    return Boolean(t1Ok || t2Ok);
  });

  const layout = getAdaptivePdfLayout(enrolledRows.length, true, true);

  const sampleSubject =
    enrolledRows.find((r) => r.term1?.hasInternalAssessment || r.term2?.hasInternalAssessment) ||
    enrolledRows[0];
  const sampleMeta = sampleSubject?.term1 || sampleSubject?.term2 || null;
  const iaMaxDisplay = sampleMeta?.iaMaxMarks || 20;
  const writtenMaxDisplay = sampleMeta?.writtenMaxMarks || 80;
  const totalMaxDisplay = sampleMeta?.maxMarks || 100;

  const bodyRows: any[] = enrolledRows.map((row: CombinedTermSubjectRow) => {
    const b1 = getScholasticBreakdown(row.term1);
    const b2 = getScholasticBreakdown(row.term2);
    const chosenSub = row.term1 || row.term2;
    const subjectLabel =
      chosenSub?.componentMode === 'elective' && chosenSub.selectedComponentName
        ? `${row.subjectName} (${chosenSub.selectedComponentName})`
        : row.subjectName;
    return [
      subjectLabel,
      b1.internalTest,
      b1.practical,
      b1.participation,
      b1.termExam,
      b1.total,
      b1.grade,
      b2.internalTest,
      b2.practical,
      b2.participation,
      b2.termExam,
      b2.total,
      b2.grade,
    ];
  });

  const s1 = student.term1Summary;
  const s2 = student.term2Summary;
  const t1AttRatio = formatAttendanceRatio(student.termRecords.term1.daysAttended, student.termRecords.term1.totalDays);
  const t2AttRatio = formatAttendanceRatio(student.termRecords.term2.daysAttended, student.termRecords.term2.totalDays);

  const t1PctStr = s1?.percentage !== null && s1?.percentage !== undefined ? `${s1.percentage.toFixed(1)}%` : '—';
  const t2PctStr = s2?.percentage !== null && s2?.percentage !== undefined ? `${s2.percentage.toFixed(1)}%` : '—';
  const t1GradeStr = s1?.grade || '—';
  const t2GradeStr = s2?.grade || '—';
  const t1ResultStr = s1?.resultStatus ? s1.resultStatus.toUpperCase() : '—';
  const t2ResultStr = s2?.resultStatus ? s2.resultStatus.toUpperCase() : '—';

  bodyRows.push([
    { content: 'Attendance', colSpan: 2, styles: { fillColor: [241, 245, 249], fontStyle: 'bold', halign: 'center' } },
    { content: 'Percentage', colSpan: 2, styles: { fillColor: [241, 245, 249], fontStyle: 'bold', halign: 'center' } },
    { content: 'Grade', colSpan: 1, styles: { fillColor: [241, 245, 249], fontStyle: 'bold', halign: 'center' } },
    { content: 'Result', colSpan: 2, styles: { fillColor: [241, 245, 249], fontStyle: 'bold', halign: 'center' } },
    { content: 'Attendance', colSpan: 2, styles: { fillColor: [236, 254, 255], fontStyle: 'bold', halign: 'center' } },
    { content: 'Percentage', colSpan: 2, styles: { fillColor: [236, 254, 255], fontStyle: 'bold', halign: 'center' } },
    { content: 'Grade', colSpan: 1, styles: { fillColor: [236, 254, 255], fontStyle: 'bold', halign: 'center' } },
    { content: 'Result', colSpan: 1, styles: { fillColor: [236, 254, 255], fontStyle: 'bold', halign: 'center' } },
  ]);
  bodyRows.push([
    { content: t1AttRatio, colSpan: 2, styles: { fillColor: [255, 255, 255], fontStyle: 'bold', halign: 'center' } },
    { content: t1PctStr, colSpan: 2, styles: { fillColor: [255, 255, 255], fontStyle: 'bold', halign: 'center' } },
    { content: t1GradeStr, colSpan: 1, styles: { fillColor: [255, 255, 255], fontStyle: 'bold', halign: 'center' } },
    { content: t1ResultStr, colSpan: 2, styles: { fillColor: [255, 255, 255], fontStyle: 'bold', halign: 'center' } },
    { content: t2AttRatio, colSpan: 2, styles: { fillColor: [255, 255, 255], fontStyle: 'bold', halign: 'center' } },
    { content: t2PctStr, colSpan: 2, styles: { fillColor: [255, 255, 255], fontStyle: 'bold', halign: 'center' } },
    { content: t2GradeStr, colSpan: 1, styles: { fillColor: [255, 255, 255], fontStyle: 'bold', halign: 'center' } },
    { content: t2ResultStr, colSpan: 1, styles: { fillColor: [255, 255, 255], fontStyle: 'bold', halign: 'center' } },
  ]);

  autoTable(doc, {
    startY: infoBottomY + layout.sectionGap,
    margin: { left: 8, right: 8, bottom: 10 },
    pageBreak: 'avoid',
    rowPageBreak: 'avoid',
    head: [
      [
        {
          content: 'Part-1 (A): Scholastic Area:',
          colSpan: 1,
          styles: { halign: 'left', fillColor: [226, 232, 240], textColor: [15, 23, 42], fontStyle: 'bold' },
        },
        {
          content: combinedReport.term1Exam?.name ? `TERM I (${combinedReport.term1Exam.name})` : 'TERM I',
          colSpan: 6,
          styles: { halign: 'center', fillColor: [30, 58, 95], textColor: [255, 255, 255], fontStyle: 'bold' },
        },
        {
          content: combinedReport.term2Exam?.name ? `TERM II (${combinedReport.term2Exam.name})` : 'TERM II',
          colSpan: 6,
          styles: { halign: 'center', fillColor: [22, 78, 99], textColor: [255, 255, 255], fontStyle: 'bold' },
        },
      ],
      [
        {
          content: 'Subjects',
          rowSpan: 2,
          styles: { valign: 'middle', halign: 'left', fillColor: [241, 245, 249], textColor: [15, 23, 42] },
        },
        {
          content: `Internal Assessment (${iaMaxDisplay} marks)`,
          colSpan: 3,
          styles: { halign: 'center', fillColor: [241, 245, 249], textColor: [15, 23, 42] },
        },
        {
          content: `Term\nExam\n(${writtenMaxDisplay})`,
          rowSpan: 2,
          styles: { valign: 'middle', halign: 'center', fillColor: [241, 245, 249], textColor: [15, 23, 42] },
        },
        {
          content: `Total\n(${totalMaxDisplay})`,
          rowSpan: 2,
          styles: { valign: 'middle', halign: 'center', fillColor: [241, 245, 249], textColor: [15, 23, 42] },
        },
        {
          content: 'Grade',
          rowSpan: 2,
          styles: { valign: 'middle', halign: 'center', fillColor: [241, 245, 249], textColor: [15, 23, 42] },
        },
        {
          content: `Internal Assessment (${iaMaxDisplay} marks)`,
          colSpan: 3,
          styles: { halign: 'center', fillColor: [236, 254, 255], textColor: [15, 23, 42] },
        },
        {
          content: `Term\nExam\n(${writtenMaxDisplay})`,
          rowSpan: 2,
          styles: { valign: 'middle', halign: 'center', fillColor: [236, 254, 255], textColor: [15, 23, 42] },
        },
        {
          content: `Total\n(${totalMaxDisplay})`,
          rowSpan: 2,
          styles: { valign: 'middle', halign: 'center', fillColor: [236, 254, 255], textColor: [15, 23, 42] },
        },
        {
          content: 'Grade',
          rowSpan: 2,
          styles: { valign: 'middle', halign: 'center', fillColor: [236, 254, 255], textColor: [15, 23, 42] },
        },
      ],
      [
        { content: 'Internal\nTest', styles: { valign: 'middle', halign: 'center', fillColor: [248, 250, 252], textColor: [15, 23, 42] } },
        { content: 'PPT/Project\n/Assignment/\nPractical', styles: { valign: 'middle', halign: 'center', fillColor: [248, 250, 252], textColor: [15, 23, 42] } },
        { content: 'Overall\nParticip.', styles: { valign: 'middle', halign: 'center', fillColor: [248, 250, 252], textColor: [15, 23, 42] } },
        { content: 'Internal\nTest', styles: { valign: 'middle', halign: 'center', fillColor: [240, 253, 250], textColor: [15, 23, 42] } },
        { content: 'PPT/Project\n/Assignment/\nPractical', styles: { valign: 'middle', halign: 'center', fillColor: [240, 253, 250], textColor: [15, 23, 42] } },
        { content: 'Overall\nParticip.', styles: { valign: 'middle', halign: 'center', fillColor: [240, 253, 250], textColor: [15, 23, 42] } },
      ],
    ],
    body: bodyRows,
    theme: 'grid',
    headStyles: {
      fontSize: layout.scholasticHeadFont,
      fontStyle: 'bold',
      lineColor: [100, 116, 139],
      lineWidth: 0.25,
      cellPadding: { top: layout.scholasticHeadPadV, bottom: layout.scholasticHeadPadV, left: 0.5, right: 0.5 },
    },
    styles: {
      fontSize: layout.scholasticBodyFont,
      fontStyle: 'bold',
      cellPadding: {
        top: layout.scholasticBodyPadV,
        bottom: layout.scholasticBodyPadV,
        left: 0.7,
        right: 0.7,
      },
      textColor: [15, 23, 42],
      lineColor: [100, 116, 139],
      lineWidth: 0.25,
      valign: 'middle',
    },
    columnStyles: {
      0: { cellWidth: 34, halign: 'left', fontStyle: 'bold' },
      1: { cellWidth: 12, halign: 'center', fontStyle: 'bold' },
      2: { cellWidth: 16.5, halign: 'center', fontStyle: 'bold' },
      3: { cellWidth: 14.5, halign: 'center', fontStyle: 'bold' },
      4: { cellWidth: 13, halign: 'center', fontStyle: 'bold' },
      5: { cellWidth: 12, halign: 'center', fontStyle: 'bold' },
      6: { cellWidth: 12, halign: 'center', fontStyle: 'bold' },
      7: { cellWidth: 12, halign: 'center', fontStyle: 'bold' },
      8: { cellWidth: 16.5, halign: 'center', fontStyle: 'bold' },
      9: { cellWidth: 14.5, halign: 'center', fontStyle: 'bold' },
      10: { cellWidth: 13, halign: 'center', fontStyle: 'bold' },
      11: { cellWidth: 12, halign: 'center', fontStyle: 'bold' },
      12: { cellWidth: 12, halign: 'center', fontStyle: 'bold' },
    },
  });

  let currentY = (doc as any).lastAutoTable?.finalY
    ? (doc as any).lastAutoTable.finalY + layout.sectionGap
    : 118;

  // Final / Overall Combined Result Box — enlarged & bold
  doc.setDrawColor(30, 58, 95);
  doc.setFillColor(239, 246, 255);
  doc.rect(8, currentY, 194, layout.stripHeight, 'FD');

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(8.4);
  doc.setTextColor(30, 58, 95);
  doc.text('FINAL / OVERALL RESULT (AVERAGE OF BOTH TERMS & TOTAL ATTENDANCE)', 11, currentY + 5.0);

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(8.3);
  doc.setTextColor(15, 23, 42);
  const ov = student.overall;
  const totalAttStr = formatAttendanceRatio(
    student.termRecords.totalDaysAttended,
    student.termRecords.totalWorkingDays,
    true
  );

  const ovValY = currentY + layout.stripHeight - 3.2;
  doc.text(
    `Avg: ${
      ov.averageObtained !== null && ov.averageMaxMarks !== null
        ? `${ov.averageObtained}/${ov.averageMaxMarks}`
        : 'Inc.'
    }`,
    11,
    ovValY
  );
  doc.text(
    `Combined: ${ov.combinedTotal !== null ? `${ov.combinedTotal}/${ov.combinedMaxMarks}` : 'Inc.'}`,
    45,
    ovValY
  );
  doc.text(
    `Final %: ${ov.finalPercentage !== null ? `${ov.finalPercentage.toFixed(2)}%` : '—'}`,
    84,
    ovValY
  );
  doc.text(`Grade: ${ov.finalGrade || '—'}`, 117, ovValY);
  doc.text(`Att.: ${totalAttStr}`, 138, ovValY);
  doc.text(`Result: ${ov.resultStatus.toUpperCase()}`, 176, ovValY);

  currentY += layout.stripHeight + layout.sectionGap;

  // Unified Co-Scholastic & Discipline Table (Part-1(B), Part-2, Part-3 — NO point counts)
  const csT1 = student.coScholastic?.term1 || {};
  const csT2 = student.coScholastic?.term2 || {};
  currentY = drawUnifiedCoScholasticTablePDF(doc, currentY, csT1, csT2, {
    fontSize: layout.coFont,
    sectionFontSize: layout.coSectionFont,
    cellPadV: layout.coPadV,
    sectionPadV: layout.coSectionPadV,
    scaleGap: layout.coScaleGap,
  });

  // Small, readable & bold Term Remarks Boxes (sized for 1 sentence per term, never overlapping signatures or Result Date)
  const halfW = 95;
  const r1Text = (student.termRecords.term1.remarks || '').trim() || '—';
  const r2Text = (student.termRecords.term2.remarks || '').trim() || '—';
  const availableUntilFooter = PDF_REMARKS_MAX_BOTTOM_Y - currentY;
  const r1LinesAll = doc.splitTextToSize(r1Text, halfW - 6) as string[];
  const r2LinesAll = doc.splitTextToSize(r2Text, halfW - 6) as string[];
  const needsTwoLines = r1LinesAll.length > 1 || r2LinesAll.length > 1;
  const desiredBoxH = needsTwoLines ? 16.5 : 13.5;
  const rBoxH = Math.min(desiredBoxH, Math.max(10.5, availableUntilFooter));
  const maxLines = rBoxH >= 15.0 ? 2 : 1;
  const r1Lines = r1LinesAll.slice(0, maxLines);
  const r2Lines = r2LinesAll.slice(0, maxLines);

  doc.setDrawColor(100, 116, 139);
  doc.setFillColor(255, 255, 255);
  doc.rect(8, currentY, halfW, rBoxH, 'FD');
  doc.rect(8 + halfW + 4, currentY, halfW, rBoxH, 'FD');

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(9.0);
  doc.setTextColor(30, 58, 95);
  doc.text('Remarks — 1st Term (Term I):', 11, currentY + 4.8);
  doc.setTextColor(22, 78, 99);
  doc.text('Remarks — Annual (Term II):', 110, currentY + 4.8);

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(9.2);
  doc.setTextColor(15, 23, 42);
  doc.text(r1Lines, 11, currentY + 10.2);
  doc.text(r2Lines, 110, currentY + 10.2);

  drawPdfResultDateAndSignatures(doc, schoolInfo, combinedReport.classInfo.resultDate);
}

export async function exportCombinedReportCardPDF(
  student: CombinedTermStudentResult,
  combinedReport: CombinedTermClassReport,
  schoolInfo: SchoolInfo
): Promise<void> {
  const doc = new jsPDF({ orientation: 'portrait', unit: 'mm', format: 'a4' });
  const [cbseLogo, schoolLogo, photoDataUrl] = await Promise.all([
    loadPdfLogoAsset(CBSE_LOGO_PATH, false),
    loadPdfLogoAsset(schoolInfo.schoolLogo, true),
    loadPdfStudentPhotoDataUrl(student.photoUrl),
  ]);
  renderCombinedReportCardPage(doc, student, combinedReport, schoolInfo, {
    cbseLogo,
    schoolLogo,
    photoDataUrl,
  });
  doc.save(
    `${student.studentCode}_${student.studentName.replace(/\s+/g, '_')}_Combined_Term1_Annual_${combinedReport.academicYear}.pdf`
  );
}

export type BatchFinalMarksheetEntry =
  | { mode: 'combined'; student: CombinedTermStudentResult; report: CombinedTermClassReport }
  | { mode: 'single'; student: ConsolidatedStudentResult; report: ConsolidatedClassReport };

export async function exportClassAllFinalMarksheetsPDF(
  entries: BatchFinalMarksheetEntry[],
  schoolInfo: SchoolInfo,
  filenameSlug: string
): Promise<string> {
  if (!entries || entries.length === 0) {
    throw new Error('No students available to generate marksheets.');
  }

  const doc = new jsPDF({ orientation: 'portrait', unit: 'mm', format: 'a4' });
  const [cbseLogo, schoolLogo] = await Promise.all([
    loadPdfLogoAsset(CBSE_LOGO_PATH, false),
    loadPdfLogoAsset(schoolInfo.schoolLogo, true),
  ]);

  // Preload all student photos in concurrency batches of 6
  const photoCache = new Map<string, string | null>();
  const uniqueUrls: string[] = [];
  for (const item of entries) {
    const raw = (item.student.photoUrl || '').trim();
    if (raw && !photoCache.has(raw)) {
      photoCache.set(raw, null);
      uniqueUrls.push(raw);
    }
  }
  const batchSize = 6;
  for (let i = 0; i < uniqueUrls.length; i += batchSize) {
    const chunk = uniqueUrls.slice(i, i + batchSize);
    const loaded = await Promise.all(chunk.map((url) => loadPdfStudentPhotoDataUrl(url)));
    chunk.forEach((url, idx) => {
      photoCache.set(url, loaded[idx]);
    });
  }

  for (let i = 0; i < entries.length; i++) {
    if (i > 0) {
      doc.addPage('a4', 'portrait');
    }
    const entry = entries[i];
    const rawUrl = (entry.student.photoUrl || '').trim();
    const photoDataUrl = rawUrl ? photoCache.get(rawUrl) || null : null;
    if (entry.mode === 'combined') {
      renderCombinedReportCardPage(doc, entry.student, entry.report, schoolInfo, {
        cbseLogo,
        schoolLogo,
        photoDataUrl,
      });
    } else {
      renderIndividualReportCardPage(doc, entry.student, entry.report, schoolInfo, {
        cbseLogo,
        schoolLogo,
        photoDataUrl,
      });
    }
  }

  const cleanSlug =
    filenameSlug
      .replace(/[^a-zA-Z0-9_-]+/g, '_')
      .replace(/^_+|_+$/g, '') || 'Class_Final_Marksheets';
  const filename = `${cleanSlug}.pdf`;
  doc.save(filename);
  return filename;
}

export async function exportClassConsolidatedPDF(
  report: ConsolidatedClassReport,
  schoolInfo: SchoolInfo
): Promise<void> {
  const doc = new jsPDF({ orientation: 'landscape', unit: 'mm', format: 'a4' });
  const logoDataUrl = await loadPdfLogoDataUrl(schoolInfo.schoolLogo);

  doc.setFillColor(30, 58, 95);
  doc.rect(0, 0, 297, 22, 'F');
  let headerTextX = 12;
  if (logoDataUrl) {
    doc.setFillColor(255, 255, 255);
    doc.roundedRect(10, 3, 16, 16, 1.5, 1.5, 'F');
    doc.addImage(logoDataUrl, 'PNG', 10.8, 3.8, 14.4, 14.4);
    headerTextX = 30;
  }
  doc.setTextColor(255, 255, 255);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(14);
  doc.text(`${schoolInfo.schoolName} — Consolidated Class Result Sheet`, headerTextX, 10);
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(9.5);
  doc.text(
    `${formatClassSectionLabel(
      report.classInfo.className,
      report.classInfo.sectionName,
      report.classInfo.hasSections ?? true
    )} | ${report.examination.name} (${report.examination.academicYear}) | Class Teacher: ${
      report.classInfo.classTeacherName || 'N/A'
    }`,
    headerTextX,
    17
  );

  const head = [
    [
      'Roll',
      'ID',
      'Student Name',
      ...report.subjects.map((s) => `${s.subjectCode}\n/${s.maxMarks}`),
      `Total\n/${report.summary.totalMaxMarks}`,
      '%',
      'Grade',
      'Rank',
      'Result',
    ],
  ];

  const body = report.students.map((st) => [
    String(st.rollNumber).padStart(2, '0'),
    st.studentCode,
    st.studentName,
    ...st.subjects.map((sub) =>
      sub.isEnrolled === false || sub.gradeStatus === 'not_applicable'
        ? '—'
        : sub.components.some((c) => c.attendanceStatus === 'absent')
          ? 'AB'
          : sub.isComplete && sub.obtainedMarks !== null
            ? `${sub.obtainedMarks} (${getSubjectDisplayGrade(sub)})`
            : 'Pend.'
    ),
    st.grandTotal !== null ? String(st.grandTotal) : 'Pend.',
    st.percentage !== null ? `${st.percentage.toFixed(1)}%` : '—',
    st.grade ?? '—',
    st.classRank ? String(st.classRank) : '—',
    st.resultStatus,
  ]);

  autoTable(doc, {
    startY: 27,
    head,
    body,
    theme: 'grid',
    headStyles: { fillColor: [30, 58, 95], textColor: [255, 255, 255], fontSize: 8 },
    styles: { fontSize: 7.8, cellPadding: 2 },
    columnStyles: {
      0: { halign: 'center', cellWidth: 11 },
      1: { cellWidth: 16 },
    },
  });

  const summaryY = (doc as any).lastAutoTable?.finalY ? (doc as any).lastAutoTable.finalY + 7 : 185;
  doc.setTextColor(15, 23, 42);
  doc.setFontSize(9);
  doc.text(
    `Students: ${report.summary.totalStudents} | Complete: ${report.summary.completedCount} | Incomplete: ${report.summary.incompleteCount} | Passed: ${report.summary.passCount} | Highest: ${report.summary.highestTotal ?? 'N/A'} | Lowest: ${report.summary.lowestTotal ?? 'N/A'} | Class Avg: ${report.summary.classAveragePercentage !== null ? `${report.summary.classAveragePercentage}%` : 'N/A'}`,
    12,
    Math.min(200, summaryY)
  );

  const consolidatedClassPart =
    report.classInfo.hasSections === false
      ? report.classInfo.className.replace(/\s+/g, '')
      : `${report.classInfo.className.replace(/\s+/g, '')}_${report.classInfo.sectionName}`;
  doc.save(`${consolidatedClassPart}_${report.examination.name.replace(/\s+/g, '_')}_Consolidated.pdf`);
}

export async function exportSubjectWisePDF(
  report: ConsolidatedClassReport,
  subjectId: number,
  schoolInfo: SchoolInfo
): Promise<void> {
  const subjectMeta = report.subjects.find((s) => s.subjectId === subjectId);
  if (!subjectMeta) return;

  const doc = new jsPDF({ orientation: 'portrait', unit: 'mm', format: 'a4' });
  const logoDataUrl = await loadPdfLogoDataUrl(schoolInfo.schoolLogo);

  doc.setFillColor(30, 58, 95);
  doc.rect(0, 0, 210, 22, 'F');
  let headerTextX = 14;
  if (logoDataUrl) {
    doc.setFillColor(255, 255, 255);
    doc.roundedRect(12, 3, 16, 16, 1.5, 1.5, 'F');
    doc.addImage(logoDataUrl, 'PNG', 12.8, 3.8, 14.4, 14.4);
    headerTextX = 32;
  }
  doc.setTextColor(255, 255, 255);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(13);
  doc.text(`${schoolInfo.schoolName} — ${subjectMeta.subjectName} Marks Report`, headerTextX, 10, {
    maxWidth: 200 - headerTextX,
  });
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(9);
  doc.text(
    `${formatClassSectionLabel(
      report.classInfo.className,
      report.classInfo.sectionName,
      report.classInfo.hasSections ?? true
    )} · ${report.examination.name} (${report.examination.academicYear})`,
    headerTextX,
    17
  );

  const compHeaders =
    subjectMeta.componentMode === 'elective'
      ? ['Option', `Exam\n/${subjectMeta.writtenMaxMarks}`]
      : subjectMeta.hasComponents
        ? subjectMeta.components.map((c) => `${c.componentName}\n/${c.maxMarks}`)
        : subjectMeta.hasInternalAssessment
          ? [`Exam\n/${subjectMeta.writtenMaxMarks}`]
          : [];
  const iaHeaders = subjectMeta.hasInternalAssessment
    ? [
        `NB\n/${subjectMeta.iaNotebookMax}`,
        `UT\n/${subjectMeta.iaUnitTestMax}`,
        `Pr\n/${subjectMeta.iaPracticalMax}`,
        `OP\n/${subjectMeta.iaParticipationMax}`,
        `IA\n/${subjectMeta.iaMaxMarks}`,
      ]
    : [];

  const head = [
    [
      'Roll',
      'ID',
      'Student Name',
      ...compHeaders,
      ...iaHeaders,
      `Total /${subjectMeta.maxMarks}`,
      'Grade',
      'Status',
    ],
  ];

  const body = report.students
    .filter((st) => {
      const subRes = st.subjects.find((s) => s.subjectId === subjectId);
      return Boolean(subRes && subRes.isEnrolled !== false && subRes.gradeStatus !== 'not_applicable');
    })
    .map((st) => {
      const subRes = st.subjects.find((s) => s.subjectId === subjectId)!;
      const compCols =
        subjectMeta.componentMode === 'elective'
          ? [
              subRes?.selectedComponentName || '—',
              subRes?.components[0]?.attendanceStatus === 'absent'
                ? 'AB'
                : subRes?.components[0]?.obtainedMarks !== null && subRes?.components[0]?.obtainedMarks !== undefined
                  ? String(subRes.components[0].obtainedMarks)
                  : '—',
            ]
          : subjectMeta.hasComponents
            ? (subRes?.components.map((c) =>
                c.attendanceStatus === 'absent' ? 'AB' : c.obtainedMarks !== null ? String(c.obtainedMarks) : '—'
              ) ?? [])
            : subjectMeta.hasInternalAssessment
              ? [
                  subRes?.components[0]?.attendanceStatus === 'absent'
                    ? 'AB'
                    : subRes?.components[0]?.obtainedMarks !== null && subRes?.components[0]?.obtainedMarks !== undefined
                      ? String(subRes.components[0].obtainedMarks)
                      : '—',
                ]
              : [];
      const iaCols = subjectMeta.hasInternalAssessment
        ? [
            subRes?.iaNotebookMarks !== null && subRes?.iaNotebookMarks !== undefined ? String(subRes.iaNotebookMarks) : '—',
            subRes?.iaUnitTestMarks !== null && subRes?.iaUnitTestMarks !== undefined ? String(subRes.iaUnitTestMarks) : '—',
            subRes?.iaPracticalMarks !== null && subRes?.iaPracticalMarks !== undefined ? String(subRes.iaPracticalMarks) : '—',
            subRes?.iaParticipationMarks !== null && subRes?.iaParticipationMarks !== undefined
              ? String(subRes.iaParticipationMarks)
              : '—',
            subRes?.iaTotalMarks !== null && subRes?.iaTotalMarks !== undefined ? String(subRes.iaTotalMarks) : '—',
          ]
        : [];
      return [
        String(st.rollNumber).padStart(2, '0'),
        st.studentCode,
        st.studentName,
        ...compCols,
        ...iaCols,
        subRes?.isComplete && subRes.obtainedMarks !== null ? String(subRes.obtainedMarks) : 'Pending',
        subRes ? getSubjectDisplayGrade(subRes) : 'Pending',
        subRes?.isComplete ? (subRes.isPassed ? 'Pass' : 'Fail') : 'Pending',
      ];
    });

  autoTable(doc, {
    startY: 28,
    head,
    body,
    theme: 'grid',
    headStyles: { fillColor: [30, 58, 95], textColor: [255, 255, 255], fontSize: 8.5 },
    styles: { fontSize: 8.5, cellPadding: 2.2 },
  });

  const subClassPart =
    report.classInfo.hasSections === false
      ? report.classInfo.className.replace(/\s+/g, '')
      : `${report.classInfo.className.replace(/\s+/g, '')}_${report.classInfo.sectionName}`;
  doc.save(`${subjectMeta.subjectCode}_${subClassPart}_${report.examination.name.replace(/\s+/g, '_')}.pdf`);
}

export async function exportSubmissionMonitoringPDF(
  examName: string,
  rows: MonitoringRow[],
  schoolInfo: SchoolInfo
): Promise<void> {
  const doc = new jsPDF({ orientation: 'landscape', unit: 'mm', format: 'a4' });
  const logoDataUrl = await loadPdfLogoDataUrl(schoolInfo.schoolLogo);

  doc.setFillColor(30, 58, 95);
  doc.rect(0, 0, 297, 22, 'F');
  let headerTextX = 12;
  if (logoDataUrl) {
    doc.setFillColor(255, 255, 255);
    doc.roundedRect(10, 3, 16, 16, 1.5, 1.5, 'F');
    doc.addImage(logoDataUrl, 'PNG', 10.8, 3.8, 14.4, 14.4);
    headerTextX = 30;
  }
  doc.setTextColor(255, 255, 255);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(13);
  doc.text(`${schoolInfo.schoolName} — Marks Submission Monitoring Report`, headerTextX, 10);
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(9.5);
  doc.text(`Examination: ${examName} | Generated: ${new Date().toLocaleDateString()}`, headerTextX, 17);

  autoTable(doc, {
    startY: 28,
    head: [['Class', 'Sec', 'Subject', 'Component', 'Max', 'Assigned Teacher', 'Entered', 'Submitted', 'Status', 'IA Status']],
    body: rows.map((r) => [
      r.className,
      r.hasSections === false ? '—' : r.sectionName,
      r.subjectName,
      r.componentName,
      String(r.maxMarks),
      r.teacherName || 'Unassigned',
      `${r.enteredCount}/${r.totalStudents}`,
      `${r.submittedCount}/${r.totalStudents}`,
      r.submissionStatus,
      r.iaStatus,
    ]),
    theme: 'grid',
    headStyles: { fillColor: [30, 58, 95], textColor: [255, 255, 255], fontSize: 8.5 },
    styles: { fontSize: 8, cellPadding: 2 },
  });

  doc.save(`Teacher_Submission_Report_${examName.replace(/\s+/g, '_')}.pdf`);
}
