export type CoScholasticGrade = 'A' | 'B' | 'C';

export const CO_SCHOLASTIC_SCALE: Record<CoScholasticGrade, { points: number; label: string }> = {
  A: { points: 5, label: 'A (5)' },
  B: { points: 4, label: 'B (4)' },
  C: { points: 2, label: 'C (2)' },
};

export interface CoScholasticItemDef {
  key: string;
  label: string;
}

export interface CoScholasticSectionDef {
  id: 'part1b' | 'part2' | 'part3';
  title: string;
  columnHeader: 'Activities' | 'Areas';
  items: CoScholasticItemDef[];
}

export const CO_SCHOLASTIC_SECTIONS: CoScholasticSectionDef[] = [
  {
    id: 'part1b',
    title: 'Part-1 (B): Scholastic Area (To be assessed on a 3 point scale)',
    columnHeader: 'Activities',
    items: [
      { key: 'cca', label: 'Participation in Co-Curricular Activities (CCA)' },
      { key: 'music_culture_art', label: 'Music/Culture/Art' },
      { key: 'reading_library', label: 'Reading/Library' },
      { key: 'clubs', label: 'Clubs: Red Ribbon/Interact Club/NCC/NSS/Atma Nirbhar' },
      { key: 'hostel_activities', label: 'Hostel Activities/Responsibilities' },
    ],
  },
  {
    id: 'part2',
    title: 'Part-2: Health & Physical Education (To be assessed on a 3 point scale)',
    columnHeader: 'Activities',
    items: [
      { key: 'games_sports', label: 'Games and Sports (Basketball/Football)' },
      { key: 'health_fitness', label: 'Health and Fitness' },
      { key: 'service', label: 'Service' },
    ],
  },
  {
    id: 'part3',
    title: 'Part-3: Discipline (To be assessed on a 3 point scale)',
    columnHeader: 'Areas',
    items: [
      { key: 'discipline', label: 'Discipline' },
      { key: 'attitude_temperament', label: 'Attitude/Temperament' },
    ],
  },
];

export const CO_SCHOLASTIC_ALL_ITEMS: CoScholasticItemDef[] = CO_SCHOLASTIC_SECTIONS.flatMap((s) => s.items);
export const CO_SCHOLASTIC_ITEM_KEYS = new Set<string>(CO_SCHOLASTIC_ALL_ITEMS.map((i) => i.key));
export const CO_SCHOLASTIC_MAX_POINTS = CO_SCHOLASTIC_ALL_ITEMS.length * CO_SCHOLASTIC_SCALE.A.points;

export function isValidCoScholasticGrade(value: unknown): value is CoScholasticGrade {
  return value === 'A' || value === 'B' || value === 'C';
}

export function getCoScholasticPoints(grade: CoScholasticGrade): number {
  return CO_SCHOLASTIC_SCALE[grade].points;
}

export function summarizeCoScholasticGrades(
  grades: Record<string, CoScholasticGrade | undefined> | undefined | null
): { gradedCount: number; totalItems: number; totalPoints: number | null; maxPoints: number } {
  const totalItems = CO_SCHOLASTIC_ALL_ITEMS.length;
  const maxPoints = CO_SCHOLASTIC_MAX_POINTS;
  if (!grades) {
    return { gradedCount: 0, totalItems, totalPoints: null, maxPoints };
  }
  let gradedCount = 0;
  let pointsSum = 0;
  for (const item of CO_SCHOLASTIC_ALL_ITEMS) {
    const g = grades[item.key];
    if (isValidCoScholasticGrade(g)) {
      gradedCount++;
      pointsSum += getCoScholasticPoints(g);
    }
  }
  return {
    gradedCount,
    totalItems,
    totalPoints: gradedCount > 0 ? pointsSum : null,
    maxPoints,
  };
}
