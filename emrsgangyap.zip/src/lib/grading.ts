import type { GradeRule } from '../types';

export const STANDARD_GRADING_SCALE: GradeRule[] = [
  { grade: 'A1', minPct: 91, maxPct: 100, remark: 'Outstanding' },
  { grade: 'A2', minPct: 81, maxPct: 90.99, remark: 'Excellent' },
  { grade: 'B1', minPct: 71, maxPct: 80.99, remark: 'Very Good' },
  { grade: 'B2', minPct: 61, maxPct: 70.99, remark: 'Good' },
  { grade: 'C1', minPct: 51, maxPct: 60.99, remark: 'Satisfactory' },
  { grade: 'C2', minPct: 41, maxPct: 50.99, remark: 'Acceptable' },
  { grade: 'D', minPct: 33, maxPct: 40.99, remark: 'Pass' },
  { grade: 'E', minPct: 0, maxPct: 32.99, remark: 'Needs Improvement' },
];

export interface SubjectGradeEvaluation {
  grade: string | null;
  display: string;
  remark: string;
  percentage: number | null;
  status: 'graded' | 'absent' | 'pending' | 'not_submitted';
}

export function calculateGradeFromPercentage(
  percentage: number,
  scale: GradeRule[] = STANDARD_GRADING_SCALE
): { grade: string; remark: string } {
  const effectiveScale = scale && scale.length > 0 ? scale : STANDARD_GRADING_SCALE;
  const sorted = [...effectiveScale].sort((a, b) => b.minPct - a.minPct);
  for (const rule of sorted) {
    if (percentage >= rule.minPct) {
      return { grade: rule.grade, remark: rule.remark };
    }
  }
  const lowest = sorted[sorted.length - 1];
  return lowest ? { grade: lowest.grade, remark: lowest.remark } : { grade: 'E', remark: 'Needs Improvement' };
}

export function calculateStandardGrade(percentage: number): { grade: string; remark: string } {
  if (percentage >= 91) return { grade: 'A1', remark: 'Outstanding' };
  if (percentage >= 81) return { grade: 'A2', remark: 'Excellent' };
  if (percentage >= 71) return { grade: 'B1', remark: 'Very Good' };
  if (percentage >= 61) return { grade: 'B2', remark: 'Good' };
  if (percentage >= 51) return { grade: 'C1', remark: 'Satisfactory' };
  if (percentage >= 41) return { grade: 'C2', remark: 'Acceptable' };
  if (percentage >= 33) return { grade: 'D', remark: 'Pass' };
  return { grade: 'E', remark: 'Needs Improvement' };
}

export function calculateSubjectGrade(
  obtainedMarks: number | null | undefined,
  maxMarks: number,
  options?: {
    isAbsent?: boolean;
    isPending?: boolean;
    isNotSubmitted?: boolean;
    scale?: GradeRule[];
  }
): SubjectGradeEvaluation {
  if (options?.isAbsent) {
    return {
      grade: null,
      display: 'AB',
      remark: 'Absent',
      percentage: null,
      status: 'absent',
    };
  }

  if (obtainedMarks === null || obtainedMarks === undefined || Number.isNaN(Number(obtainedMarks)) || options?.isPending) {
    const notSubmitted = Boolean(options?.isNotSubmitted);
    return {
      grade: null,
      display: notSubmitted ? 'Not Submitted' : 'Pending',
      remark: notSubmitted ? 'Not Submitted' : 'Pending',
      percentage: null,
      status: notSubmitted ? 'not_submitted' : 'pending',
    };
  }

  const total = Number(obtainedMarks);
  const safeMax = maxMarks > 0 ? Number(maxMarks) : 100;
  const pct = Number(((total / safeMax) * 100).toFixed(2));
  const { grade, remark } = calculateStandardGrade(pct);

  return {
    grade,
    display: grade,
    remark,
    percentage: pct,
    status: 'graded',
  };
}

/**
 * Generates the exact 8-tier nested IF Excel formula for subject grading.
 * When maxMarks === 100 (80 External + 20 Internal), uses the direct cell reference:
 * =IF(ISNUMBER(H2),IF(H2>=91,"A1",IF(H2>=81,"A2",IF(H2>=71,"B1",IF(H2>=61,"B2",IF(H2>=51,"C1",IF(H2>=41,"C2",IF(H2>=33,"D","E"))))))),IF(H2="AB","AB","Pending"))
 * Missing/non-numeric values safely resolve to "Pending" / "Not Submitted" instead of "E".
 */
export function buildExcelGradeFormula(
  totalCellRef: string,
  maxMarks = 100,
  missingLabel: 'Pending' | 'Not Submitted' = 'Pending'
): string {
  const scoreExpr = maxMarks === 100 || maxMarks <= 0 ? totalCellRef : `(${totalCellRef}/${maxMarks}*100)`;
  const coreIf = `IF(${scoreExpr}>=91,"A1",IF(${scoreExpr}>=81,"A2",IF(${scoreExpr}>=71,"B1",IF(${scoreExpr}>=61,"B2",IF(${scoreExpr}>=51,"C1",IF(${scoreExpr}>=41,"C2",IF(${scoreExpr}>=33,"D","E")))))))`;
  return `=IF(ISNUMBER(${totalCellRef}),${coreIf},IF(${totalCellRef}="AB","AB","${missingLabel}"))`;
}

export function getGradeBadgeClass(grade: string | null | undefined, status?: string): string {
  if (status === 'absent' || grade === 'AB') {
    return 'bg-rose-50 text-rose-700 border-rose-200';
  }
  if (!grade || status === 'pending' || status === 'not_submitted' || grade === 'Pending' || grade === 'Not Submitted') {
    return 'bg-amber-50 text-amber-800 border-amber-200';
  }
  switch (grade) {
    case 'A1':
    case 'A2':
      return 'bg-emerald-50 text-emerald-800 border-emerald-200';
    case 'B1':
    case 'B2':
      return 'bg-sky-50 text-sky-800 border-sky-200';
    case 'C1':
    case 'C2':
      return 'bg-indigo-50 text-indigo-800 border-indigo-200';
    case 'D':
      return 'bg-slate-100 text-slate-800 border-slate-300';
    case 'E':
      return 'bg-red-50 text-red-700 border-red-200';
    default:
      return 'bg-slate-100 text-slate-700 border-slate-200';
  }
}

export function formatClassSectionLabel(
  className: string,
  sectionName?: string | null,
  hasSections: boolean | number = true
): string {
  if (hasSections === false || hasSections === 0) {
    return className;
  }
  const cleanSection = String(sectionName || '').trim();
  if (!cleanSection || cleanSection.toLowerCase() === 'general') {
    return className;
  }
  return `${className} · Section ${cleanSection}`;
}

export function parseTargetClassIds(raw: string | number[] | null | undefined): number[] {
  if (Array.isArray(raw)) {
    return raw.map((v) => Number(v)).filter((n) => Number.isFinite(n) && n > 0);
  }
  if (!raw || typeof raw !== 'string') return [];
  const trimmed = raw.trim();
  if (!trimmed) return [];
  try {
    const parsed = JSON.parse(trimmed);
    if (Array.isArray(parsed)) {
      return parsed.map((v) => Number(v)).filter((n) => Number.isFinite(n) && n > 0);
    }
  } catch {
    return trimmed
      .split(',')
      .map((s) => Number(s.trim()))
      .filter((n) => Number.isFinite(n) && n > 0);
  }
  return [];
}

export function doesSubjectApplyToClass(
  rawTargetClassIds: string | number[] | null | undefined,
  classId: number
): boolean {
  const ids = parseTargetClassIds(rawTargetClassIds);
  return ids.length === 0 || ids.includes(Number(classId));
}

