const TOKEN_KEY = 'school_portal_session_token';
const DEFAULT_TIMEOUT_MS = 15000;

let memoryToken: string | null = null;

export function getStoredToken(): string | null {
  if (memoryToken) return memoryToken;
  try {
    const ls = window.localStorage?.getItem(TOKEN_KEY);
    if (ls) {
      memoryToken = ls;
      return ls;
    }
  } catch {
    // ignore storage errors
  }
  try {
    const ss = window.sessionStorage?.getItem(TOKEN_KEY);
    if (ss) {
      memoryToken = ss;
      return ss;
    }
  } catch {
    // ignore storage errors
  }
  return null;
}

export function setStoredToken(token: string | null) {
  memoryToken = token;
  try {
    if (token) window.localStorage?.setItem(TOKEN_KEY, token);
    else window.localStorage?.removeItem(TOKEN_KEY);
  } catch {
    // ignore storage errors on restricted mobile WebViews
  }
  try {
    if (token) window.sessionStorage?.setItem(TOKEN_KEY, token);
    else window.sessionStorage?.removeItem(TOKEN_KEY);
  } catch {
    // ignore storage errors
  }
}

export interface ApiFetchOptions extends RequestInit {
  timeoutMs?: number;
}

export function extractErrorMessage(input: unknown, fallback = 'An unexpected error occurred.'): string {
  if (typeof input === 'string') {
    const trimmed = input.trim();
    return trimmed && trimmed !== '[object Object]' ? trimmed : fallback;
  }
  if (input instanceof Error) {
    return extractErrorMessage(input.message, fallback);
  }
  if (input && typeof input === 'object') {
    const obj = input as Record<string, unknown>;
    if (obj.error !== undefined) {
      const nested = extractErrorMessage(obj.error, '');
      if (nested) return nested;
    }
    const msg = typeof obj.message === 'string' ? obj.message.trim() : '';
    const code = typeof obj.code === 'string' || typeof obj.code === 'number' ? String(obj.code) : '';
    const details = typeof obj.details === 'string' ? obj.details.trim() : '';
    if (msg && code) return `${msg} (${code})`;
    if (msg) return msg;
    if (details) return details;
    if (typeof obj.error_description === 'string' && obj.error_description.trim()) {
      return obj.error_description.trim();
    }
    try {
      const serialized = JSON.stringify(obj);
      if (serialized && serialized !== '{}') return serialized;
    } catch {
      // ignore serialization errors
    }
  }
  return fallback;
}

export function isAbortError(err: unknown): boolean {
  return Boolean(err && typeof err === 'object' && (err as { name?: string }).name === 'AbortError');
}

export async function apiFetch<T = any>(url: string, options: ApiFetchOptions = {}): Promise<T> {
  const { timeoutMs = DEFAULT_TIMEOUT_MS, signal: externalSignal, ...fetchOptions } = options;
  const token = getStoredToken();
  const headers = new Headers(fetchOptions.headers || {});
  if (!headers.has('Content-Type') && fetchOptions.body && !(fetchOptions.body instanceof FormData)) {
    headers.set('Content-Type', 'application/json');
  }
  if (token && !headers.has('Authorization')) {
    headers.set('Authorization', `Bearer ${token}`);
  }
  if (!headers.has('Accept')) {
    headers.set('Accept', 'application/json');
  }

  const controller = new AbortController();
  let timedOut = false;
  let externallyAborted = Boolean(externalSignal?.aborted);
  const timer = window.setTimeout(() => {
    timedOut = true;
    controller.abort();
  }, timeoutMs);

  const onExternalAbort = () => {
    externallyAborted = true;
    controller.abort();
  };
  if (externalSignal) {
    if (externalSignal.aborted) {
      externallyAborted = true;
      controller.abort();
    } else {
      externalSignal.addEventListener('abort', onExternalAbort, { once: true });
    }
  }

  let res: Response;
  try {
    res = await fetch(url, {
      ...fetchOptions,
      cache: 'no-store',
      headers,
      credentials: 'include',
      signal: controller.signal,
    });
  } catch (err: any) {
    if (timedOut) {
      throw new Error('Connection timed out while contacting the server. Please check your network and retry.');
    }
    if (externallyAborted || err?.name === 'AbortError') {
      const abortErr = new Error('Request was cancelled.');
      abortErr.name = 'AbortError';
      throw abortErr;
    }
    throw new Error('Unable to reach the school server. Please check your internet connection and retry.');
  } finally {
    window.clearTimeout(timer);
    if (externalSignal) {
      externalSignal.removeEventListener('abort', onExternalAbort);
    }
  }

  const contentType = res.headers.get('content-type') || '';
  const rawText = await res.text();

  if (!res.ok) {
    let errMessage = `Server error (${res.status}${res.statusText ? ` ${res.statusText}` : ''})`;
    if (rawText) {
      try {
        const parsed = JSON.parse(rawText);
        errMessage = extractErrorMessage(parsed, errMessage);
      } catch {
        // non-JSON error body (e.g., proxy 502/503 HTML page)
      }
    }
    if (res.status === 404 && url.startsWith('/api/')) {
      errMessage = `Backend API route unavailable (404): ${errMessage}`;
    }
    throw new Error(errMessage);
  }

  if (contentType.includes('application/json') || rawText.trim().startsWith('{') || rawText.trim().startsWith('[')) {
    try {
      return JSON.parse(rawText) as T;
    } catch {
      throw new Error('Received malformed JSON data from the server.');
    }
  }

  throw new Error('Unexpected response from server (expected JSON). Please ensure the backend server is running.');
}

export async function downloadAuthorizedFile(url: string, filename: string) {
  const token = getStoredToken();
  const controller = new AbortController();
  const timer = window.setTimeout(() => controller.abort(), 30000);
  try {
    const res = await fetch(url, {
      cache: 'no-store',
      headers: token ? { Authorization: `Bearer ${token}` } : {},
      credentials: 'include',
      signal: controller.signal,
    });
    if (!res.ok) {
      throw new Error(`Failed to download file (${res.status}).`);
    }
    const blob = await res.blob();
    const objUrl = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = objUrl;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    a.remove();
    window.setTimeout(() => URL.revokeObjectURL(objUrl), 1000);
  } finally {
    window.clearTimeout(timer);
  }
}
