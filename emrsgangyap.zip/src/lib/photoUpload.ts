const TARGET_MAX_PHOTO_BYTES = 96 * 1024;
const STRICT_MAX_PHOTO_BYTES = 100 * 1024;

export function getDataUrlByteSize(dataUrl: string): number {
  const trimmed = (dataUrl || '').trim();
  const commaIdx = trimmed.indexOf(',');
  if (commaIdx === -1) return 0;
  const b64 = trimmed.slice(commaIdx + 1);
  if (!b64) return 0;
  const padding = b64.endsWith('==') ? 2 : b64.endsWith('=') ? 1 : 0;
  return Math.max(0, Math.floor((b64.length * 3) / 4) - padding);
}

export function formatPhotoByteSize(bytes: number): string {
  if (!bytes || bytes <= 0) return '0 KB';
  return `${Math.max(1, Math.round(bytes / 1024))} KB`;
}

export function formatResultDateDisplay(isoDate?: string | null): string {
  const clean = (isoDate || '').trim();
  if (!clean) return '—';
  const match = clean.match(/^(\d{4})-(\d{2})-(\d{2})$/);
  if (!match) return clean;
  const year = Number(match[1]);
  const monthIdx = Number(match[2]) - 1;
  const day = Number(match[3]);
  const months = [
    'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun',
    'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec',
  ];
  if (monthIdx < 0 || monthIdx > 11 || day < 1 || day > 31) return clean;
  return `${String(day).padStart(2, '0')} ${months[monthIdx]} ${year}`;
}

export function compressCanvasToUnder100KB(
  sourceCanvas: HTMLCanvasElement,
  targetBytes = TARGET_MAX_PHOTO_BYTES
): { dataUrl: string; byteSize: number } {
  const qualities = [0.86, 0.76, 0.66, 0.56, 0.46, 0.36, 0.28, 0.2];
  const scales = [1, 0.85, 0.72, 0.58, 0.45];

  let bestUrl = '';
  let bestBytes = Number.POSITIVE_INFINITY;

  for (const scale of scales) {
    let workingCanvas = sourceCanvas;
    if (scale < 1) {
      const w = Math.max(96, Math.round(sourceCanvas.width * scale));
      const h = Math.max(112, Math.round(sourceCanvas.height * scale));
      const scaled = document.createElement('canvas');
      scaled.width = w;
      scaled.height = h;
      const ctx = scaled.getContext('2d');
      if (ctx) {
        ctx.fillStyle = '#FFFFFF';
        ctx.fillRect(0, 0, w, h);
        ctx.drawImage(sourceCanvas, 0, 0, w, h);
        workingCanvas = scaled;
      }
    }

    for (const quality of qualities) {
      const candidate = workingCanvas.toDataURL('image/jpeg', quality);
      if (!candidate || !candidate.startsWith('data:image/')) continue;
      const size = getDataUrlByteSize(candidate);
      if (size < bestBytes) {
        bestUrl = candidate;
        bestBytes = size;
      }
      if (size > 0 && size <= targetBytes) {
        return { dataUrl: candidate, byteSize: size };
      }
    }
  }

  if (!bestUrl || bestBytes >= STRICT_MAX_PHOTO_BYTES) {
    throw new Error('Could not compress image under 100 KB. Please choose a clearer smaller photo.');
  }
  return { dataUrl: bestUrl, byteSize: bestBytes };
}

export async function compressPhotoFileToUnder100KB(
  file: File
): Promise<{ dataUrl: string; byteSize: number }> {
  if (!file.type.startsWith('image/')) {
    throw new Error('Please choose a valid image file (JPG, PNG, or WebP).');
  }
  if (file.size > 15 * 1024 * 1024) {
    throw new Error('Selected photo is over 15 MB. Please choose a smaller image.');
  }

  const objectUrl = URL.createObjectURL(file);
  try {
    const img = await new Promise<HTMLImageElement>((resolve, reject) => {
      const el = new Image();
      el.onload = () => resolve(el);
      el.onerror = () => reject(new Error('Could not read the selected image file.'));
      el.src = objectUrl;
    });

    const maxW = 300;
    const maxH = 360;
    const srcW = img.naturalWidth || img.width || 240;
    const srcH = img.naturalHeight || img.height || 300;
    const scale = Math.min(1, maxW / srcW, maxH / srcH);
    const outW = Math.max(1, Math.round(srcW * scale));
    const outH = Math.max(1, Math.round(srcH * scale));

    const canvas = document.createElement('canvas');
    canvas.width = outW;
    canvas.height = outH;
    const ctx = canvas.getContext('2d');
    if (!ctx) {
      throw new Error('Unable to process image in this browser.');
    }
    ctx.fillStyle = '#FFFFFF';
    ctx.fillRect(0, 0, outW, outH);
    ctx.drawImage(img, 0, 0, outW, outH);

    return compressCanvasToUnder100KB(canvas);
  } finally {
    URL.revokeObjectURL(objectUrl);
  }
}

export function captureVideoFrameToUnder100KB(
  video: HTMLVideoElement
): { dataUrl: string; byteSize: number } {
  const vw = video.videoWidth || 640;
  const vh = video.videoHeight || 480;
  if (!vw || !vh) {
    throw new Error('Camera preview is not ready yet. Please wait a moment and try again.');
  }

  // Crop centered 5:6 passport aspect region for clean student ID/marksheet portrait
  const targetAspect = 5 / 6;
  const currentAspect = vw / vh;
  let sx = 0;
  let sy = 0;
  let sw = vw;
  let sh = vh;

  if (currentAspect > targetAspect) {
    sw = Math.round(vh * targetAspect);
    sx = Math.round((vw - sw) / 2);
  } else if (currentAspect < targetAspect) {
    sh = Math.round(vw / targetAspect);
    sy = Math.round((vh - sh) / 2);
  }

  const outW = 280;
  const outH = 336;
  const canvas = document.createElement('canvas');
  canvas.width = outW;
  canvas.height = outH;
  const ctx = canvas.getContext('2d');
  if (!ctx) {
    throw new Error('Unable to capture image in this browser.');
  }
  ctx.fillStyle = '#FFFFFF';
  ctx.fillRect(0, 0, outW, outH);
  ctx.drawImage(video, sx, sy, sw, sh, 0, 0, outW, outH);

  return compressCanvasToUnder100KB(canvas);
}
