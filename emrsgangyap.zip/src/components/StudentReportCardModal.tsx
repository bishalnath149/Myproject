import React, { useMemo, useState } from 'react';
import { X, FileDown, Printer, AlertTriangle } from 'lucide-react';
import type {
  CombinedTermClassReport,
  CombinedTermStudentResult,
  ConsolidatedClassReport,
  ConsolidatedStudentResult,
  ConsolidatedSubjectResult,
  SchoolInfo,
} from '../types';
import {
  CBSE_LOGO_PATH,
  exportCombinedReportCardPDF,
  exportIndividualReportCardPDF,
} from '../lib/exports';
import { CO_SCHOLASTIC_SECTIONS } from '../lib/coScholastic';
import { formatClassSectionLabel, getGradeBadgeClass } from '../lib/grading';
import { formatResultDateDisplay } from '../lib/photoUpload';
import { ResultStatusLabel } from './StatusIndicator';
import { SchoolLogo } from './SchoolLogo';

interface Props {
  student: ConsolidatedStudentResult;
  report: ConsolidatedClassReport;
  combinedReport?: CombinedTermClassReport | null;
  initialMode?: 'term1' | 'combined';
  schoolInfo: SchoolInfo;
  onClose: () => void;
}

function formatAttendanceDisplay(daysAttended?: number | null, totalDays?: number | null): string {
  if (daysAttended === null || daysAttended === undefined) {
    if (totalDays !== null && totalDays !== undefined) return `— / ${totalDays}`;
    return '—';
  }
  if (totalDays === null || totalDays === undefined) return `${daysAttended}`;
  return `${daysAttended}/${totalDays}`;
}

function getScholasticBreakdown(sub: ConsolidatedSubjectResult | null): {
  internalTest: string;
  practical: string;
  participation: string;
  termExam: string;
  total: string;
  grade: string;
  isAbsent: boolean;
  isIncomplete: boolean;
} {
  if (!sub || sub.isEnrolled === false || sub.gradeStatus === 'not_applicable') {
    return {
      internalTest: '—',
      practical: '—',
      participation: '—',
      termExam: '—',
      total: '—',
      grade: '—',
      isAbsent: false,
      isIncomplete: false,
    };
  }

  const isAbsent = sub.components.some((c) => c.attendanceStatus === 'absent');
  const hasInternalTest = sub.hasInternalAssessment && sub.iaNotebookMax + sub.iaUnitTestMax > 0;
  const internalTest = !hasInternalTest
    ? '—'
    : sub.iaNotebookMarks === null && sub.iaUnitTestMarks === null
      ? '—'
      : String(Number(((sub.iaNotebookMarks ?? 0) + (sub.iaUnitTestMarks ?? 0)).toFixed(2)));

  const practical =
    !sub.hasInternalAssessment || sub.iaPracticalMax <= 0
      ? '—'
      : sub.iaPracticalMarks !== null && sub.iaPracticalMarks !== undefined
        ? String(sub.iaPracticalMarks)
        : '—';

  const participation =
    !sub.hasInternalAssessment || sub.iaParticipationMax <= 0
      ? '—'
      : sub.iaParticipationMarks !== null && sub.iaParticipationMarks !== undefined
        ? String(sub.iaParticipationMarks)
        : '—';

  let termExam = '—';
  if (isAbsent) {
    termExam = 'AB';
  } else if (sub.writtenObtainedMarks !== null && sub.writtenObtainedMarks !== undefined) {
    termExam = String(sub.writtenObtainedMarks);
  } else if (sub.components.length > 0 && sub.components.every((c) => c.obtainedMarks !== null)) {
    termExam = String(
      Number(sub.components.reduce((acc, c) => acc + (c.obtainedMarks ?? 0), 0).toFixed(2))
    );
  } else if (sub.gradeStatus === 'not_submitted') {
    termExam = 'N/S';
  }

  if (isAbsent) {
    return {
      internalTest,
      practical,
      participation,
      termExam: 'AB',
      total: 'AB',
      grade: 'AB',
      isAbsent: true,
      isIncomplete: false,
    };
  }

  if (sub.isComplete && sub.obtainedMarks !== null) {
    return {
      internalTest,
      practical,
      participation,
      termExam,
      total: String(sub.obtainedMarks),
      grade: sub.grade || '—',
      isAbsent: false,
      isIncomplete: false,
    };
  }

  const pendingLabel = sub.gradeStatus === 'not_submitted' ? 'N/S' : 'Pend.';
  return {
    internalTest,
    practical,
    participation,
    termExam,
    total: pendingLabel,
    grade: pendingLabel,
    isAbsent: false,
    isIncomplete: true,
  };
}

export function StudentReportCardModal({
  student,
  report,
  combinedReport,
  initialMode = 'term1',
  schoolInfo,
  onClose,
}: Props) {
  const combinedStudent: CombinedTermStudentResult | null = useMemo(() => {
    if (!combinedReport) return null;
    return combinedReport.students.find((s) => s.studentId === student.studentId) || null;
  }, [combinedReport, student.studentId]);

  const term1ViewReport: ConsolidatedClassReport = combinedReport?.term1Report || report;
  const term1ViewStudent: ConsolidatedStudentResult = useMemo(() => {
    if (combinedReport?.term1Report) {
      const matched = combinedReport.term1Report.students.find((s) => s.studentId === student.studentId);
      if (matched) return matched;
    }
    return student;
  }, [combinedReport, student]);

  const canShowCombined = Boolean(combinedReport && combinedStudent);
  const [viewMode, setViewMode] = useState<'term1' | 'combined'>(
    initialMode === 'combined' && canShowCombined ? 'combined' : 'term1'
  );
  const [downloadingPdf, setDownloadingPdf] = useState(false);

  const effectiveMode: 'term1' | 'combined' =
    viewMode === 'combined' && canShowCombined ? 'combined' : 'term1';

  const activeSingleTermNum = term1ViewReport.coScholasticMeta?.term === 2 ? 2 : 1;
  const activeSingleTermRec =
    activeSingleTermNum === 2 ? term1ViewStudent.termRecords?.term2 : term1ViewStudent.termRecords?.term1;

  const coTerm1 =
    effectiveMode === 'combined' && combinedStudent
      ? combinedStudent.coScholastic?.term1 || {}
      : term1ViewStudent.coScholastic?.term1 || {};
  const coTerm2 =
    effectiveMode === 'combined' && combinedStudent
      ? combinedStudent.coScholastic?.term2 || {}
      : term1ViewStudent.coScholastic?.term2 || {};

  const activeResultDate =
    effectiveMode === 'combined'
      ? combinedReport?.classInfo.resultDate
      : term1ViewReport.classInfo.resultDate;

  const showCoScholastic =
    effectiveMode === 'combined' ||
    Boolean(term1ViewReport.coScholasticMeta?.eligible) ||
    Boolean(term1ViewReport.coScholasticMeta?.hasAnyGradesForYear) ||
    Object.keys(coTerm1).length > 0 ||
    Object.keys(coTerm2).length > 0;

  const handleDownloadPdf = async () => {
    setDownloadingPdf(true);
    try {
      if (effectiveMode === 'combined' && combinedStudent && combinedReport) {
        await exportCombinedReportCardPDF(combinedStudent, combinedReport, schoolInfo);
      } else {
        await exportIndividualReportCardPDF(term1ViewStudent, term1ViewReport, schoolInfo);
      }
    } finally {
      setDownloadingPdf(false);
    }
  };

  const displayHasSections =
    effectiveMode === 'combined'
      ? combinedReport?.classInfo.hasSections ?? combinedStudent?.hasSections ?? true
      : term1ViewReport.classInfo.hasSections ?? term1ViewStudent.hasSections ?? true;

  const profileSource = effectiveMode === 'combined' && combinedStudent ? combinedStudent : term1ViewStudent;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/50 p-3 sm:p-4 overflow-y-auto">
      <div
        className={`bg-white border border-slate-200 rounded-xl w-full ${
          effectiveMode === 'combined' ? 'max-w-6xl' : 'max-w-4xl'
        } max-h-[92vh] overflow-y-auto shadow-xl`}
      >
        {/* Top Action Bar */}
        <div className="sticky top-0 z-10 flex flex-col lg:flex-row lg:items-center lg:justify-between gap-3 px-4 sm:px-6 py-3.5 bg-white border-b border-slate-200 no-print">
          <div className="flex items-start justify-between gap-2">
            <div>
              <h2 className="text-base font-semibold text-slate-900">Student Report Card</h2>
              <p className="text-xs text-slate-500">
                {profileSource.studentCode} ·{' '}
                {formatClassSectionLabel(profileSource.className, profileSource.sectionName, displayHasSections)}
                {profileSource.stream ? ` (${profileSource.stream})` : ''} ·{' '}
                {effectiveMode === 'combined'
                  ? `1st Term & Annual Combined (${combinedReport?.academicYear})`
                  : term1ViewReport.examination.name}
              </p>
            </div>
            <button
              type="button"
              onClick={onClose}
              className="lg:hidden p-2 text-slate-500 hover:text-slate-900 rounded-lg hover:bg-slate-100 cursor-pointer"
              aria-label="Close report card"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            {/* 2-Option Marksheet Format Switcher */}
            {canShowCombined && (
              <div className="inline-flex rounded-lg border border-slate-200 bg-slate-100 p-0.5 text-xs">
                <button
                  type="button"
                  onClick={() => setViewMode('term1')}
                  className={`px-3 py-1.5 rounded-md font-medium transition-colors cursor-pointer whitespace-nowrap ${
                    effectiveMode === 'term1'
                      ? 'bg-white text-slate-900 shadow-xs'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  1st Term Only
                </button>
                <button
                  type="button"
                  onClick={() => setViewMode('combined')}
                  className={`px-3 py-1.5 rounded-md font-medium transition-colors cursor-pointer whitespace-nowrap ${
                    effectiveMode === 'combined'
                      ? 'bg-[#1E3A5F] text-white shadow-xs'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  Combined (Term I + Annual)
                </button>
              </div>
            )}

            <button
              type="button"
              onClick={() => window.print()}
              className="inline-flex items-center justify-center gap-1.5 px-3 py-2 min-h-[38px] text-xs font-medium text-slate-700 bg-white border border-slate-300 rounded-lg hover:bg-slate-50 transition-colors whitespace-nowrap cursor-pointer"
            >
              <Printer className="w-3.5 h-3.5" />
              Print
            </button>
            <button
              type="button"
              onClick={handleDownloadPdf}
              disabled={downloadingPdf}
              className="inline-flex items-center justify-center gap-1.5 px-3.5 py-2 min-h-[38px] text-xs font-medium text-white bg-[#1E3A5F] rounded-lg hover:bg-[#162D4A] disabled:opacity-60 transition-colors whitespace-nowrap cursor-pointer"
            >
              <FileDown className="w-3.5 h-3.5" />
              {downloadingPdf ? 'Preparing PDF...' : 'Download PDF'}
            </button>
            <button
              type="button"
              onClick={onClose}
              className="hidden lg:inline-flex p-2 text-slate-500 hover:text-slate-900 rounded-lg hover:bg-slate-100 cursor-pointer"
              aria-label="Close report card"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Report Card Document Body */}
        <div className="p-4 sm:p-6 md:p-8 space-y-6">
          {/* Official School Marksheet Banner */}
          <div className="space-y-3 pb-4 border-b border-slate-200">
            <div className="rounded-lg bg-[#1E3A5F] text-white px-4 py-3.5 flex items-center justify-between gap-3">
              <img
                src={CBSE_LOGO_PATH}
                alt="CBSE Logo"
                className="w-14 h-14 sm:w-16 sm:h-16 object-contain rounded-md bg-white p-1 shrink-0"
              />
              <div className="text-center flex-1 min-w-0 leading-snug">
                <h3 className="text-sm sm:text-lg font-bold tracking-tight">
                  Eklavya Model Residential School Gangyap
                </h3>
                <p className="text-[11px] sm:text-xs text-slate-100">
                  (NESTS, Ministry of Tribal Affairs, Govt. of India)
                </p>
                <p className="text-[11px] sm:text-xs text-slate-100">
                  CBSE School No. 37406. Affiliation No.: 1820172.
                </p>
                <p className="text-[11px] sm:text-xs text-slate-100">UDISE: 11020800203</p>
                <p className="text-[11px] sm:text-xs text-slate-100">estd: 2007.</p>
              </div>
              <SchoolLogo
                src={schoolInfo.schoolLogo}
                alt="School Emblem"
                className="w-14 h-14 sm:w-16 sm:h-16 object-contain rounded-md bg-white p-1 shrink-0"
              />
            </div>

            <div className="flex flex-wrap items-center justify-between gap-2 px-1">
              <p className="text-xs font-semibold" style={{ color: 'var(--brand-primary, #1E3A5F)' }}>
                {schoolInfo.siteContent?.reportCardTitle || 'Statement of Marks'} ·{' '}
                {effectiveMode === 'combined'
                  ? `1st Term & Annual Combined (${combinedReport?.academicYear})`
                  : `${term1ViewReport.examination.name} (${term1ViewReport.examination.academicYear})`}
              </p>
              <div className="flex items-center gap-3">
                {effectiveMode === 'term1' && term1ViewStudent.classRank && (
                  <span className="text-xs font-mono text-slate-600 tabular-nums">
                    Class Rank: #{term1ViewStudent.classRank}
                  </span>
                )}
                <ResultStatusLabel
                  status={
                    effectiveMode === 'combined' && combinedStudent
                      ? combinedStudent.overall.resultStatus
                      : term1ViewStudent.resultStatus
                  }
                />
              </div>
            </div>
          </div>

          {/* Student Top Section Info Grid (Full Class Name, Parent Names, Address, Contact, AAPAAR ID — Non-Mandatory; Photo shown on Final Combined Marksheet only) */}
          <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-4 p-4 bg-slate-50 border border-slate-200 rounded-lg text-xs sm:text-sm">
            <div className="flex-1 grid grid-cols-2 sm:grid-cols-4 gap-x-4 gap-y-3">
              <div>
                <div className="text-[11px] text-slate-500">Student Name</div>
                <div className="font-semibold text-slate-900 mt-0.5">{profileSource.studentName}</div>
              </div>
              <div>
                <div className="text-[11px] text-slate-500">Student ID</div>
                <div className="font-mono font-medium text-slate-900 mt-0.5">{profileSource.studentCode}</div>
              </div>
              <div>
                <div className="text-[11px] text-slate-500">Class &amp; Section</div>
                <div className="font-medium text-slate-900 mt-0.5">
                  {formatClassSectionLabel(profileSource.className, profileSource.sectionName, displayHasSections)}
                  {profileSource.stream && (
                    <span className="ml-1.5 px-1.5 py-0.5 text-[10px] font-medium rounded bg-sky-50 text-sky-800 border border-sky-200">
                      {profileSource.stream}
                    </span>
                  )}
                </div>
              </div>
              <div>
                <div className="text-[11px] text-slate-500">Roll Number</div>
                <div className="font-mono font-medium text-slate-900 mt-0.5 tabular-nums">
                  {String(profileSource.rollNumber).padStart(2, '0')}
                </div>
              </div>

              <div>
                <div className="text-[11px] text-slate-500">Father&apos;s Name</div>
                <div className="font-medium text-slate-800 mt-0.5">{profileSource.fatherName || '—'}</div>
              </div>
              <div>
                <div className="text-[11px] text-slate-500">Mother&apos;s Name</div>
                <div className="font-medium text-slate-800 mt-0.5">{profileSource.motherName || '—'}</div>
              </div>
              <div>
                <div className="text-[11px] text-slate-500">Contact No.</div>
                <div className="font-mono text-slate-800 mt-0.5">{profileSource.contactNo || '—'}</div>
              </div>
              <div>
                <div className="text-[11px] text-slate-500">AAPAAR ID</div>
                <div className="font-mono text-slate-800 mt-0.5">{profileSource.aapaarId || '—'}</div>
              </div>
              <div className="col-span-2 sm:col-span-4 pt-1 border-t border-slate-200/70">
                <div className="text-[11px] text-slate-500">Residential Address</div>
                <div className="font-medium text-slate-800 mt-0.5">{profileSource.residentialAddress || '—'}</div>
              </div>
            </div>

            {profileSource.photoUrl && (
              <div className="shrink-0 self-center sm:self-start">
                <img
                  src={profileSource.photoUrl}
                  alt={profileSource.studentName}
                  className="w-24 h-28 sm:w-[96px] sm:h-[116px] object-cover rounded-lg border border-slate-300 bg-white p-0.5 shadow-xs"
                />
              </div>
            )}
          </div>

          {effectiveMode === 'term1' ? (
            (() => {
              const enrolledSubs = term1ViewStudent.subjects.filter(
                (sub) => sub.isEnrolled !== false && sub.gradeStatus !== 'not_applicable'
              );
              const sampleSub = enrolledSubs.find((s) => s.hasInternalAssessment) || enrolledSubs[0];
              const iaMax = sampleSub?.iaMaxMarks || 20;
              const writtenMax = sampleSub?.writtenMaxMarks || 80;
              const totalMax = sampleSub?.maxMarks || 100;
              return (
                <>
                  {term1ViewStudent.resultStatus === 'Incomplete' &&
                    term1ViewStudent.missingComponents.length > 0 && (
                      <div className="flex items-start gap-3 p-3.5 bg-amber-50 border border-amber-200 rounded-lg text-xs text-amber-900">
                        <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
                        <div>
                          <span className="font-semibold">Result Incomplete:</span> Final percentage, grade, and rank
                          are withheld until all required subject marks are submitted. Pending/Draft:{' '}
                          <span className="font-medium">{term1ViewStudent.missingComponents.join(', ')}</span>.
                        </div>
                      </div>
                    )}

                  {/* Option 1: 1st Term Only — Part-1 (A): Scholastic Area */}
                  <div className="border border-slate-300 rounded-lg overflow-x-auto">
                    <table className="w-full text-xs">
                      <thead>
                        <tr className="border-b border-slate-300">
                          <th className="text-left font-bold px-3 py-2 bg-slate-200 text-slate-900 border-r border-slate-300">
                            Part-1 (A): Scholastic Area:
                          </th>
                          <th
                            colSpan={6}
                            className="text-center font-bold px-3 py-2 bg-[#1E3A5F] text-white"
                          >
                            {activeSingleTermNum === 2 ? 'TERM II' : 'TERM I'} — {term1ViewReport.examination.name}
                          </th>
                        </tr>
                        <tr className="bg-slate-100 text-slate-800 border-b border-slate-300">
                          <th
                            rowSpan={2}
                            className="text-left font-bold px-3 py-2 border-r border-slate-300 align-middle"
                          >
                            Subjects
                          </th>
                          <th
                            colSpan={3}
                            className="text-center font-bold px-2 py-1.5 border-r border-slate-300"
                          >
                            Internal Assessment ({iaMax} marks)
                          </th>
                          <th
                            rowSpan={2}
                            className="text-center font-bold px-2 py-1.5 border-r border-slate-300 align-middle"
                          >
                            Term Exam ({writtenMax})
                          </th>
                          <th
                            rowSpan={2}
                            className="text-center font-bold px-2 py-1.5 border-r border-slate-300 align-middle"
                          >
                            Total ({totalMax})
                          </th>
                          <th rowSpan={2} className="text-center font-bold px-2 py-1.5 align-middle">
                            Grade
                          </th>
                        </tr>
                        <tr className="bg-slate-50 text-[11px] text-slate-700 border-b border-slate-300">
                          <th className="text-center font-semibold px-2 py-1.5 border-r border-slate-300">
                            Internal Test
                          </th>
                          <th className="text-center font-semibold px-2 py-1.5 border-r border-slate-300">
                            PPT/Project/Assignment/Practical
                          </th>
                          <th className="text-center font-semibold px-2 py-1.5 border-r border-slate-300">
                            Overall Participation
                          </th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-200">
                        {enrolledSubs.map((sub) => {
                          const b = getScholasticBreakdown(sub);
                          return (
                            <tr key={sub.subjectId} className="text-slate-900 hover:bg-slate-50/60">
                              <td className="px-3 py-2 font-semibold border-r border-slate-300">
                                {sub.subjectName}
                                {sub.componentMode === 'elective' && sub.selectedComponentName ? (
                                  <span className="ml-1 text-[11px] font-normal text-slate-500">
                                    ({sub.selectedComponentName})
                                  </span>
                                ) : null}
                              </td>
                              <td className="px-2 py-2 text-center font-mono tabular-nums border-r border-slate-200">
                                {b.internalTest}
                              </td>
                              <td className="px-2 py-2 text-center font-mono tabular-nums border-r border-slate-200">
                                {b.practical}
                              </td>
                              <td className="px-2 py-2 text-center font-mono tabular-nums border-r border-slate-200">
                                {b.participation}
                              </td>
                              <td className="px-2 py-2 text-center font-mono tabular-nums font-semibold border-r border-slate-200">
                                {b.termExam === 'AB' ? (
                                  <span className="text-rose-700 font-bold">AB</span>
                                ) : (
                                  b.termExam
                                )}
                              </td>
                              <td className="px-2 py-2 text-center font-mono tabular-nums font-bold border-r border-slate-200">
                                {b.isAbsent ? (
                                  <span className="text-rose-700 font-bold">AB</span>
                                ) : b.isIncomplete ? (
                                  <span className="text-[11px] font-sans text-amber-700">{b.total}</span>
                                ) : (
                                  b.total
                                )}
                              </td>
                              <td className="px-2 py-2 text-center">
                                <span
                                  className={`inline-flex items-center px-2 py-0.5 text-[11px] font-mono font-semibold rounded border ${getGradeBadgeClass(
                                    b.grade
                                  )}`}
                                >
                                  {b.grade}
                                </span>
                              </td>
                            </tr>
                          );
                        })}

                        {/* Bottom Summary Row inside Part-1 (A) */}
                        <tr className="bg-slate-100 text-slate-800 font-bold border-t-2 border-slate-300">
                          <td colSpan={2} className="px-2 py-1.5 text-center border-r border-slate-300">
                            Attendance
                          </td>
                          <td colSpan={2} className="px-2 py-1.5 text-center border-r border-slate-300">
                            Percentage
                          </td>
                          <td className="px-2 py-1.5 text-center border-r border-slate-300">Grade</td>
                          <td colSpan={2} className="px-2 py-1.5 text-center">
                            Result
                          </td>
                        </tr>
                        <tr className="bg-white text-slate-900 font-mono font-bold">
                          <td colSpan={2} className="px-2 py-2 text-center border-r border-slate-300 tabular-nums">
                            {formatAttendanceDisplay(
                              activeSingleTermRec?.daysAttended,
                              activeSingleTermRec?.totalDays
                            )}
                          </td>
                          <td colSpan={2} className="px-2 py-2 text-center border-r border-slate-300 tabular-nums">
                            {term1ViewStudent.percentage !== null
                              ? `${term1ViewStudent.percentage.toFixed(1)}%`
                              : '—'}
                          </td>
                          <td className="px-2 py-2 text-center border-r border-slate-300">
                            {term1ViewStudent.grade || '—'}
                          </td>
                          <td colSpan={2} className="px-2 py-2 text-center font-sans">
                            <ResultStatusLabel status={term1ViewStudent.resultStatus} />
                          </td>
                        </tr>
                      </tbody>
                    </table>
                  </div>

                  {/* Grand Total & Rank Strip */}
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 p-3.5 bg-slate-50 border border-slate-200 rounded-lg text-xs">
                    <div>
                      <div className="text-[11px] text-slate-500">Grand Total</div>
                      <div className="text-sm font-bold font-mono tabular-nums text-slate-900 mt-0.5">
                        {term1ViewStudent.grandTotal !== null
                          ? `${term1ViewStudent.grandTotal} / ${term1ViewStudent.totalMaxMarks}`
                          : 'Incomplete'}
                      </div>
                    </div>
                    <div>
                      <div className="text-[11px] text-slate-500">Percentage</div>
                      <div className="text-sm font-bold font-mono tabular-nums text-slate-900 mt-0.5">
                        {term1ViewStudent.percentage !== null
                          ? `${term1ViewStudent.percentage.toFixed(2)}%`
                          : '—'}
                      </div>
                    </div>
                    <div>
                      <div className="text-[11px] text-slate-500">Overall Grade</div>
                      <div className="text-sm font-bold font-mono text-slate-900 mt-0.5">
                        {term1ViewStudent.grade || '—'}
                      </div>
                    </div>
                    <div>
                      <div className="text-[11px] text-slate-500">Class Rank</div>
                      <div className="text-sm font-bold font-mono text-slate-900 mt-0.5">
                        {term1ViewStudent.classRank ? `#${term1ViewStudent.classRank}` : 'N/A'}
                      </div>
                    </div>
                  </div>
                </>
              );
            })()
          ) : (
            combinedStudent &&
            combinedReport &&
            (() => {
              const enrolledCombinedRows = combinedStudent.subjects.filter((row) => {
                const t1Ok =
                  row.term1 && row.term1.isEnrolled !== false && row.term1.gradeStatus !== 'not_applicable';
                const t2Ok =
                  row.term2 && row.term2.isEnrolled !== false && row.term2.gradeStatus !== 'not_applicable';
                return Boolean(t1Ok || t2Ok);
              });
              const sampleSub =
                enrolledCombinedRows.find(
                  (r) => r.term1?.hasInternalAssessment || r.term2?.hasInternalAssessment
                ) || enrolledCombinedRows[0];
              const sampleMeta = sampleSub?.term1 || sampleSub?.term2 || null;
              const iaMax = sampleMeta?.iaMaxMarks || 20;
              const writtenMax = sampleMeta?.writtenMaxMarks || 80;
              const totalMax = sampleMeta?.maxMarks || 100;
              const s1 = combinedStudent.term1Summary;
              const s2 = combinedStudent.term2Summary;

              return (
                <>
                  {/* Option 2: Part-1 (A): Scholastic Area (TERM I Left + TERM II Right) */}
                  <div className="border border-slate-300 rounded-lg overflow-x-auto">
                    <table className="w-full text-[11px] sm:text-xs">
                      <thead>
                        <tr className="border-b border-slate-300">
                          <th className="text-left font-bold px-2.5 py-2 bg-slate-200 text-slate-900 border-r border-slate-300 whitespace-nowrap">
                            Part-1 (A): Scholastic Area:
                          </th>
                          <th
                            colSpan={6}
                            className="text-center font-bold px-2 py-2 bg-[#1E3A5F] text-white border-r border-slate-300"
                          >
                            TERM I{combinedReport.term1Exam ? ` · ${combinedReport.term1Exam.name}` : ''}
                          </th>
                          <th
                            colSpan={6}
                            className="text-center font-bold px-2 py-2 bg-[#164E63] text-white"
                          >
                            TERM II{combinedReport.term2Exam ? ` · ${combinedReport.term2Exam.name}` : ''}
                          </th>
                        </tr>
                        <tr className="text-[11px] text-slate-800 border-b border-slate-300">
                          <th
                            rowSpan={2}
                            className="text-left font-bold px-2.5 py-1.5 bg-slate-100 border-r border-slate-300 align-middle"
                          >
                            Subjects
                          </th>
                          <th
                            colSpan={3}
                            className="text-center font-bold px-1.5 py-1 bg-slate-100 border-r border-slate-300"
                          >
                            Internal Assessment ({iaMax} marks)
                          </th>
                          <th
                            rowSpan={2}
                            className="text-center font-bold px-1.5 py-1 bg-slate-100 border-r border-slate-300 align-middle"
                          >
                            Term Exam ({writtenMax})
                          </th>
                          <th
                            rowSpan={2}
                            className="text-center font-bold px-1.5 py-1 bg-slate-100 border-r border-slate-300 align-middle"
                          >
                            Total ({totalMax})
                          </th>
                          <th
                            rowSpan={2}
                            className="text-center font-bold px-1.5 py-1 bg-slate-100 border-r border-slate-400 align-middle"
                          >
                            Grade
                          </th>
                          <th
                            colSpan={3}
                            className="text-center font-bold px-1.5 py-1 bg-cyan-50/70 border-r border-slate-300"
                          >
                            Internal Assessment ({iaMax} marks)
                          </th>
                          <th
                            rowSpan={2}
                            className="text-center font-bold px-1.5 py-1 bg-cyan-50/70 border-r border-slate-300 align-middle"
                          >
                            Term Exam ({writtenMax})
                          </th>
                          <th
                            rowSpan={2}
                            className="text-center font-bold px-1.5 py-1 bg-cyan-50/70 border-r border-slate-300 align-middle"
                          >
                            Total ({totalMax})
                          </th>
                          <th
                            rowSpan={2}
                            className="text-center font-bold px-1.5 py-1 bg-cyan-50/70 align-middle"
                          >
                            Grade
                          </th>
                        </tr>
                        <tr className="text-[10px] text-slate-700 border-b border-slate-300">
                          <th className="text-center font-semibold px-1.5 py-1 bg-slate-50 border-r border-slate-300">
                            Internal Test
                          </th>
                          <th className="text-center font-semibold px-1.5 py-1 bg-slate-50 border-r border-slate-300">
                            PPT/Project/Assignment/Practical
                          </th>
                          <th className="text-center font-semibold px-1.5 py-1 bg-slate-50 border-r border-slate-300">
                            Overall Participation
                          </th>
                          <th className="text-center font-semibold px-1.5 py-1 bg-cyan-50/40 border-r border-slate-300">
                            Internal Test
                          </th>
                          <th className="text-center font-semibold px-1.5 py-1 bg-cyan-50/40 border-r border-slate-300">
                            PPT/Project/Assignment/Practical
                          </th>
                          <th className="text-center font-semibold px-1.5 py-1 bg-cyan-50/40 border-r border-slate-300">
                            Overall Participation
                          </th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-200">
                        {enrolledCombinedRows.map((row) => {
                          const b1 = getScholasticBreakdown(row.term1);
                          const b2 = getScholasticBreakdown(row.term2);
                          const chosenSub = row.term1 || row.term2;
                          return (
                            <tr key={row.subjectId} className="hover:bg-slate-50/60 text-slate-900">
                              <td className="px-2.5 py-1.5 font-semibold border-r border-slate-300 whitespace-nowrap">
                                {row.subjectName}
                                {chosenSub?.componentMode === 'elective' && chosenSub.selectedComponentName
                                  ? ` (${chosenSub.selectedComponentName})`
                                  : ''}
                              </td>

                              {/* TERM I */}
                              <td className="px-1.5 py-1.5 text-center font-mono tabular-nums border-r border-slate-200">
                                {b1.internalTest}
                              </td>
                              <td className="px-1.5 py-1.5 text-center font-mono tabular-nums border-r border-slate-200">
                                {b1.practical}
                              </td>
                              <td className="px-1.5 py-1.5 text-center font-mono tabular-nums border-r border-slate-200">
                                {b1.participation}
                              </td>
                              <td className="px-1.5 py-1.5 text-center font-mono tabular-nums font-semibold border-r border-slate-200">
                                {b1.termExam === 'AB' ? (
                                  <span className="text-rose-700 font-bold">AB</span>
                                ) : (
                                  b1.termExam
                                )}
                              </td>
                              <td className="px-1.5 py-1.5 text-center font-mono tabular-nums font-bold border-r border-slate-200">
                                {b1.isAbsent ? (
                                  <span className="text-rose-700 font-bold">AB</span>
                                ) : b1.isIncomplete ? (
                                  <span className="text-[10px] font-sans text-amber-700">{b1.total}</span>
                                ) : (
                                  b1.total
                                )}
                              </td>
                              <td className="px-1.5 py-1.5 text-center border-r border-slate-400">
                                {row.term1 ? (
                                  <span
                                    className={`inline-flex items-center px-1.5 py-0.5 text-[10px] font-mono font-semibold rounded border ${getGradeBadgeClass(
                                      b1.grade
                                    )}`}
                                  >
                                    {b1.grade}
                                  </span>
                                ) : (
                                  '—'
                                )}
                              </td>

                              {/* TERM II */}
                              <td className="px-1.5 py-1.5 text-center font-mono tabular-nums bg-cyan-50/15 border-r border-slate-200">
                                {b2.internalTest}
                              </td>
                              <td className="px-1.5 py-1.5 text-center font-mono tabular-nums bg-cyan-50/15 border-r border-slate-200">
                                {b2.practical}
                              </td>
                              <td className="px-1.5 py-1.5 text-center font-mono tabular-nums bg-cyan-50/15 border-r border-slate-200">
                                {b2.participation}
                              </td>
                              <td className="px-1.5 py-1.5 text-center font-mono tabular-nums font-semibold bg-cyan-50/15 border-r border-slate-200">
                                {b2.termExam === 'AB' ? (
                                  <span className="text-rose-700 font-bold">AB</span>
                                ) : (
                                  b2.termExam
                                )}
                              </td>
                              <td className="px-1.5 py-1.5 text-center font-mono tabular-nums font-bold bg-cyan-50/15 border-r border-slate-200">
                                {b2.isAbsent ? (
                                  <span className="text-rose-700 font-bold">AB</span>
                                ) : b2.isIncomplete ? (
                                  <span className="text-[10px] font-sans text-amber-700">{b2.total}</span>
                                ) : (
                                  b2.total
                                )}
                              </td>
                              <td className="px-1.5 py-1.5 text-center bg-cyan-50/15">
                                {row.term2 ? (
                                  <span
                                    className={`inline-flex items-center px-1.5 py-0.5 text-[10px] font-mono font-semibold rounded border ${getGradeBadgeClass(
                                      b2.grade
                                    )}`}
                                  >
                                    {b2.grade}
                                  </span>
                                ) : (
                                  '—'
                                )}
                              </td>
                            </tr>
                          );
                        })}

                        {/* Bottom Summary Rows inside Part-1 (A) table */}
                        <tr className="border-t-2 border-slate-300 font-bold text-slate-800">
                          <td colSpan={2} className="px-2 py-1.5 text-center bg-slate-100 border-r border-slate-300">
                            Attendance
                          </td>
                          <td colSpan={2} className="px-2 py-1.5 text-center bg-slate-100 border-r border-slate-300">
                            Percentage
                          </td>
                          <td className="px-2 py-1.5 text-center bg-slate-100 border-r border-slate-300">Grade</td>
                          <td colSpan={2} className="px-2 py-1.5 text-center bg-slate-100 border-r border-slate-400">
                            Result
                          </td>
                          <td colSpan={2} className="px-2 py-1.5 text-center bg-cyan-50/60 border-r border-slate-300">
                            Attendance
                          </td>
                          <td colSpan={2} className="px-2 py-1.5 text-center bg-cyan-50/60 border-r border-slate-300">
                            Percentage
                          </td>
                          <td className="px-2 py-1.5 text-center bg-cyan-50/60 border-r border-slate-300">Grade</td>
                          <td className="px-2 py-1.5 text-center bg-cyan-50/60">Result</td>
                        </tr>
                        <tr className="bg-white font-mono font-bold text-slate-900">
                          <td colSpan={2} className="px-2 py-1.5 text-center border-r border-slate-300 tabular-nums">
                            {formatAttendanceDisplay(
                              combinedStudent.termRecords.term1.daysAttended,
                              combinedStudent.termRecords.term1.totalDays
                            )}
                          </td>
                          <td colSpan={2} className="px-2 py-1.5 text-center border-r border-slate-300 tabular-nums">
                            {s1?.percentage !== null && s1?.percentage !== undefined
                              ? `${s1.percentage.toFixed(1)}%`
                              : '—'}
                          </td>
                          <td className="px-2 py-1.5 text-center border-r border-slate-300">
                            {s1?.grade || '—'}
                          </td>
                          <td colSpan={2} className="px-2 py-1.5 text-center border-r border-slate-400 font-sans">
                            {s1 ? <ResultStatusLabel status={s1.resultStatus} /> : '—'}
                          </td>
                          <td colSpan={2} className="px-2 py-1.5 text-center border-r border-slate-300 tabular-nums">
                            {formatAttendanceDisplay(
                              combinedStudent.termRecords.term2.daysAttended,
                              combinedStudent.termRecords.term2.totalDays
                            )}
                          </td>
                          <td colSpan={2} className="px-2 py-1.5 text-center border-r border-slate-300 tabular-nums">
                            {s2?.percentage !== null && s2?.percentage !== undefined
                              ? `${s2.percentage.toFixed(1)}%`
                              : '—'}
                          </td>
                          <td className="px-2 py-1.5 text-center border-r border-slate-300">
                            {s2?.grade || '—'}
                          </td>
                          <td className="px-2 py-1.5 text-center font-sans">
                            {s2 ? <ResultStatusLabel status={s2.resultStatus} /> : '—'}
                          </td>
                        </tr>
                      </tbody>
                    </table>
                  </div>

                  {/* Final / Overall Combined Result Strip */}
                  <div className="p-3.5 rounded-lg border-2 border-[#1E3A5F]/30 bg-sky-50/40 space-y-2.5">
                    <div className="flex flex-wrap items-center justify-between gap-2">
                      <div className="text-xs font-bold uppercase tracking-wider text-[#1E3A5F]">
                        Final / Overall Result (Average of Both Terms &amp; Total Attendance)
                      </div>
                      <ResultStatusLabel status={combinedStudent.overall.resultStatus} />
                    </div>
                    <div className="grid grid-cols-2 sm:grid-cols-5 gap-3 text-xs">
                      <div>
                        <div className="text-[11px] text-slate-500">Average Marks (Both Terms)</div>
                        <div className="text-sm font-bold font-mono tabular-nums text-slate-900 mt-0.5">
                          {combinedStudent.overall.averageObtained !== null &&
                          combinedStudent.overall.averageMaxMarks !== null
                            ? `${combinedStudent.overall.averageObtained} / ${combinedStudent.overall.averageMaxMarks}`
                            : 'Incomplete'}
                        </div>
                      </div>
                      <div>
                        <div className="text-[11px] text-slate-500">Combined Total (T1 + T2)</div>
                        <div className="text-sm font-bold font-mono tabular-nums text-slate-900 mt-0.5">
                          {combinedStudent.overall.combinedTotal !== null
                            ? `${combinedStudent.overall.combinedTotal} / ${combinedStudent.overall.combinedMaxMarks}`
                            : 'Incomplete'}
                        </div>
                      </div>
                      <div>
                        <div className="text-[11px] text-slate-500">Final Percentage (Both Exams)</div>
                        <div className="text-sm font-bold font-mono tabular-nums text-[#1E3A5F] mt-0.5">
                          {combinedStudent.overall.finalPercentage !== null
                            ? `${combinedStudent.overall.finalPercentage.toFixed(2)}%`
                            : '—'}
                        </div>
                      </div>
                      <div>
                        <div className="text-[11px] text-slate-500">Final Overall Grade</div>
                        <div className="text-sm font-bold font-mono text-slate-900 mt-0.5">
                          {combinedStudent.overall.finalGrade || '—'}
                        </div>
                      </div>
                      <div>
                        <div className="text-[11px] text-slate-500">Total Attendance (T1 + T2)</div>
                        <div className="text-sm font-bold font-mono tabular-nums text-slate-900 mt-0.5">
                          {formatAttendanceDisplay(
                            combinedStudent.termRecords.totalDaysAttended,
                            combinedStudent.termRecords.totalWorkingDays
                          )}
                          {combinedStudent.termRecords.totalDaysAttended !== null &&
                          combinedStudent.termRecords.totalWorkingDays !== null &&
                          combinedStudent.termRecords.totalWorkingDays > 0
                            ? ` (${(
                                (combinedStudent.termRecords.totalDaysAttended /
                                  combinedStudent.termRecords.totalWorkingDays) *
                                100
                              ).toFixed(1)}%)`
                            : ''}
                        </div>
                      </div>
                    </div>
                  </div>
                </>
              );
            })()
          )}

          {/* Co-Scholastic Areas, Health & Discipline (3-Point Scale) */}
          {showCoScholastic && (
            <div className="space-y-3">
              {CO_SCHOLASTIC_SECTIONS.map((section) => (
                <div key={section.id} className="border border-slate-300 rounded-lg overflow-hidden">
                  <div className="px-3.5 py-1.5 bg-slate-100 border-b border-slate-300 text-xs font-bold text-slate-900">
                    {section.title}
                  </div>
                  <table className="w-full text-xs">
                    <thead className="bg-slate-50 border-b border-slate-300 text-slate-800">
                      <tr>
                        <th className="text-left font-bold px-3.5 py-1.5">{section.columnHeader}</th>
                        <th className="text-center font-bold px-3 py-1.5 w-32 border-l border-slate-300">
                          Grade Term I
                        </th>
                        <th className="text-center font-bold px-3 py-1.5 w-32 border-l border-slate-300">
                          Grade Term II
                        </th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-200">
                      {section.items.map((item) => {
                        const g1 = coTerm1[item.key];
                        const g2 = coTerm2[item.key];
                        return (
                          <tr key={item.key} className="text-slate-900">
                            <td className="px-3.5 py-1.5 font-medium">{item.label}</td>
                            <td className="px-3 py-1.5 text-center font-mono font-bold border-l border-slate-200">
                              {g1 || '—'}
                            </td>
                            <td className="px-3 py-1.5 text-center font-mono font-bold border-l border-slate-200">
                              {g2 || '—'}
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              ))}

              <div className="flex flex-wrap items-center justify-between gap-2 px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-[11px] text-slate-600">
                <span>
                  <strong className="text-slate-800">3-Point Grading Scale:</strong> Grades A, B, C
                </span>
              </div>
            </div>
          )}

          {/* Term Remarks Section (Compact 1-Sentence Box) */}
          {effectiveMode === 'combined' && combinedStudent ? (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              <div className="px-3.5 py-2.5 border border-slate-300 rounded-lg bg-white">
                <div className="text-xs font-bold text-[#1E3A5F] mb-0.5">Remarks — 1st Term (Term I)</div>
                <p className="text-sm text-slate-800 whitespace-pre-wrap leading-snug">
                  {combinedStudent.termRecords.term1.remarks || '—'}
                </p>
              </div>
              <div className="px-3.5 py-2.5 border border-slate-300 rounded-lg bg-white">
                <div className="text-xs font-bold text-[#164E63] mb-0.5">
                  Remarks — Annual / Final Term (Term II)
                </div>
                <p className="text-sm text-slate-800 whitespace-pre-wrap leading-snug">
                  {combinedStudent.termRecords.term2.remarks || '—'}
                </p>
              </div>
            </div>
          ) : (
            <div className="px-3.5 py-2.5 border border-slate-300 rounded-lg bg-white">
              <div className="text-xs font-bold text-[#1E3A5F] mb-0.5">
                Remarks ({activeSingleTermNum === 2 ? 'Annual / Term II' : '1st Term'})
              </div>
              <p className="text-sm text-slate-800 whitespace-pre-wrap leading-snug">
                {activeSingleTermRec?.remarks || '—'}
              </p>
            </div>
          )}

          {/* Signature Footer & Result Date (Below Class Teacher in Bottom-Left Corner) */}
          <div className="pt-10 border-t border-slate-200 space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 text-center text-xs text-slate-500">
              <div>
                <div className="border-t border-slate-300 pt-1.5 font-medium text-slate-700">
                  {schoolInfo.siteContent?.reportCardFooterLeft || 'Class Teacher'}
                </div>
                <div>Signature</div>
              </div>
              <div>
                <div className="border-t border-slate-300 pt-1.5 font-medium text-slate-700">Examination Cell</div>
                <div>{schoolInfo.siteContent?.reportCardFooterCenter || 'Controller of Examinations'}</div>
              </div>
              <div>
                <div className="border-t border-slate-300 pt-1.5 font-medium text-slate-700">
                  {schoolInfo.siteContent?.reportCardFooterRight || 'Principal'}
                </div>
                <div>Eklavya Model Residential School Gangyap</div>
              </div>
            </div>

            <div className="pt-1 text-left text-xs font-medium text-slate-700">
              <span className="font-bold text-[#1E3A5F]">Result Date:</span>{' '}
              <span className="font-mono font-semibold text-slate-900">
                {formatResultDateDisplay(activeResultDate)}
              </span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
