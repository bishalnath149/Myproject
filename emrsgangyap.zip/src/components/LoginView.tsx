import React, { useState } from 'react';
import { Lock, User, ArrowRight, ShieldCheck } from 'lucide-react';
import type { AuthUser, SchoolInfo } from '../types';
import { apiFetch, setStoredToken } from '../lib/api';
import { SchoolLogo } from './SchoolLogo';

interface Props {
  schoolInfo: SchoolInfo;
  onLoginSuccess: (user: AuthUser) => Promise<void> | void;
}

export function LoginView({ schoolInfo, onLoginSuccess }: Props) {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const primary = schoolInfo.themeConfig?.primaryColor || '#1E3A5F';
  const accent = schoolInfo.themeConfig?.accentColor || '#0284C7';
  const schoolName = schoolInfo.schoolName || 'EMRS Gangyap';
  const heading = schoolInfo.siteContent?.loginHeading || 'Portal Sign In';
  const buttonLabel = schoolInfo.siteContent?.loginButtonLabel || 'Sign In';
  const portalTitle = schoolInfo.siteContent?.portalTitle || 'Examination & Marks Portal';

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setLoading(true);
    try {
      const data = await apiFetch<{ token: string; user: AuthUser }>('/api/auth/login', {
        method: 'POST',
        body: JSON.stringify({ username, password }),
      });
      setStoredToken(data.token);
      await onLoginSuccess(data.user);
    } catch (err: any) {
      setError(err.message || 'Sign-in failed.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen min-h-[100dvh] bg-gradient-to-br from-slate-100 via-slate-50 to-sky-50/70 flex flex-col items-center justify-center p-4 sm:p-6">
      <div className="w-full max-w-md bg-white border border-slate-200/90 rounded-2xl shadow-xl shadow-slate-200/60 overflow-hidden">
        <div
          className="h-2 w-full"
          style={{ background: `linear-gradient(90deg, ${primary}, ${accent})` }}
        />

        <div className="p-6 sm:p-8 space-y-6">
          <div className="text-center space-y-2.5">
            <SchoolLogo
              src={schoolInfo.schoolLogo}
              alt={schoolName}
              className="w-16 h-16 sm:w-20 sm:h-20 mx-auto object-contain rounded-2xl border border-slate-200 p-1.5 bg-white shadow-xs"
            />
            <div className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md text-[11px] font-semibold tracking-wide uppercase bg-slate-100 text-slate-700">
              <ShieldCheck className="w-3.5 h-3.5" style={{ color: accent }} />
              {portalTitle}
            </div>
            <h1
              className="text-2xl sm:text-3xl font-bold tracking-tight font-display"
              style={{ color: primary }}
            >
              {schoolName}
            </h1>
            <p className="text-xs font-medium text-slate-500">
              {heading} · AY {schoolInfo.currentAcademicYear}
            </p>
          </div>

          {error && (
            <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-xs font-medium text-red-800">
              {error}
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label htmlFor="username" className="block text-xs font-semibold text-slate-700 mb-1.5">
                Username
              </label>
              <div className="relative">
                <User className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  id="username"
                  type="text"
                  required
                  autoComplete="username"
                  autoCapitalize="none"
                  autoCorrect="off"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  placeholder="Enter username"
                  className="w-full min-h-[44px] pl-9 pr-3.5 py-2.5 text-base sm:text-sm bg-slate-50/70 border border-slate-300 rounded-xl focus:bg-white focus:outline-none focus:ring-2 focus:ring-sky-500/20 focus:border-sky-600 transition-colors"
                />
              </div>
            </div>

            <div>
              <label htmlFor="password" className="block text-xs font-semibold text-slate-700 mb-1.5">
                Password
              </label>
              <div className="relative">
                <Lock className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  id="password"
                  type="password"
                  required
                  autoComplete="current-password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="Enter password"
                  className="w-full min-h-[44px] pl-9 pr-3.5 py-2.5 text-base sm:text-sm bg-slate-50/70 border border-slate-300 rounded-xl focus:bg-white focus:outline-none focus:ring-2 focus:ring-sky-500/20 focus:border-sky-600 transition-colors"
                />
              </div>
            </div>

            <button
              type="submit"
              disabled={loading}
              style={{ backgroundColor: primary }}
              className="w-full min-h-[44px] inline-flex items-center justify-center gap-2 px-4 py-2.5 text-sm font-semibold text-white rounded-xl hover:opacity-95 disabled:opacity-60 transition-all shadow-sm cursor-pointer"
            >
              {loading ? 'Signing in...' : buttonLabel}
              <ArrowRight className="w-4 h-4" />
            </button>
          </form>

          <p className="pt-2 border-t border-slate-100 text-[11px] text-center text-slate-500">
            Authorized faculty and administrators only. Contact your school administrator for account credentials.
          </p>
        </div>
      </div>
    </div>
  );
}
