import React, { useEffect, useMemo, useState } from 'react';
import {
  ArrowRight,
  CheckCircle2,
  CheckSquare,
  GraduationCap,
  RotateCcw,
  Square,
  Undo2,
  X,
} from 'lucide-react';
import type {
  PromoteStudentsResponse,
  PromotionCandidate,
  PromotionCandidatesResponse,
  SchoolInfo,
  UnpromoteStudentsResponse,
} from '../types';
import { apiFetch, extractErrorMessage } from '../lib/api';
import { formatClassSectionLabel } from '../lib/grading';

export interface AllowedPromotionClassSection {
  classId: number;
  className: string;
  hasSections?: boolean;
  sectionId: number;
  sectionName: string;
  academicYear?: string;
}

export function suggestNextAcademicYear(current: string): string {
  const match = current.match(/^(\d{4})-(\d{2,4})$/);
  if (!match) return `${current}-next`;
  const start = Number(match[1]) + 1;
  if (match[2].length === 2) {
    return `${start}-${String((start + 1) % 100).padStart(2, '0')}`;
  }
  return `${start}-${start + 1}`;
}

export function ClassWisePromotionPanel({
  schoolInfo,
  selectedAcademicYear,
  onPromoted,
  allowedClassSections,
  isClassTeacherView = false,
}: {
  schoolInfo: SchoolInfo;
  selectedAcademicYear: string;
  onPromoted: (targetYear: string, switchedActive: boolean) => void | Promise<void>;
  allowedClassSections?: AllowedPromotionClassSection[];
  isClassTeacherView?: boolean;
}) {
  const availableSourceYears = useMemo(() => {
    if (isClassTeacherView && allowedClassSections && allowedClassSections.length > 0) {
      const years = Array.from(
        new Set(
          allowedClassSections
            .map((a) => a.academicYear)
            .filter((y): y is string => Boolean(y))
        )
      );
      if (years.length > 0) return years;
    }
    return (schoolInfo.academicYears || []).map((ay) => ay.name);
  }, [isClassTeacherView, allowedClassSections, schoolInfo.academicYears]);

  const initialSourceYear = useMemo(() => {
    if (availableSourceYears.length === 0) return selectedAcademicYear;
    if (availableSourceYears.includes(selectedAcademicYear)) return selectedAcademicYear;
    return availableSourceYears[0];
  }, [availableSourceYears, selectedAcademicYear]);

  const [sourceYear, setSourceYear] = useState(initialSourceYear);
  const [targetYear, setTargetYear] = useState(() => suggestNextAcademicYear(initialSourceYear));

  const scopedClassOptions = useMemo(() => {
    if (!isClassTeacherView || !allowedClassSections) {
      return schoolInfo.classes;
    }
    const yearMatches = allowedClassSections.filter(
      (a) => !a.academicYear || a.academicYear === sourceYear
    );
    const pool = yearMatches.length > 0 ? yearMatches : allowedClassSections;
    const allowedClassIds = new Set(pool.map((a) => a.classId));
    return schoolInfo.classes.filter((c) => allowedClassIds.has(c.id));
  }, [isClassTeacherView, allowedClassSections, schoolInfo.classes, sourceYear]);

  const [classId, setClassId] = useState<number>(() => scopedClassOptions[0]?.id || schoolInfo.classes[0]?.id || 1);

  const scopedSectionOptions = useMemo(() => {
    const classObj = schoolInfo.classes.find((c) => c.id === classId);
    if (!classObj) return [];
    if (!isClassTeacherView || !allowedClassSections) {
      return classObj.sections;
    }
    const yearMatches = allowedClassSections.filter(
      (a) => a.classId === classId && (!a.academicYear || a.academicYear === sourceYear)
    );
    const allowedSecIds = new Set(yearMatches.map((a) => a.sectionId));
    return classObj.sections.filter((s) => allowedSecIds.has(s.id));
  }, [schoolInfo.classes, classId, isClassTeacherView, allowedClassSections, sourceYear]);

  const [sectionId, setSectionId] = useState<string>(() => {
    if (isClassTeacherView && scopedSectionOptions.length === 1) {
      return String(scopedSectionOptions[0].id);
    }
    return '';
  });
  const [examId, setExamId] = useState<string>('');

  const [setAsCurrentYear, setSetAsCurrentYear] = useState(false);
  const [copyAssignments, setCopyAssignments] = useState(false);

  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [unpromoting, setUnpromoting] = useState(false);
  const [confirmUnpromoteOpen, setConfirmUnpromoteOpen] = useState(false);
  const [data, setData] = useState<PromotionCandidatesResponse | null>(null);
  const [markedIds, setMarkedIds] = useState<Set<number>>(new Set());
  const [unpromoteIds, setUnpromoteIds] = useState<Set<number>>(new Set());
  const [error, setError] = useState<string | null>(null);
  const [promoNotice, setPromoNotice] = useState<PromoteStudentsResponse | null>(null);
  const [undoNotice, setUndoNotice] = useState<UnpromoteStudentsResponse | null>(null);

  useEffect(() => {
    const nextSrc =
      availableSourceYears.length === 0 || availableSourceYears.includes(selectedAcademicYear)
        ? selectedAcademicYear
        : availableSourceYears[0];
    setSourceYear(nextSrc);
    setTargetYear(suggestNextAcademicYear(nextSrc));
    setExamId('');
  }, [selectedAcademicYear]);

  useEffect(() => {
    if (scopedClassOptions.length > 0 && !scopedClassOptions.some((c) => c.id === classId)) {
      setClassId(scopedClassOptions[0].id);
    }
  }, [scopedClassOptions, classId]);

  useEffect(() => {
    if (isClassTeacherView && scopedSectionOptions.length === 1) {
      const onlyId = String(scopedSectionOptions[0].id);
      if (sectionId !== onlyId) setSectionId(onlyId);
    } else if (sectionId && !scopedSectionOptions.some((s) => String(s.id) === sectionId)) {
      setSectionId('');
    }
  }, [isClassTeacherView, scopedSectionOptions, sectionId]);

  const loadCandidates = async (overrideExamId?: string) => {
    if (!classId) {
      setData(null);
      setLoading(false);
      return;
    }
    setLoading(true);
    setError(null);
    try {
      const qs = new URLSearchParams();
      qs.set('sourceAcademicYear', sourceYear);
      if (targetYear.trim()) qs.set('targetAcademicYear', targetYear.trim());
      qs.set('classId', String(classId));
      if (sectionId) qs.set('sectionId', sectionId);
      const effectiveExam = overrideExamId !== undefined ? overrideExamId : examId;
      if (effectiveExam) qs.set('examinationId', effectiveExam);

      const res = await apiFetch<PromotionCandidatesResponse>(
        `/api/students/promotion-candidates?${qs.toString()}`
      );
      setData(res);
      if (!effectiveExam && res.selectedExaminationId) {
        setExamId(String(res.selectedExaminationId));
      }
      // Auto-tick all eligible Passed students by default for one-click promotion
      const passedSet = new Set<number>();
      for (const c of res.candidates) {
        if (!c.alreadyInTargetYear && c.resultStatus === 'Pass') {
          passedSet.add(c.studentId);
        }
      }
      setMarkedIds(passedSet);
      setUnpromoteIds(new Set());
    } catch (err: unknown) {
      setError(extractErrorMessage(err, 'Could not load promotion candidates.'));
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadCandidates();
  }, [sourceYear, classId, sectionId, targetYear]);

  const eligibleCandidates = (data?.candidates || []).filter((c) => !c.alreadyInTargetYear);
  const transferredCandidates = (data?.candidates || []).filter((c) => c.alreadyInTargetYear);
  const passedEligibleCandidates = eligibleCandidates.filter((c) => c.resultStatus === 'Pass');
  const allEligibleMarked =
    eligibleCandidates.length > 0 && eligibleCandidates.every((c) => markedIds.has(c.studentId));
  const allPromotedTicked =
    transferredCandidates.length > 0 && transferredCandidates.every((c) => unpromoteIds.has(c.studentId));

  const toggleStudentMark = (studentId: number) => {
    setMarkedIds((prev) => {
      const next = new Set(prev);
      if (next.has(studentId)) next.delete(studentId);
      else next.add(studentId);
      return next;
    });
  };

  const toggleUnpromoteMark = (studentId: number) => {
    setUnpromoteIds((prev) => {
      const next = new Set(prev);
      if (next.has(studentId)) next.delete(studentId);
      else next.add(studentId);
      return next;
    });
  };

  const handleTickPassed = () => {
    setMarkedIds(new Set(passedEligibleCandidates.map((c) => c.studentId)));
  };

  const handleTickAllEligible = () => {
    setMarkedIds(new Set(eligibleCandidates.map((c) => c.studentId)));
  };

  const handleClearTicks = () => {
    setMarkedIds(new Set());
  };

  const handleToggleAllPromotedForUndo = () => {
    if (allPromotedTicked) {
      setUnpromoteIds(new Set());
    } else {
      setUnpromoteIds(new Set(transferredCandidates.map((c) => c.studentId)));
    }
  };

  const handleOneClickPromote = async () => {
    if (markedIds.size === 0 || !targetYear.trim()) return;
    setSubmitting(true);
    setError(null);
    setPromoNotice(null);
    setUndoNotice(null);
    try {
      const res = await apiFetch<PromoteStudentsResponse>('/api/students/promote', {
        method: 'POST',
        body: JSON.stringify({
          sourceAcademicYear: sourceYear,
          targetAcademicYear: targetYear.trim(),
          classId,
          studentIds: Array.from(markedIds),
          examinationId: examId && examId !== 'none' ? Number(examId) : null,
          setAsCurrentYear: isClassTeacherView ? false : setAsCurrentYear,
          copyTeacherAssignments: isClassTeacherView ? false : copyAssignments,
          copyClassTeachers: isClassTeacherView ? false : copyAssignments,
        }),
      });
      setPromoNotice(res);
      await loadCandidates();
      await onPromoted(res.targetAcademicYear, res.setAsCurrentYear);
    } catch (err: unknown) {
      setError(extractErrorMessage(err, 'Could not promote selected students.'));
    } finally {
      setSubmitting(false);
    }
  };

  const handleConfirmUnpromote = async () => {
    if (unpromoteIds.size === 0 || !targetYear.trim()) return;
    setUnpromoting(true);
    setError(null);
    setPromoNotice(null);
    setUndoNotice(null);
    try {
      const res = await apiFetch<UnpromoteStudentsResponse>('/api/students/unpromote', {
        method: 'POST',
        body: JSON.stringify({
          sourceAcademicYear: sourceYear,
          targetAcademicYear: targetYear.trim(),
          classId,
          studentIds: Array.from(unpromoteIds),
        }),
      });
      setConfirmUnpromoteOpen(false);
      setUndoNotice(res);
      await loadCandidates();
      await onPromoted(res.sourceAcademicYear, false);
    } catch (err: unknown) {
      setConfirmUnpromoteOpen(false);
      setError(extractErrorMessage(err, 'Could not un-promote selected students.'));
    } finally {
      setUnpromoting(false);
    }
  };

  const academicYearSummaryMap = new Map((schoolInfo.academicYears || []).map((ay) => [ay.name, ay]));
  const nextClassLabel = data?.nextClass ? data.nextClass.name : 'Graduated (Alumni)';
  const selectedClassObj = schoolInfo.classes.find((c) => c.id === classId);
  const hasSectionsForSelectedClass = selectedClassObj?.hasSections !== false;

  return (
    <div className="space-y-4">
      {error && (
        <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-xs font-medium text-red-800">
          {error}
        </div>
      )}

      {promoNotice && (
        <div className="flex flex-wrap items-center justify-between gap-3 p-3.5 rounded-xl bg-emerald-50 border border-emerald-200 text-xs text-emerald-900">
          <div className="flex items-center gap-2 font-medium">
            <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
            <span>
              Transferred{' '}
              <span className="font-mono font-bold">
                {promoNotice.promotedCount + promoNotice.graduatedCount}
              </span>{' '}
              student(s) from <span className="font-semibold">{promoNotice.sourceClassName}</span> (
              <span className="font-mono">{promoNotice.sourceAcademicYear}</span>) to{' '}
              <span className="font-semibold">{promoNotice.nextClassName}</span> (
              <span className="font-mono">{promoNotice.targetAcademicYear}</span>).
              {promoNotice.skippedCount > 0 && ` ${promoNotice.skippedCount} already enrolled skipped.`}
            </span>
          </div>
          <span className="text-[11px] font-mono text-emerald-700">
            Tick any promoted student below if you need to undo
          </span>
        </div>
      )}

      {undoNotice && (
        <div className="flex flex-wrap items-center justify-between gap-3 p-3.5 rounded-xl bg-amber-50 border border-amber-200 text-xs text-amber-950">
          <div className="flex items-center gap-2 font-medium">
            <Undo2 className="w-4 h-4 text-amber-700 shrink-0" />
            <span>
              Un-promoted <span className="font-mono font-bold">{undoNotice.unpromotedCount}</span> student(s) back to{' '}
              <span className="font-semibold">{undoNotice.sourceClassName}</span> (
              <span className="font-mono">{undoNotice.sourceAcademicYear}</span>) and removed{' '}
              <span className="font-mono">{undoNotice.targetAcademicYear}</span> promotion enrollment.
            </span>
          </div>
        </div>
      )}

      {/* Class-Wise & Academic Year Selection Bar */}
      <div className="bg-white border border-slate-200 rounded-xl p-4 space-y-3 text-xs">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3">
          <div>
            <label className="block font-semibold text-slate-700 mb-1">From Academic Year</label>
            <select
              value={sourceYear}
              onChange={(e) => {
                const nextSrc = e.target.value;
                setSourceYear(nextSrc);
                setTargetYear(suggestNextAcademicYear(nextSrc));
                setExamId('');
                setPromoNotice(null);
                setUndoNotice(null);
              }}
              className="w-full px-3 py-2 border border-slate-300 rounded-lg bg-white font-mono"
            >
              {(availableSourceYears.length > 0 ? availableSourceYears : [sourceYear]).map((yr) => {
                const ay = academicYearSummaryMap.get(yr);
                return (
                  <option key={yr} value={yr}>
                    {yr} {ay ? `(${ay.studentCount} active)` : ''}
                  </option>
                );
              })}
            </select>
          </div>

          <div>
            <label className="block font-semibold text-slate-700 mb-1">Class (Class-Wise)</label>
            <select
              value={classId}
              disabled={isClassTeacherView && scopedClassOptions.length <= 1}
              onChange={(e) => {
                setClassId(Number(e.target.value));
                setSectionId('');
                setPromoNotice(null);
                setUndoNotice(null);
              }}
              className="w-full px-3 py-2 border border-slate-300 rounded-lg bg-white font-medium disabled:bg-slate-50"
            >
              {scopedClassOptions.map((c) => (
                <option key={c.id} value={c.id}>
                  {c.name}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block font-semibold text-slate-700 mb-1">Section Filter</label>
            <select
              value={sectionId}
              disabled={!hasSectionsForSelectedClass || (isClassTeacherView && scopedSectionOptions.length <= 1)}
              onChange={(e) => setSectionId(e.target.value)}
              className="w-full px-3 py-2 border border-slate-300 rounded-lg bg-white disabled:bg-slate-50"
            >
              {!hasSectionsForSelectedClass ? (
                <option value="">No Sections (Single Cohort)</option>
              ) : (
                <>
                  {(!isClassTeacherView || scopedSectionOptions.length > 1) && (
                    <option value="">
                      {isClassTeacherView ? 'All Assigned Sections' : 'All Sections'} (
                      {scopedSectionOptions.map((s) => s.name).join(', ')})
                    </option>
                  )}
                  {scopedSectionOptions.map((s) => (
                    <option key={s.id} value={s.id}>
                      Section {s.name}
                    </option>
                  ))}
                </>
              )}
            </select>
          </div>

          <div>
            <label className="block font-semibold text-slate-700 mb-1">Pass/Fail Reference Exam</label>
            <select
              value={examId}
              onChange={(e) => {
                const val = e.target.value;
                setExamId(val);
                loadCandidates(val);
              }}
              className="w-full px-3 py-2 border border-slate-300 rounded-lg bg-white"
            >
              {(data?.availableExaminations || []).map((ex) => (
                <option key={ex.id} value={String(ex.id)}>
                  {ex.name} {ex.hasMarks ? '· Marks Ready' : '· No Marks'}
                </option>
              ))}
              <option value="none">Manual Tick Only (No Exam Filter)</option>
            </select>
          </div>

          <div>
            <label className="block font-semibold text-slate-700 mb-1">To Next Academic Year *</label>
            <input
              type="text"
              value={targetYear}
              onChange={(e) => setTargetYear(e.target.value)}
              placeholder="e.g. 2026-27"
              className="w-full px-3 py-2 border border-slate-300 rounded-lg font-mono bg-white"
            />
          </div>
        </div>

        <div className="flex flex-wrap items-center justify-between gap-3 pt-2 border-t border-slate-100">
          {!isClassTeacherView ? (
            <div className="flex flex-wrap items-center gap-4 text-slate-700">
              <label className="inline-flex items-center gap-2 cursor-pointer">
                <input
                  type="checkbox"
                  checked={setAsCurrentYear}
                  onChange={(e) => setSetAsCurrentYear(e.target.checked)}
                  className="rounded border-slate-300 text-[#1E3A5F]"
                />
                <span>Switch active school year to {targetYear || 'next year'}</span>
              </label>
              <label className="inline-flex items-center gap-2 cursor-pointer">
                <input
                  type="checkbox"
                  checked={copyAssignments}
                  onChange={(e) => setCopyAssignments(e.target.checked)}
                  className="rounded border-slate-300 text-[#1E3A5F]"
                />
                <span>Also carry forward teacher assignments to {targetYear || 'next year'}</span>
              </label>
            </div>
          ) : (
            <div className="text-slate-600">
              Promote eligible students in your assigned class/section to the next class, or tick transferred students to un-promote.
            </div>
          )}

          <div className="text-[11px] text-slate-500">
            Promotion Path:{' '}
            <span className="font-semibold text-slate-800">{data?.sourceClass.name || 'Class'}</span>{' '}
            <span className="font-mono text-slate-400">({sourceYear})</span>{' '}
            <ArrowRight className="w-3 h-3 inline text-slate-400 mx-0.5" />{' '}
            <span className="font-semibold text-[#1E3A5F]">{nextClassLabel}</span>{' '}
            <span className="font-mono text-slate-500">({targetYear})</span>
          </div>
        </div>
      </div>

      {/* KPI & One-Click Action Bar */}
      <div className="bg-white border border-slate-200 rounded-xl p-4 flex flex-wrap items-center justify-between gap-4 text-xs">
        <div className="flex flex-wrap items-center gap-2">
          <span className="px-2.5 py-1 rounded-md bg-slate-100 text-slate-700 font-medium">
            Total: <span className="font-mono font-bold">{data?.summary.totalStudents ?? 0}</span>
          </span>
          <span className="px-2.5 py-1 rounded-md bg-emerald-50 border border-emerald-200 text-emerald-800 font-medium">
            Passed: <span className="font-mono font-bold">{data?.summary.passCount ?? 0}</span>
          </span>
          <span className="px-2.5 py-1 rounded-md bg-red-50 border border-red-200 text-red-800 font-medium">
            Failed: <span className="font-mono font-bold">{data?.summary.failCount ?? 0}</span>
          </span>
          {(data?.summary.incompleteCount ?? 0) > 0 && (
            <span className="px-2.5 py-1 rounded-md bg-amber-50 border border-amber-200 text-amber-800 font-medium">
              Incomplete: <span className="font-mono font-bold">{data?.summary.incompleteCount}</span>
            </span>
          )}
          {(data?.summary.alreadyTransferredCount ?? 0) > 0 && (
            <span className="px-2.5 py-1 rounded-md bg-sky-50 border border-sky-200 text-sky-800 font-medium">
              Promoted to {targetYear}:{' '}
              <span className="font-mono font-bold">{data?.summary.alreadyTransferredCount}</span>
            </span>
          )}
          <span className="px-2.5 py-1 rounded-md bg-[#1E3A5F]/10 border border-[#1E3A5F]/20 text-[#1E3A5F] font-semibold">
            Promote Ticked: <span className="font-mono font-bold">{markedIds.size}</span>
          </span>
          {unpromoteIds.size > 0 && (
            <span className="px-2.5 py-1 rounded-md bg-amber-100 border border-amber-300 text-amber-900 font-semibold">
              Undo Ticked: <span className="font-mono font-bold">{unpromoteIds.size}</span>
            </span>
          )}
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <button
            type="button"
            onClick={handleTickPassed}
            disabled={passedEligibleCandidates.length === 0}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 font-medium text-emerald-800 bg-emerald-50 border border-emerald-200 rounded-lg hover:bg-emerald-100 disabled:opacity-40 cursor-pointer"
          >
            <CheckSquare className="w-3.5 h-3.5" />
            Tick All Passed ({passedEligibleCandidates.length})
          </button>
          <button
            type="button"
            onClick={handleTickAllEligible}
            disabled={eligibleCandidates.length === 0}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 font-medium text-slate-700 bg-white border border-slate-300 rounded-lg hover:bg-slate-50 disabled:opacity-40 cursor-pointer"
          >
            Tick All ({eligibleCandidates.length})
          </button>
          <button
            type="button"
            onClick={handleClearTicks}
            disabled={markedIds.size === 0}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 font-medium text-slate-600 bg-white border border-slate-300 rounded-lg hover:bg-slate-50 disabled:opacity-40 cursor-pointer"
          >
            <Square className="w-3.5 h-3.5" />
            Clear Ticks
          </button>
          <button
            type="button"
            onClick={handleOneClickPromote}
            disabled={submitting || markedIds.size === 0 || !targetYear.trim() || targetYear.trim() === sourceYear}
            className="inline-flex items-center gap-1.5 px-4 py-2 font-semibold text-white bg-[#1E3A5F] rounded-lg hover:bg-[#162D4A] disabled:opacity-40 whitespace-nowrap cursor-pointer"
          >
            <GraduationCap className="w-4 h-4" />
            {submitting
              ? 'Transferring...'
              : `Promote ${markedIds.size} Student${markedIds.size === 1 ? '' : 's'} to ${nextClassLabel} (${targetYear})`}
          </button>

          {transferredCandidates.length > 0 && (
            <>
              <button
                type="button"
                onClick={handleToggleAllPromotedForUndo}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 font-medium text-sky-800 bg-sky-50 border border-sky-200 rounded-lg hover:bg-sky-100 cursor-pointer"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                {allPromotedTicked
                  ? 'Clear Undo Ticks'
                  : `Tick Promoted for Undo (${transferredCandidates.length})`}
              </button>
              {unpromoteIds.size > 0 && (
                <button
                  type="button"
                  onClick={() => setConfirmUnpromoteOpen(true)}
                  disabled={unpromoting || !targetYear.trim() || targetYear.trim() === sourceYear}
                  className="inline-flex items-center gap-1.5 px-4 py-2 font-semibold text-white bg-amber-600 rounded-lg hover:bg-amber-700 disabled:opacity-40 whitespace-nowrap cursor-pointer"
                >
                  <Undo2 className="w-4 h-4" />
                  {unpromoting
                    ? 'Undoing...'
                    : `Undo Promotion / Un-promote (${unpromoteIds.size})`}
                </button>
              )}
            </>
          )}
        </div>
      </div>

      {/* Students Table with Checkbox & Mark/Undo Button */}
      <div className="bg-white border border-slate-200 rounded-xl overflow-hidden">
        <div className="overflow-x-auto max-h-[580px]">
          <table className="w-full text-xs">
            <thead className="bg-slate-50 border-b border-slate-200 text-slate-600 sticky top-0 z-10">
              <tr>
                <th className="w-10 px-4 py-2.5 text-center">
                  <input
                    type="checkbox"
                    aria-label="Toggle all eligible students"
                    checked={allEligibleMarked}
                    disabled={eligibleCandidates.length === 0}
                    onChange={() => (allEligibleMarked ? handleClearTicks() : handleTickAllEligible())}
                    className="rounded border-slate-300 text-[#1E3A5F] cursor-pointer"
                  />
                </th>
                <th className="text-left font-semibold px-3 py-2.5">Student ID</th>
                <th className="text-left font-semibold px-3 py-2.5">Roll</th>
                <th className="text-left font-semibold px-3 py-2.5">Student Name</th>
                <th className="text-left font-semibold px-3 py-2.5">Current Class</th>
                <th className="text-right font-semibold px-3 py-2.5">Exam Score</th>
                <th className="text-center font-semibold px-3 py-2.5">Result</th>
                <th className="text-left font-semibold px-3 py-2.5">Next Class ({targetYear})</th>
                <th className="text-right font-semibold px-4 py-2.5">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200">
              {loading ? (
                <tr>
                  <td colSpan={9} className="px-4 py-8 text-center text-slate-500">
                    Evaluating class students and examination results...
                  </td>
                </tr>
              ) : !data || data.candidates.length === 0 ? (
                <tr>
                  <td colSpan={9} className="px-4 py-8 text-center text-slate-500">
                    No active students found in this class for {sourceYear}.
                  </td>
                </tr>
              ) : (
                data.candidates.map((c: PromotionCandidate) => {
                  const isPromoted = c.alreadyInTargetYear;
                  const isMarked = isPromoted ? unpromoteIds.has(c.studentId) : markedIds.has(c.studentId);

                  return (
                    <tr
                      key={c.studentId}
                      className={`transition-colors ${
                        isPromoted
                          ? isMarked
                            ? 'bg-amber-50/70 hover:bg-amber-50'
                            : 'bg-sky-50/30 text-slate-600 hover:bg-sky-50/50'
                          : isMarked
                          ? 'bg-emerald-50/35 hover:bg-emerald-50/60'
                          : 'hover:bg-slate-50/70'
                      }`}
                    >
                      <td className="px-4 py-2.5 text-center">
                        <input
                          type="checkbox"
                          aria-label={
                            isPromoted
                              ? `Select ${c.fullName} to un-promote`
                              : `Mark ${c.fullName} for promotion`
                          }
                          checked={isMarked}
                          onChange={() =>
                            isPromoted
                              ? toggleUnpromoteMark(c.studentId)
                              : toggleStudentMark(c.studentId)
                          }
                          className={`rounded border-slate-300 cursor-pointer ${
                            isPromoted ? 'text-amber-600 focus:ring-amber-500' : 'text-[#1E3A5F]'
                          }`}
                        />
                      </td>
                      <td className="px-3 py-2.5 font-mono text-slate-600">{c.studentCode}</td>
                      <td className="px-3 py-2.5 font-mono font-semibold tabular-nums">
                        {String(c.rollNumber).padStart(2, '0')}
                      </td>
                      <td className="px-3 py-2.5 font-medium text-slate-900">
                        <span>{c.fullName}</span>
                        {c.stream && (
                          <span className="ml-1.5 px-1.5 py-0.5 text-[10px] font-medium rounded bg-sky-50 text-sky-800 border border-sky-200">
                            {c.stream}
                          </span>
                        )}
                      </td>
                      <td className="px-3 py-2.5 text-slate-600">
                        {formatClassSectionLabel(
                          c.className,
                          c.sectionName,
                          c.hasSections ?? selectedClassObj?.hasSections ?? true
                        )}
                      </td>
                      <td className="px-3 py-2.5 text-right font-mono tabular-nums text-slate-700">
                        {c.grandTotal !== null && c.totalMaxMarks ? (
                          <span>
                            {c.grandTotal}/{c.totalMaxMarks}{' '}
                            <span className="text-slate-500">({c.percentage?.toFixed(1)}%)</span>
                          </span>
                        ) : (
                          '—'
                        )}
                      </td>
                      <td className="px-3 py-2.5 text-center">
                        {c.resultStatus === 'Pass' && (
                          <span className="inline-flex px-2 py-0.5 rounded border text-[11px] font-semibold bg-emerald-50 text-emerald-800 border-emerald-200">
                            Pass {c.grade ? `(${c.grade})` : ''}
                          </span>
                        )}
                        {c.resultStatus === 'Fail' && (
                          <span className="inline-flex px-2 py-0.5 rounded border text-[11px] font-semibold bg-red-50 text-red-800 border-red-200">
                            Fail
                          </span>
                        )}
                        {c.resultStatus === 'Incomplete' && (
                          <span
                            title={`${c.missingCount} subject/component marks missing`}
                            className="inline-flex px-2 py-0.5 rounded border text-[11px] font-semibold bg-amber-50 text-amber-800 border-amber-200"
                          >
                            Incomplete
                          </span>
                        )}
                        {c.resultStatus === 'No Exam' && (
                          <span className="inline-flex px-2 py-0.5 rounded border text-[11px] font-medium bg-slate-100 text-slate-600 border-slate-200">
                            Manual
                          </span>
                        )}
                      </td>
                      <td className="px-3 py-2.5">
                        {isPromoted && c.targetEnrollment ? (
                          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded border text-[11px] font-medium bg-sky-50 text-sky-800 border-sky-200">
                            Promoted ({targetYear}):{' '}
                            {c.targetEnrollment.status === 'graduated'
                              ? 'Graduated'
                              : formatClassSectionLabel(
                                  c.targetEnrollment.className,
                                  c.targetEnrollment.sectionName,
                                  c.targetEnrollment.hasSections ?? true
                                )}
                          </span>
                        ) : (
                          <span className="text-slate-700 font-medium">
                            {c.targetClassId
                              ? formatClassSectionLabel(
                                  c.targetClassName,
                                  c.targetSectionName,
                                  c.targetHasSections ?? true
                                )
                              : 'Graduated (Alumni)'}
                          </span>
                        )}
                      </td>
                      <td className="px-4 py-2.5 text-right whitespace-nowrap">
                        {isPromoted ? (
                          <button
                            type="button"
                            onClick={() => toggleUnpromoteMark(c.studentId)}
                            className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-md border text-[11px] font-semibold transition-colors cursor-pointer ${
                              isMarked
                                ? 'bg-amber-600 text-white border-amber-600 hover:bg-amber-700'
                                : 'bg-white text-amber-700 border-amber-300 hover:bg-amber-50'
                            }`}
                          >
                            <Undo2 className="w-3 h-3" />
                            {isMarked ? 'Undo Marked' : 'Mark Undo'}
                          </button>
                        ) : (
                          <button
                            type="button"
                            onClick={() => toggleStudentMark(c.studentId)}
                            className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-md border text-[11px] font-semibold transition-colors cursor-pointer ${
                              isMarked
                                ? 'bg-emerald-600 text-white border-emerald-600 hover:bg-emerald-700'
                                : 'bg-white text-slate-700 border-slate-300 hover:bg-slate-100'
                            }`}
                          >
                            {isMarked ? (
                              <>
                                <CheckCircle2 className="w-3 h-3" />
                                Marked
                              </>
                            ) : (
                              'Mark'
                            )}
                          </button>
                        )}
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Confirm Undo Promotion Modal */}
      {confirmUnpromoteOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/50 p-4">
          <div className="bg-white border border-slate-200 rounded-xl w-full max-w-md p-6 space-y-4 shadow-xl text-xs">
            <div className="flex items-start justify-between gap-2">
              <div className="flex items-center gap-2">
                <Undo2 className="w-5 h-5 text-amber-600 shrink-0" />
                <h3 className="text-base font-bold text-slate-900">Confirm Undo Promotion (Un-promote)</h3>
              </div>
              <button
                type="button"
                disabled={unpromoting}
                onClick={() => setConfirmUnpromoteOpen(false)}
                className="p-1 text-slate-400 hover:text-slate-700 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
            <p className="text-slate-600 leading-relaxed">
              You are about to un-promote{' '}
              <span className="font-mono font-bold text-slate-900">{unpromoteIds.size}</span>{' '}
              selected student(s) by removing their <span className="font-mono font-semibold">{targetYear}</span>{' '}
              enrollment and returning them to{' '}
              <span className="font-semibold text-slate-900">{data?.sourceClass.name}</span> (
              <span className="font-mono">{sourceYear}</span>).
            </p>
            <div className="p-3 bg-amber-50 border border-amber-200 rounded-lg text-amber-900 leading-relaxed">
              Historical marks from <span className="font-mono font-semibold">{sourceYear}</span> remain untouched. If any selected student already has entered marks in <span className="font-mono font-semibold">{targetYear}</span>, un-promotion will be safely blocked.
            </div>
            <div className="flex flex-col-reverse sm:flex-row sm:justify-end gap-2 pt-1">
              <button
                type="button"
                disabled={unpromoting}
                onClick={() => setConfirmUnpromoteOpen(false)}
                className="min-h-[38px] px-3.5 py-2 border border-slate-300 rounded-lg hover:bg-slate-50 cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="button"
                disabled={unpromoting}
                onClick={handleConfirmUnpromote}
                className="min-h-[38px] px-4 py-2 font-semibold text-white bg-amber-600 rounded-lg hover:bg-amber-700 disabled:opacity-50 cursor-pointer"
              >
                {unpromoting ? 'Un-promoting...' : `Un-promote ${unpromoteIds.size} Student(s)`}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
