import React, { useEffect, useMemo, useRef, useState } from 'react';
import {
  AlertTriangle,
  Award,
  CalendarCheck,
  CalendarDays,
  CheckCircle2,
  ChevronDown,
  ChevronLeft,
  ChevronRight,
  Lock,
  MessageSquareText,
  Pencil,
  RefreshCw,
  RotateCcw,
  Save,
  Search,
} from 'lucide-react';
import type { CoScholasticGradeValue, CoScholasticSheetResponse, StudentTermData } from '../types';
import { apiFetch, extractErrorMessage, isAbortError } from '../lib/api';
import {
  CO_SCHOLASTIC_ALL_ITEMS,
  CO_SCHOLASTIC_SECTIONS,
  isValidCoScholasticGrade,
  summarizeCoScholasticGrades,
} from '../lib/coScholastic';
import { formatClassSectionLabel } from '../lib/grading';
import { formatResultDateDisplay } from '../lib/photoUpload';

interface Props {
  examinationId: number;
  classId: number;
  sectionId: number;
  onSaved?: () => Promise<void> | void;
}

type SectionKey = 'attendance' | 'coScholastic' | 'remarks';

const GRADE_OPTIONS: CoScholasticGradeValue[] = ['A', 'B', 'C'];

function getGradeChipStyle(grade: CoScholasticGradeValue | undefined, active: boolean) {
  if (!active) {
    return 'bg-white text-slate-600 border-slate-300 hover:bg-slate-100';
  }
  if (grade === 'A') {
    return 'bg-emerald-600 text-white border-emerald-700 shadow-xs';
  }
  if (grade === 'B') {
    return 'bg-sky-600 text-white border-sky-700 shadow-xs';
  }
  return 'bg-amber-600 text-white border-amber-700 shadow-xs';
}

function getStaticGradeBadgeClass(grade?: CoScholasticGradeValue) {
  if (grade === 'A') return 'bg-emerald-50 text-emerald-800 border-emerald-200';
  if (grade === 'B') return 'bg-sky-50 text-sky-800 border-sky-200';
  if (grade === 'C') return 'bg-amber-50 text-amber-800 border-amber-200';
  return 'bg-slate-50 text-slate-400 border-slate-200';
}

function numToStr(v: number | null | undefined): string {
  return v !== null && v !== undefined ? String(v) : '';
}

function parseIntOrNull(s: string): number | null {
  const trimmed = s.trim();
  if (!trimmed) return null;
  const n = Number(trimmed);
  return Number.isFinite(n) ? n : NaN;
}

export function CoScholasticGradesPanel({ examinationId, classId, sectionId, onSaved }: Props) {
  const [sheet, setSheet] = useState<CoScholasticSheetResponse | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [selectedStudentId, setSelectedStudentId] = useState<number>(0);
  const [searchQuery, setSearchQuery] = useState('');
  const [draftGrades, setDraftGrades] = useState<Record<string, CoScholasticGradeValue | ''>>({});

  // Term I & Term II Attendance + Remarks
  const [t1DaysAttended, setT1DaysAttended] = useState('');
  const [t1TotalDays, setT1TotalDays] = useState('');
  const [t1Remarks, setT1Remarks] = useState('');
  const [t2DaysAttended, setT2DaysAttended] = useState('');
  const [t2TotalDays, setT2TotalDays] = useState('');
  const [t2Remarks, setT2Remarks] = useState('');

  // During Final (Term II) exam, Term I is displayed cleanly as reference & optionally unlockable to edit
  const [unlockT1InFinal, setUnlockT1InFinal] = useState(false);

  // Class Result Date (one date per class/section/academicYear)
  const [resultDateInput, setResultDateInput] = useState('');
  const [savingResultDate, setSavingResultDate] = useState(false);

  // Highlighted accordion section flow ('attendance' -> 'coScholastic' -> 'remarks', or 'all')
  const [openSection, setOpenSection] = useState<SectionKey | 'all' | null>('attendance');

  const [dirty, setDirty] = useState(false);
  const [saving, setSaving] = useState(false);
  const [bulkBusyTerm, setBulkBusyTerm] = useState<1 | 2 | null>(null);
  const [feedback, setFeedback] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  const reqSeqRef = useRef(0);
  const abortRef = useRef<AbortController | null>(null);

  useEffect(() => {
    return () => {
      abortRef.current?.abort();
    };
  }, []);

  const loadSheet = async () => {
    abortRef.current?.abort();
    if (!examinationId || !classId || !sectionId) {
      setSheet(null);
      return;
    }
    const controller = new AbortController();
    abortRef.current = controller;
    const seq = ++reqSeqRef.current;

    setLoading(true);
    setError(null);
    setFeedback(null);
    try {
      const data = await apiFetch<CoScholasticSheetResponse>(
        `/api/co-scholastic/sheet?examinationId=${examinationId}&classId=${classId}&sectionId=${sectionId}`,
        { signal: controller.signal }
      );
      if (seq !== reqSeqRef.current) return;
      setSheet(data);
      setResultDateInput(data.classInfo?.resultDate || '');
      setSelectedStudentId((prev) => {
        if (prev && data.students.some((s) => s.studentId === prev)) return prev;
        return data.students[0]?.studentId || 0;
      });
    } catch (err: unknown) {
      if (isAbortError(err) || seq !== reqSeqRef.current) return;
      setSheet(null);
      setError(extractErrorMessage(err, 'Could not load class teacher assessment sheet.'));
    } finally {
      if (seq === reqSeqRef.current) {
        setLoading(false);
      }
    }
  };

  useEffect(() => {
    loadSheet();
  }, [examinationId, classId, sectionId]);

  const activeTerm = sheet?.termMeta.eligible ? sheet.termMeta.term : null;

  const selectedStudent = useMemo(() => {
    if (!sheet) return null;
    return sheet.students.find((s) => s.studentId === selectedStudentId) || sheet.students[0] || null;
  }, [sheet, selectedStudentId]);

  useEffect(() => {
    setUnlockT1InFinal(false);
    if (!selectedStudent || !sheet) {
      setDraftGrades({});
      setT1DaysAttended('');
      setT1TotalDays('');
      setT1Remarks('');
      setT2DaysAttended('');
      setT2TotalDays('');
      setT2Remarks('');
      setDirty(false);
      return;
    }

    const sourceMap =
      activeTerm === 1 ? selectedStudent.term1 : activeTerm === 2 ? selectedStudent.term2 : {};
    const nextDraft: Record<string, CoScholasticGradeValue | ''> = {};
    for (const item of CO_SCHOLASTIC_ALL_ITEMS) {
      const val = sourceMap[item.key];
      nextDraft[item.key] = isValidCoScholasticGrade(val) ? val : '';
    }
    setDraftGrades(nextDraft);

    const tr = selectedStudent.termRecords;
    setT1DaysAttended(numToStr(tr?.term1?.daysAttended));
    setT1TotalDays(numToStr(tr?.term1?.totalDays));
    setT1Remarks(tr?.term1?.remarks || '');
    setT2DaysAttended(numToStr(tr?.term2?.daysAttended));
    setT2TotalDays(numToStr(tr?.term2?.totalDays));
    setT2Remarks(tr?.term2?.remarks || '');

    setDirty(false);
  }, [selectedStudent?.studentId, activeTerm, sheet?.termMeta.examinationId]);

  const filteredStudents = useMemo(() => {
    if (!sheet) return [];
    const q = searchQuery.trim().toLowerCase();
    if (!q) return sheet.students;
    return sheet.students.filter(
      (st) =>
        st.studentName.toLowerCase().includes(q) ||
        st.studentCode.toLowerCase().includes(q) ||
        String(st.rollNumber).includes(q)
    );
  }, [sheet, searchQuery]);

  const draftSummary = useMemo(() => {
    const clean: Record<string, CoScholasticGradeValue> = {};
    for (const item of CO_SCHOLASTIC_ALL_ITEMS) {
      const v = draftGrades[item.key];
      if (isValidCoScholasticGrade(v)) clean[item.key] = v;
    }
    return summarizeCoScholasticGrades(clean);
  }, [draftGrades]);

  const liveAttendanceTotal = useMemo(() => {
    const a1 = parseIntOrNull(t1DaysAttended);
    const d1 = parseIntOrNull(t1TotalDays);
    const a2 = parseIntOrNull(t2DaysAttended);
    const d2 = parseIntOrNull(t2TotalDays);
    const validAtt =
      (a1 !== null && !Number.isNaN(a1) ? a1 : 0) + (a2 !== null && !Number.isNaN(a2) ? a2 : 0);
    const validTot =
      (d1 !== null && !Number.isNaN(d1) ? d1 : 0) + (d2 !== null && !Number.isNaN(d2) ? d2 : 0);
    const hasAnyAtt = (a1 !== null && !Number.isNaN(a1)) || (a2 !== null && !Number.isNaN(a2));
    const hasAnyTot = (d1 !== null && !Number.isNaN(d1)) || (d2 !== null && !Number.isNaN(d2));
    return {
      attended: hasAnyAtt ? validAtt : null,
      total: hasAnyTot ? validTot : null,
      pct: hasAnyAtt && hasAnyTot && validTot > 0 ? ((validAtt / validTot) * 100).toFixed(1) : null,
    };
  }, [t1DaysAttended, t1TotalDays, t2DaysAttended, t2TotalDays]);

  const isSectionOpen = (key: SectionKey) => openSection === 'all' || openSection === key;
  const toggleSection = (key: SectionKey) => {
    setOpenSection((prev) => (prev === key ? null : key));
  };

  const selectStudent = (studentId: number) => {
    setFeedback(null);
    setSelectedStudentId(studentId);
  };

  const handleSetGrade = (itemKey: string, val: CoScholasticGradeValue | '') => {
    if (!activeTerm) return;
    setDraftGrades((prev) => ({ ...prev, [itemKey]: val }));
    setDirty(true);
    setFeedback(null);
  };

  const handleBulkFill = (mode: 'all_A' | 'all_B' | 'clear') => {
    if (!activeTerm) return;
    setDraftGrades((prev) => {
      const next = { ...prev };
      for (const item of CO_SCHOLASTIC_ALL_ITEMS) {
        if (mode === 'all_A') next[item.key] = 'A';
        else if (mode === 'all_B') next[item.key] = 'B';
        else next[item.key] = '';
      }
      return next;
    });
    setDirty(true);
    setFeedback(null);
  };

  const handleSaveResultDate = async (overrideDate?: string) => {
    if (!sheet) return;
    const nextDate = overrideDate !== undefined ? overrideDate : resultDateInput;
    setSavingResultDate(true);
    setFeedback(null);
    try {
      const res = await apiFetch<{ success: boolean; resultDate: string | null }>(
        '/api/class-teacher/result-date',
        {
          method: 'POST',
          body: JSON.stringify({
            classId,
            sectionId,
            academicYear: sheet.termMeta.academicYear,
            examinationId,
            resultDate: nextDate,
          }),
        }
      );
      setResultDateInput(res.resultDate || '');
      setSheet((prev) =>
        prev
          ? {
              ...prev,
              classInfo: {
                ...prev.classInfo,
                resultDate: res.resultDate,
              },
            }
          : prev
      );
      if (onSaved) await onSaved();
      setFeedback({
        type: 'success',
        text: res.resultDate
          ? `Result Date (${formatResultDateDisplay(res.resultDate)}) saved for all students in ${formatClassSectionLabel(
              sheet.classInfo.className,
              sheet.classInfo.sectionName,
              sheet.classInfo.hasSections ?? true
            )} (AY ${sheet.termMeta.academicYear}).`
          : 'Cleared class Result Date.',
      });
    } catch (err: unknown) {
      setFeedback({
        type: 'error',
        text: extractErrorMessage(err, 'Failed to save class Result Date.'),
      });
    } finally {
      setSavingResultDate(false);
    }
  };

  const handleBulkApplyTotalDays = async (termNum: 1 | 2) => {
    if (!sheet) return;
    const rawStr = termNum === 1 ? t1TotalDays : t2TotalDays;
    const parsed = parseIntOrNull(rawStr);
    if (parsed === null || !Number.isInteger(parsed) || parsed < 0 || parsed > 366) {
      setFeedback({
        type: 'error',
        text: `Enter a valid whole number (0–366) in Term ${termNum} Total Working Days first, then click Apply to Class.`,
      });
      return;
    }

    setBulkBusyTerm(termNum);
    setFeedback(null);
    try {
      const res = await apiFetch<{
        success: boolean;
        updatedCount: number;
        term: number;
        totalDays: number;
      }>('/api/class-teacher/term-records/bulk-total-days', {
        method: 'POST',
        body: JSON.stringify({
          classId,
          sectionId,
          academicYear: sheet.termMeta.academicYear,
          examinationId,
          term: termNum,
          totalDays: parsed,
        }),
      });

      setSheet((prev) =>
        prev
          ? {
              ...prev,
              students: prev.students.map((st) => {
                const tr: StudentTermData = st.termRecords || {
                  term1: { daysAttended: null, totalDays: null, remarks: '' },
                  term2: { daysAttended: null, totalDays: null, remarks: '' },
                  totalDaysAttended: null,
                  totalWorkingDays: null,
                };
                const nextT1 = termNum === 1 ? { ...tr.term1, totalDays: parsed } : tr.term1;
                const nextT2 = termNum === 2 ? { ...tr.term2, totalDays: parsed } : tr.term2;
                const totWork =
                  nextT1.totalDays !== null || nextT2.totalDays !== null
                    ? (nextT1.totalDays ?? 0) + (nextT2.totalDays ?? 0)
                    : null;
                return {
                  ...st,
                  termRecords: {
                    ...tr,
                    term1: nextT1,
                    term2: nextT2,
                    totalWorkingDays: totWork,
                  },
                };
              }),
            }
          : prev
      );

      if (onSaved) await onSaved();
      setFeedback({
        type: 'success',
        text: `Applied Term ${termNum} Total Working Days (${parsed}) to all ${res.updatedCount} active students.`,
      });
    } catch (err: unknown) {
      setFeedback({
        type: 'error',
        text: extractErrorMessage(err, `Failed to apply Term ${termNum} Total Working Days to class.`),
      });
    } finally {
      setBulkBusyTerm(null);
    }
  };

  const handleSaveStudent = async (advanceToNext = false) => {
    if (!sheet || !selectedStudent) return;

    const shouldSaveTerm1 = activeTerm === 1 || !activeTerm || unlockT1InFinal;
    const shouldSaveTerm2 = activeTerm === 2 || !activeTerm;

    const a1 = parseIntOrNull(t1DaysAttended);
    const d1 = parseIntOrNull(t1TotalDays);
    const a2 = parseIntOrNull(t2DaysAttended);
    const d2 = parseIntOrNull(t2TotalDays);

    if (shouldSaveTerm1) {
      if (
        (a1 !== null && (!Number.isInteger(a1) || a1 < 0 || a1 > 366)) ||
        (d1 !== null && (!Number.isInteger(d1) || d1 < 0 || d1 > 366))
      ) {
        setFeedback({
          type: 'error',
          text: 'Term I attendance days must be whole numbers between 0 and 366 (or left blank).',
        });
        return;
      }
      if (a1 !== null && d1 !== null && a1 > d1) {
        setFeedback({
          type: 'error',
          text: `Term I: Days Attended (${a1}) cannot exceed Total Working Days (${d1}).`,
        });
        return;
      }
    }

    if (shouldSaveTerm2) {
      if (
        (a2 !== null && (!Number.isInteger(a2) || a2 < 0 || a2 > 366)) ||
        (d2 !== null && (!Number.isInteger(d2) || d2 < 0 || d2 > 366))
      ) {
        setFeedback({
          type: 'error',
          text: 'Term II attendance days must be whole numbers between 0 and 366 (or left blank).',
        });
        return;
      }
      if (a2 !== null && d2 !== null && a2 > d2) {
        setFeedback({
          type: 'error',
          text: `Term II: Days Attended (${a2}) cannot exceed Total Working Days (${d2}).`,
        });
        return;
      }
    }

    setSaving(true);
    setFeedback(null);
    try {
      const termPayload: Record<string, unknown> = {
        classId,
        sectionId,
        studentId: selectedStudent.studentId,
        academicYear: sheet.termMeta.academicYear,
        examinationId,
      };
      if (shouldSaveTerm1) {
        termPayload.term1 = {
          daysAttended: a1,
          totalDays: d1,
          remarks: t1Remarks,
        };
      }
      if (shouldSaveTerm2) {
        termPayload.term2 = {
          daysAttended: a2,
          totalDays: d2,
          remarks: t2Remarks,
        };
      }

      const termRes = await apiFetch<{
        success: boolean;
        studentId: number;
        termRecords: StudentTermData;
      }>('/api/class-teacher/term-records/save', {
        method: 'POST',
        body: JSON.stringify(termPayload),
      });

      let coRes: {
        term1: Record<string, CoScholasticGradeValue>;
        term2: Record<string, CoScholasticGradeValue>;
        term1TotalPoints: number | null;
        term2TotalPoints: number | null;
      } | null = null;

      if (activeTerm) {
        const payloadGrades: Record<string, CoScholasticGradeValue | null> = {};
        for (const item of CO_SCHOLASTIC_ALL_ITEMS) {
          const val = draftGrades[item.key];
          payloadGrades[item.key] = isValidCoScholasticGrade(val) ? val : null;
        }
        coRes = await apiFetch<{
          success: boolean;
          studentId: number;
          term: 1 | 2;
          term1: Record<string, CoScholasticGradeValue>;
          term2: Record<string, CoScholasticGradeValue>;
          term1TotalPoints: number | null;
          term2TotalPoints: number | null;
        }>('/api/co-scholastic/save', {
          method: 'POST',
          body: JSON.stringify({
            examinationId,
            classId,
            sectionId,
            studentId: selectedStudent.studentId,
            grades: payloadGrades,
          }),
        });
      }

      setSheet((prev) =>
        prev
          ? {
              ...prev,
              students: prev.students.map((st) =>
                st.studentId === selectedStudent.studentId
                  ? {
                      ...st,
                      termRecords: termRes.termRecords,
                      ...(coRes
                        ? {
                            term1: coRes.term1,
                            term2: coRes.term2,
                            term1TotalPoints: coRes.term1TotalPoints,
                            term2TotalPoints: coRes.term2TotalPoints,
                          }
                        : {}),
                    }
                  : st
              ),
            }
          : prev
      );
      setDirty(false);

      if (onSaved) {
        await onSaved();
      }

      const savedWhat = activeTerm
        ? `${sheet.termMeta.termLabel} grades, attendance & remarks`
        : 'attendance & remarks';

      if (advanceToNext && sheet.students.length > 0) {
        const idx = sheet.students.findIndex((s) => s.studentId === selectedStudent.studentId);
        if (idx >= 0 && idx < sheet.students.length - 1) {
          const nextStudent = sheet.students[idx + 1];
          setSelectedStudentId(nextStudent.studentId);
          setFeedback({
            type: 'success',
            text: `Saved ${savedWhat} for ${selectedStudent.studentName}. Moved to ${nextStudent.studentName}.`,
          });
          return;
        }
      }

      setFeedback({
        type: 'success',
        text: `Saved ${savedWhat} for ${selectedStudent.studentName}.`,
      });
    } catch (err: unknown) {
      setFeedback({
        type: 'error',
        text: extractErrorMessage(err, 'Failed to save student records.'),
      });
    } finally {
      setSaving(false);
    }
  };

  if (loading && !sheet) {
    return (
      <div className="bg-white border border-slate-200 rounded-xl p-10 text-center text-sm text-slate-500">
        Loading Co-Scholastic Grades, Attendance &amp; Remarks Sheet...
      </div>
    );
  }

  if (error) {
    return (
      <div className="p-4 rounded-xl bg-red-50 border border-red-200 flex flex-wrap items-center justify-between gap-2 text-sm text-red-800">
        <span>{error}</span>
        <button
          type="button"
          onClick={loadSheet}
          className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-white border border-red-200 rounded-lg text-xs font-semibold text-red-800 hover:bg-red-100 cursor-pointer"
        >
          <RefreshCw className="w-3.5 h-3.5" />
          Retry
        </button>
      </div>
    );
  }

  if (!sheet) {
    return (
      <div className="bg-white border border-slate-200 rounded-xl p-10 text-center text-sm text-slate-500">
        Select an examination, class, and section to enter Co-Scholastic Grades, Attendance, and Remarks.
      </div>
    );
  }

  const selectedIndex = selectedStudent
    ? sheet.students.findIndex((s) => s.studentId === selectedStudent.studentId)
    : -1;

  // Compute section status badges for accordion headers
  const activeAttendanceStatus = (() => {
    if (activeTerm === 1) {
      return t1DaysAttended.trim() || t1TotalDays.trim()
        ? `Term I: ${t1DaysAttended.trim() || '—'}/${t1TotalDays.trim() || '—'}`
        : 'Pending';
    }
    if (activeTerm === 2) {
      return t2DaysAttended.trim() || t2TotalDays.trim()
        ? `Term II: ${t2DaysAttended.trim() || '—'}/${t2TotalDays.trim() || '—'}`
        : 'Pending Term II';
    }
    return liveAttendanceTotal.attended !== null || liveAttendanceTotal.total !== null
      ? `Total: ${liveAttendanceTotal.attended ?? '—'}/${liveAttendanceTotal.total ?? '—'}`
      : 'Not entered';
  })();

  const activeCoStatus = (() => {
    if (!activeTerm) return 'View Only';
    return `${draftSummary.gradedCount}/${draftSummary.totalItems} Graded`;
  })();

  const activeRemarksStatus = (() => {
    if (activeTerm === 1) return t1Remarks.trim() ? 'Entered' : 'Optional';
    if (activeTerm === 2) return t2Remarks.trim() ? 'Term II Entered' : 'Optional';
    return t1Remarks.trim() || t2Remarks.trim() ? 'Entered' : 'Optional';
  })();

  const savedClassResultDate = sheet.classInfo.resultDate || '';
  const resultDateDirty = (resultDateInput || '') !== (savedClassResultDate || '');

  return (
    <div className="space-y-4">
      {/* Header + Class Result Date Bar */}
      <div className="bg-white border border-slate-200 rounded-xl p-4 space-y-3.5">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div>
            <div className="flex items-center gap-2 flex-wrap">
              <h2 className="text-sm font-bold text-slate-900">
                Co-Scholastic Grades, Attendance &amp; Remarks —{' '}
                {formatClassSectionLabel(
                  sheet.classInfo.className,
                  sheet.classInfo.sectionName,
                  sheet.classInfo.hasSections ?? true
                )}
              </h2>
              {sheet.termMeta.eligible && sheet.termMeta.termLabel ? (
                <span className="inline-flex items-center gap-1 px-2.5 py-0.5 text-xs font-semibold rounded bg-emerald-50 text-emerald-800 border border-emerald-200">
                  <Award className="w-3.5 h-3.5" />
                  {activeTerm === 1
                    ? `Half-Yearly (${sheet.termMeta.termLabel})`
                    : `Annual / Final (${sheet.termMeta.termLabel})`}{' '}
                  · {sheet.termMeta.examinationName}
                </span>
              ) : (
                <span className="inline-flex items-center gap-1 px-2.5 py-0.5 text-xs font-semibold rounded bg-amber-50 text-amber-800 border border-amber-200">
                  <Lock className="w-3.5 h-3.5" />
                  Co-Scholastic View Only · Attendance &amp; Remarks Editable
                </span>
              )}
            </div>
            <p className="text-xs text-slate-500 mt-1">{sheet.termMeta.reason}</p>
          </div>

          <div className="flex flex-wrap items-center gap-2 text-xs">
            <span className="font-semibold text-slate-600">3-Point Scale:</span>
            <span className="px-2 py-0.5 font-mono font-semibold rounded bg-slate-100 text-slate-800 border border-slate-200">
              Grades A, B, C
            </span>
            <button
              type="button"
              onClick={loadSheet}
              disabled={loading}
              className="ml-1 inline-flex items-center gap-1 px-3 py-1.5 min-h-[36px] text-xs font-medium text-slate-700 bg-white border border-slate-300 rounded-lg hover:bg-slate-50 cursor-pointer"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} />
              Refresh
            </button>
          </div>
        </div>

        {/* Class Result Date Card (Single setting for entire class/section/academic year) */}
        <div className="p-3 sm:p-3.5 rounded-xl bg-sky-50/70 border border-sky-200 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
          <div className="flex items-start gap-2.5">
            <CalendarCheck className="w-4 h-4 text-[#1E3A5F] shrink-0 mt-0.5" />
            <div>
              <div className="text-xs font-bold text-[#1E3A5F]">
                Result Date for Marksheets (AY {sheet.termMeta.academicYear})
              </div>
              <p className="text-[11px] text-slate-600 mt-0.5">
                Entered once for{' '}
                <strong className="text-slate-800">
                  {formatClassSectionLabel(
                    sheet.classInfo.className,
                    sheet.classInfo.sectionName,
                    sheet.classInfo.hasSections ?? true
                  )}
                </strong>{' '}
                and displayed automatically on all students&apos; PDF &amp; screen report cards.
              </p>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-2 w-full sm:w-auto">
            <input
              type="date"
              aria-label="Class Result Date"
              value={resultDateInput}
              onChange={(e) => setResultDateInput(e.target.value)}
              className="min-h-[40px] px-3 py-1.5 text-xs font-mono bg-white border border-slate-300 rounded-lg focus:outline-none focus:border-[#1E3A5F] flex-1 sm:flex-initial"
            />
            <button
              type="button"
              disabled={savingResultDate || (!resultDateDirty && Boolean(savedClassResultDate))}
              onClick={() => handleSaveResultDate()}
              className="min-h-[40px] inline-flex items-center justify-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-white bg-[#1E3A5F] rounded-lg hover:bg-[#162D4A] disabled:opacity-50 cursor-pointer whitespace-nowrap"
            >
              <Save className="w-3.5 h-3.5" />
              {savingResultDate ? 'Saving...' : 'Save Result Date'}
            </button>
            {savedClassResultDate && (
              <span className="text-[11px] font-mono text-emerald-800 bg-emerald-50 border border-emerald-200 px-2 py-1 rounded">
                Saved: {formatResultDateDisplay(savedClassResultDate)}
              </span>
            )}
          </div>
        </div>

        {!sheet.termMeta.eligible && (
          <div className="flex items-start gap-2.5 p-3 rounded-lg bg-amber-50 border border-amber-200 text-xs text-amber-950">
            <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
            <div>
              <span className="font-semibold">3-point Grade entry disabled for {sheet.termMeta.examinationName}:</span>{' '}
              Co-Scholastic &amp; Discipline grades apply only to the 1st 100-mark exam (Half-Yearly / Term I) and 2nd
              100-mark exam (Annual / Term II). You can still edit Term I &amp; Term II Attendance and Remarks below.
              {sheet.termMeta.eligibleExams.length > 0 && (
                <span className="block mt-1">
                  Eligible exams in {sheet.termMeta.academicYear}:{' '}
                  {sheet.termMeta.eligibleExams.map((ex) => `${ex.name} (${ex.termLabel})`).join(' · ')}.
                </span>
              )}
            </div>
          </div>
        )}
      </div>

      {feedback && (
        <div
          className={`flex items-center gap-2 p-3 rounded-xl border text-xs font-medium ${
            feedback.type === 'success'
              ? 'bg-emerald-50 border-emerald-200 text-emerald-900'
              : 'bg-red-50 border-red-200 text-red-900'
          }`}
        >
          {feedback.type === 'success' ? (
            <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
          ) : (
            <AlertTriangle className="w-4 h-4 text-red-600 shrink-0" />
          )}
          <span>{feedback.text}</span>
        </div>
      )}

      {sheet.students.length === 0 ? (
        <div className="bg-white border border-slate-200 rounded-xl p-10 text-center text-sm text-slate-500">
          No active students found in{' '}
          {formatClassSectionLabel(
            sheet.classInfo.className,
            sheet.classInfo.sectionName,
            sheet.classInfo.hasSections ?? true
          )}{' '}
          for {sheet.termMeta.academicYear}.
        </div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-4 items-start">
          {/* Left Pane: Individual Student Selector */}
          <div className="lg:col-span-4 bg-white border border-slate-200 rounded-xl overflow-hidden">
            <div className="p-3 border-b border-slate-200 space-y-2 bg-slate-50/60">
              <div className="flex items-center justify-between text-xs font-semibold text-slate-700">
                <span>Select Student ({sheet.students.length})</span>
                <span className="font-mono text-[11px] text-slate-500">
                  {activeTerm ? `Term ${activeTerm} Status` : 'Saved Overview'}
                </span>
              </div>
              <div className="relative">
                <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Search roll, ID, or name..."
                  className="w-full min-h-[38px] pl-8 pr-3 py-1.5 text-xs bg-white border border-slate-300 rounded-lg focus:outline-none focus:border-[#1E3A5F]"
                />
              </div>
            </div>

            <div className="divide-y divide-slate-100 max-h-[42vh] lg:max-h-[65vh] overflow-y-auto">
              {filteredStudents.map((st) => {
                const isSelected = selectedStudent?.studentId === st.studentId;
                const activeMap = activeTerm === 2 ? st.term2 : st.term1;
                const summary = summarizeCoScholasticGrades(activeMap);
                const t1Done = summarizeCoScholasticGrades(st.term1).gradedCount;
                const t2Done = summarizeCoScholasticGrades(st.term2).gradedCount;
                const hasAtt =
                  activeTerm === 1
                    ? st.termRecords?.term1?.daysAttended !== null
                    : activeTerm === 2
                      ? st.termRecords?.term2?.daysAttended !== null
                      : st.termRecords?.term1?.daysAttended !== null ||
                        st.termRecords?.term2?.daysAttended !== null;

                return (
                  <button
                    key={st.studentId}
                    type="button"
                    onClick={() => selectStudent(st.studentId)}
                    className={`w-full text-left px-3.5 py-2.5 flex items-center justify-between gap-2 transition-colors cursor-pointer ${
                      isSelected ? 'bg-[#1E3A5F] text-white' : 'hover:bg-slate-50 text-slate-900'
                    }`}
                  >
                    <div className="min-w-0">
                      <div className="flex items-center gap-2">
                        <span
                          className={`font-mono text-xs font-semibold tabular-nums ${
                            isSelected ? 'text-sky-200' : 'text-slate-500'
                          }`}
                        >
                          {String(st.rollNumber).padStart(2, '0')}
                        </span>
                        <span className="text-xs font-semibold truncate">{st.studentName}</span>
                      </div>
                      <div
                        className={`text-[10px] font-mono mt-0.5 ${
                          isSelected ? 'text-slate-200' : 'text-slate-400'
                        }`}
                      >
                        {st.studentCode}
                        {st.stream ? ` · ${st.stream}` : ''}
                        {hasAtt ? ' · Att ✓' : ''}
                      </div>
                    </div>

                    <div className="shrink-0 text-right">
                      {activeTerm ? (
                        <span
                          className={`inline-flex items-center px-2 py-0.5 rounded text-[10px] font-mono font-semibold border ${
                            isSelected
                              ? 'bg-white/15 text-white border-white/25'
                              : summary.gradedCount === summary.totalItems
                                ? 'bg-emerald-50 text-emerald-800 border-emerald-200'
                                : summary.gradedCount > 0
                                  ? 'bg-amber-50 text-amber-800 border-amber-200'
                                  : 'bg-slate-100 text-slate-500 border-slate-200'
                          }`}
                        >
                          {summary.gradedCount}/{summary.totalItems}
                        </span>
                      ) : (
                        <span
                          className={`text-[10px] font-mono ${isSelected ? 'text-slate-200' : 'text-slate-500'}`}
                        >
                          T1:{t1Done}/10 · T2:{t2Done}/10
                        </span>
                      )}
                    </div>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Right Pane: Highlighted Accordion Sections for Selected Student */}
          {selectedStudent && (
            <div className="lg:col-span-8 bg-white border border-slate-200 rounded-xl overflow-hidden">
              {/* Student Header */}
              <div className="px-4 sm:px-5 py-3.5 border-b border-slate-200 bg-slate-50 flex flex-wrap items-center justify-between gap-3">
                <div>
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="font-mono text-xs font-bold px-2 py-0.5 rounded bg-slate-200 text-slate-800">
                      Roll {String(selectedStudent.rollNumber).padStart(2, '0')}
                    </span>
                    <h3 className="text-base font-bold text-slate-900">{selectedStudent.studentName}</h3>
                    <span className="font-mono text-xs text-slate-500">{selectedStudent.studentCode}</span>
                    {dirty && (
                      <span className="px-2 py-0.5 rounded bg-amber-100 text-amber-900 font-semibold text-[11px]">
                        Unsaved Changes
                      </span>
                    )}
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => setOpenSection((prev) => (prev === 'all' ? 'attendance' : 'all'))}
                    className="px-2.5 py-1.5 text-[11px] font-medium text-slate-700 bg-white border border-slate-300 rounded-lg hover:bg-slate-100 cursor-pointer"
                  >
                    {openSection === 'all' ? 'One-by-One Mode' : 'Expand All Sections'}
                  </button>
                </div>
              </div>

              <div className="p-3 sm:p-5 space-y-3.5">
                {/* 1. HIGHLIGHTED DROPDOWN SECTION: ATTENDANCE */}
                <div
                  className={`rounded-xl border transition-all overflow-hidden ${
                    isSectionOpen('attendance')
                      ? 'border-[#1E3A5F] bg-white ring-2 ring-[#1E3A5F]/15 shadow-xs'
                      : 'border-slate-200 bg-slate-50/70 hover:border-slate-300'
                  }`}
                >
                  <button
                    type="button"
                    onClick={() => toggleSection('attendance')}
                    className={`w-full px-4 py-3.5 flex items-center justify-between gap-3 text-left transition-colors cursor-pointer ${
                      isSectionOpen('attendance')
                        ? 'bg-[#1E3A5F] text-white'
                        : 'text-slate-900 hover:bg-slate-100/70'
                    }`}
                  >
                    <div className="flex items-center gap-2.5 min-w-0">
                      <span
                        className={`w-6 h-6 rounded-full text-xs font-bold flex items-center justify-center shrink-0 ${
                          isSectionOpen('attendance')
                            ? 'bg-white text-[#1E3A5F]'
                            : 'bg-[#1E3A5F]/10 text-[#1E3A5F]'
                        }`}
                      >
                        1
                      </span>
                      <CalendarDays className="w-4 h-4 shrink-0" />
                      <div className="min-w-0">
                        <div className="text-xs sm:text-sm font-bold truncate">
                          Attendance
                          {activeTerm === 1
                            ? ' — Half-Yearly (Term I)'
                            : activeTerm === 2
                              ? ' — Half-Yearly (Saved) & Final Exam (Term II)'
                              : ' (Term I & Term II)'}
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center gap-2 shrink-0">
                      <span
                        className={`px-2 py-0.5 rounded text-[11px] font-mono font-semibold ${
                          isSectionOpen('attendance')
                            ? 'bg-white/20 text-white'
                            : 'bg-white border border-slate-200 text-slate-700'
                        }`}
                      >
                        {activeAttendanceStatus}
                      </span>
                      <ChevronDown
                        className={`w-4 h-4 transition-transform ${
                          isSectionOpen('attendance') ? 'rotate-180' : ''
                        }`}
                      />
                    </div>
                  </button>

                  {isSectionOpen('attendance') && (
                    <div className="p-4 space-y-4 border-t border-slate-200 bg-white">
                      {activeTerm === 2 && (
                        <div className="flex flex-wrap items-center justify-between gap-2 text-xs font-mono tabular-nums text-slate-700 bg-slate-50 border border-slate-200 rounded-lg px-3 py-2">
                          <span>
                            Combined Attendance (Term I + Term II):{' '}
                            <strong className="text-slate-900">
                              {liveAttendanceTotal.attended !== null || liveAttendanceTotal.total !== null
                                ? `${liveAttendanceTotal.attended ?? '—'} / ${liveAttendanceTotal.total ?? '—'}${
                                    liveAttendanceTotal.pct !== null ? ` (${liveAttendanceTotal.pct}%)` : ''
                                  }`
                                : 'Not entered'}
                            </strong>
                          </span>
                          <button
                            type="button"
                            onClick={() => setUnlockT1InFinal((prev) => !prev)}
                            className="inline-flex items-center gap-1 font-sans text-[11px] font-medium text-[#1E3A5F] hover:underline cursor-pointer"
                          >
                            <Pencil className="w-3 h-3" />
                            {unlockT1InFinal ? 'Lock Half-Yearly Data' : 'Edit Half-Yearly Data'}
                          </button>
                        </div>
                      )}

                      <div
                        className={`grid grid-cols-1 ${
                          activeTerm === 1 ? '' : 'md:grid-cols-2'
                        } gap-4`}
                      >
                        {/* Term I (Half-Yearly) Attendance Card */}
                        {activeTerm !== 2 || unlockT1InFinal ? (
                          activeTerm !== 2 || unlockT1InFinal ? (
                            <div className="bg-slate-50/70 border border-slate-200 rounded-lg p-3.5 space-y-3">
                              <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-200 pb-2">
                                <span className="text-xs font-bold text-[#1E3A5F]">
                                  Half-Yearly Exam (Term I) Attendance
                                </span>
                                <button
                                  type="button"
                                  disabled={bulkBusyTerm !== null}
                                  onClick={() => handleBulkApplyTotalDays(1)}
                                  title="Copy this Term I Total Days value to all students in the section"
                                  className="text-[11px] font-semibold text-[#1E3A5F] hover:underline disabled:opacity-50 cursor-pointer"
                                >
                                  {bulkBusyTerm === 1 ? 'Applying...' : 'Apply Total Days to All'}
                                </button>
                              </div>
                              <div className="grid grid-cols-2 gap-3 text-xs">
                                <div>
                                  <label className="block font-medium text-slate-600 mb-1">Days Attended</label>
                                  <input
                                    type="number"
                                    min={0}
                                    max={366}
                                    value={t1DaysAttended}
                                    onChange={(e) => {
                                      setT1DaysAttended(e.target.value);
                                      setDirty(true);
                                      setFeedback(null);
                                    }}
                                    placeholder="e.g. 92"
                                    className="w-full min-h-[42px] sm:min-h-[38px] px-2.5 py-1.5 bg-white border border-slate-300 rounded-lg font-mono tabular-nums focus:outline-none focus:border-[#1E3A5F]"
                                  />
                                </div>
                                <div>
                                  <label className="block font-medium text-slate-600 mb-1">Total Working Days</label>
                                  <input
                                    type="number"
                                    min={0}
                                    max={366}
                                    value={t1TotalDays}
                                    onChange={(e) => {
                                      setT1TotalDays(e.target.value);
                                      setDirty(true);
                                      setFeedback(null);
                                    }}
                                    placeholder="e.g. 105"
                                    className="w-full min-h-[42px] sm:min-h-[38px] px-2.5 py-1.5 bg-white border border-slate-300 rounded-lg font-mono tabular-nums focus:outline-none focus:border-[#1E3A5F]"
                                  />
                                </div>
                              </div>
                            </div>
                          ) : null
                        ) : (
                          /* Read-only Previously Entered Half-Yearly (Term I) Attendance Reference in Annual Exam */
                          <div className="bg-slate-50 border border-slate-200 rounded-lg p-3.5 space-y-2.5">
                            <div className="flex items-center justify-between gap-2 border-b border-slate-200 pb-2">
                              <span className="text-xs font-bold text-slate-700">
                                Previously Entered · Half-Yearly (Term I)
                              </span>
                              <span className="px-2 py-0.5 text-[10px] font-semibold bg-slate-200/80 text-slate-700 rounded">
                                Saved Record
                              </span>
                            </div>
                            <div className="grid grid-cols-2 gap-3 text-xs pt-1">
                              <div>
                                <div className="text-[11px] text-slate-500">Days Attended (Term I)</div>
                                <div className="mt-1 px-2.5 py-2 bg-white border border-slate-200 rounded-lg font-mono font-bold text-slate-900 tabular-nums">
                                  {t1DaysAttended.trim() || '—'}
                                </div>
                              </div>
                              <div>
                                <div className="text-[11px] text-slate-500">Total Days (Term I)</div>
                                <div className="mt-1 px-2.5 py-2 bg-white border border-slate-200 rounded-lg font-mono font-bold text-slate-900 tabular-nums">
                                  {t1TotalDays.trim() || '—'}
                                </div>
                              </div>
                            </div>
                          </div>
                        )}

                        {/* Term II (Annual / Final) Attendance Card — hidden when Half-Yearly (Term I) is selected */}
                        {activeTerm !== 1 && (
                          <div className="bg-cyan-50/35 border border-cyan-300 rounded-lg p-3.5 space-y-3">
                            <div className="flex flex-wrap items-center justify-between gap-2 border-b border-cyan-200 pb-2">
                              <span className="text-xs font-bold text-[#164E63]">
                                Annual / Final Exam (Term II) Attendance
                              </span>
                              <button
                                type="button"
                                disabled={bulkBusyTerm !== null}
                                onClick={() => handleBulkApplyTotalDays(2)}
                                title="Copy this Term II Total Days value to all students in the section"
                                className="text-[11px] font-semibold text-[#164E63] hover:underline disabled:opacity-50 cursor-pointer"
                              >
                                {bulkBusyTerm === 2 ? 'Applying...' : 'Apply Total Days to All'}
                              </button>
                            </div>
                            <div className="grid grid-cols-2 gap-3 text-xs">
                              <div>
                                <label className="block font-medium text-slate-700 mb-1">Days Attended</label>
                                <input
                                  type="number"
                                  min={0}
                                  max={366}
                                  value={t2DaysAttended}
                                  onChange={(e) => {
                                    setT2DaysAttended(e.target.value);
                                    setDirty(true);
                                    setFeedback(null);
                                  }}
                                  placeholder="e.g. 96"
                                  className="w-full min-h-[42px] sm:min-h-[38px] px-2.5 py-1.5 bg-white border border-slate-300 rounded-lg font-mono tabular-nums focus:outline-none focus:border-[#164E63]"
                                />
                              </div>
                              <div>
                                <label className="block font-medium text-slate-700 mb-1">Total Working Days</label>
                                <input
                                  type="number"
                                  min={0}
                                  max={366}
                                  value={t2TotalDays}
                                  onChange={(e) => {
                                    setT2TotalDays(e.target.value);
                                    setDirty(true);
                                    setFeedback(null);
                                  }}
                                  placeholder="e.g. 105"
                                  className="w-full min-h-[42px] sm:min-h-[38px] px-2.5 py-1.5 bg-white border border-slate-300 rounded-lg font-mono tabular-nums focus:outline-none focus:border-[#164E63]"
                                />
                              </div>
                            </div>
                          </div>
                        )}
                      </div>

                      {openSection !== 'all' && (
                        <div className="flex justify-end pt-1">
                          <button
                            type="button"
                            onClick={() => setOpenSection('coScholastic')}
                            className="inline-flex items-center gap-1.5 px-3.5 py-2 min-h-[38px] text-xs font-semibold text-[#1E3A5F] bg-sky-50 border border-sky-200 rounded-lg hover:bg-sky-100 cursor-pointer"
                          >
                            Next: Co-Scholastic Grades
                            <ChevronRight className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      )}
                    </div>
                  )}
                </div>

                {/* 2. HIGHLIGHTED DROPDOWN SECTION: CO-SCHOLASTIC & DISCIPLINE GRADES */}
                <div
                  className={`rounded-xl border transition-all overflow-hidden ${
                    isSectionOpen('coScholastic')
                      ? 'border-[#1E3A5F] bg-white ring-2 ring-[#1E3A5F]/15 shadow-xs'
                      : 'border-slate-200 bg-slate-50/70 hover:border-slate-300'
                  }`}
                >
                  <button
                    type="button"
                    onClick={() => toggleSection('coScholastic')}
                    className={`w-full px-4 py-3.5 flex items-center justify-between gap-3 text-left transition-colors cursor-pointer ${
                      isSectionOpen('coScholastic')
                        ? 'bg-[#1E3A5F] text-white'
                        : 'text-slate-900 hover:bg-slate-100/70'
                    }`}
                  >
                    <div className="flex items-center gap-2.5 min-w-0">
                      <span
                        className={`w-6 h-6 rounded-full text-xs font-bold flex items-center justify-center shrink-0 ${
                          isSectionOpen('coScholastic')
                            ? 'bg-white text-[#1E3A5F]'
                            : 'bg-[#1E3A5F]/10 text-[#1E3A5F]'
                        }`}
                      >
                        2
                      </span>
                      <Award className="w-4 h-4 shrink-0" />
                      <div className="min-w-0">
                        <div className="text-xs sm:text-sm font-bold truncate">
                          Co-Scholastic &amp; Discipline Grades
                          {activeTerm === 1
                            ? ' — Half-Yearly (Grade Term I)'
                            : activeTerm === 2
                              ? ' — Half-Yearly (Saved) + Final Exam (Grade Term II)'
                              : ' (View Only)'}
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center gap-2 shrink-0">
                      <span
                        className={`px-2 py-0.5 rounded text-[11px] font-mono font-semibold ${
                          isSectionOpen('coScholastic')
                            ? 'bg-white/20 text-white'
                            : 'bg-white border border-slate-200 text-slate-700'
                        }`}
                      >
                        {activeCoStatus}
                      </span>
                      <ChevronDown
                        className={`w-4 h-4 transition-transform ${
                          isSectionOpen('coScholastic') ? 'rotate-180' : ''
                        }`}
                      />
                    </div>
                  </button>

                  {isSectionOpen('coScholastic') && (
                    <div className="p-4 space-y-4 border-t border-slate-200 bg-white">
                      {activeTerm && (
                        <div className="flex flex-wrap items-center justify-between gap-2 pb-1">
                          <span className="text-xs text-slate-600">
                            {activeTerm === 1
                              ? 'Entering Grade Term I only (Term II opens during Annual/Final exam).'
                              : 'Saved Half-Yearly (Grade Term I) is shown alongside new Grade Term II entry.'}
                          </span>
                          <div className="flex flex-wrap items-center gap-1.5">
                            <button
                              type="button"
                              onClick={() => handleBulkFill('all_A')}
                              className="min-h-[34px] px-3 py-1 text-xs font-semibold rounded-lg border border-emerald-300 bg-emerald-50 text-emerald-800 hover:bg-emerald-100 cursor-pointer"
                            >
                              ALL (A)
                            </button>
                            <button
                              type="button"
                              onClick={() => handleBulkFill('all_B')}
                              className="min-h-[34px] px-3 py-1 text-xs font-semibold rounded-lg border border-sky-300 bg-sky-50 text-sky-800 hover:bg-sky-100 cursor-pointer"
                            >
                              ALL (B)
                            </button>
                            <button
                              type="button"
                              onClick={() => handleBulkFill('clear')}
                              className="min-h-[34px] inline-flex items-center gap-1 px-2.5 py-1 text-xs font-medium rounded-lg border border-slate-300 bg-white text-slate-700 hover:bg-slate-50 cursor-pointer"
                            >
                              <RotateCcw className="w-3 h-3" />
                              Clear
                            </button>
                          </div>
                        </div>
                      )}

                      {CO_SCHOLASTIC_SECTIONS.map((section) => (
                        <div key={section.id} className="border border-slate-300 rounded-lg overflow-hidden">
                          <div className="px-3.5 py-2 bg-slate-100 border-b border-slate-300 text-xs font-bold text-slate-900">
                            {section.title}
                          </div>

                          {/* Mobile Cards (<768px) */}
                          <div className="md:hidden divide-y divide-slate-200">
                            {section.items.map((item) => {
                              const t1Saved = selectedStudent.term1[item.key];
                              const t2Saved = selectedStudent.term2[item.key];
                              const t1Current =
                                activeTerm === 1
                                  ? isValidCoScholasticGrade(draftGrades[item.key])
                                    ? (draftGrades[item.key] as CoScholasticGradeValue)
                                    : undefined
                                  : t1Saved;
                              const t2Current =
                                activeTerm === 2
                                  ? isValidCoScholasticGrade(draftGrades[item.key])
                                    ? (draftGrades[item.key] as CoScholasticGradeValue)
                                    : undefined
                                  : t2Saved;

                              return (
                                <div key={item.key} className="p-3 space-y-2.5 text-xs">
                                  <div className="flex items-center justify-between gap-2">
                                    <span className="font-semibold text-slate-800">{item.label}</span>
                                    {activeTerm === 2 && (
                                      <span
                                        className={`px-2 py-0.5 text-[11px] font-mono font-bold rounded border ${getStaticGradeBadgeClass(
                                          t1Current
                                        )}`}
                                      >
                                        Term I: {t1Current || '—'}
                                      </span>
                                    )}
                                  </div>

                                  {activeTerm ? (
                                    <div className="grid grid-cols-3 gap-2">
                                      {GRADE_OPTIONS.map((g) => {
                                        const isActive = (activeTerm === 1 ? t1Current : t2Current) === g;
                                        return (
                                          <button
                                            key={g}
                                            type="button"
                                            onClick={() => handleSetGrade(item.key, isActive ? '' : g)}
                                            className={`min-h-[42px] text-xs font-mono font-bold rounded-lg border transition-colors cursor-pointer ${getGradeChipStyle(
                                              g,
                                              isActive
                                            )}`}
                                          >
                                            {g}
                                          </button>
                                        );
                                      })}
                                    </div>
                                  ) : (
                                    <div className="flex items-center gap-3 font-mono text-[11px]">
                                      <span>Term I: {t1Current || '—'}</span>
                                      <span>Term II: {t2Current || '—'}</span>
                                    </div>
                                  )}
                                </div>
                              );
                            })}
                          </div>

                          {/* Desktop Table (>=768px) */}
                          <div className="hidden md:block overflow-x-auto">
                            <table className="w-full text-xs">
                              <thead className="bg-slate-50 border-b border-slate-300 text-slate-700">
                                <tr>
                                  <th className="text-left font-bold px-3.5 py-2">{section.columnHeader}</th>
                                  <th className="text-center font-bold px-3 py-2 w-44 border-l border-slate-200">
                                    Grade Term I
                                    {activeTerm === 1 && (
                                      <span className="ml-1.5 px-1.5 py-0.5 text-[10px] font-semibold bg-emerald-100 text-emerald-800 rounded">
                                        Active
                                      </span>
                                    )}
                                    {activeTerm === 2 && (
                                      <span className="ml-1.5 px-1.5 py-0.5 text-[10px] font-medium bg-slate-200 text-slate-700 rounded">
                                        Saved
                                      </span>
                                    )}
                                  </th>
                                  {activeTerm !== 1 && (
                                    <th className="text-center font-bold px-3 py-2 w-44 border-l border-slate-200">
                                      Grade Term II
                                      {activeTerm === 2 && (
                                        <span className="ml-1.5 px-1.5 py-0.5 text-[10px] font-semibold bg-emerald-100 text-emerald-800 rounded">
                                          Active
                                        </span>
                                      )}
                                    </th>
                                  )}
                                </tr>
                              </thead>
                              <tbody className="divide-y divide-slate-200">
                                {section.items.map((item) => {
                                  const t1Saved = selectedStudent.term1[item.key];
                                  const t2Saved = selectedStudent.term2[item.key];
                                  const t1Current =
                                    activeTerm === 1
                                      ? isValidCoScholasticGrade(draftGrades[item.key])
                                        ? (draftGrades[item.key] as CoScholasticGradeValue)
                                        : undefined
                                      : t1Saved;
                                  const t2Current =
                                    activeTerm === 2
                                      ? isValidCoScholasticGrade(draftGrades[item.key])
                                        ? (draftGrades[item.key] as CoScholasticGradeValue)
                                        : undefined
                                      : t2Saved;

                                  return (
                                    <tr key={item.key} className="hover:bg-slate-50/70">
                                      <td className="px-3.5 py-2.5 font-medium text-slate-800">{item.label}</td>

                                      <td className="px-3 py-2 text-center border-l border-slate-200">
                                        {activeTerm === 1 ? (
                                          <div className="inline-flex items-center gap-1">
                                            {GRADE_OPTIONS.map((g) => (
                                              <button
                                                key={g}
                                                type="button"
                                                onClick={() => handleSetGrade(item.key, t1Current === g ? '' : g)}
                                                className={`min-w-[36px] h-8 px-2 text-xs font-mono font-bold rounded border transition-colors cursor-pointer ${getGradeChipStyle(
                                                  g,
                                                  t1Current === g
                                                )}`}
                                              >
                                                {g}
                                              </button>
                                            ))}
                                          </div>
                                        ) : (
                                          <span
                                            className={`inline-flex items-center justify-center min-w-[32px] px-2 py-0.5 text-xs font-mono font-bold rounded border ${getStaticGradeBadgeClass(
                                              t1Current
                                            )}`}
                                          >
                                            {t1Current || '—'}
                                          </span>
                                        )}
                                      </td>

                                      {activeTerm !== 1 && (
                                        <td className="px-3 py-2 text-center border-l border-slate-200">
                                          {activeTerm === 2 ? (
                                            <div className="inline-flex items-center gap-1">
                                              {GRADE_OPTIONS.map((g) => (
                                                <button
                                                  key={g}
                                                  type="button"
                                                  onClick={() => handleSetGrade(item.key, t2Current === g ? '' : g)}
                                                  className={`min-w-[36px] h-8 px-2 text-xs font-mono font-bold rounded border transition-colors cursor-pointer ${getGradeChipStyle(
                                                    g,
                                                    t2Current === g
                                                  )}`}
                                                >
                                                  {g}
                                                </button>
                                              ))}
                                            </div>
                                          ) : (
                                            <span
                                              className={`inline-flex items-center justify-center min-w-[32px] px-2 py-0.5 text-xs font-mono font-bold rounded border ${getStaticGradeBadgeClass(
                                                t2Current
                                              )}`}
                                            >
                                              {t2Current || '—'}
                                            </span>
                                          )}
                                        </td>
                                      )}
                                    </tr>
                                  );
                                })}
                              </tbody>
                            </table>
                          </div>
                        </div>
                      ))}

                      {openSection !== 'all' && (
                        <div className="flex items-center justify-between pt-1">
                          <button
                            type="button"
                            onClick={() => setOpenSection('attendance')}
                            className="inline-flex items-center gap-1.5 px-3 py-2 min-h-[38px] text-xs font-medium text-slate-700 bg-white border border-slate-300 rounded-lg hover:bg-slate-50 cursor-pointer"
                          >
                            <ChevronLeft className="w-3.5 h-3.5" />
                            Back to Attendance
                          </button>
                          <button
                            type="button"
                            onClick={() => setOpenSection('remarks')}
                            className="inline-flex items-center gap-1.5 px-3.5 py-2 min-h-[38px] text-xs font-semibold text-[#1E3A5F] bg-sky-50 border border-sky-200 rounded-lg hover:bg-sky-100 cursor-pointer"
                          >
                            Next: Remarks
                            <ChevronRight className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      )}
                    </div>
                  )}
                </div>

                {/* 3. HIGHLIGHTED DROPDOWN SECTION: REMARKS */}
                <div
                  className={`rounded-xl border transition-all overflow-hidden ${
                    isSectionOpen('remarks')
                      ? 'border-[#1E3A5F] bg-white ring-2 ring-[#1E3A5F]/15 shadow-xs'
                      : 'border-slate-200 bg-slate-50/70 hover:border-slate-300'
                  }`}
                >
                  <button
                    type="button"
                    onClick={() => toggleSection('remarks')}
                    className={`w-full px-4 py-3.5 flex items-center justify-between gap-3 text-left transition-colors cursor-pointer ${
                      isSectionOpen('remarks')
                        ? 'bg-[#1E3A5F] text-white'
                        : 'text-slate-900 hover:bg-slate-100/70'
                    }`}
                  >
                    <div className="flex items-center gap-2.5 min-w-0">
                      <span
                        className={`w-6 h-6 rounded-full text-xs font-bold flex items-center justify-center shrink-0 ${
                          isSectionOpen('remarks')
                            ? 'bg-white text-[#1E3A5F]'
                            : 'bg-[#1E3A5F]/10 text-[#1E3A5F]'
                        }`}
                      >
                        3
                      </span>
                      <MessageSquareText className="w-4 h-4 shrink-0" />
                      <div className="min-w-0">
                        <div className="text-xs sm:text-sm font-bold truncate">
                          Remarks
                          {activeTerm === 1
                            ? ' — Half-Yearly (Term I)'
                            : activeTerm === 2
                              ? ' — Term I (Saved) & Final Exam (Term II)'
                              : ' (Term I & Term II)'}
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center gap-2 shrink-0">
                      <span
                        className={`px-2 py-0.5 rounded text-[11px] font-mono font-semibold ${
                          isSectionOpen('remarks')
                            ? 'bg-white/20 text-white'
                            : 'bg-white border border-slate-200 text-slate-700'
                        }`}
                      >
                        {activeRemarksStatus}
                      </span>
                      <ChevronDown
                        className={`w-4 h-4 transition-transform ${
                          isSectionOpen('remarks') ? 'rotate-180' : ''
                        }`}
                      />
                    </div>
                  </button>

                  {isSectionOpen('remarks') && (
                    <div className="p-4 space-y-4 border-t border-slate-200 bg-white">
                      {activeTerm === 2 && (
                        <div className="flex justify-end">
                          <button
                            type="button"
                            onClick={() => setUnlockT1InFinal((prev) => !prev)}
                            className="inline-flex items-center gap-1 text-[11px] font-medium text-[#1E3A5F] hover:underline cursor-pointer"
                          >
                            <Pencil className="w-3 h-3" />
                            {unlockT1InFinal ? 'Lock Half-Yearly Remarks' : 'Edit Half-Yearly Remarks'}
                          </button>
                        </div>
                      )}

                      <div className={`grid grid-cols-1 ${activeTerm === 1 ? '' : 'md:grid-cols-2'} gap-4 text-xs`}>
                        {activeTerm !== 2 || unlockT1InFinal ? (
                          <div>
                            <label className="block font-bold text-[#1E3A5F] mb-1.5">
                              Remarks — 1st Term (Term I)
                            </label>
                            <textarea
                              rows={3}
                              maxLength={600}
                              value={t1Remarks}
                              onChange={(e) => {
                                setT1Remarks(e.target.value);
                                setDirty(true);
                                setFeedback(null);
                              }}
                              placeholder="Optional remarks for 1st Term report card..."
                              className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs focus:outline-none focus:border-[#1E3A5F]"
                            />
                          </div>
                        ) : (
                          <div className="bg-slate-50 border border-slate-200 rounded-lg p-3">
                            <div className="flex items-center justify-between gap-2 mb-1.5">
                              <span className="font-bold text-slate-700">Previously Entered · Term I Remarks</span>
                              <span className="px-2 py-0.5 text-[10px] font-semibold bg-slate-200/80 text-slate-700 rounded">
                                Saved Record
                              </span>
                            </div>
                            <p className="text-xs text-slate-800 whitespace-pre-wrap min-h-[54px] bg-white border border-slate-200 rounded p-2">
                              {t1Remarks.trim() || '—'}
                            </p>
                          </div>
                        )}

                        {activeTerm !== 1 && (
                          <div>
                            <label className="block font-bold text-[#164E63] mb-1.5">
                              Remarks — Annual / Final Term (Term II)
                            </label>
                            <textarea
                              rows={3}
                              maxLength={600}
                              value={t2Remarks}
                              onChange={(e) => {
                                setT2Remarks(e.target.value);
                                setDirty(true);
                                setFeedback(null);
                              }}
                              placeholder="Optional remarks for Annual / Final Term report card..."
                              className="w-full px-3 py-2 border border-cyan-300 rounded-lg text-xs focus:outline-none focus:border-[#164E63]"
                            />
                          </div>
                        )}
                      </div>

                      {openSection !== 'all' && (
                        <div className="flex justify-start pt-1">
                          <button
                            type="button"
                            onClick={() => setOpenSection('coScholastic')}
                            className="inline-flex items-center gap-1.5 px-3 py-2 min-h-[38px] text-xs font-medium text-slate-700 bg-white border border-slate-300 rounded-lg hover:bg-slate-50 cursor-pointer"
                          >
                            <ChevronLeft className="w-3.5 h-3.5" />
                            Back to Co-Scholastic
                          </button>
                        </div>
                      )}
                    </div>
                  )}
                </div>
              </div>

              {/* Action Footer */}
              <div className="px-4 sm:px-5 py-3.5 bg-slate-50 border-t border-slate-200 flex flex-wrap items-center justify-between gap-3">
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    disabled={selectedIndex <= 0 || saving}
                    onClick={() => selectStudent(sheet.students[selectedIndex - 1].studentId)}
                    className="inline-flex items-center gap-1 px-3 py-2 min-h-[40px] text-xs font-medium text-slate-700 bg-white border border-slate-300 rounded-lg hover:bg-slate-50 disabled:opacity-40 cursor-pointer"
                  >
                    <ChevronLeft className="w-3.5 h-3.5" />
                    Prev
                  </button>
                  <button
                    type="button"
                    disabled={selectedIndex < 0 || selectedIndex >= sheet.students.length - 1 || saving}
                    onClick={() => selectStudent(sheet.students[selectedIndex + 1].studentId)}
                    className="inline-flex items-center gap-1 px-3 py-2 min-h-[40px] text-xs font-medium text-slate-700 bg-white border border-slate-300 rounded-lg hover:bg-slate-50 disabled:opacity-40 cursor-pointer"
                  >
                    Next
                    <ChevronRight className="w-3.5 h-3.5" />
                  </button>
                </div>

                <div className="flex flex-wrap items-center gap-2">
                  <button
                    type="button"
                    disabled={saving}
                    onClick={() => handleSaveStudent(false)}
                    className="inline-flex items-center gap-1.5 px-3.5 py-2 min-h-[40px] text-xs font-semibold text-slate-800 bg-white border border-slate-300 rounded-lg hover:bg-slate-50 disabled:opacity-50 cursor-pointer"
                  >
                    <Save className="w-3.5 h-3.5" />
                    {saving ? 'Saving...' : activeTerm ? 'Save Student Record' : 'Save Attendance & Remarks'}
                  </button>
                  {selectedIndex >= 0 && selectedIndex < sheet.students.length - 1 && (
                    <button
                      type="button"
                      disabled={saving}
                      onClick={() => handleSaveStudent(true)}
                      className="inline-flex items-center gap-1.5 px-4 py-2 min-h-[40px] text-xs font-semibold text-white rounded-lg hover:opacity-95 disabled:opacity-50 cursor-pointer shadow-xs"
                      style={{ backgroundColor: 'var(--brand-primary, #1E3A5F)' }}
                    >
                      <Save className="w-3.5 h-3.5" />
                      Save &amp; Next Student
                    </button>
                  )}
                </div>
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
