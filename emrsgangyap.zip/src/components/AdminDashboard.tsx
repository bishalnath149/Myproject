import React, { useEffect, useRef, useState } from 'react';
import {
  Users,
  GraduationCap,
  BookOpen,
  Calendar,
  ClipboardCheck,
  AlertCircle,
  ArrowRight,
  Layers,
  CheckCircle2,
  Clock,
  Filter,
  RotateCcw,
} from 'lucide-react';
import type { AdminAnalyticsResponse, ExaminationRecord, SchoolInfo } from '../types';
import { apiFetch, extractErrorMessage, isAbortError } from '../lib/api';
import { AdminStudentsView } from './admin/AdminStudentsView';
import {
  AdminClassesSubjectsView,
  AdminTeacherAssignmentsView,
} from './admin/AdminAcademicView';
import { AdminTeachersView } from './admin/AdminTeachersView';
import {
  AdminExaminationsView,
  AdminMonitoringView,
} from './admin/AdminExamsAndMonitoringView';
import { AdminAuditLogsView, AdminSettingsView } from './admin/AdminSystemView';
import { ClassTeacherWorkspace } from './ClassTeacherWorkspace';
import { CHART_PALETTE, InteractiveBarChart, InteractiveDonutChart } from './admin/AdminAnalyticsCharts';

export type AdminSection =
  | 'overview'
  | 'students'
  | 'users'
  | 'classes-subjects'
  | 'teacher-assignments'
  | 'examinations'
  | 'monitoring'
  | 'results'
  | 'audit-logs'
  | 'settings'
  | string;

export function AdminDashboard({
  activeSection,
  onNavigate,
  schoolInfo,
  examinations,
  selectedAcademicYear,
  onSelectAcademicYear,
  onRefreshSchoolData,
}: {
  activeSection: AdminSection;
  onNavigate: (sec: AdminSection) => void;
  schoolInfo: SchoolInfo;
  examinations: ExaminationRecord[];
  selectedAcademicYear: string;
  onSelectAcademicYear: (year: string) => void;
  onRefreshSchoolData: (nextSelectedYear?: string) => Promise<void> | void;
}) {
  const [analytics, setAnalytics] = useState<AdminAnalyticsResponse | null>(null);
  const [loadingAnalytics, setLoadingAnalytics] = useState(false);
  const [analyticsError, setAnalyticsError] = useState<string | null>(null);
  const analyticsAbortRef = useRef<AbortController | null>(null);
  const analyticsSeqRef = useRef(0);

  const [filterExamId, setFilterExamId] = useState<string>('');
  const [filterClassId, setFilterClassId] = useState<string>('');
  const [filterSectionId, setFilterSectionId] = useState<string>('');
  const [filterSubjectId, setFilterSubjectId] = useState<string>('');

  const [resultSubTab, setResultSubTab] = useState<
    'consolidated' | 'students' | 'student-details' | 'co-scholastic' | 'analysis' | 'comparison'
  >('consolidated');

  const yearExams = examinations.filter((e) => e.academic_year === selectedAcademicYear);
  const selectedClassObj = schoolInfo.classes.find((c) => String(c.id) === filterClassId);
  const availableSections = selectedClassObj?.sections || [];

  // Unique subjects from active year exams or all exams
  const subjectFilterMap = new Map<number, string>();
  for (const ex of yearExams) {
    for (const sub of ex.subjects) {
      if (!subjectFilterMap.has(sub.subject_id)) {
        subjectFilterMap.set(sub.subject_id, sub.subject_name);
      }
    }
  }
  const availableSubjects = Array.from(subjectFilterMap.entries()).map(([id, name]) => ({ id, name }));

  const loadAnalytics = async () => {
    analyticsAbortRef.current?.abort();
    const controller = new AbortController();
    analyticsAbortRef.current = controller;
    const seq = ++analyticsSeqRef.current;

    setLoadingAnalytics(true);
    setAnalyticsError(null);
    const params = new URLSearchParams({ academicYear: selectedAcademicYear });
    if (filterExamId) params.set('examinationId', filterExamId);
    if (filterClassId) params.set('classId', filterClassId);
    if (filterSectionId) params.set('sectionId', filterSectionId);
    if (filterSubjectId) params.set('subjectId', filterSubjectId);

    try {
      const res = await apiFetch<AdminAnalyticsResponse>(`/api/admin/analytics?${params.toString()}`, {
        signal: controller.signal,
      });
      if (seq === analyticsSeqRef.current) {
        setAnalytics(res);
      }
    } catch (err: unknown) {
      if (isAbortError(err) || seq !== analyticsSeqRef.current) return;
      setAnalyticsError(extractErrorMessage(err, 'Failed to load dashboard analytics.'));
    } finally {
      if (seq === analyticsSeqRef.current) {
        setLoadingAnalytics(false);
      }
    }
  };

  useEffect(() => {
    if (activeSection === 'overview') {
      loadAnalytics();
    }
    return () => {
      analyticsAbortRef.current?.abort();
    };
  }, [activeSection, selectedAcademicYear, filterExamId, filterClassId, filterSectionId, filterSubjectId, examinations]);

  const allSectionOptions = schoolInfo.classes.flatMap((c) =>
    c.sections.map((s) => ({
      classId: c.id,
      className: c.name,
      hasSections: c.hasSections,
      sectionId: s.id,
      sectionName: s.name,
    }))
  );

  if (activeSection === 'students') {
    return (
      <AdminStudentsView
        schoolInfo={schoolInfo}
        examinations={examinations}
        selectedAcademicYear={selectedAcademicYear}
        onChanged={() => onRefreshSchoolData()}
      />
    );
  }
  if (activeSection === 'users') {
    return (
      <AdminTeachersView
        schoolInfo={schoolInfo}
        selectedAcademicYear={selectedAcademicYear}
        onChanged={() => onRefreshSchoolData()}
      />
    );
  }
  if (activeSection === 'classes-subjects') {
    return (
      <AdminClassesSubjectsView
        schoolInfo={schoolInfo}
        selectedAcademicYear={selectedAcademicYear}
        onChanged={() => onRefreshSchoolData()}
      />
    );
  }
  if (activeSection === 'teacher-assignments') {
    return (
      <AdminTeacherAssignmentsView
        schoolInfo={schoolInfo}
        selectedAcademicYear={selectedAcademicYear}
        onChanged={() => onRefreshSchoolData()}
      />
    );
  }
  if (activeSection === 'examinations') {
    return (
      <AdminExaminationsView
        schoolInfo={schoolInfo}
        examinations={examinations}
        selectedAcademicYear={selectedAcademicYear}
        onChanged={() => onRefreshSchoolData()}
      />
    );
  }
  if (activeSection === 'monitoring') {
    return (
      <AdminMonitoringView
        schoolInfo={schoolInfo}
        examinations={examinations}
        selectedAcademicYear={selectedAcademicYear}
        onChanged={() => onRefreshSchoolData()}
      />
    );
  }
  if (activeSection === 'results') {
    return (
      <ClassTeacherWorkspace
        title="Result Management, Reports & Analytics"
        allowedSections={allSectionOptions}
        examinations={examinations}
        schoolInfo={schoolInfo}
        selectedAcademicYear={selectedAcademicYear}
        activeTab={resultSubTab}
        onTabChange={(tab) => {
          if (tab !== 'promotion') setResultSubTab(tab);
        }}
        isAdminView={true}
      />
    );
  }
  if (activeSection === 'audit-logs') {
    return <AdminAuditLogsView />;
  }
  if (activeSection === 'settings') {
    return (
      <AdminSettingsView
        schoolInfo={schoolInfo}
        selectedAcademicYear={selectedAcademicYear}
        onSelectAcademicYear={(yr) => {
          onSelectAcademicYear(yr);
          onNavigate('overview');
        }}
        onSaved={onRefreshSchoolData}
      />
    );
  }

  // Custom configurable sections created by Admin
  const customSection = (schoolInfo.portalSections || []).find(
    (s) => s.custom && s.id === activeSection && s.enabled
  );
  if (customSection) {
    return (
      <div className="space-y-4 max-w-4xl">
        <div className="bg-white border border-slate-200 rounded-2xl p-6 space-y-3 shadow-xs">
          <div className="flex items-center justify-between gap-3 border-b border-slate-100 pb-3">
            <div>
              <h1 className="text-xl font-bold text-slate-900">
                {customSection.customHeading || customSection.label}
              </h1>
              {customSection.description && (
                <p className="text-xs text-slate-500 mt-0.5">{customSection.description}</p>
              )}
            </div>
            <button
              type="button"
              onClick={() => onNavigate('settings')}
              className="px-3 py-1.5 text-xs font-medium text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg"
            >
              Edit Section
            </button>
          </div>
          <div className="text-sm text-slate-700 whitespace-pre-line leading-relaxed">
            {customSection.customBody || 'No content added yet. Edit this section in Website & System Settings.'}
          </div>
        </div>
      </div>
    );
  }

  const isArchived = selectedAcademicYear !== schoolInfo.currentAcademicYear;
  const activeExamObj = yearExams.find((e) => e.id === analytics?.activeExaminationId);
  const summary = analytics?.summary;
  const charts = analytics?.charts;
  const primaryColor = schoolInfo.themeConfig?.primaryColor || '#1E3A5F';

  const summaryCards = [
    {
      label: 'Total Students',
      value: summary?.totalStudents ?? '—',
      icon: <GraduationCap className="w-4 h-4 text-blue-600" />,
      bg: 'bg-blue-50 border-blue-200/80',
      onClick: () => onNavigate('students'),
    },
    {
      label: 'Total Teachers',
      value: summary?.totalTeachers ?? '—',
      icon: <Users className="w-4 h-4 text-indigo-600" />,
      bg: 'bg-indigo-50 border-indigo-200/80',
      onClick: () => onNavigate('users'),
    },
    {
      label: 'Total Classes',
      value: summary?.totalClasses ?? '—',
      icon: <Layers className="w-4 h-4 text-violet-600" />,
      bg: 'bg-violet-50 border-violet-200/80',
      onClick: () => onNavigate('classes-subjects'),
    },
    {
      label: 'Total Sections',
      value: summary?.totalSections ?? '—',
      icon: <Layers className="w-4 h-4 text-cyan-600" />,
      bg: 'bg-cyan-50 border-cyan-200/80',
      onClick: () => onNavigate('classes-subjects'),
    },
    {
      label: 'Total Subjects',
      value: summary?.totalSubjects ?? '—',
      icon: <BookOpen className="w-4 h-4 text-teal-600" />,
      bg: 'bg-teal-50 border-teal-200/80',
      onClick: () => onNavigate('classes-subjects'),
    },
    {
      label: 'Total Examinations',
      value: summary?.totalExaminations ?? '—',
      icon: <Calendar className="w-4 h-4 text-sky-600" />,
      bg: 'bg-sky-50 border-sky-200/80',
      onClick: () => onNavigate('examinations'),
    },
    {
      label: 'Marks Entry Completed',
      value: summary?.marksCompleted ?? '—',
      icon: <CheckCircle2 className="w-4 h-4 text-emerald-600" />,
      bg: 'bg-emerald-50 border-emerald-200/80',
      onClick: () => onNavigate('monitoring'),
    },
    {
      label: 'Marks Entry Pending',
      value: summary?.marksPending ?? '—',
      icon: <Clock className="w-4 h-4 text-amber-600" />,
      bg: 'bg-amber-50 border-amber-200/80',
      onClick: () => onNavigate('monitoring'),
    },
  ];

  const resetFilters = () => {
    setFilterExamId('');
    setFilterClassId('');
    setFilterSectionId('');
    setFilterSubjectId('');
  };

  const hasFilters = Boolean(filterExamId || filterClassId || filterSectionId || filterSubjectId);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-4 border-b border-slate-200 pb-4">
        <div>
          <div className="flex items-center gap-2.5">
            <h1 className="text-xl font-bold text-slate-900 tracking-tight">
              {schoolInfo.schoolName} — Analytics Overview
            </h1>
            {isArchived && (
              <span className="px-2 py-0.5 text-[11px] font-semibold bg-amber-100 text-amber-900 border border-amber-200 rounded-md">
                Archived Record
              </span>
            )}
          </div>
          <p className="text-xs text-slate-500 mt-0.5">
            Academic Year {selectedAcademicYear}
            {activeExamObj ? ` · Examination: ${activeExamObj.name}` : ''}
          </p>
        </div>
        <div className="flex flex-wrap items-center gap-2 w-full sm:w-auto">
          <button
            type="button"
            onClick={() => onNavigate('monitoring')}
            className="min-h-[42px] sm:min-h-[36px] flex-1 sm:flex-none inline-flex items-center justify-center gap-1.5 px-3.5 py-2 text-xs font-medium text-slate-700 bg-white border border-slate-300 rounded-lg hover:bg-slate-50 cursor-pointer"
          >
            <ClipboardCheck className="w-3.5 h-3.5" style={{ color: primaryColor }} />
            Submission Monitor
          </button>
          <button
            type="button"
            onClick={() => onNavigate('results')}
            style={{ backgroundColor: primaryColor }}
            className="min-h-[42px] sm:min-h-[36px] flex-1 sm:flex-none inline-flex items-center justify-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-white rounded-lg hover:opacity-95 cursor-pointer"
          >
            Consolidated Results
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {analyticsError && (
        <div className="flex flex-wrap items-center justify-between gap-3 p-3.5 bg-red-50 border border-red-200 rounded-xl text-xs text-red-900">
          <span>{analyticsError}</span>
          <button
            type="button"
            onClick={loadAnalytics}
            className="min-h-[38px] px-3 py-1.5 font-semibold bg-red-800 text-white rounded-lg hover:bg-red-900 cursor-pointer"
          >
            Retry
          </button>
        </div>
      )}

      {/* Interactive Filters Bar */}
      <div className="bg-white border border-slate-200 rounded-2xl p-4 shadow-xs">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-2.5 items-center">
          <div className="flex items-center gap-1.5 text-xs font-semibold text-slate-700 sm:col-span-2 lg:col-span-5">
            <Filter className="w-3.5 h-3.5 text-sky-600" />
            <span>Filter Analytics</span>
            {loadingAnalytics && <span className="text-[11px] font-normal text-slate-400 ml-auto">Updating charts...</span>}
          </div>
          <select
            value={filterExamId || String(analytics?.activeExaminationId || '')}
            onChange={(e) => setFilterExamId(e.target.value)}
            className="w-full min-h-[42px] sm:min-h-[36px] px-3 py-1.5 text-xs border border-slate-300 rounded-lg bg-slate-50 text-slate-800 font-medium"
          >
            {yearExams.length === 0 && <option value="">No Examinations</option>}
            {yearExams.map((ex) => (
              <option key={ex.id} value={ex.id}>
                {ex.name} ({ex.status})
              </option>
            ))}
          </select>

          <select
            value={filterClassId}
            onChange={(e) => {
              setFilterClassId(e.target.value);
              setFilterSectionId('');
            }}
            className="w-full min-h-[42px] sm:min-h-[36px] px-3 py-1.5 text-xs border border-slate-300 rounded-lg bg-slate-50 text-slate-800 font-medium"
          >
            <option value="">All Classes</option>
            {schoolInfo.classes.map((c) => (
              <option key={c.id} value={c.id}>
                {c.name}
              </option>
            ))}
          </select>

          <select
            value={filterSectionId}
            onChange={(e) => setFilterSectionId(e.target.value)}
            disabled={!filterClassId || selectedClassObj?.hasSections === false}
            className="w-full min-h-[42px] sm:min-h-[36px] px-3 py-1.5 text-xs border border-slate-300 rounded-lg bg-slate-50 text-slate-800 font-medium disabled:opacity-50"
          >
            <option value="">
              {selectedClassObj?.hasSections === false ? 'No Sections' : 'All Sections'}
            </option>
            {selectedClassObj?.hasSections !== false &&
              availableSections.map((s) => (
                <option key={s.id} value={s.id}>
                  Section {s.name}
                </option>
              ))}
          </select>

          <select
            value={filterSubjectId}
            onChange={(e) => setFilterSubjectId(e.target.value)}
            className="w-full min-h-[42px] sm:min-h-[36px] px-3 py-1.5 text-xs border border-slate-300 rounded-lg bg-slate-50 text-slate-800 font-medium"
          >
            <option value="">All Subjects</option>
            {availableSubjects.map((sub) => (
              <option key={sub.id} value={sub.id}>
                {sub.name}
              </option>
            ))}
          </select>

          {hasFilters ? (
            <button
              type="button"
              onClick={resetFilters}
              className="min-h-[42px] sm:min-h-[36px] inline-flex items-center justify-center gap-1 px-3 py-1.5 text-xs font-medium text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg cursor-pointer"
            >
              <RotateCcw className="w-3 h-3" />
              Reset Filters
            </button>
          ) : (
            <div className="hidden lg:block" />
          )}
        </div>
      </div>

      {/* 8 Summary Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3.5">
        {summaryCards.map((card) => (
          <button
            key={card.label}
            type="button"
            onClick={card.onClick}
            className="text-left bg-white border border-slate-200 rounded-2xl p-4 hover:border-sky-400 hover:shadow-md transition-all cursor-pointer"
          >
            <div className="flex items-center justify-between gap-2">
              <span className="text-xs font-medium text-slate-500">{card.label}</span>
              <span className={`w-8 h-8 rounded-xl border flex items-center justify-center ${card.bg}`}>
                {card.icon}
              </span>
            </div>
            <div className="text-2xl font-bold font-mono tabular-nums text-slate-900 mt-2">
              {card.value}
            </div>
          </button>
        ))}
      </div>

      {/* Pending Correction Request Alert */}
      {(summary?.pendingCorrections ?? 0) > 0 && (
        <div className="flex items-center justify-between gap-3 p-3.5 bg-amber-50 border border-amber-200 rounded-xl text-xs text-amber-900">
          <div className="flex items-center gap-2">
            <AlertCircle className="w-4 h-4 text-amber-600 shrink-0" />
            <span>
              <span className="font-semibold">{summary?.pendingCorrections}</span> teacher mark correction
              request(s) awaiting approval.
            </span>
          </div>
          <button
            type="button"
            onClick={() => onNavigate('monitoring')}
            className="font-semibold underline whitespace-nowrap cursor-pointer"
          >
            Review Requests
          </button>
        </div>
      )}

      {/* 6 Colourful Interactive Pie / Doughnut Charts */}
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <h2 className="text-sm font-bold text-slate-900 uppercase tracking-wider">
            Distribution &amp; Completion Analytics
          </h2>
          <span className="text-[11px] text-slate-500">Hover or click segments to inspect / filter</span>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          <InteractiveDonutChart
            title="Class-Wise Student Distribution"
            subtitle="Click a class slice to filter analytics"
            variant="donut"
            centerLabel="Students"
            data={(charts?.classStudentDistribution || []).map((c, idx) => ({
              id: c.id,
              label: c.label,
              value: c.value,
              color: CHART_PALETTE[idx % CHART_PALETTE.length],
            }))}
            onSelectSlice={(slice) => {
              if (slice.id) {
                setFilterClassId(String(slice.id));
                setFilterSectionId('');
              }
            }}
          />

          <InteractiveDonutChart
            title="Section-Wise Student Distribution"
            subtitle="Active enrollment across class sections"
            variant="pie"
            data={(charts?.sectionStudentDistribution || []).map((s, idx) => ({
              id: s.sectionId,
              label: s.label,
              value: s.value,
              color: CHART_PALETTE[(idx + 2) % CHART_PALETTE.length],
            }))}
          />

          <InteractiveDonutChart
            title="Subject-Wise Marks Submission Status"
            subtitle="Completed marks entries by subject (click to filter)"
            variant="donut"
            centerLabel="Completed"
            data={(charts?.subjectMarksStatus || []).map((s, idx) => ({
              id: s.subjectId,
              label: s.subjectName,
              value: s.completed,
              color: CHART_PALETTE[idx % CHART_PALETTE.length],
            }))}
            onSelectSlice={(slice) => {
              if (slice.id) setFilterSubjectId(String(slice.id));
            }}
          />

          <InteractiveDonutChart
            title="Completed vs. Pending Marks Entry"
            subtitle="Overall submission progress for selected examination"
            variant="donut"
            centerLabel="Entries"
            data={[
              {
                label: 'Completed',
                value: charts?.completedVsPending.find((x) => x.label === 'Completed')?.value || 0,
                color: '#10B981',
              },
              {
                label: 'Pending',
                value: charts?.completedVsPending.find((x) => x.label === 'Pending')?.value || 0,
                color: '#F59E0B',
              },
            ]}
          />

          <InteractiveDonutChart
            title="Examination Participation"
            subtitle="Present, Absent, and Pending student entries"
            variant="pie"
            data={[
              {
                label: 'Present',
                value: charts?.examParticipation.find((x) => x.label === 'Present')?.value || 0,
                color: '#2563EB',
              },
              {
                label: 'Absent',
                value: charts?.examParticipation.find((x) => x.label === 'Absent')?.value || 0,
                color: '#EF4444',
              },
              {
                label: 'Pending',
                value: charts?.examParticipation.find((x) => x.label === 'Pending')?.value || 0,
                color: '#94A3B8',
              },
            ]}
          />

          <InteractiveDonutChart
            title="Class-Wise Examination Performance"
            subtitle="Average percentage share across evaluated classes"
            variant="donut"
            valueUnit="%"
            centerLabel="Avg %"
            data={(charts?.classExamPerformance || []).map((c, idx) => ({
              id: c.classId,
              label: c.className,
              value: c.averagePct,
              color: CHART_PALETTE[(idx + 4) % CHART_PALETTE.length],
            }))}
            onSelectSlice={(slice) => {
              if (slice.id) {
                setFilterClassId(String(slice.id));
                setFilterSectionId('');
              }
            }}
          />
        </div>
      </div>

      {/* 4 Colourful Interactive Bar Charts */}
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <h2 className="text-sm font-bold text-slate-900 uppercase tracking-wider">
            Performance &amp; Comparison Charts
          </h2>
          <span className="text-[11px] text-slate-500">Computed from recorded marks</span>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          <InteractiveBarChart
            title="Class-Wise Average Performance"
            subtitle="Average percentage & pass rate per class"
            items={(charts?.classExamPerformance || []).map((c, idx) => ({
              id: c.classId,
              label: c.className,
              value: c.averagePct,
              sublabel: `${c.passRate}% pass · ${c.evaluatedCount} students`,
              color: CHART_PALETTE[idx % CHART_PALETTE.length],
            }))}
            onSelectBar={(item) => {
              if (item.id) {
                setFilterClassId(String(item.id));
                setFilterSectionId('');
              }
            }}
          />

          <InteractiveBarChart
            title="Subject-Wise Average Marks"
            subtitle="Average percentage & marks per subject"
            items={(charts?.subjectAverageMarks || []).map((s, idx) => ({
              id: s.subjectId,
              label: s.subjectName,
              value: s.averagePct,
              sublabel: `${s.averageMarks}/${s.maxMarks} avg`,
              color: CHART_PALETTE[(idx + 1) % CHART_PALETTE.length],
            }))}
            onSelectBar={(item) => {
              if (item.id) setFilterSubjectId(String(item.id));
            }}
          />

          <InteractiveBarChart
            title="Section-Wise Comparison"
            subtitle="Performance comparison across sections"
            items={(charts?.sectionComparison || []).map((s, idx) => ({
              id: s.sectionId,
              label: s.label,
              value: s.averagePct,
              sublabel: `${s.passRate}% pass`,
              color: CHART_PALETTE[(idx + 3) % CHART_PALETTE.length],
            }))}
          />

          <InteractiveBarChart
            title="Examination-Wise Performance Comparison"
            subtitle="Click an examination bar to inspect its analytics"
            items={(charts?.examComparison || []).map((ex, idx) => ({
              id: ex.examinationId,
              label: ex.examinationName,
              value: ex.averagePct,
              sublabel: `${ex.status} · ${ex.passRate}% pass`,
              color: CHART_PALETTE[(idx + 5) % CHART_PALETTE.length],
            }))}
            onSelectBar={(item) => {
              if (item.id) setFilterExamId(String(item.id));
            }}
          />
        </div>
      </div>
    </div>
  );
}
