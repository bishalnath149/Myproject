import React, { useEffect, useMemo, useRef, useState } from 'react';
import {
  Save,
  Send,
  RotateCcw,
  RefreshCw,
  Lock,
  AlertCircle,
  CheckCircle2,
  ClipboardList,
  History,
  FileWarning,
  FileSpreadsheet,
} from 'lucide-react';
import type {
  AttendanceStatus,
  ComponentMode,
  ExaminationRecord,
  TeacherExcelExportPayload,
} from '../types';
import { apiFetch, extractErrorMessage, isAbortError } from '../lib/api';
import { calculateSubjectGrade, formatClassSectionLabel, getGradeBadgeClass } from '../lib/grading';
import { exportTeacherMarksExcel } from '../lib/exports';
import { SubmissionStatusLabel } from './StatusIndicator';

interface AssignedItem {
  id: number;
  subject_id: number;
  subject_name: string;
  subject_code: string;
  has_components: number;
  component_mode?: ComponentMode;
  component_id: number;
  component_name: string;
  component_code: string;
  class_id: number;
  class_name: string;
  has_sections?: number | boolean;
  section_id: number;
  section_name: string;
  academic_year: string;
}

interface MarksSheetStudent {
  studentId: number;
  studentCode: string;
  fullName: string;
  rollNumber: number;
  obtainedMarks: number | null;
  attendanceStatus: AttendanceStatus;
  status: 'submitted' | 'draft' | 'pending';
  isRowLocked: boolean;
  submittedAt: string | null;
  updatedAt: string | null;
  otherComponentsMarks?: number | null;
  otherComponentsMax?: number;
  otherComponentsComplete?: boolean;
  otherComponentsAbsent?: boolean;
  iaNotebookMarks: number | null;
  iaUnitTestMarks: number | null;
  iaPracticalMarks: number | null;
  iaParticipationMarks: number | null;
  nbStatus: 'submitted' | 'draft' | 'pending';
  utStatus: 'submitted' | 'draft' | 'pending';
  prStatus: 'submitted' | 'draft' | 'pending';
  opStatus: 'submitted' | 'draft' | 'pending';
  iaStatus: 'submitted' | 'draft' | 'pending';
}

interface InternalAssessmentContext {
  enabled: boolean;
  canEditIa: boolean;
  iaPermissions: {
    notebook: boolean;
    unit_test: boolean;
    practical: boolean;
    participation: boolean;
  };
  iaLocked: boolean;
  iaAlreadySubmitted: boolean;
  submittedByName: string | null;
  notebookMax: number;
  unitTestMax: number;
  practicalMax: number;
  participationMax: number;
  totalIaMax: number;
  subjectTotalMax: number;
}

interface MarksSheetResponse {
  examination: {
    id: number;
    name: string;
    academicYear: string;
    status: string;
    marksEntryOpen: boolean;
  };
  context: {
    classId: number;
    className: string;
    hasSections?: boolean;
    sectionId: number;
    sectionName: string;
    subjectId: number;
    subjectName: string;
    hasComponents: boolean;
    componentMode?: ComponentMode;
    filteredByElective?: boolean;
    componentId: number;
    examComponentId: number;
    componentName: string;
    maxMarks: number;
    passingMarks: number;
  };
  isLocked: boolean;
  anySubmitted: boolean;
  allSubmitted: boolean;
  examWindowOpen: boolean;
  latestCorrectionRequest: { id: number; reason: string; status: string; created_at: string } | null;
  internalAssessment: InternalAssessmentContext;
  students: MarksSheetStudent[];
}

interface SubmissionHistoryRow {
  examination_id: number;
  examination_name: string;
  class_id: number;
  class_name: string;
  has_sections?: number | boolean;
  section_id: number;
  section_name: string;
  subject_name: string;
  component_name: string;
  max_marks: number;
  entered_count: number;
  submitted_count: number;
  total_students: number;
  last_updated_at: string | null;
  submitted_at: string | null;
}

interface IaDraftEntry {
  nb: string;
  ut: string;
  pr: string;
  op: string;
}

export function TeacherMarksWorkspace({
  assignments,
  examinations,
  activeSubTab,
  onSubTabChange,
}: {
  assignments: AssignedItem[];
  examinations: ExaminationRecord[];
  activeSubTab: 'entry' | 'assignments' | 'history';
  onSubTabChange: (tab: 'entry' | 'assignments' | 'history') => void;
}) {
  const [selectedAssignmentId, setSelectedAssignmentId] = useState<number>(assignments[0]?.id || 0);
  const [selectedExamId, setSelectedExamId] = useState<number>(() => {
    const active = examinations.find((e) => e.status === 'Active' && e.marksEntryOpen);
    return active?.id || examinations[0]?.id || 0;
  });

  const [sheet, setSheet] = useState<MarksSheetResponse | null>(null);
  const [draftInputs, setDraftInputs] = useState<Record<number, string>>({});
  const [attendanceDrafts, setAttendanceDrafts] = useState<Record<number, AttendanceStatus>>({});
  const [iaDraftInputs, setIaDraftInputs] = useState<Record<number, IaDraftEntry>>({});
  const [loadingSheet, setLoadingSheet] = useState(false);
  const [saving, setSaving] = useState(false);
  const [exporting, setExporting] = useState<'single' | 'all' | null>(null);
  const [feedback, setFeedback] = useState<{ type: 'success' | 'error'; text: string } | null>(null);
  const [confirmSubmitOpen, setConfirmSubmitOpen] = useState(false);
  const [correctionModalOpen, setCorrectionModalOpen] = useState(false);
  const [correctionReason, setCorrectionReason] = useState('');
  const [historyRows, setHistoryRows] = useState<SubmissionHistoryRow[]>([]);
  const [loadingHistory, setLoadingHistory] = useState(false);
  const [historyError, setHistoryError] = useState<string | null>(null);

  const sheetSeqRef = useRef(0);
  const sheetAbortRef = useRef<AbortController | null>(null);
  const historySeqRef = useRef(0);
  const historyAbortRef = useRef<AbortController | null>(null);
  const topScrollRef = useRef<HTMLDivElement | null>(null);
  const tableScrollRef = useRef<HTMLDivElement | null>(null);
  const tableRef = useRef<HTMLTableElement | null>(null);
  const syncingScrollRef = useRef<'top' | 'table' | null>(null);
  const [tableScrollWidth, setTableScrollWidth] = useState(0);
  const [hasHorizontalOverflow, setHasHorizontalOverflow] = useState(false);

  useEffect(() => {
    return () => {
      sheetAbortRef.current?.abort();
      historyAbortRef.current?.abort();
    };
  }, []);

  useEffect(() => {
    const container = tableScrollRef.current;
    const table = tableRef.current;
    if (!container || !table) {
      setHasHorizontalOverflow(false);
      return;
    }
    const measure = () => {
      const sw = table.scrollWidth;
      const cw = container.clientWidth;
      setTableScrollWidth(sw);
      setHasHorizontalOverflow(sw > cw + 2);
    };
    measure();
    const ro = new ResizeObserver(measure);
    ro.observe(container);
    ro.observe(table);
    return () => ro.disconnect();
  }, [sheet, activeSubTab]);

  const handleTopScroll = () => {
    if (syncingScrollRef.current === 'table') return;
    if (!topScrollRef.current || !tableScrollRef.current) return;
    syncingScrollRef.current = 'top';
    tableScrollRef.current.scrollLeft = topScrollRef.current.scrollLeft;
    requestAnimationFrame(() => {
      if (syncingScrollRef.current === 'top') syncingScrollRef.current = null;
    });
  };

  const handleTableScroll = () => {
    if (syncingScrollRef.current === 'top') return;
    if (!topScrollRef.current || !tableScrollRef.current) return;
    syncingScrollRef.current = 'table';
    topScrollRef.current.scrollLeft = tableScrollRef.current.scrollLeft;
    requestAnimationFrame(() => {
      if (syncingScrollRef.current === 'table') syncingScrollRef.current = null;
    });
  };

  const selectedAssignment = useMemo(
    () => assignments.find((a) => a.id === selectedAssignmentId) || assignments[0] || null,
    [assignments, selectedAssignmentId]
  );

  useEffect(() => {
    if (assignments.length === 0) {
      if (selectedAssignmentId !== 0) setSelectedAssignmentId(0);
      return;
    }
    if (!assignments.some((a) => a.id === selectedAssignmentId)) {
      setSelectedAssignmentId(assignments[0].id);
    }
  }, [assignments, selectedAssignmentId]);

  useEffect(() => {
    if (examinations.length === 0) {
      if (selectedExamId !== 0) setSelectedExamId(0);
      return;
    }
    if (!examinations.some((e) => e.id === selectedExamId)) {
      const active = examinations.find((e) => e.status === 'Active' && e.marksEntryOpen);
      setSelectedExamId(active?.id || examinations[0].id);
    }
  }, [examinations, selectedExamId]);

  const loadMarksSheet = async (assign: AssignedItem | null, examId: number) => {
    sheetAbortRef.current?.abort();
    if (!assign || !examId) {
      setSheet(null);
      return;
    }
    const controller = new AbortController();
    sheetAbortRef.current = controller;
    const seq = ++sheetSeqRef.current;

    setLoadingSheet(true);
    setFeedback(null);
    try {
      const data = await apiFetch<MarksSheetResponse>(
        `/api/teacher/marks-sheet?examinationId=${examId}&classId=${assign.class_id}&sectionId=${assign.section_id}&componentId=${assign.component_id}`,
        { signal: controller.signal }
      );
      if (seq !== sheetSeqRef.current) return;
      setSheet(data);
      const map: Record<number, string> = {};
      const attMap: Record<number, AttendanceStatus> = {};
      const iaMap: Record<number, IaDraftEntry> = {};
      for (const st of data.students) {
        attMap[st.studentId] = st.attendanceStatus || (st.obtainedMarks !== null ? 'present' : 'pending');
        map[st.studentId] =
          st.attendanceStatus === 'absent' || st.obtainedMarks === null || st.obtainedMarks === undefined
            ? ''
            : String(st.obtainedMarks);
        iaMap[st.studentId] = {
          nb: st.iaNotebookMarks !== null && st.iaNotebookMarks !== undefined ? String(st.iaNotebookMarks) : '',
          ut: st.iaUnitTestMarks !== null && st.iaUnitTestMarks !== undefined ? String(st.iaUnitTestMarks) : '',
          pr: st.iaPracticalMarks !== null && st.iaPracticalMarks !== undefined ? String(st.iaPracticalMarks) : '',
          op:
            st.iaParticipationMarks !== null && st.iaParticipationMarks !== undefined
              ? String(st.iaParticipationMarks)
              : '',
        };
      }
      setDraftInputs(map);
      setAttendanceDrafts(attMap);
      setIaDraftInputs(iaMap);
    } catch (err: unknown) {
      if (isAbortError(err) || seq !== sheetSeqRef.current) return;
      setSheet(null);
      setFeedback({ type: 'error', text: extractErrorMessage(err, 'Could not load marks sheet.') });
    } finally {
      if (seq === sheetSeqRef.current) {
        setLoadingSheet(false);
      }
    }
  };

  useEffect(() => {
    if (activeSubTab === 'entry') {
      loadMarksSheet(selectedAssignment, selectedExamId);
    }
  }, [selectedAssignment?.id, selectedExamId, activeSubTab]);

  const loadHistory = async () => {
    historyAbortRef.current?.abort();
    const controller = new AbortController();
    historyAbortRef.current = controller;
    const seq = ++historySeqRef.current;

    setLoadingHistory(true);
    setHistoryError(null);
    try {
      const data = await apiFetch<SubmissionHistoryRow[]>('/api/teacher/submission-history', {
        signal: controller.signal,
      });
      if (seq !== historySeqRef.current) return;
      setHistoryRows(data);
    } catch (err: unknown) {
      if (isAbortError(err) || seq !== historySeqRef.current) return;
      setHistoryError(extractErrorMessage(err, 'Failed to load submission history.'));
    } finally {
      if (seq === historySeqRef.current) {
        setLoadingHistory(false);
      }
    }
  };

  useEffect(() => {
    if (activeSubTab === 'history') {
      loadHistory();
    }
  }, [activeSubTab]);

  const validationState = useMemo(() => {
    if (!sheet) {
      return {
        invalidIds: new Set<number>(),
        maxExternalAllowed: 100,
        maxIaAllowed: 0,
        presentCount: 0,
        absentCount: 0,
        pendingCount: 0,
        invalidIaMap: new Map<number, { nb: boolean; ut: boolean; pr: boolean; op: boolean }>(),
        invalidIaTotalIds: new Set<number>(),
      };
    }
    const invalidIds = new Set<number>();
    const invalidIaMap = new Map<number, { nb: boolean; ut: boolean; pr: boolean; op: boolean }>();
    const invalidIaTotalIds = new Set<number>();
    let presentCount = 0;
    let absentCount = 0;
    let pendingCount = 0;

    const ia = sheet.internalAssessment;
    const maxExternalAllowed = sheet.context.maxMarks;
    const maxIaAllowed = ia ? ia.totalIaMax : 0;

    for (const st of sheet.students) {
      const att = attendanceDrafts[st.studentId] || 'pending';
      const raw = (draftInputs[st.studentId] ?? '').trim();

      if (att === 'absent') {
        absentCount++;
      } else if (raw === '') {
        pendingCount++;
      } else {
        const num = Number(raw);
        if (Number.isNaN(num) || num < 0 || num > maxExternalAllowed) {
          invalidIds.add(st.studentId);
        } else {
          presentCount++;
        }
      }

      if (ia?.enabled && ia.canEditIa) {
        const iaRaw = iaDraftInputs[st.studentId] || { nb: '', ut: '', pr: '', op: '' };
        const nbStr = iaRaw.nb.trim();
        const utStr = iaRaw.ut.trim();
        const prStr = iaRaw.pr.trim();
        const opStr = iaRaw.op.trim();
        const nbBad =
          ia.notebookMax > 0 &&
          ia.iaPermissions.notebook &&
          nbStr !== '' &&
          (Number.isNaN(Number(nbStr)) || Number(nbStr) < 0 || Number(nbStr) > ia.notebookMax);
        const utBad =
          ia.unitTestMax > 0 &&
          ia.iaPermissions.unit_test &&
          utStr !== '' &&
          (Number.isNaN(Number(utStr)) || Number(utStr) < 0 || Number(utStr) > ia.unitTestMax);
        const prBad =
          ia.practicalMax > 0 &&
          ia.iaPermissions.practical &&
          prStr !== '' &&
          (Number.isNaN(Number(prStr)) || Number(prStr) < 0 || Number(prStr) > ia.practicalMax);
        const opBad =
          ia.participationMax > 0 &&
          ia.iaPermissions.participation &&
          opStr !== '' &&
          (Number.isNaN(Number(opStr)) || Number(opStr) < 0 || Number(opStr) > ia.participationMax);
        if (nbBad || utBad || prBad || opBad) {
          invalidIaMap.set(st.studentId, { nb: nbBad, ut: utBad, pr: prBad, op: opBad });
        } else {
          const nbVal = nbStr === '' ? 0 : Number(nbStr);
          const utVal = utStr === '' ? 0 : Number(utStr);
          const prVal = prStr === '' ? 0 : Number(prStr);
          const opVal = opStr === '' ? 0 : Number(opStr);
          if (nbVal + utVal + prVal + opVal > maxIaAllowed) {
            invalidIaTotalIds.add(st.studentId);
          }
        }
      }
    }
    return {
      invalidIds,
      maxExternalAllowed,
      maxIaAllowed,
      presentCount,
      absentCount,
      pendingCount,
      invalidIaMap,
      invalidIaTotalIds,
    };
  }, [sheet, draftInputs, attendanceDrafts, iaDraftInputs]);

  const handleInputChange = (studentId: number, value: string) => {
    setDraftInputs((prev) => ({ ...prev, [studentId]: value }));
    setAttendanceDrafts((prev) => ({
      ...prev,
      [studentId]: value.trim() === '' ? 'pending' : 'present',
    }));
    setFeedback(null);
  };

  const handleAttendanceChange = (studentId: number, status: AttendanceStatus) => {
    setAttendanceDrafts((prev) => ({ ...prev, [studentId]: status }));
    if (status === 'absent' || status === 'pending') {
      setDraftInputs((prev) => ({ ...prev, [studentId]: '' }));
    }
    setFeedback(null);
  };

  const handleIaInputChange = (studentId: number, field: keyof IaDraftEntry, value: string) => {
    setIaDraftInputs((prev) => ({
      ...prev,
      [studentId]: {
        ...(prev[studentId] || { nb: '', ut: '', pr: '', op: '' }),
        [field]: value,
      },
    }));
    setFeedback(null);
  };

  const handleClearEntries = () => {
    if (!sheet || sheet.isLocked || !sheet.examWindowOpen) return;
    setDraftInputs((prev) => {
      const next = { ...prev };
      for (const st of sheet.students) {
        if (!st.isRowLocked) next[st.studentId] = '';
      }
      return next;
    });
    setAttendanceDrafts((prev) => {
      const next = { ...prev };
      for (const st of sheet.students) {
        if (!st.isRowLocked) next[st.studentId] = 'pending';
      }
      return next;
    });
    if (sheet.internalAssessment.enabled && sheet.internalAssessment.canEditIa) {
      const perms = sheet.internalAssessment.iaPermissions;
      setIaDraftInputs((prev) => {
        const next = { ...prev };
        for (const st of sheet.students) {
          const cur = next[st.studentId] || { nb: '', ut: '', pr: '', op: '' };
          next[st.studentId] = {
            nb: perms.notebook && st.nbStatus !== 'submitted' ? '' : cur.nb,
            ut: perms.unit_test && st.utStatus !== 'submitted' ? '' : cur.ut,
            pr: perms.practical && st.prStatus !== 'submitted' ? '' : cur.pr,
            op: perms.participation && st.opStatus !== 'submitted' ? '' : cur.op,
          };
        }
        return next;
      });
    }
    setFeedback(null);
  };

  const handleDownloadExcel = async (scope: 'single' | 'all') => {
    const examId = sheet?.examination.id || selectedExamId;
    if (!examId) {
      setFeedback({ type: 'error', text: 'Please select an examination first.' });
      return;
    }
    if (scope === 'single' && !selectedAssignment) {
      setFeedback({ type: 'error', text: 'Please select a subject assignment to export.' });
      return;
    }
    setExporting(scope);
    setFeedback(null);
    try {
      const qs = new URLSearchParams({ examinationId: String(examId), scope });
      if (scope === 'single' && selectedAssignment) {
        qs.set('classId', String(selectedAssignment.class_id));
        qs.set('sectionId', String(selectedAssignment.section_id));
        qs.set('componentId', String(selectedAssignment.component_id));
      }
      const payload = await apiFetch<TeacherExcelExportPayload>(`/api/teacher/marks-export?${qs.toString()}`);
      if (!payload.sheets || payload.sheets.length === 0) {
        setFeedback({ type: 'error', text: 'No marks sheets found for the selected examination.' });
        return;
      }
      const filename = await exportTeacherMarksExcel(payload);
      setFeedback({ type: 'success', text: `Downloaded Excel marksheet: ${filename}` });
    } catch (err: unknown) {
      setFeedback({ type: 'error', text: extractErrorMessage(err, 'Failed to export marks to Excel.') });
    } finally {
      setExporting(null);
    }
  };

  const handleOpenSubmit = () => {
    if (!sheet) return;
    if (validationState.invalidIds.size > 0) {
      setFeedback({
        type: 'error',
        text: `Please correct ${validationState.invalidIds.size} invalid external mark(s) (0–${validationState.maxExternalAllowed}).`,
      });
      return;
    }
    if (validationState.invalidIaMap.size > 0 || validationState.invalidIaTotalIds.size > 0) {
      setFeedback({
        type: 'error',
        text: `Please correct Internal Assessment marks (individual limits and total max ${validationState.maxIaAllowed}).`,
      });
      return;
    }
    setConfirmSubmitOpen(true);
  };

  const saveMarks = async (mode: 'draft' | 'submit') => {
    if (!sheet || !selectedAssignment) return;
    if (validationState.invalidIds.size > 0) {
      setFeedback({
        type: 'error',
        text: `Please correct ${validationState.invalidIds.size} invalid external mark(s) (0–${validationState.maxExternalAllowed}).`,
      });
      return;
    }
    if (validationState.invalidIaMap.size > 0 || validationState.invalidIaTotalIds.size > 0) {
      setFeedback({
        type: 'error',
        text: `Please correct Internal Assessment marks (total IA cannot exceed ${validationState.maxIaAllowed}).`,
      });
      return;
    }

    setSaving(true);
    setFeedback(null);
    try {
      const entries = sheet.students.map((st) => {
        const att = attendanceDrafts[st.studentId] || 'pending';
        const raw = (draftInputs[st.studentId] ?? '').trim();
        if (att === 'absent') {
          return { studentId: st.studentId, attendanceStatus: 'absent' as AttendanceStatus, obtainedMarks: null };
        }
        if (raw === '') {
          return { studentId: st.studentId, attendanceStatus: 'pending' as AttendanceStatus, obtainedMarks: null };
        }
        return {
          studentId: st.studentId,
          attendanceStatus: 'present' as AttendanceStatus,
          obtainedMarks: Number(raw),
        };
      });

      const iaEntries =
        sheet.internalAssessment.enabled && sheet.internalAssessment.canEditIa
          ? sheet.students.map((st) => {
              const iaRaw = iaDraftInputs[st.studentId] || { nb: '', ut: '', pr: '', op: '' };
              return {
                studentId: st.studentId,
                notebookMarks: iaRaw.nb.trim() === '' ? null : Number(iaRaw.nb.trim()),
                unitTestMarks: iaRaw.ut.trim() === '' ? null : Number(iaRaw.ut.trim()),
                practicalMarks: iaRaw.pr.trim() === '' ? null : Number(iaRaw.pr.trim()),
                participationMarks: iaRaw.op.trim() === '' ? null : Number(iaRaw.op.trim()),
              };
            })
          : undefined;

      await apiFetch('/api/teacher/marks-save', {
        method: 'POST',
        body: JSON.stringify({
          examinationId: sheet.examination.id,
          classId: sheet.context.classId,
          sectionId: sheet.context.sectionId,
          componentId: sheet.context.componentId,
          mode,
          entries,
          iaEntries,
        }),
      });

      setConfirmSubmitOpen(false);
      await loadMarksSheet(selectedAssignment, selectedExamId);
      setFeedback({
        type: 'success',
        text:
          mode === 'submit'
            ? 'Entered marks submitted successfully.'
            : 'Draft marks saved successfully.',
      });
    } catch (err: any) {
      setFeedback({ type: 'error', text: err.message || 'Failed to save marks.' });
    } finally {
      setSaving(false);
    }
  };

  const submitCorrectionRequest = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!sheet) return;
    setSaving(true);
    try {
      await apiFetch('/api/teacher/correction-request', {
        method: 'POST',
        body: JSON.stringify({
          examinationId: sheet.examination.id,
          examComponentId: sheet.context.examComponentId,
          classId: sheet.context.classId,
          sectionId: sheet.context.sectionId,
          reason: correctionReason,
        }),
      });
      setCorrectionModalOpen(false);
      setCorrectionReason('');
      await loadMarksSheet(selectedAssignment, selectedExamId);
      setFeedback({
        type: 'success',
        text: 'Correction request sent to Administrator.',
      });
    } catch (err: any) {
      setFeedback({ type: 'error', text: err.message || 'Failed to submit request.' });
    } finally {
      setSaving(false);
    }
  };

  const ia = sheet?.internalAssessment;
  const showIaCols = Boolean(ia?.enabled);
  const showNb = Boolean(ia?.enabled && ia.notebookMax > 0);
  const showUt = Boolean(ia?.enabled && ia.unitTestMax > 0);
  const showPr = Boolean(ia?.enabled && ia.practicalMax > 0);
  const showOp = Boolean(ia?.enabled && ia.participationMax > 0);
  const canInteractSheet = Boolean(sheet && sheet.examWindowOpen && !sheet.isLocked);

  return (
    <div className="space-y-6">
      {/* Sub-navigation bar */}
      <div className="flex flex-wrap items-center justify-between gap-3 sm:gap-4 border-b border-slate-200 pb-4">
        <div>
          <h1 className="text-xl font-bold text-slate-900 tracking-tight">Marks Entry Portal</h1>
        </div>
        <div className="flex flex-wrap items-center gap-1 p-1 bg-slate-100 rounded-xl border border-slate-200 w-full sm:w-auto">
          <button
            type="button"
            onClick={() => onSubTabChange('entry')}
            className={`inline-flex items-center justify-center gap-1.5 px-3 py-2 text-xs font-medium rounded-lg transition-colors whitespace-nowrap min-h-[38px] flex-1 sm:flex-initial ${
              activeSubTab === 'entry' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <ClipboardList className="w-3.5 h-3.5" />
            Enter Marks
          </button>
          <button
            type="button"
            onClick={() => onSubTabChange('assignments')}
            className={`inline-flex items-center justify-center gap-1.5 px-3 py-2 text-xs font-medium rounded-lg transition-colors whitespace-nowrap min-h-[38px] flex-1 sm:flex-initial ${
              activeSubTab === 'assignments'
                ? 'bg-white text-slate-900 shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            My Classes ({assignments.length})
          </button>
          <button
            type="button"
            onClick={() => onSubTabChange('history')}
            className={`inline-flex items-center justify-center gap-1.5 px-3 py-2 text-xs font-medium rounded-lg transition-colors whitespace-nowrap min-h-[38px] flex-1 sm:flex-initial ${
              activeSubTab === 'history'
                ? 'bg-white text-slate-900 shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <History className="w-3.5 h-3.5" />
            History
          </button>
        </div>
      </div>

      {/* TAB 1: MY ASSIGNMENTS */}
      {activeSubTab === 'assignments' && (
        <div className="bg-white border border-slate-200 rounded-xl overflow-hidden shadow-xs">
          <div className="px-4 sm:px-5 py-4 border-b border-slate-200 flex flex-wrap items-center justify-between gap-3">
            <h2 className="text-sm font-semibold text-slate-900">Assigned Classes &amp; Subjects</h2>
            {assignments.length > 0 && selectedExamId > 0 && (
              <button
                type="button"
                onClick={() => handleDownloadExcel('all')}
                disabled={exporting !== null}
                className="inline-flex items-center gap-1.5 px-3.5 py-2 min-h-[38px] text-xs font-semibold text-white bg-emerald-700 hover:bg-emerald-800 rounded-lg disabled:opacity-50 transition-colors whitespace-nowrap cursor-pointer"
              >
                <FileSpreadsheet className="w-3.5 h-3.5" />
                {exporting === 'all' ? 'Preparing Excel...' : 'Download Excel'}
              </button>
            )}
          </div>
          {assignments.length === 0 ? (
            <div className="p-10 text-center text-sm text-slate-500">
              No subject assignments found for your account.
            </div>
          ) : (
            <>
              {/* Mobile cards */}
              <div className="md:hidden divide-y divide-slate-200">
                {assignments.map((a) => (
                  <div key={a.id} className="p-4 space-y-2.5">
                    <div className="flex items-start justify-between gap-2">
                      <div>
                        <div className="font-semibold text-sm text-slate-900">{a.subject_name}</div>
                        <div className="text-xs text-slate-600 mt-0.5">
                          {formatClassSectionLabel(
                            a.class_name,
                            a.section_name,
                            a.has_sections !== 0 && a.has_sections !== false
                          )}
                        </div>
                      </div>
                      <span className="font-mono text-xs text-slate-500">{a.academic_year}</span>
                    </div>
                    <div className="text-xs text-slate-600">
                      Component: <span className="font-medium text-slate-800">{a.has_components ? a.component_name : 'Full Subject'}</span>
                    </div>
                    <button
                      type="button"
                      onClick={() => {
                        setSelectedAssignmentId(a.id);
                        onSubTabChange('entry');
                      }}
                      className="w-full min-h-[40px] px-3 py-2 text-xs font-semibold text-white rounded-lg hover:opacity-95 transition-colors"
                      style={{ backgroundColor: 'var(--brand-primary, #1E3A5F)' }}
                    >
                      Open Marks Sheet
                    </button>
                  </div>
                ))}
              </div>

              {/* Desktop table */}
              <div className="hidden md:block overflow-x-auto">
                <table className="w-full text-sm">
                  <thead className="bg-slate-50 border-b border-slate-200 text-xs text-slate-600">
                    <tr>
                      <th className="text-left font-semibold px-4 py-2.5">Class</th>
                      <th className="text-left font-semibold px-4 py-2.5">Section</th>
                      <th className="text-left font-semibold px-4 py-2.5">Subject</th>
                      <th className="text-left font-semibold px-4 py-2.5">Component</th>
                      <th className="text-left font-semibold px-4 py-2.5">Academic Year</th>
                      <th className="text-right font-semibold px-4 py-2.5">Action</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-200">
                    {assignments.map((a) => (
                      <tr key={a.id} className="hover:bg-slate-50/70">
                        <td className="px-4 py-2.5 font-medium text-slate-900">{a.class_name}</td>
                        <td className="px-4 py-2.5 text-slate-700">
                          {a.has_sections === 0 || a.has_sections === false
                            ? 'Single Cohort'
                            : `Section ${a.section_name}`}
                        </td>
                        <td className="px-4 py-2.5 text-slate-900 font-medium">{a.subject_name}</td>
                        <td className="px-4 py-2.5 text-slate-600">
                          {a.has_components ? a.component_name : 'Full Subject'}
                        </td>
                        <td className="px-4 py-2.5 font-mono text-xs text-slate-500">{a.academic_year}</td>
                        <td className="px-4 py-2.5 text-right">
                          <button
                            type="button"
                            onClick={() => {
                              setSelectedAssignmentId(a.id);
                              onSubTabChange('entry');
                            }}
                            className="px-3 py-1.5 text-xs font-medium text-white rounded-lg hover:opacity-95 transition-colors whitespace-nowrap"
                            style={{ backgroundColor: 'var(--brand-primary, #1E3A5F)' }}
                          >
                            Open Marks Sheet
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </>
          )}
        </div>
      )}

      {/* TAB 2: SUBMISSION HISTORY */}
      {activeSubTab === 'history' && (
        <div className="bg-white border border-slate-200 rounded-xl overflow-hidden shadow-xs">
          <div className="px-4 sm:px-5 py-4 border-b border-slate-200 flex items-center justify-between gap-2">
            <h2 className="text-sm font-semibold text-slate-900">Marks Submission History</h2>
            {historyError && (
              <button
                type="button"
                onClick={loadHistory}
                className="px-3 py-1.5 text-xs font-medium text-slate-700 bg-white border border-slate-300 rounded-lg hover:bg-slate-50"
              >
                Retry
              </button>
            )}
          </div>
          {historyError ? (
            <div className="p-6 text-center text-sm text-red-700 bg-red-50/50">
              {historyError}
            </div>
          ) : loadingHistory ? (
            <div className="p-8 text-center text-sm text-slate-500">Loading submission history...</div>
          ) : historyRows.length === 0 ? (
            <div className="p-8 text-center text-sm text-slate-500">No examination history found.</div>
          ) : (
            <>
              {/* Mobile cards */}
              <div className="md:hidden divide-y divide-slate-200">
                {historyRows.map((h, i) => {
                  const status =
                    h.total_students > 0 && h.submitted_count === h.total_students
                      ? 'Submitted'
                      : h.entered_count > 0
                        ? 'Draft'
                        : 'Pending';
                  return (
                    <div key={i} className="p-4 space-y-2">
                      <div className="flex items-start justify-between gap-2">
                        <div>
                          <div className="font-semibold text-sm text-slate-900">{h.examination_name}</div>
                          <div className="text-xs text-slate-600 mt-0.5">
                            {formatClassSectionLabel(
                              h.class_name,
                              h.section_name,
                              h.has_sections !== 0 && h.has_sections !== false
                            )}
                          </div>
                        </div>
                        <SubmissionStatusLabel status={status} />
                      </div>
                      <div className="text-xs text-slate-800">
                        {h.subject_name}
                        {h.component_name !== h.subject_name ? ` — ${h.component_name}` : ''}
                      </div>
                      <div className="grid grid-cols-3 gap-2 pt-1 text-xs font-mono tabular-nums text-slate-600">
                        <div>Max: <strong className="text-slate-900">{h.max_marks}</strong></div>
                        <div>Entered: <strong className="text-slate-900">{h.entered_count}/{h.total_students}</strong></div>
                        <div>Sub: <strong className="text-slate-900">{h.submitted_count}/{h.total_students}</strong></div>
                      </div>
                    </div>
                  );
                })}
              </div>

              {/* Desktop table */}
              <div className="hidden md:block overflow-x-auto">
                <table className="w-full text-sm">
                  <thead className="bg-slate-50 border-b border-slate-200 text-xs text-slate-600">
                    <tr>
                      <th className="text-left font-semibold px-4 py-2.5">Examination</th>
                      <th className="text-left font-semibold px-4 py-2.5">Class &amp; Section</th>
                      <th className="text-left font-semibold px-4 py-2.5">Subject / Component</th>
                      <th className="text-right font-semibold px-4 py-2.5">Max</th>
                      <th className="text-right font-semibold px-4 py-2.5">Entered</th>
                      <th className="text-right font-semibold px-4 py-2.5">Submitted</th>
                      <th className="text-center font-semibold px-4 py-2.5">Status</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-200">
                    {historyRows.map((h, i) => {
                      const status =
                        h.total_students > 0 && h.submitted_count === h.total_students
                          ? 'Submitted'
                          : h.entered_count > 0
                            ? 'Draft'
                            : 'Pending';
                      return (
                        <tr key={i} className="hover:bg-slate-50/70">
                          <td className="px-4 py-2.5 font-medium text-slate-900">{h.examination_name}</td>
                          <td className="px-4 py-2.5 text-slate-700">
                            {formatClassSectionLabel(
                              h.class_name,
                              h.section_name,
                              h.has_sections !== 0 && h.has_sections !== false
                            )}
                          </td>
                          <td className="px-4 py-2.5 text-slate-800">
                            {h.subject_name}
                            {h.component_name !== h.subject_name ? ` — ${h.component_name}` : ''}
                          </td>
                          <td className="px-4 py-2.5 text-right font-mono tabular-nums">{h.max_marks}</td>
                          <td className="px-4 py-2.5 text-right font-mono tabular-nums">
                            {h.entered_count}/{h.total_students}
                          </td>
                          <td className="px-4 py-2.5 text-right font-mono tabular-nums">
                            {h.submitted_count}/{h.total_students}
                          </td>
                          <td className="px-4 py-2.5 text-center">
                            <SubmissionStatusLabel status={status} />
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </>
          )}
        </div>
      )}

      {/* TAB 3: MARKS ENTRY */}
      {activeSubTab === 'entry' && (
        <div className="space-y-4">
          {/* Selection Controls */}
          <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-xs">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                  Class, Section &amp; Subject
                </label>
                <select
                  value={selectedAssignmentId}
                  onChange={(e) => setSelectedAssignmentId(Number(e.target.value))}
                  className="w-full min-h-[40px] px-3 py-2 text-sm bg-white border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-600"
                >
                  {assignments.map((a) => (
                    <option key={a.id} value={a.id}>
                      {formatClassSectionLabel(
                        a.class_name,
                        a.section_name,
                        a.has_sections !== 0 && a.has_sections !== false
                      )}{' '}
                      — {a.subject_name}
                      {a.has_components ? ` · ${a.component_name}` : ''}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                  Examination
                </label>
                <select
                  value={selectedExamId}
                  onChange={(e) => setSelectedExamId(Number(e.target.value))}
                  className="w-full min-h-[40px] px-3 py-2 text-sm bg-white border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-600"
                >
                  {examinations.map((ex) => (
                    <option key={ex.id} value={ex.id}>
                      {ex.name} ({ex.academic_year}) — {ex.marksEntryOpen && ex.status === 'Active' ? 'Open' : ex.status}
                    </option>
                  ))}
                </select>
              </div>
            </div>
          </div>

          {feedback && (
            <div
              className={`flex items-center justify-between gap-2.5 p-3.5 rounded-xl border text-xs font-medium ${
                feedback.type === 'success'
                  ? 'bg-emerald-50 border-emerald-200 text-emerald-900'
                  : 'bg-red-50 border-red-200 text-red-900'
              }`}
            >
              <div className="flex items-center gap-2.5">
                {feedback.type === 'success' ? (
                  <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                ) : (
                  <AlertCircle className="w-4 h-4 text-red-600 shrink-0" />
                )}
                <span>{feedback.text}</span>
              </div>
              {feedback.type === 'error' && !sheet && (
                <button
                  type="button"
                  onClick={() => loadMarksSheet(selectedAssignment, selectedExamId)}
                  className="px-3 py-1 bg-white border border-red-300 rounded-md text-red-800 hover:bg-red-50 shrink-0"
                >
                  Retry
                </button>
              )}
            </div>
          )}

          {loadingSheet ? (
            <div className="bg-white border border-slate-200 rounded-xl p-10 text-center text-sm text-slate-500">
              Loading student list...
            </div>
          ) : !sheet ? (
            <div className="bg-white border border-slate-200 rounded-xl p-10 text-center text-sm text-slate-500">
              Select an assigned subject and examination to enter marks.
            </div>
          ) : (
            <div className="bg-white border border-slate-200 rounded-xl overflow-hidden shadow-xs">
              {/* Summary & Action Header */}
              <div className="px-5 py-4 bg-slate-50/80 border-b border-slate-200 flex flex-wrap items-center justify-between gap-4">
                <div className="flex flex-wrap items-center gap-x-6 gap-y-2 text-sm">
                  <div>
                    <span className="text-[11px] text-slate-500 block">Class &amp; Section</span>
                    <span className="font-semibold text-slate-900">
                      {formatClassSectionLabel(
                        sheet.context.className,
                        sheet.context.sectionName,
                        sheet.context.hasSections ?? true
                      )}
                    </span>
                  </div>
                  <div>
                    <span className="text-[11px] text-slate-500 block">Examination</span>
                    <span className="font-semibold text-slate-900">{sheet.examination.name}</span>
                  </div>
                  <div>
                    <span className="text-[11px] text-slate-500 block">Subject</span>
                    <span className="font-semibold text-slate-900">
                      {sheet.context.subjectName}
                      {sheet.context.hasComponents ? ` · ${sheet.context.componentName}` : ''}
                    </span>
                  </div>
                  <div>
                    <span className="text-[11px] text-slate-500 block">Max Marks</span>
                    <span className="font-mono font-bold tabular-nums" style={{ color: 'var(--brand-primary, #1E3A5F)' }}>
                      {sheet.context.maxMarks}
                      {ia?.enabled ? ` (+${ia.totalIaMax} IA)` : ''}
                    </span>
                  </div>
                  <div className="flex items-center gap-2 text-xs font-mono tabular-nums pt-1">
                    <span className="px-2 py-0.5 rounded bg-emerald-50 text-emerald-800 border border-emerald-200 font-semibold">
                      P: {validationState.presentCount}
                    </span>
                    <span className="px-2 py-0.5 rounded bg-rose-50 text-rose-800 border border-rose-200 font-semibold">
                      AB: {validationState.absentCount}
                    </span>
                    <span className="px-2 py-0.5 rounded bg-slate-100 text-slate-700 border border-slate-200 font-semibold">
                      Pending: {validationState.pendingCount}
                    </span>
                  </div>
                </div>

                <div className="flex flex-wrap items-center gap-2">
                  <button
                    type="button"
                    onClick={() => loadMarksSheet(selectedAssignment, selectedExamId)}
                    disabled={loadingSheet || saving}
                    title="Refresh student roster and marks"
                    className="inline-flex items-center gap-1.5 px-3 py-2 min-h-[38px] text-xs font-medium text-slate-700 bg-white border border-slate-300 rounded-lg hover:bg-slate-50 disabled:opacity-50 transition-colors whitespace-nowrap cursor-pointer"
                  >
                    <RefreshCw className={`w-3.5 h-3.5 ${loadingSheet ? 'animate-spin' : ''}`} />
                    Refresh Roster
                  </button>
                  <button
                    type="button"
                    onClick={() => handleDownloadExcel('single')}
                    disabled={loadingSheet || exporting !== null || sheet.students.length === 0}
                    title="Download marksheet in Excel (.xlsx) format"
                    className="inline-flex items-center gap-1.5 px-3 py-2 min-h-[38px] text-xs font-semibold text-emerald-800 bg-emerald-50 border border-emerald-300 rounded-lg hover:bg-emerald-100 disabled:opacity-50 transition-colors whitespace-nowrap cursor-pointer"
                  >
                    <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-700" />
                    {exporting === 'single' ? 'Exporting...' : 'Download Excel'}
                  </button>
                  {assignments.length > 1 && (
                    <button
                      type="button"
                      onClick={() => handleDownloadExcel('all')}
                      disabled={loadingSheet || exporting !== null}
                      title="Download all assigned classes and subjects in separate worksheets"
                      className="inline-flex items-center gap-1.5 px-3 py-2 min-h-[38px] text-xs font-medium text-slate-700 bg-white border border-slate-300 rounded-lg hover:bg-slate-50 disabled:opacity-50 transition-colors whitespace-nowrap cursor-pointer"
                    >
                      <FileSpreadsheet className="w-3.5 h-3.5 text-[#1E3A5F]" />
                      {exporting === 'all' ? 'Exporting All...' : 'All Assigned (.xlsx)'}
                    </button>
                  )}
                  {sheet.anySubmitted && (
                    sheet.latestCorrectionRequest?.status === 'pending' ? (
                      <span className="text-xs text-amber-700 font-medium px-2.5 py-2 bg-amber-50 border border-amber-200 rounded-lg">
                        Correction Pending
                      </span>
                    ) : (
                      <button
                        type="button"
                        onClick={() => setCorrectionModalOpen(true)}
                        className="inline-flex items-center gap-1.5 px-3 py-2 min-h-[38px] text-xs font-medium text-slate-700 bg-white border border-slate-300 rounded-lg hover:bg-slate-50 transition-colors whitespace-nowrap"
                      >
                        <FileWarning className="w-3.5 h-3.5 text-amber-600" />
                        Request Correction
                      </button>
                    )
                  )}

                  {sheet.isLocked ? (
                    <span className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-medium bg-emerald-50 text-emerald-800 border border-emerald-200 rounded-lg">
                      <Lock className="w-3.5 h-3.5" /> Submitted
                    </span>
                  ) : !sheet.examWindowOpen ? (
                    <span className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-medium bg-slate-100 text-slate-700 border border-slate-200 rounded-lg">
                      <Lock className="w-3.5 h-3.5" /> Entry Closed
                    </span>
                  ) : (
                    <>
                      <button
                        type="button"
                        onClick={handleClearEntries}
                        disabled={saving}
                        className="inline-flex items-center gap-1.5 px-3 py-2 min-h-[38px] text-xs font-medium text-slate-700 bg-white border border-slate-300 rounded-lg hover:bg-slate-50 transition-colors whitespace-nowrap"
                      >
                        <RotateCcw className="w-3.5 h-3.5" />
                        Clear Unsubmitted
                      </button>
                      <button
                        type="button"
                        onClick={() => saveMarks('draft')}
                        disabled={saving || sheet.students.length === 0}
                        className="inline-flex items-center gap-1.5 px-3.5 py-2 min-h-[38px] text-xs font-medium text-slate-800 bg-amber-50 border border-amber-300 rounded-lg hover:bg-amber-100 disabled:opacity-50 transition-colors whitespace-nowrap"
                      >
                        <Save className="w-3.5 h-3.5 text-amber-700" />
                        Save Draft
                      </button>
                      <button
                        type="button"
                        onClick={handleOpenSubmit}
                        disabled={saving || sheet.students.length === 0}
                        className="inline-flex items-center gap-1.5 px-4 py-2 min-h-[38px] text-xs font-semibold text-white rounded-lg hover:opacity-95 disabled:opacity-50 transition-colors whitespace-nowrap shadow-xs"
                        style={{ backgroundColor: 'var(--brand-primary, #1E3A5F)' }}
                      >
                        <Send className="w-3.5 h-3.5" />
                        Submit Marks
                      </button>
                    </>
                  )}
                </div>
              </div>

              {/* Synced Top Horizontal Scrollbar */}
              {hasHorizontalOverflow && (
                <div
                  ref={topScrollRef}
                  onScroll={handleTopScroll}
                  className="overflow-x-auto overflow-y-hidden border-b border-slate-200 bg-slate-50/90"
                  aria-label="Top horizontal table scrollbar"
                >
                  <div style={{ width: `${tableScrollWidth}px`, height: '14px' }} />
                </div>
              )}

              {/* Marks Entry Table */}
              <div
                ref={tableScrollRef}
                onScroll={handleTableScroll}
                className="overflow-auto max-h-[65vh] relative"
              >
                <table ref={tableRef} className="w-full text-sm">
                  <thead className="bg-slate-50 border-b border-slate-200 text-xs text-slate-600 sticky top-0 z-20 shadow-[0_1px_0_0_rgba(226,232,240,1)]">
                    <tr>
                      <th className="text-left font-semibold px-3 py-2.5 w-14 min-w-[56px] bg-slate-50 md:sticky md:left-0 md:z-30">
                        Roll
                      </th>
                      <th className="text-left font-semibold px-3 py-2.5 w-24 min-w-[96px] bg-slate-50 md:sticky md:left-[56px] md:z-30">
                        ID
                      </th>
                      <th className="text-left font-semibold px-3 py-2.5 min-w-[170px] bg-slate-50 md:sticky md:left-[152px] md:z-30 md:border-r md:border-slate-200 md:shadow-[2px_0_4px_-2px_rgba(15,23,42,0.12)]">
                        Student Name
                      </th>
                      <th className="text-center font-semibold px-3 py-2.5 whitespace-nowrap">Attendance</th>
                      <th className="text-left font-semibold px-3 py-2.5 whitespace-nowrap">
                        {sheet.context.hasComponents ? sheet.context.componentName : 'Exam Marks'}{' '}
                        <span className="font-mono text-slate-500 font-normal">(/{sheet.context.maxMarks})</span>
                      </th>
                      {showNb && (
                        <th className="text-left font-semibold px-2.5 py-2.5 whitespace-nowrap bg-sky-50/50">
                          Notebook <span className="font-mono text-slate-500 font-normal">(/{ia!.notebookMax})</span>
                        </th>
                      )}
                      {showUt && (
                        <th className="text-left font-semibold px-2.5 py-2.5 whitespace-nowrap bg-sky-50/50">
                          Unit Test <span className="font-mono text-slate-500 font-normal">(/{ia!.unitTestMax})</span>
                        </th>
                      )}
                      {showPr && (
                        <th className="text-left font-semibold px-2.5 py-2.5 whitespace-nowrap bg-sky-50/50">
                          Practical <span className="font-mono text-slate-500 font-normal">(/{ia!.practicalMax})</span>
                        </th>
                      )}
                      {showOp && (
                        <th className="text-left font-semibold px-2.5 py-2.5 whitespace-nowrap bg-sky-50/50">
                          Participation{' '}
                          <span className="font-mono text-slate-500 font-normal">(/{ia!.participationMax})</span>
                        </th>
                      )}
                      {showIaCols && (
                        <th className="text-right font-semibold px-3 py-2.5 whitespace-nowrap bg-sky-50/50">
                          IA Total <span className="font-mono text-slate-500 font-normal">(/{ia!.totalIaMax})</span>
                        </th>
                      )}
                      <th className="text-right font-semibold px-3 py-2.5 whitespace-nowrap">
                        Subject Total{' '}
                        <span className="font-mono text-slate-500 font-normal">
                          (/
                          {ia?.enabled
                            ? ia.subjectTotalMax
                            : sheet.context.hasComponents && sheet.context.componentMode === 'combined'
                              ? sheet.context.maxMarks +
                                Math.max(0, ...(sheet.students.map((s) => s.otherComponentsMax || 0)))
                              : sheet.context.maxMarks}
                          )
                        </span>
                      </th>
                      <th className="text-center font-semibold px-3 py-2.5 whitespace-nowrap">Grade</th>
                      <th className="text-center font-semibold px-3 py-2.5 w-28">Status</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-200">
                    {sheet.students.length === 0 ? (
                      <tr>
                        <td
                          colSpan={15}
                          className="px-4 py-10 text-center text-sm text-slate-500"
                        >
                          No students enrolled in{' '}
                          {formatClassSectionLabel(
                            sheet.context.className,
                            sheet.context.sectionName,
                            sheet.context.hasSections ?? true
                          )}{' '}
                          for <span className="font-semibold">{sheet.context.componentName}</span>.
                        </td>
                      </tr>
                    ) : null}
                    {sheet.students.map((st) => {
                      const att = attendanceDrafts[st.studentId] || 'pending';
                      const rawVal = draftInputs[st.studentId] ?? '';
                      const isInvalid = validationState.invalidIds.has(st.studentId);
                      const rowLocked = !sheet.examWindowOpen || st.isRowLocked;
                      const iaRaw = iaDraftInputs[st.studentId] || { nb: '', ut: '', pr: '', op: '' };
                      const iaInvalid = validationState.invalidIaMap.get(st.studentId);

                      const nbEditable = Boolean(
                        sheet.examWindowOpen &&
                          ia?.enabled &&
                          ia.canEditIa &&
                          ia.iaPermissions.notebook &&
                          st.nbStatus !== 'submitted'
                      );
                      const utEditable = Boolean(
                        sheet.examWindowOpen &&
                          ia?.enabled &&
                          ia.canEditIa &&
                          ia.iaPermissions.unit_test &&
                          st.utStatus !== 'submitted'
                      );
                      const prEditable = Boolean(
                        sheet.examWindowOpen &&
                          ia?.enabled &&
                          ia.canEditIa &&
                          ia.iaPermissions.practical &&
                          st.prStatus !== 'submitted'
                      );
                      const opEditable = Boolean(
                        sheet.examWindowOpen &&
                          ia?.enabled &&
                          ia.canEditIa &&
                          ia.iaPermissions.participation &&
                          st.opStatus !== 'submitted'
                      );

                      const nbNum = showNb ? (iaRaw.nb.trim() === '' ? null : Number(iaRaw.nb)) : 0;
                      const utNum = showUt ? (iaRaw.ut.trim() === '' ? null : Number(iaRaw.ut)) : 0;
                      const prNum = showPr ? (iaRaw.pr.trim() === '' ? null : Number(iaRaw.pr)) : 0;
                      const opNum = showOp ? (iaRaw.op.trim() === '' ? null : Number(iaRaw.op)) : 0;
                      const iaSum =
                        nbNum !== null &&
                        utNum !== null &&
                        prNum !== null &&
                        opNum !== null &&
                        !Number.isNaN(nbNum) &&
                        !Number.isNaN(utNum) &&
                        !Number.isNaN(prNum) &&
                        !Number.isNaN(opNum)
                          ? nbNum + utNum + prNum + opNum
                          : null;
                      const examNum = att === 'present' && rawVal.trim() !== '' ? Number(rawVal) : null;
                      const isCombined =
                        sheet.context.hasComponents && sheet.context.componentMode === 'combined';
                      const otherComplete = !isCombined || Boolean(st.otherComponentsComplete);
                      const otherAbsent = isCombined && Boolean(st.otherComponentsAbsent);
                      const anyAbsent = att === 'absent' || otherAbsent;
                      const allWrittenEntered =
                        !anyAbsent &&
                        examNum !== null &&
                        !Number.isNaN(examNum) &&
                        (!isCombined || (otherComplete && st.otherComponentsMarks !== null && st.otherComponentsMarks !== undefined));
                      const writtenCombinedTotal = allWrittenEntered
                        ? examNum! + (isCombined ? Number(st.otherComponentsMarks || 0) : 0)
                        : null;
                      const subjComplete =
                        allWrittenEntered && (!showIaCols || iaSum !== null);
                      const subjTotal =
                        subjComplete && writtenCombinedTotal !== null
                          ? writtenCombinedTotal + (showIaCols ? Number(iaSum || 0) : 0)
                          : null;
                      const subjMax = ia?.enabled
                        ? ia.subjectTotalMax
                        : sheet.context.maxMarks + (isCombined ? Number(st.otherComponentsMax || 0) : 0);
                      const iaTotalInvalid = validationState.invalidIaTotalIds.has(st.studentId);
                      const gradeInfo = calculateSubjectGrade(subjTotal, subjMax, {
                        isAbsent: anyAbsent,
                        isPending: !subjComplete,
                        isNotSubmitted: !subjComplete && st.status === 'pending' && rawVal.trim() === '',
                      });

                      const stickyCellBg =
                        isInvalid || iaInvalid || iaTotalInvalid
                          ? 'bg-red-50'
                          : att === 'absent'
                            ? 'bg-rose-50'
                            : 'bg-white group-hover:bg-slate-50';

                      return (
                        <tr
                          key={st.studentId}
                          className={`group ${
                            isInvalid || iaInvalid || iaTotalInvalid
                              ? 'bg-red-50/40'
                              : att === 'absent'
                                ? 'bg-rose-50/30'
                                : 'hover:bg-slate-50/70'
                          }`}
                        >
                          <td
                            className={`px-3 py-2 font-mono text-xs font-semibold text-slate-700 tabular-nums w-14 min-w-[56px] md:sticky md:left-0 md:z-10 ${stickyCellBg}`}
                          >
                            {String(st.rollNumber).padStart(2, '0')}
                          </td>
                          <td
                            className={`px-3 py-2 font-mono text-xs text-slate-500 w-24 min-w-[96px] md:sticky md:left-[56px] md:z-10 ${stickyCellBg}`}
                          >
                            {st.studentCode}
                          </td>
                          <td
                            className={`px-3 py-2 font-medium text-slate-900 whitespace-nowrap min-w-[170px] md:sticky md:left-[152px] md:z-10 md:border-r md:border-slate-200 md:shadow-[2px_0_4px_-2px_rgba(15,23,42,0.12)] ${stickyCellBg}`}
                          >
                            {st.fullName}
                          </td>
                          <td className="px-3 py-2 text-center">
                            <div className="inline-flex rounded-lg border border-slate-200 bg-slate-50 p-0.5 text-[11px]">
                              <button
                                type="button"
                                disabled={rowLocked}
                                onClick={() => handleAttendanceChange(st.studentId, 'present')}
                                className={`px-2.5 py-1.5 min-h-[34px] rounded font-medium transition-colors ${
                                  att === 'present'
                                    ? 'bg-emerald-600 text-white shadow-xs'
                                    : 'text-slate-600 hover:text-slate-900'
                                } disabled:opacity-60`}
                              >
                                Present
                              </button>
                              <button
                                type="button"
                                disabled={rowLocked}
                                onClick={() => handleAttendanceChange(st.studentId, 'absent')}
                                className={`px-2.5 py-1.5 min-h-[34px] rounded font-medium transition-colors ${
                                  att === 'absent'
                                    ? 'bg-rose-600 text-white shadow-xs'
                                    : 'text-slate-600 hover:text-slate-900'
                                } disabled:opacity-60`}
                              >
                                Absent
                              </button>
                              <button
                                type="button"
                                disabled={rowLocked}
                                onClick={() => handleAttendanceChange(st.studentId, 'pending')}
                                className={`px-2.5 py-1.5 min-h-[34px] rounded font-medium transition-colors ${
                                  att === 'pending'
                                    ? 'bg-slate-700 text-white shadow-xs'
                                    : 'text-slate-600 hover:text-slate-900'
                                } disabled:opacity-60`}
                              >
                                Pending
                              </button>
                            </div>
                          </td>
                          <td className="px-3 py-2">
                            {att === 'absent' ? (
                              <span className="inline-flex items-center justify-center w-24 px-2.5 py-2 text-xs font-mono font-bold text-rose-700 bg-rose-50 border border-rose-200 rounded-md">
                                AB
                              </span>
                            ) : (
                              <div className="flex items-center gap-1.5">
                                <input
                                  type="number"
                                  step="0.5"
                                  min={0}
                                  max={validationState.maxExternalAllowed}
                                  disabled={rowLocked}
                                  value={rawVal}
                                  placeholder="—"
                                  onChange={(e) => handleInputChange(st.studentId, e.target.value)}
                                  className={`w-24 min-h-[38px] px-2.5 py-1.5 text-sm font-mono tabular-nums rounded-md border focus:outline-none focus:ring-2 ${
                                    isInvalid
                                      ? 'border-red-400 bg-red-50 text-red-900 focus:ring-red-200'
                                      : rowLocked
                                        ? 'border-slate-200 bg-slate-100 text-slate-700'
                                        : 'border-slate-300 bg-white text-slate-900 focus:ring-indigo-500/20 focus:border-indigo-600'
                                  }`}
                                />
                                {isInvalid && (
                                  <span className="text-[11px] font-medium text-red-700 whitespace-nowrap">
                                    0–{validationState.maxExternalAllowed}
                                  </span>
                                )}
                              </div>
                            )}
                          </td>
                          {showNb && (
                            <td className="px-2.5 py-2 bg-sky-50/30">
                              <input
                                type="number"
                                step="0.5"
                                min={0}
                                max={ia!.notebookMax}
                                disabled={!nbEditable}
                                value={iaRaw.nb}
                                placeholder="—"
                                onChange={(e) => handleIaInputChange(st.studentId, 'nb', e.target.value)}
                                className={`w-16 px-2 py-1.5 text-xs font-mono tabular-nums rounded-md border focus:outline-none focus:ring-2 ${
                                  iaInvalid?.nb || iaTotalInvalid
                                    ? 'border-red-400 bg-red-50 text-red-900 focus:ring-red-200'
                                    : !nbEditable
                                      ? 'border-slate-200 bg-slate-100 text-slate-700'
                                      : 'border-slate-300 bg-white text-slate-900 focus:ring-indigo-500/20 focus:border-indigo-600'
                                }`}
                              />
                            </td>
                          )}
                          {showUt && (
                            <td className="px-2.5 py-2 bg-sky-50/30">
                              <input
                                type="number"
                                step="0.5"
                                min={0}
                                max={ia!.unitTestMax}
                                disabled={!utEditable}
                                value={iaRaw.ut}
                                placeholder="—"
                                onChange={(e) => handleIaInputChange(st.studentId, 'ut', e.target.value)}
                                className={`w-16 px-2 py-1.5 text-xs font-mono tabular-nums rounded-md border focus:outline-none focus:ring-2 ${
                                  iaInvalid?.ut || iaTotalInvalid
                                    ? 'border-red-400 bg-red-50 text-red-900 focus:ring-red-200'
                                    : !utEditable
                                      ? 'border-slate-200 bg-slate-100 text-slate-700'
                                      : 'border-slate-300 bg-white text-slate-900 focus:ring-indigo-500/20 focus:border-indigo-600'
                                }`}
                              />
                            </td>
                          )}
                          {showPr && (
                            <td className="px-2.5 py-2 bg-sky-50/30">
                              <input
                                type="number"
                                step="0.5"
                                min={0}
                                max={ia!.practicalMax}
                                disabled={!prEditable}
                                value={iaRaw.pr}
                                placeholder="—"
                                onChange={(e) => handleIaInputChange(st.studentId, 'pr', e.target.value)}
                                className={`w-16 px-2 py-1.5 text-xs font-mono tabular-nums rounded-md border focus:outline-none focus:ring-2 ${
                                  iaInvalid?.pr || iaTotalInvalid
                                    ? 'border-red-400 bg-red-50 text-red-900 focus:ring-red-200'
                                    : !prEditable
                                      ? 'border-slate-200 bg-slate-100 text-slate-700'
                                      : 'border-slate-300 bg-white text-slate-900 focus:ring-indigo-500/20 focus:border-indigo-600'
                                }`}
                              />
                            </td>
                          )}
                          {showOp && (
                            <td className="px-2.5 py-2 bg-sky-50/30">
                              <input
                                type="number"
                                step="0.5"
                                min={0}
                                max={ia!.participationMax}
                                disabled={!opEditable}
                                value={iaRaw.op}
                                placeholder="—"
                                onChange={(e) => handleIaInputChange(st.studentId, 'op', e.target.value)}
                                className={`w-16 px-2 py-1.5 text-xs font-mono tabular-nums rounded-md border focus:outline-none focus:ring-2 ${
                                  iaInvalid?.op || iaTotalInvalid
                                    ? 'border-red-400 bg-red-50 text-red-900 focus:ring-red-200'
                                    : !opEditable
                                      ? 'border-slate-200 bg-slate-100 text-slate-700'
                                      : 'border-slate-300 bg-white text-slate-900 focus:ring-indigo-500/20 focus:border-indigo-600'
                                }`}
                              />
                            </td>
                          )}
                          {showIaCols && (
                            <td
                              className={`px-3 py-2 text-right font-mono text-xs font-semibold tabular-nums bg-sky-50/30 ${
                                iaTotalInvalid ? 'text-red-700' : 'text-[#1E3A5F]'
                              }`}
                            >
                              {iaSum !== null ? iaSum : '—'}
                            </td>
                          )}
                          <td className="px-3 py-2 text-right font-mono text-xs font-bold tabular-nums text-slate-900 whitespace-nowrap">
                            {anyAbsent ? (
                              <span className="text-rose-700">AB</span>
                            ) : subjTotal !== null ? (
                              <span>{subjTotal}</span>
                            ) : (
                              <span className="text-slate-400 font-normal">
                                {isCombined && examNum !== null && !otherComplete ? 'Awaiting parts' : '—'}
                              </span>
                            )}
                          </td>
                          <td className="px-3 py-2 text-center whitespace-nowrap">
                            <span
                              className={`inline-flex items-center px-2 py-0.5 text-[11px] font-mono font-semibold rounded border ${getGradeBadgeClass(
                                gradeInfo.grade || gradeInfo.display
                              )}`}
                              title={gradeInfo.remark || gradeInfo.display}
                            >
                              {gradeInfo.display}
                            </span>
                          </td>
                          <td className="px-3 py-2 text-center">
                            <SubmissionStatusLabel status={st.status} />
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>

              {/* Bottom Sticky Action Bar for convenience on long rosters */}
              {canInteractSheet && sheet.students.length > 0 && (
                <div className="px-4 sm:px-5 py-3 bg-slate-50 border-t border-slate-200 flex flex-wrap items-center justify-between gap-3">
                  <div className="text-xs text-slate-600 font-mono tabular-nums">
                    Present: <strong className="text-emerald-700">{validationState.presentCount}</strong> · Absent:{' '}
                    <strong className="text-rose-700">{validationState.absentCount}</strong> · Pending:{' '}
                    <strong className="text-slate-800">{validationState.pendingCount}</strong>
                  </div>
                  <div className="flex flex-wrap items-center gap-2 w-full sm:w-auto">
                    <button
                      type="button"
                      onClick={() => saveMarks('draft')}
                      disabled={saving}
                      className="inline-flex items-center justify-center gap-1.5 px-3.5 py-2 min-h-[40px] flex-1 sm:flex-initial text-xs font-medium text-slate-800 bg-amber-50 border border-amber-300 rounded-lg hover:bg-amber-100 disabled:opacity-50"
                    >
                      <Save className="w-3.5 h-3.5 text-amber-700" />
                      Save Draft
                    </button>
                    <button
                      type="button"
                      onClick={handleOpenSubmit}
                      disabled={saving}
                      className="inline-flex items-center justify-center gap-1.5 px-4 py-2 min-h-[40px] flex-1 sm:flex-initial text-xs font-semibold text-white rounded-lg hover:opacity-95 disabled:opacity-50"
                      style={{ backgroundColor: 'var(--brand-primary, #1E3A5F)' }}
                    >
                      <Send className="w-3.5 h-3.5" />
                      Submit Marks
                    </button>
                  </div>
                </div>
              )}
            </div>
          )}
        </div>
      )}

      {/* Submission Confirmation Modal */}
      {confirmSubmitOpen && sheet && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/50 p-4">
          <div className="bg-white border border-slate-200 rounded-xl w-full max-w-md max-h-[90vh] overflow-y-auto p-5 sm:p-6 space-y-4 shadow-xl">
            <h3 className="text-base font-bold text-slate-900">Confirm Marks Submission</h3>
            <p className="text-sm text-slate-600 leading-relaxed">
              Submit marks for{' '}
              <span className="font-semibold text-slate-900">
                {formatClassSectionLabel(
                  sheet.context.className,
                  sheet.context.sectionName,
                  sheet.context.hasSections ?? true
                )}{' '}
                — {sheet.context.componentName}
              </span>{' '}
              ({sheet.examination.name})?
            </p>
            <div className="p-3 bg-slate-50 border border-slate-200 rounded-lg text-xs text-slate-700 space-y-1.5 font-mono tabular-nums">
              <div className="flex justify-between">
                <span>Present (Marks Entered):</span>
                <span className="font-bold text-emerald-700">{validationState.presentCount}</span>
              </div>
              <div className="flex justify-between">
                <span>Absent (AB):</span>
                <span className="font-bold text-rose-700">{validationState.absentCount}</span>
              </div>
              <div className="flex justify-between">
                <span>Pending (Can be entered later):</span>
                <span className="font-bold text-slate-800">{validationState.pendingCount}</span>
              </div>
            </div>
            <div className="flex items-center justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setConfirmSubmitOpen(false)}
                className="px-3.5 py-2 min-h-[40px] text-xs font-medium text-slate-700 bg-white border border-slate-300 rounded-lg hover:bg-slate-50"
              >
                Cancel
              </button>
              <button
                type="button"
                disabled={saving}
                onClick={() => saveMarks('submit')}
                className="px-4 py-2 min-h-[40px] text-xs font-semibold text-white rounded-lg hover:opacity-95 disabled:opacity-50"
                style={{ backgroundColor: 'var(--brand-primary, #1E3A5F)' }}
              >
                {saving ? 'Submitting...' : 'Confirm & Submit'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Correction Request Modal */}
      {correctionModalOpen && sheet && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/50 p-4">
          <form
            onSubmit={submitCorrectionRequest}
            className="bg-white border border-slate-200 rounded-xl w-full max-w-md max-h-[90vh] overflow-y-auto p-5 sm:p-6 space-y-4 shadow-xl"
          >
            <h3 className="text-base font-bold text-slate-900">Request Marks Correction</h3>
            <p className="text-xs text-slate-600">
              {formatClassSectionLabel(
                sheet.context.className,
                sheet.context.sectionName,
                sheet.context.hasSections ?? true
              )}{' '}
              · {sheet.context.componentName}
            </p>
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1.5">Reason for Correction</label>
              <textarea
                required
                rows={3}
                value={correctionReason}
                onChange={(e) => setCorrectionReason(e.target.value)}
                placeholder="Reason for unlocking submitted marks..."
                className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-600"
              />
            </div>
            <div className="flex items-center justify-end gap-2">
              <button
                type="button"
                onClick={() => setCorrectionModalOpen(false)}
                className="px-3.5 py-2 min-h-[40px] text-xs font-medium text-slate-700 bg-white border border-slate-300 rounded-lg hover:bg-slate-50"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={saving}
                className="px-4 py-2 min-h-[40px] text-xs font-semibold text-white rounded-lg hover:opacity-95 disabled:opacity-50"
                style={{ backgroundColor: 'var(--brand-primary, #1E3A5F)' }}
              >
                Submit Request
              </button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
}
