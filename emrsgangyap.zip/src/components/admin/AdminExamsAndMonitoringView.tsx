import React, { useEffect, useMemo, useRef, useState } from 'react';
import {
  Plus,
  Lock,
  Unlock,
  FileDown,
  Check,
  X,
  SlidersHorizontal,
  Trash2,
  RotateCcw,
  RefreshCw,
  Search,
} from 'lucide-react';
import type {
  ExaminationRecord,
  MonitoringRow,
  SchoolInfo,
  SubjectRecord,
} from '../../types';
import { apiFetch, extractErrorMessage, isAbortError } from '../../lib/api';
import { exportSubmissionMonitoringPDF } from '../../lib/exports';
import { formatClassSectionLabel } from '../../lib/grading';
import { ExamStatusLabel, SubmissionStatusLabel } from '../StatusIndicator';
import {
  BulkActionToolbar,
  BulkConfirmModal,
  PaginationBar,
  UndoBanner,
  usePagination,
  type BulkConfirmItem,
} from '../BulkActions';

interface CorrectionRequestRow {
  id: number;
  examination_id: number;
  examination_name: string;
  examination_component_id: number;
  subject_name: string;
  component_name: string;
  class_id: number;
  class_name: string;
  has_sections?: number | boolean;
  hasSections?: boolean;
  section_id: number;
  section_name: string;
  requested_by_name: string;
  reason: string;
  status: 'pending' | 'approved' | 'rejected';
  reviewed_by_name: string | null;
  created_at: string;
}

export function AdminExaminationsView({
  schoolInfo,
  examinations,
  selectedAcademicYear,
  onChanged,
}: {
  schoolInfo: SchoolInfo;
  examinations: ExaminationRecord[];
  selectedAcademicYear: string;
  onChanged: () => Promise<void> | void;
}) {
  const [viewMode, setViewMode] = useState<'active' | 'archived'>('active');
  const [archivedExams, setArchivedExams] = useState<ExaminationRecord[]>([]);
  const [loadingArchived, setLoadingArchived] = useState(false);
  const [subjects, setSubjects] = useState<SubjectRecord[]>([]);
  const [showAllYears, setShowAllYears] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [createOpen, setCreateOpen] = useState(false);
  const [editExam, setEditExam] = useState<ExaminationRecord | null>(null);
  const [editMeta, setEditMeta] = useState({
    name: '',
    examType: 'Regular',
    startDate: '',
    endDate: '',
    status: 'Active',
    passingPercentage: 33,
    addSubjects: [] as number[],
    removeSubjectIds: [] as number[],
  });
  const [deleteExamTarget, setDeleteExamTarget] = useState<ExaminationRecord | null>(null);
  const [deletingExam, setDeletingExam] = useState(false);
  const [selectedIds, setSelectedIds] = useState<number[]>([]);
  const [bulkConfirm, setBulkConfirm] = useState<{
    action: 'delete' | 'archive' | 'restore' | 'open_entry' | 'close_entry' | 'set_active' | 'set_completed' | 'set_published';
    ids: number[];
    items: BulkConfirmItem[];
  } | null>(null);
  const [bulkBusy, setBulkBusy] = useState(false);
  const [undoState, setUndoState] = useState<{ ids: number[]; message: string } | null>(null);

  const [componentEdits, setComponentEdits] = useState<
    Record<number, { maxMarks: number; passingMarks: number }>
  >({});
  const [iaEdits, setIaEdits] = useState<
    Record<
      number,
      {
        hasInternalAssessment: boolean;
        iaNotebookMax: number;
        iaUnitTestMax: number;
        iaPracticalMax: number;
        iaParticipationMax: number;
      }
    >
  >({});
  const [targetClassEdits, setTargetClassEdits] = useState<Record<number, number[]>>({});
  const [error, setError] = useState<string | null>(null);
  const [modalError, setModalError] = useState<string | null>(null);

  const examTypesList =
    schoolInfo.examinationTypes && schoolInfo.examinationTypes.length > 0
      ? schoolInfo.examinationTypes
      : ['Regular', 'Unit Test', 'Half-Yearly', 'Annual'];

  const [newExam, setNewExam] = useState({
    name: '',
    examType: examTypesList[0] || 'Regular',
    academicYear: selectedAcademicYear,
    startDate: '2025-11-10',
    endDate: '2025-11-18',
    status: 'Active',
    marksEntryOpen: true,
    passingPercentage: schoolInfo.defaultPassPercentage,
  });

  useEffect(() => {
    setNewExam((prev) => ({ ...prev, academicYear: selectedAcademicYear }));
  }, [selectedAcademicYear]);

  const [selectedSubMap, setSelectedSubMap] = useState<
    Record<
      number,
      {
        enabled: boolean;
        hasInternalAssessment: boolean;
        iaNotebookMax: number;
        iaUnitTestMax: number;
        iaPracticalMax: number;
        iaParticipationMax: number;
        targetClassIds: number[];
        components: Record<number, { maxMarks: number; passingMarks: number; name: string }>;
      }
    >
  >({});

  const loadSubjects = async () => {
    try {
      const subs = await apiFetch<SubjectRecord[]>('/api/admin/subjects');
      setSubjects(subs);
      const init: typeof selectedSubMap = {};
      for (const s of subs) {
        const compObj: Record<number, { maxMarks: number; passingMarks: number; name: string }> = {};
        for (const c of s.components) {
          compObj[c.id] = {
            name: c.name,
            maxMarks: c.default_max_marks,
            passingMarks: Math.round(c.default_max_marks * 0.33),
          };
        }
        init[s.id] = {
          enabled: true,
          hasInternalAssessment: s.hasInternalAssessment,
          iaNotebookMax: s.iaNotebookMax ?? 5,
          iaUnitTestMax: s.iaUnitTestMax ?? 5,
          iaPracticalMax: s.iaPracticalMax ?? 5,
          iaParticipationMax: s.iaParticipationMax ?? 5,
          targetClassIds: s.applicableClassIds ? [...s.applicableClassIds] : [],
          components: compObj,
        };
      }
      setSelectedSubMap(init);
    } catch (err) {
      setError(extractErrorMessage(err));
    }
  };

  const loadArchived = async () => {
    setLoadingArchived(true);
    setError(null);
    try {
      const rows = await apiFetch<ExaminationRecord[]>('/api/examinations?view=archived');
      setArchivedExams(rows);
    } catch (err) {
      setError(extractErrorMessage(err));
    } finally {
      setLoadingArchived(false);
    }
  };

  useEffect(() => {
    loadSubjects();
  }, []);

  useEffect(() => {
    setSelectedIds([]);
    if (viewMode === 'archived') {
      loadArchived();
    }
  }, [viewMode]);

  const handleCreateExam = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    const chosenSubjects = subjects
      .filter((s) => selectedSubMap[s.id]?.enabled)
      .map((s) => {
        const cfgSub = selectedSubMap[s.id];
        const comps = s.components.map((c) => {
          const cfg = cfgSub.components[c.id];
          return {
            componentId: c.id,
            componentName: c.name,
            maxMarks: Number(cfg?.maxMarks ?? c.default_max_marks),
            passingMarks: Number(cfg?.passingMarks ?? Math.round(c.default_max_marks * 0.33)),
          };
        });
        const writtenMax =
          s.componentMode === 'elective'
            ? Number(comps[0]?.maxMarks || 0)
            : comps.reduce((sum, c) => sum + c.maxMarks, 0);
        const iaMax = cfgSub.hasInternalAssessment
          ? Number(cfgSub.iaNotebookMax || 0) +
            Number(cfgSub.iaUnitTestMax || 0) +
            Number(cfgSub.iaPracticalMax || 0) +
            Number(cfgSub.iaParticipationMax || 0)
          : 0;
        const totalPass = Math.round(((writtenMax + iaMax) * Number(newExam.passingPercentage || 33)) / 100);
        return {
          subjectId: s.id,
          passingMarks: totalPass,
          isRequired: true,
          hasInternalAssessment: cfgSub.hasInternalAssessment,
          iaNotebookMax: Number(cfgSub.iaNotebookMax || 0),
          iaUnitTestMax: Number(cfgSub.iaUnitTestMax || 0),
          iaPracticalMax: Number(cfgSub.iaPracticalMax || 0),
          iaParticipationMax: Number(cfgSub.iaParticipationMax || 0),
          targetClassIds: cfgSub.targetClassIds || [],
          components: comps,
        };
      });

    if (chosenSubjects.length === 0) {
      setModalError('Select at least one subject for the examination.');
      return;
    }

    setModalError(null);
    try {
      await apiFetch('/api/admin/examinations', {
        method: 'POST',
        body: JSON.stringify({ ...newExam, subjects: chosenSubjects }),
      });
      setCreateOpen(false);
      setNewExam({ ...newExam, name: '' });
      await onChanged();
    } catch (err) {
      setModalError(extractErrorMessage(err));
    }
  };

  const updateExamStatus = async (ex: ExaminationRecord, status: string, marksEntryOpen?: boolean) => {
    setError(null);
    try {
      await apiFetch(`/api/admin/examinations/${ex.id}`, {
        method: 'PUT',
        body: JSON.stringify({
          status,
          marksEntryOpen: marksEntryOpen === undefined ? ex.marksEntryOpen : marksEntryOpen,
        }),
      });
      await onChanged();
    } catch (err) {
      setError(extractErrorMessage(err));
    }
  };

  const openEditComponents = (ex: ExaminationRecord) => {
    setError(null);
    setModalError(null);
    setEditExam(ex);
    setEditMeta({
      name: ex.name,
      examType: ex.exam_type || examTypesList[0] || 'Regular',
      startDate: ex.start_date,
      endDate: ex.end_date,
      status: ex.status,
      passingPercentage: ex.passing_percentage,
      addSubjects: [],
      removeSubjectIds: [],
    });
    const map: Record<number, { maxMarks: number; passingMarks: number }> = {};
    const iaMap: typeof iaEdits = {};
    const targetMap: Record<number, number[]> = {};
    for (const sub of ex.subjects) {
      iaMap[sub.id] = {
        hasInternalAssessment: sub.hasInternalAssessment,
        iaNotebookMax: sub.iaNotebookMax ?? 5,
        iaUnitTestMax: sub.iaUnitTestMax ?? 5,
        iaPracticalMax: sub.iaPracticalMax ?? 5,
        iaParticipationMax: sub.iaParticipationMax ?? 5,
      };
      targetMap[sub.id] = sub.targetClassIds ? [...sub.targetClassIds] : [];
      for (const c of sub.components) {
        map[c.id] = { maxMarks: c.max_marks, passingMarks: c.passing_marks };
      }
    }
    setComponentEdits(map);
    setIaEdits(iaMap);
    setTargetClassEdits(targetMap);
  };

  const saveComponentEdits = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editExam) return;
    setError(null);
    setModalError(null);
    const componentUpdates = Object.entries(componentEdits).map(([id, vals]) => ({
      examComponentId: Number(id),
      maxMarks: vals.maxMarks,
      passingMarks: vals.passingMarks,
    }));
    const subjectIaUpdates = Object.entries(iaEdits).map(([id, vals]) => ({
      examSubjectId: Number(id),
      hasInternalAssessment: vals.hasInternalAssessment,
      iaNotebookMax: Number(vals.iaNotebookMax || 0),
      iaUnitTestMax: Number(vals.iaUnitTestMax || 0),
      iaPracticalMax: Number(vals.iaPracticalMax || 0),
      iaParticipationMax: Number(vals.iaParticipationMax || 0),
      targetClassIds: targetClassEdits[Number(id)] ?? [],
    }));
    try {
      await apiFetch(`/api/admin/examinations/${editExam.id}`, {
        method: 'PUT',
        body: JSON.stringify({
          name: editMeta.name,
          examType: editMeta.examType,
          startDate: editMeta.startDate,
          endDate: editMeta.endDate,
          status: editMeta.status,
          passingPercentage: Number(editMeta.passingPercentage || editExam.passing_percentage),
          addSubjects: editMeta.addSubjects,
          removeSubjectIds: editMeta.removeSubjectIds,
          componentUpdates,
          subjectIaUpdates,
        }),
      });
      setEditExam(null);
      await onChanged();
    } catch (err) {
      setModalError(extractErrorMessage(err));
    }
  };

  const confirmDeleteExam = async () => {
    if (!deleteExamTarget) return;
    setDeletingExam(true);
    setError(null);
    try {
      await apiFetch(`/api/admin/examinations/${deleteExamTarget.id}`, { method: 'DELETE' });
      const tid = deleteExamTarget.id;
      const tname = deleteExamTarget.name;
      setDeleteExamTarget(null);
      setUndoState({
        ids: [tid],
        message: `Archived examination "${tname}". Historical mark sheets and reports remain preserved.`,
      });
      await onChanged();
    } catch (err) {
      setError(extractErrorMessage(err));
      setDeleteExamTarget(null);
    } finally {
      setDeletingExam(false);
    }
  };

  const handleRestoreExam = async (id: number) => {
    setError(null);
    try {
      await apiFetch('/api/admin/examinations/bulk-action', {
        method: 'POST',
        body: JSON.stringify({ action: 'restore', ids: [id] }),
      });
      await loadArchived();
      await onChanged();
    } catch (err) {
      setError(extractErrorMessage(err));
    }
  };

  const sourceList = viewMode === 'active' ? examinations : archivedExams;

  const visibleExaminations = useMemo(() => {
    const q = searchQuery.trim().toLowerCase();
    return sourceList.filter((e) => {
      if (!showAllYears && e.academic_year !== selectedAcademicYear) return false;
      if (q) {
        const hay = `${e.name} ${e.exam_type || ''} ${e.academic_year} ${e.status}`.toLowerCase();
        if (!hay.includes(q)) return false;
      }
      return true;
    });
  }, [sourceList, showAllYears, selectedAcademicYear, searchQuery]);

  const {
    page,
    setPage,
    pageSize,
    setPageSize,
    pagedItems: pagedExams,
  } = usePagination(visibleExaminations, 10);

  useEffect(() => {
    setPage(1);
  }, [showAllYears, selectedAcademicYear, searchQuery, viewMode, setPage]);

  const pagedIds = pagedExams.map((e) => e.id);
  const allPagedSelected = pagedIds.length > 0 && pagedIds.every((id) => selectedIds.includes(id));

  const toggleSelect = (id: number) => {
    setSelectedIds((prev) => (prev.includes(id) ? prev.filter((x) => x !== id) : [...prev, id]));
  };

  const toggleSelectAllPage = () => {
    if (allPagedSelected) {
      setSelectedIds((prev) => prev.filter((id) => !pagedIds.includes(id)));
    } else {
      setSelectedIds((prev) => Array.from(new Set([...prev, ...pagedIds])));
    }
  };

  const openBulkExamConfirm = (
    action: 'delete' | 'archive' | 'restore' | 'open_entry' | 'close_entry' | 'set_active' | 'set_completed' | 'set_published'
  ) => {
    const chosen = sourceList.filter((ex) => selectedIds.includes(ex.id));
    if (chosen.length === 0) return;
    setBulkConfirm({
      action,
      ids: chosen.map((ex) => ex.id),
      items: chosen.map((ex) => ({
        id: ex.id,
        label: ex.name,
        sublabel: `${ex.academic_year} · ${ex.status}`,
      })),
    });
  };

  const executeBulkAction = async () => {
    if (!bulkConfirm) return;
    setBulkBusy(true);
    setError(null);
    try {
      await apiFetch('/api/admin/examinations/bulk-action', {
        method: 'POST',
        body: JSON.stringify({ action: bulkConfirm.action, ids: bulkConfirm.ids }),
      });
      const count = bulkConfirm.ids.length;
      if (bulkConfirm.action === 'delete' || bulkConfirm.action === 'archive') {
        setUndoState({
          ids: bulkConfirm.ids,
          message: `Archived ${count} examination${count === 1 ? '' : 's'}. Historical marks & report cards preserved.`,
        });
      } else {
        setUndoState(null);
      }
      setBulkConfirm(null);
      setSelectedIds([]);
      if (viewMode === 'archived') {
        await loadArchived();
      }
      await onChanged();
    } catch (err) {
      setError(extractErrorMessage(err));
      setBulkConfirm(null);
    } finally {
      setBulkBusy(false);
    }
  };

  const handleUndo = async () => {
    if (!undoState) return;
    setBulkBusy(true);
    setError(null);
    try {
      await apiFetch('/api/admin/examinations/bulk-action', {
        method: 'POST',
        body: JSON.stringify({ action: 'restore', ids: undoState.ids }),
      });
      setUndoState(null);
      if (viewMode === 'archived') await loadArchived();
      await onChanged();
    } catch (err) {
      setError(extractErrorMessage(err));
    } finally {
      setBulkBusy(false);
    }
  };

  return (
    <div className="space-y-4">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
        <div>
          <h2 className="text-lg font-bold text-slate-900">Examination Management</h2>
          <p className="text-xs text-slate-500">
            Configure examinations, maximum marks, components, and marks entry windows (
            {showAllYears ? 'All Academic Years' : `AY ${selectedAcademicYear}`})
          </p>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <div className="inline-flex p-1 bg-slate-100 rounded-xl border border-slate-200">
            <button
              type="button"
              onClick={() => setViewMode('active')}
              className={`min-h-[36px] px-3 py-1 text-xs font-semibold rounded-lg transition-colors cursor-pointer ${
                viewMode === 'active' ? 'bg-white text-[#1E3A5F] shadow-xs' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Active
            </button>
            <button
              type="button"
              onClick={() => setViewMode('archived')}
              className={`min-h-[36px] px-3 py-1 text-xs font-semibold rounded-lg transition-colors cursor-pointer ${
                viewMode === 'archived' ? 'bg-white text-[#1E3A5F] shadow-xs' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Archived
            </button>
          </div>
          {viewMode === 'active' && (
            <button
              type="button"
              onClick={() => {
                setModalError(null);
                setNewExam((p) => ({ ...p, academicYear: selectedAcademicYear }));
                setCreateOpen(true);
              }}
              className="min-h-[40px] inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-white bg-[#1E3A5F] rounded-lg hover:bg-[#162D4A] cursor-pointer"
            >
              <Plus className="w-3.5 h-3.5" />
              Create Examination
            </button>
          )}
        </div>
      </div>

      {/* Filters & Select Page Bar */}
      <div className="bg-white border border-slate-200 rounded-xl p-3 flex flex-wrap items-center justify-between gap-3 text-xs">
        <div className="flex flex-wrap items-center gap-2.5 flex-1">
          <div className="relative flex-1 min-w-[200px] sm:max-w-xs">
            <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search examination name or type..."
              className="w-full min-h-[38px] pl-8 pr-3 py-1.5 border border-slate-300 rounded-lg"
            />
          </div>
          <label className="min-h-[38px] inline-flex items-center gap-2 px-3 py-1.5 border border-slate-200 rounded-lg bg-slate-50 font-medium text-slate-700 cursor-pointer">
            <input
              type="checkbox"
              checked={showAllYears}
              onChange={(e) => setShowAllYears(e.target.checked)}
              className="rounded border-slate-300 text-[#1E3A5F]"
            />
            Show All Years
          </label>
        </div>
        {pagedIds.length > 0 && (
          <label className="min-h-[38px] inline-flex items-center gap-2 px-3 py-1.5 border border-slate-300 rounded-lg bg-white font-medium text-slate-700 cursor-pointer">
            <input
              type="checkbox"
              checked={allPagedSelected}
              onChange={toggleSelectAllPage}
              className="rounded border-slate-300"
            />
            Select Page ({pagedIds.length})
          </label>
        )}
      </div>

      {error && (
        <div className="p-3.5 rounded-xl bg-red-50 border border-red-200 flex flex-wrap items-center justify-between gap-2 text-xs text-red-800">
          <span>{error}</span>
          <button
            type="button"
            onClick={() => (viewMode === 'archived' ? loadArchived() : onChanged())}
            className="min-h-[34px] inline-flex items-center gap-1 px-3 py-1 bg-white border border-red-200 rounded-lg font-semibold text-red-800 hover:bg-red-100 cursor-pointer"
          >
            <RefreshCw className="w-3.5 h-3.5" />
            Retry
          </button>
        </div>
      )}

      {undoState && (
        <UndoBanner
          message={undoState.message}
          onUndo={handleUndo}
          onDismiss={() => setUndoState(null)}
          busy={bulkBusy}
        />
      )}

      {selectedIds.length > 0 && (
        <BulkActionToolbar
          selectedCount={selectedIds.length}
          entityLabel="examination"
          onClearSelection={() => setSelectedIds([])}
          disabled={bulkBusy}
          actions={
            viewMode === 'active'
              ? [
                  {
                    id: 'open-entry',
                    label: 'Open Entry',
                    icon: 'activate',
                    variant: 'success',
                    onClick: () => openBulkExamConfirm('open_entry'),
                  },
                  {
                    id: 'close-entry',
                    label: 'Close Entry',
                    icon: 'deactivate',
                    variant: 'warning',
                    onClick: () => openBulkExamConfirm('close_entry'),
                  },
                  {
                    id: 'set-published',
                    label: 'Publish',
                    icon: 'edit',
                    variant: 'primary',
                    onClick: () => openBulkExamConfirm('set_published'),
                  },
                  {
                    id: 'archive-exam',
                    label: 'Delete / Archive',
                    icon: 'delete',
                    variant: 'danger',
                    onClick: () => openBulkExamConfirm('delete'),
                  },
                ]
              : [
                  {
                    id: 'restore-exam',
                    label: 'Restore Selected',
                    icon: 'restore',
                    variant: 'success',
                    onClick: () => openBulkExamConfirm('restore'),
                  },
                ]
          }
        />
      )}

      <div className="space-y-4">
        {loadingArchived && viewMode === 'archived' ? (
          <div className="bg-white border border-slate-200 rounded-xl p-8 text-center text-xs text-slate-500">
            Loading archived examinations...
          </div>
        ) : pagedExams.length === 0 ? (
          <div className="bg-white border border-slate-200 rounded-xl p-8 text-center text-xs text-slate-500">
            {viewMode === 'archived'
              ? 'No archived examinations found.'
              : `No examinations configured yet for ${showAllYears ? 'selected filter' : `Academic Year ${selectedAcademicYear}`}.`}
          </div>
        ) : (
          <>
            {pagedExams.map((ex) => {
              const totalMax = ex.subjects.reduce((s, sub) => s + sub.max_marks, 0);
              const isSelected = selectedIds.includes(ex.id);
              return (
                <div
                  key={ex.id}
                  className={`bg-white border rounded-xl p-4 sm:p-5 space-y-4 ${
                    isSelected ? 'border-[#1E3A5F] ring-1 ring-[#1E3A5F]/20' : 'border-slate-200'
                  }`}
                >
                  <div className="flex flex-col lg:flex-row lg:items-start lg:justify-between gap-4">
                    <div className="flex items-start gap-3 min-w-0">
                      <input
                        type="checkbox"
                        checked={isSelected}
                        onChange={() => toggleSelect(ex.id)}
                        aria-label={`Select ${ex.name}`}
                        className="mt-1 w-4 h-4 rounded border-slate-300 cursor-pointer shrink-0"
                      />
                      <div className="min-w-0">
                        <div className="flex flex-wrap items-center gap-2.5">
                          <h3 className="text-base font-bold text-slate-900">{ex.name}</h3>
                          {ex.exam_type && (
                            <span className="text-xs font-medium text-indigo-800">{ex.exam_type}</span>
                          )}
                          <ExamStatusLabel status={ex.status} marksEntryOpen={ex.marksEntryOpen} />
                        </div>
                        <div className="text-xs text-slate-500 mt-1 font-mono tabular-nums">
                          {ex.academic_year} · {ex.start_date} to {ex.end_date} · Pass Criteria:{' '}
                          {ex.passing_percentage}% · Total Max: {totalMax} Marks
                        </div>
                      </div>
                    </div>

                    {viewMode === 'active' ? (
                      <div className="flex flex-wrap items-center gap-2 text-xs">
                        <select
                          value={ex.status}
                          onChange={(e) => updateExamStatus(ex, e.target.value)}
                          className="min-h-[38px] px-2.5 py-1.5 border border-slate-300 rounded-lg bg-white font-medium"
                        >
                          <option value="Upcoming">Upcoming</option>
                          <option value="Active">Active</option>
                          <option value="Completed">Completed</option>
                          <option value="Published">Published</option>
                        </select>
                        <button
                          type="button"
                          onClick={() => updateExamStatus(ex, ex.status, !ex.marksEntryOpen)}
                          className={`min-h-[38px] inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg border font-medium cursor-pointer ${
                            ex.marksEntryOpen
                              ? 'bg-emerald-50 border-emerald-200 text-emerald-800 hover:bg-emerald-100'
                              : 'bg-slate-100 border-slate-300 text-slate-700 hover:bg-slate-200'
                          }`}
                        >
                          {ex.marksEntryOpen ? <Unlock className="w-3.5 h-3.5" /> : <Lock className="w-3.5 h-3.5" />}
                          {ex.marksEntryOpen ? 'Marks Entry Open' : 'Marks Entry Closed'}
                        </button>
                        <button
                          type="button"
                          onClick={() => openEditComponents(ex)}
                          className="min-h-[38px] inline-flex items-center gap-1 px-3 py-1.5 border border-slate-300 rounded-lg hover:bg-slate-50 font-medium cursor-pointer"
                        >
                          <SlidersHorizontal className="w-3.5 h-3.5" />
                          Edit &amp; Configure Marks
                        </button>
                        <button
                          type="button"
                          onClick={() => setDeleteExamTarget(ex)}
                          className="min-h-[38px] min-w-[38px] inline-flex items-center justify-center p-1.5 text-red-600 hover:bg-red-50 rounded-lg cursor-pointer"
                          title="Archive / Soft-Delete Examination"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    ) : (
                      <div className="flex items-center gap-2">
                        <button
                          type="button"
                          onClick={() => handleRestoreExam(ex.id)}
                          className="min-h-[38px] inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-emerald-800 bg-emerald-50 border border-emerald-200 rounded-lg hover:bg-emerald-100 cursor-pointer"
                        >
                          <RotateCcw className="w-3.5 h-3.5" />
                          Restore Examination
                        </button>
                      </div>
                    )}
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2.5 pt-2 border-t border-slate-100">
                    {ex.subjects.map((sub) => {
                      const targetLabels =
                        sub.targetClassIds && sub.targetClassIds.length > 0
                          ? sub.targetClassIds
                              .map((cid) => schoolInfo.classes.find((c) => c.id === cid)?.name)
                              .filter(Boolean)
                              .join(', ')
                          : '';
                      return (
                        <div key={sub.id} className="p-2.5 bg-slate-50 border border-slate-200 rounded-lg text-xs">
                          <div className="flex items-center justify-between font-semibold text-slate-900 gap-2">
                            <span className="truncate">{sub.subject_name}</span>
                            <span className="font-mono text-[#1E3A5F] tabular-nums shrink-0">{sub.max_marks} Marks</span>
                          </div>
                          {(sub.streamCategory || sub.hasPractical || targetLabels) && (
                            <div className="flex flex-wrap items-center gap-1 mt-1 text-[10px]">
                              {sub.streamCategory && (
                                <span className="px-1.5 py-0.5 rounded bg-indigo-50 text-indigo-800 border border-indigo-200">
                                  {sub.streamCategory}
                                </span>
                              )}
                              {sub.hasPractical && (
                                <span className="px-1.5 py-0.5 rounded bg-sky-50 text-sky-800 border border-sky-200">
                                  Practical
                                </span>
                              )}
                              {targetLabels && (
                                <span className="px-1.5 py-0.5 rounded bg-amber-50 text-amber-800 border border-amber-200">
                                  {targetLabels}
                                </span>
                              )}
                            </div>
                          )}
                          {sub.components.length > 1 && (
                            <div className="mt-1 text-[11px] text-slate-600">
                              {sub.components.map((c) => `${c.component_name} (${c.max_marks})`).join(' · ')}
                            </div>
                          )}
                          {sub.hasInternalAssessment && (
                            <div className="mt-1 text-[11px] font-mono text-sky-800">
                              Exam {sub.writtenMaxMarks} + IA {sub.iaMaxMarks} (NB {sub.iaNotebookMax} · UT{' '}
                              {sub.iaUnitTestMax} · Pr {sub.iaPracticalMax} · OP {sub.iaParticipationMax})
                            </div>
                          )}
                        </div>
                      );
                    })}
                  </div>
                </div>
              );
            })}

            <div className="bg-white border border-slate-200 rounded-xl overflow-hidden">
              <PaginationBar
                totalItems={visibleExaminations.length}
                page={page}
                pageSize={pageSize}
                onPageChange={setPage}
                onPageSizeChange={setPageSize}
              />
            </div>
          </>
        )}
      </div>

      {/* Bulk Confirm Modal */}
      <BulkConfirmModal
        open={Boolean(bulkConfirm)}
        title={
          bulkConfirm
            ? `Confirm ${bulkConfirm.action.replace('_', ' ')} for ${bulkConfirm.items.length} examination(s)?`
            : ''
        }
        confirmLabel="Confirm Action"
        description={
          bulkConfirm?.action === 'delete' || bulkConfirm?.action === 'archive'
            ? `Archive ${bulkConfirm.items.length} selected examination(s)?`
            : `Apply status update to ${bulkConfirm?.items.length || 0} selected examination(s).`
        }
        safetyNote={
          bulkConfirm?.action === 'delete' || bulkConfirm?.action === 'archive'
            ? 'Historical student mark sheets, IA scores, and report cards are preserved and can be restored anytime from the Archived tab.'
            : undefined
        }
        items={bulkConfirm?.items || []}
        variant={
          bulkConfirm?.action === 'delete' || bulkConfirm?.action === 'archive'
            ? 'danger'
            : bulkConfirm?.action === 'close_entry'
              ? 'warning'
              : 'primary'
        }
        busy={bulkBusy}
        onCancel={() => setBulkConfirm(null)}
        onConfirm={executeBulkAction}
      />

      {/* Create Examination Modal */}
      {createOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/50 p-4">
          <form
            onSubmit={handleCreateExam}
            className="bg-white border border-slate-200 rounded-xl w-full max-w-2xl max-h-[90vh] overflow-y-auto p-6 space-y-5 shadow-xl text-xs"
          >
            <div className="flex items-center justify-between">
              <h3 className="text-base font-bold text-slate-900">Create New Examination</h3>
              <button type="button" onClick={() => setCreateOpen(false)} className="p-1 cursor-pointer">
                <X className="w-4 h-4 text-slate-400" />
              </button>
            </div>
            {modalError && (
              <div className="p-2.5 rounded-lg bg-red-50 border border-red-200 text-red-800 font-medium">
                {modalError}
              </div>
            )}

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div>
                <label className="block font-semibold text-slate-700 mb-1">Examination Name *</label>
                <input
                  type="text"
                  required
                  value={newExam.name}
                  onChange={(e) => setNewExam({ ...newExam, name: e.target.value })}
                  placeholder="e.g. Unit Test 2"
                  className="w-full min-h-[40px] px-3 py-2 border border-slate-300 rounded-lg"
                />
              </div>
              <div>
                <label className="block font-semibold text-slate-700 mb-1">Examination Type</label>
                <select
                  value={newExam.examType}
                  onChange={(e) => setNewExam({ ...newExam, examType: e.target.value })}
                  className="w-full min-h-[40px] px-3 py-2 border border-slate-300 rounded-lg bg-white"
                >
                  {examTypesList.map((t) => (
                    <option key={t} value={t}>
                      {t}
                    </option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block font-semibold text-slate-700 mb-1">Academic Year</label>
                <input
                  type="text"
                  value={newExam.academicYear}
                  onChange={(e) => setNewExam({ ...newExam, academicYear: e.target.value })}
                  className="w-full min-h-[40px] px-3 py-2 border border-slate-300 rounded-lg font-mono"
                />
              </div>
              <div>
                <label className="block font-semibold text-slate-700 mb-1">Start Date *</label>
                <input
                  type="date"
                  required
                  value={newExam.startDate}
                  onChange={(e) => setNewExam({ ...newExam, startDate: e.target.value })}
                  className="w-full min-h-[40px] px-3 py-2 border border-slate-300 rounded-lg"
                />
              </div>
              <div>
                <label className="block font-semibold text-slate-700 mb-1">End Date *</label>
                <input
                  type="date"
                  required
                  value={newExam.endDate}
                  onChange={(e) => setNewExam({ ...newExam, endDate: e.target.value })}
                  className="w-full min-h-[40px] px-3 py-2 border border-slate-300 rounded-lg"
                />
              </div>
              <div>
                <label className="block font-semibold text-slate-700 mb-1">Pass % Criteria</label>
                <input
                  type="number"
                  min={1}
                  max={100}
                  value={newExam.passingPercentage}
                  onChange={(e) => setNewExam({ ...newExam, passingPercentage: Number(e.target.value) })}
                  className="w-full min-h-[40px] px-3 py-2 border border-slate-300 rounded-lg font-mono"
                />
              </div>
            </div>

            <div className="space-y-2.5">
              <div className="font-semibold text-slate-800">Configure Subjects, Components &amp; Internal Assessment</div>
              {subjects.map((sub) => {
                const subCfg = selectedSubMap[sub.id];
                if (!subCfg) return null;
                const writtenTotal =
                  sub.componentMode === 'elective'
                    ? Number(subCfg.components[sub.components[0]?.id]?.maxMarks ?? sub.components[0]?.default_max_marks ?? 0)
                    : sub.components.reduce(
                        (sum, c) => sum + Number(subCfg.components[c.id]?.maxMarks ?? c.default_max_marks),
                        0
                      );
                const iaTotal = subCfg.hasInternalAssessment
                  ? Number(subCfg.iaNotebookMax || 0) +
                    Number(subCfg.iaUnitTestMax || 0) +
                    Number(subCfg.iaPracticalMax || 0) +
                    Number(subCfg.iaParticipationMax || 0)
                  : 0;
                return (
                  <div key={sub.id} className="p-3 border border-slate-200 rounded-lg space-y-2">
                    <div className="flex flex-wrap items-center justify-between gap-2">
                      <label className="flex items-center gap-2 font-semibold text-slate-900">
                        <input
                          type="checkbox"
                          checked={subCfg.enabled}
                          onChange={(e) =>
                            setSelectedSubMap((p) => ({
                              ...p,
                              [sub.id]: { ...p[sub.id], enabled: e.target.checked },
                            }))
                          }
                        />
                        {sub.name}
                        {sub.componentMode === 'elective' && (
                          <span className="text-[11px] font-normal text-amber-700">
                            (Elective — 1 option per student)
                          </span>
                        )}
                      </label>
                      {subCfg.enabled && (
                        <span className="font-mono text-[11px] font-semibold text-[#1E3A5F] tabular-nums">
                          Total: {writtenTotal + iaTotal} Marks
                        </span>
                      )}
                    </div>
                    {subCfg.enabled && (
                      <div className="space-y-2 pl-2 sm:pl-5">
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                          {sub.components.map((c) => {
                            const cCfg = subCfg.components[c.id];
                            return (
                              <div key={c.id} className="flex items-center justify-between gap-2 bg-slate-50 p-2 rounded">
                                <span className="font-medium text-slate-700">{c.name}</span>
                                <div className="flex items-center gap-1.5">
                                  <span className="text-slate-500">Exam Max:</span>
                                  <input
                                    type="number"
                                    min={1}
                                    value={cCfg?.maxMarks ?? c.default_max_marks}
                                    onChange={(e) => {
                                      const maxVal = Number(e.target.value);
                                      setSelectedSubMap((p) => ({
                                        ...p,
                                        [sub.id]: {
                                          ...p[sub.id],
                                          components: {
                                            ...p[sub.id].components,
                                            [c.id]: {
                                              ...p[sub.id].components[c.id],
                                              maxMarks: maxVal,
                                              passingMarks: Math.round(maxVal * 0.33),
                                            },
                                          },
                                        },
                                      }));
                                    }}
                                    className="w-16 px-2 py-1 border border-slate-300 rounded font-mono bg-white"
                                  />
                                </div>
                              </div>
                            );
                          })}
                        </div>
                        <div className="flex flex-wrap items-center justify-between gap-2 bg-sky-50/70 border border-sky-100 p-2 rounded">
                          <label className="inline-flex items-center gap-1.5 font-medium text-sky-900">
                            <input
                              type="checkbox"
                              checked={subCfg.hasInternalAssessment}
                              onChange={(e) =>
                                setSelectedSubMap((p) => ({
                                  ...p,
                                  [sub.id]: { ...p[sub.id], hasInternalAssessment: e.target.checked },
                                }))
                              }
                            />
                            Internal Assessment
                          </label>
                          {subCfg.hasInternalAssessment && (
                            <div className="flex flex-wrap items-center gap-2 text-[11px]">
                              <label className="flex items-center gap-1">
                                <span className="text-slate-600">NB:</span>
                                <input
                                  type="number"
                                  min={0}
                                  value={subCfg.iaNotebookMax}
                                  onChange={(e) =>
                                    setSelectedSubMap((p) => ({
                                      ...p,
                                      [sub.id]: { ...p[sub.id], iaNotebookMax: Number(e.target.value) },
                                    }))
                                  }
                                  className="w-12 px-1.5 py-1 border border-slate-300 rounded font-mono bg-white"
                                />
                              </label>
                              <label className="flex items-center gap-1">
                                <span className="text-slate-600">UT:</span>
                                <input
                                  type="number"
                                  min={0}
                                  value={subCfg.iaUnitTestMax}
                                  onChange={(e) =>
                                    setSelectedSubMap((p) => ({
                                      ...p,
                                      [sub.id]: { ...p[sub.id], iaUnitTestMax: Number(e.target.value) },
                                    }))
                                  }
                                  className="w-12 px-1.5 py-1 border border-slate-300 rounded font-mono bg-white"
                                />
                              </label>
                              <label className="flex items-center gap-1">
                                <span className="text-slate-600">Pr:</span>
                                <input
                                  type="number"
                                  min={0}
                                  value={subCfg.iaPracticalMax}
                                  onChange={(e) =>
                                    setSelectedSubMap((p) => ({
                                      ...p,
                                      [sub.id]: { ...p[sub.id], iaPracticalMax: Number(e.target.value) },
                                    }))
                                  }
                                  className="w-12 px-1.5 py-1 border border-slate-300 rounded font-mono bg-white"
                                />
                              </label>
                              <label className="flex items-center gap-1">
                                <span className="text-slate-600">OP:</span>
                                <input
                                  type="number"
                                  min={0}
                                  value={subCfg.iaParticipationMax}
                                  onChange={(e) =>
                                    setSelectedSubMap((p) => ({
                                      ...p,
                                      [sub.id]: { ...p[sub.id], iaParticipationMax: Number(e.target.value) },
                                    }))
                                  }
                                  className="w-12 px-1.5 py-1 border border-slate-300 rounded font-mono bg-white"
                                />
                              </label>
                            </div>
                          )}
                        </div>
                        <div className="flex flex-wrap items-center gap-1.5 text-[11px] pt-0.5">
                          <span className="text-slate-500 font-medium mr-1">Applies to Classes:</span>
                          <button
                            type="button"
                            onClick={() =>
                              setSelectedSubMap((p) => ({
                                ...p,
                                [sub.id]: { ...p[sub.id], targetClassIds: [] },
                              }))
                            }
                            className={`px-2 py-0.5 rounded border cursor-pointer ${
                              subCfg.targetClassIds.length === 0
                                ? 'bg-[#1E3A5F] text-white border-[#1E3A5F]'
                                : 'bg-white text-slate-600 border-slate-300'
                            }`}
                          >
                            All Classes
                          </button>
                          {schoolInfo.classes.map((cls) => {
                            const active = subCfg.targetClassIds.includes(cls.id);
                            return (
                              <button
                                key={cls.id}
                                type="button"
                                onClick={() =>
                                  setSelectedSubMap((p) => {
                                    const cur = p[sub.id].targetClassIds || [];
                                    const next = cur.includes(cls.id)
                                      ? cur.filter((id) => id !== cls.id)
                                      : [...cur, cls.id];
                                    return {
                                      ...p,
                                      [sub.id]: { ...p[sub.id], targetClassIds: next },
                                    };
                                  })
                                }
                                className={`px-2 py-0.5 rounded border cursor-pointer ${
                                  active
                                    ? 'bg-indigo-600 text-white border-indigo-600'
                                    : 'bg-white text-slate-600 border-slate-300 hover:bg-slate-50'
                                }`}
                              >
                                {cls.name}
                              </button>
                            );
                          })}
                        </div>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>

            <div className="flex flex-col-reverse sm:flex-row sm:justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setCreateOpen(false)}
                className="min-h-[40px] px-3.5 py-2 border border-slate-300 rounded-lg cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="min-h-[40px] px-4 py-2 font-semibold text-white bg-[#1E3A5F] rounded-lg cursor-pointer"
              >
                Create Examination
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Edit Examination & Configure Marks Modal */}
      {editExam && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/50 p-4">
          <form
            onSubmit={saveComponentEdits}
            className="bg-white border border-slate-200 rounded-xl w-full max-w-2xl max-h-[90vh] overflow-y-auto p-6 space-y-4 shadow-xl text-xs"
          >
            <div className="flex items-center justify-between">
              <h3 className="text-base font-bold text-slate-900">
                Edit Examination &amp; Marks — {editExam.name}
              </h3>
              <button type="button" onClick={() => setEditExam(null)} className="p-1 cursor-pointer">
                <X className="w-4 h-4 text-slate-400" />
              </button>
            </div>
            {modalError && (
              <div className="p-2.5 rounded-lg bg-red-50 border border-red-200 text-red-800 font-medium">
                {modalError}
              </div>
            )}

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 p-3 bg-slate-50 border border-slate-200 rounded-lg">
              <div>
                <label className="block font-semibold text-slate-700 mb-1">Exam Name *</label>
                <input
                  type="text"
                  required
                  value={editMeta.name}
                  onChange={(e) => setEditMeta({ ...editMeta, name: e.target.value })}
                  className="w-full min-h-[38px] px-2.5 py-1.5 border border-slate-300 rounded bg-white"
                />
              </div>
              <div>
                <label className="block font-semibold text-slate-700 mb-1">Exam Type</label>
                <select
                  value={editMeta.examType}
                  onChange={(e) => setEditMeta({ ...editMeta, examType: e.target.value })}
                  className="w-full min-h-[38px] px-2.5 py-1.5 border border-slate-300 rounded bg-white"
                >
                  {!examTypesList.includes(editMeta.examType) && (
                    <option value={editMeta.examType}>{editMeta.examType}</option>
                  )}
                  {examTypesList.map((t) => (
                    <option key={t} value={t}>
                      {t}
                    </option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block font-semibold text-slate-700 mb-1">Pass % Criteria</label>
                <input
                  type="number"
                  min={1}
                  max={100}
                  value={editMeta.passingPercentage}
                  onChange={(e) => setEditMeta({ ...editMeta, passingPercentage: Number(e.target.value) })}
                  className="w-full min-h-[38px] px-2.5 py-1.5 border border-slate-300 rounded bg-white font-mono"
                />
              </div>
              <div>
                <label className="block font-semibold text-slate-700 mb-1">Start Date</label>
                <input
                  type="date"
                  required
                  value={editMeta.startDate}
                  onChange={(e) => setEditMeta({ ...editMeta, startDate: e.target.value })}
                  className="w-full min-h-[38px] px-2.5 py-1.5 border border-slate-300 rounded bg-white"
                />
              </div>
              <div>
                <label className="block font-semibold text-slate-700 mb-1">End Date</label>
                <input
                  type="date"
                  required
                  value={editMeta.endDate}
                  onChange={(e) => setEditMeta({ ...editMeta, endDate: e.target.value })}
                  className="w-full min-h-[38px] px-2.5 py-1.5 border border-slate-300 rounded bg-white"
                />
              </div>
              <div>
                <label className="block font-semibold text-slate-700 mb-1">Status</label>
                <select
                  value={editMeta.status}
                  onChange={(e) => setEditMeta({ ...editMeta, status: e.target.value })}
                  className="w-full min-h-[38px] px-2.5 py-1.5 border border-slate-300 rounded bg-white"
                >
                  <option value="Upcoming">Upcoming</option>
                  <option value="Active">Active</option>
                  <option value="Completed">Completed</option>
                  <option value="Published">Published</option>
                </select>
              </div>
            </div>

            <div className="space-y-3">
              {editExam.subjects
                .filter((sub) => !editMeta.removeSubjectIds.includes(sub.subject_id))
                .map((sub) => {
                  const iaCfg = iaEdits[sub.id] || {
                    hasInternalAssessment: sub.hasInternalAssessment,
                    iaNotebookMax: sub.iaNotebookMax,
                    iaUnitTestMax: sub.iaUnitTestMax,
                    iaPracticalMax: sub.iaPracticalMax,
                    iaParticipationMax: sub.iaParticipationMax,
                  };
                  const writtenTotal =
                    sub.componentMode === 'elective'
                      ? Number(componentEdits[sub.components[0]?.id]?.maxMarks ?? sub.components[0]?.max_marks ?? 0)
                      : sub.components.reduce(
                          (sum, c) => sum + Number(componentEdits[c.id]?.maxMarks ?? c.max_marks),
                          0
                        );
                  const iaTotal = iaCfg.hasInternalAssessment
                    ? Number(iaCfg.iaNotebookMax || 0) +
                      Number(iaCfg.iaUnitTestMax || 0) +
                      Number(iaCfg.iaPracticalMax || 0) +
                      Number(iaCfg.iaParticipationMax || 0)
                    : 0;
                  return (
                    <div key={sub.id} className="border border-slate-200 rounded-lg p-3 space-y-2">
                      <div className="flex flex-wrap items-center justify-between gap-2">
                        <span className="font-semibold text-slate-900">
                          {sub.subject_name}
                          {sub.componentMode === 'elective' && (
                            <span className="ml-2 text-[11px] font-normal text-amber-700">
                              (Elective — 1 option per student)
                            </span>
                          )}
                        </span>
                        <div className="flex items-center gap-2">
                          <span className="font-mono font-bold text-[#1E3A5F] tabular-nums">
                            Total: {writtenTotal + iaTotal} Marks
                          </span>
                          <button
                            type="button"
                            onClick={() =>
                              setEditMeta((p) => ({
                                ...p,
                                removeSubjectIds: [...p.removeSubjectIds, sub.subject_id],
                              }))
                            }
                            className="text-red-600 hover:text-red-800 px-1.5 py-0.5 rounded hover:bg-red-50 cursor-pointer"
                            title="Remove subject from this exam"
                          >
                            Remove
                          </button>
                        </div>
                      </div>
                      {sub.components.map((c) => (
                        <div
                          key={c.id}
                          className="flex flex-wrap items-center justify-between gap-3 bg-slate-50 px-3 py-2 rounded"
                        >
                          <span className="font-medium text-slate-700">{c.component_name}</span>
                          <div className="flex items-center gap-3">
                            <label className="flex items-center gap-1.5">
                              <span className="text-slate-500">Max:</span>
                              <input
                                type="number"
                                min={1}
                                value={componentEdits[c.id]?.maxMarks ?? c.max_marks}
                                onChange={(e) =>
                                  setComponentEdits((p) => ({
                                    ...p,
                                    [c.id]: { ...p[c.id], maxMarks: Number(e.target.value) },
                                  }))
                                }
                                className="w-16 px-2 py-1 border border-slate-300 rounded font-mono bg-white"
                              />
                            </label>
                            <label className="flex items-center gap-1.5">
                              <span className="text-slate-500">Pass:</span>
                              <input
                                type="number"
                                min={0}
                                value={componentEdits[c.id]?.passingMarks ?? c.passing_marks}
                                onChange={(e) =>
                                  setComponentEdits((p) => ({
                                    ...p,
                                    [c.id]: { ...p[c.id], passingMarks: Number(e.target.value) },
                                  }))
                                }
                                className="w-16 px-2 py-1 border border-slate-300 rounded font-mono bg-white"
                              />
                            </label>
                          </div>
                        </div>
                      ))}
                      <div className="flex flex-wrap items-center justify-between gap-2 bg-sky-50/70 border border-sky-100 px-3 py-2 rounded">
                        <label className="inline-flex items-center gap-1.5 font-medium text-sky-900">
                          <input
                            type="checkbox"
                            checked={iaCfg.hasInternalAssessment}
                            onChange={(e) =>
                              setIaEdits((p) => ({
                                ...p,
                                [sub.id]: { ...iaCfg, hasInternalAssessment: e.target.checked },
                              }))
                            }
                          />
                          Internal Assessment (IA)
                        </label>
                        {iaCfg.hasInternalAssessment && (
                          <div className="flex flex-wrap items-center gap-2 text-[11px]">
                            <label className="flex items-center gap-1">
                              <span className="text-slate-600">NB:</span>
                              <input
                                type="number"
                                min={0}
                                value={iaCfg.iaNotebookMax}
                                onChange={(e) =>
                                  setIaEdits((p) => ({
                                    ...p,
                                    [sub.id]: { ...iaCfg, iaNotebookMax: Number(e.target.value) },
                                  }))
                                }
                                className="w-14 px-1.5 py-1 border border-slate-300 rounded font-mono bg-white"
                              />
                            </label>
                            <label className="flex items-center gap-1">
                              <span className="text-slate-600">UT:</span>
                              <input
                                type="number"
                                min={0}
                                value={iaCfg.iaUnitTestMax}
                                onChange={(e) =>
                                  setIaEdits((p) => ({
                                    ...p,
                                    [sub.id]: { ...iaCfg, iaUnitTestMax: Number(e.target.value) },
                                  }))
                                }
                                className="w-14 px-1.5 py-1 border border-slate-300 rounded font-mono bg-white"
                              />
                            </label>
                            <label className="flex items-center gap-1">
                              <span className="text-slate-600">Pr:</span>
                              <input
                                type="number"
                                min={0}
                                value={iaCfg.iaPracticalMax}
                                onChange={(e) =>
                                  setIaEdits((p) => ({
                                    ...p,
                                    [sub.id]: { ...iaCfg, iaPracticalMax: Number(e.target.value) },
                                  }))
                                }
                                className="w-14 px-1.5 py-1 border border-slate-300 rounded font-mono bg-white"
                              />
                            </label>
                            <label className="flex items-center gap-1">
                              <span className="text-slate-600">OP:</span>
                              <input
                                type="number"
                                min={0}
                                value={iaCfg.iaParticipationMax}
                                onChange={(e) =>
                                  setIaEdits((p) => ({
                                    ...p,
                                    [sub.id]: { ...iaCfg, iaParticipationMax: Number(e.target.value) },
                                  }))
                                }
                                className="w-14 px-1.5 py-1 border border-slate-300 rounded font-mono bg-white"
                              />
                            </label>
                          </div>
                        )}
                      </div>
                      <div className="flex flex-wrap items-center gap-1.5 text-[11px] pt-0.5">
                        <span className="text-slate-500 font-medium mr-1">Applies to Classes:</span>
                        <button
                          type="button"
                          onClick={() => setTargetClassEdits((p) => ({ ...p, [sub.id]: [] }))}
                          className={`px-2 py-0.5 rounded border cursor-pointer ${
                            (targetClassEdits[sub.id] || []).length === 0
                              ? 'bg-[#1E3A5F] text-white border-[#1E3A5F]'
                              : 'bg-white text-slate-600 border-slate-300'
                          }`}
                        >
                          All Classes
                        </button>
                        {schoolInfo.classes.map((cls) => {
                          const cur = targetClassEdits[sub.id] || [];
                          const active = cur.includes(cls.id);
                          return (
                            <button
                              key={cls.id}
                              type="button"
                              onClick={() =>
                                setTargetClassEdits((p) => {
                                  const prev = p[sub.id] || [];
                                  const next = prev.includes(cls.id)
                                    ? prev.filter((id) => id !== cls.id)
                                    : [...prev, cls.id];
                                  return { ...p, [sub.id]: next };
                                })
                              }
                              className={`px-2 py-0.5 rounded border cursor-pointer ${
                                active
                                  ? 'bg-indigo-600 text-white border-indigo-600'
                                  : 'bg-white text-slate-600 border-slate-300 hover:bg-slate-50'
                              }`}
                            >
                              {cls.name}
                            </button>
                          );
                        })}
                      </div>
                    </div>
                  );
                })}
            </div>

            {subjects.some(
              (s) =>
                !editExam.subjects.some((es) => es.subject_id === s.id) ||
                editMeta.removeSubjectIds.includes(s.id)
            ) && (
              <div className="p-3 bg-slate-50 border border-slate-200 rounded-lg space-y-2">
                <div className="font-semibold text-slate-700">Add Subjects to Examination</div>
                <div className="flex flex-wrap gap-2">
                  {subjects
                    .filter(
                      (s) =>
                        !editExam.subjects.some((es) => es.subject_id === s.id) ||
                        editMeta.removeSubjectIds.includes(s.id)
                    )
                    .map((s) => {
                      const checked = editMeta.addSubjects.includes(s.id);
                      return (
                        <label
                          key={s.id}
                          className="inline-flex items-center gap-1.5 px-2.5 py-1 bg-white border border-slate-200 rounded-md cursor-pointer"
                        >
                          <input
                            type="checkbox"
                            checked={checked}
                            onChange={(e) => {
                              if (editMeta.removeSubjectIds.includes(s.id)) {
                                setEditMeta((p) => ({
                                  ...p,
                                  removeSubjectIds: p.removeSubjectIds.filter((id) => id !== s.id),
                                }));
                                return;
                              }
                              setEditMeta((p) => ({
                                ...p,
                                addSubjects: e.target.checked
                                  ? [...p.addSubjects, s.id]
                                  : p.addSubjects.filter((id) => id !== s.id),
                              }));
                            }}
                          />
                          <span>{s.name}</span>
                        </label>
                      );
                    })}
                </div>
              </div>
            )}

            <div className="flex flex-col-reverse sm:flex-row sm:justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setEditExam(null)}
                className="min-h-[40px] px-3.5 py-2 border border-slate-300 rounded-lg cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="min-h-[40px] px-4 py-2 font-semibold text-white bg-[#1E3A5F] rounded-lg cursor-pointer"
              >
                Save Configuration
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Archive Examination Confirmation Modal */}
      {deleteExamTarget && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/50 p-4">
          <div className="bg-white border border-slate-200 rounded-xl w-full max-w-sm p-6 space-y-4 shadow-xl text-xs">
            <h3 className="text-base font-bold text-slate-900">Archive / Soft-Delete Examination</h3>
            <p className="text-slate-600 leading-relaxed">
              Archive <span className="font-semibold text-slate-900">{deleteExamTarget.name}</span> (
              <span className="font-mono">{deleteExamTarget.academic_year}</span>)?
            </p>
            <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-lg text-emerald-900">
              All subject mark sheets and internal assessment records saved for this examination remain safely
              preserved. You can restore this examination anytime from the Archived tab.
            </div>
            <div className="flex flex-col-reverse sm:flex-row sm:justify-end gap-2">
              <button
                type="button"
                disabled={deletingExam}
                onClick={() => setDeleteExamTarget(null)}
                className="min-h-[40px] px-3.5 py-2 border border-slate-300 rounded-lg hover:bg-slate-50 cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="button"
                disabled={deletingExam}
                onClick={confirmDeleteExam}
                className="min-h-[40px] px-4 py-2 font-semibold text-white bg-red-600 rounded-lg hover:bg-red-700 disabled:opacity-50 cursor-pointer"
              >
                {deletingExam ? 'Archiving...' : 'Archive Examination'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export function AdminMonitoringView({
  schoolInfo,
  examinations,
  selectedAcademicYear,
  onChanged,
}: {
  schoolInfo: SchoolInfo;
  examinations: ExaminationRecord[];
  selectedAcademicYear: string;
  onChanged: () => Promise<void> | void;
}) {
  const yearExaminations = examinations.filter((e) => e.academic_year === selectedAcademicYear);
  const [selectedExamId, setSelectedExamId] = useState<number>(() => {
    const pool = yearExaminations.length > 0 ? yearExaminations : examinations;
    const active = pool.find((e) => e.status === 'Active') || pool.find((e) => e.status === 'Published');
    return active?.id || pool[0]?.id || 0;
  });
  const [filterClassId, setFilterClassId] = useState('');
  const [filterSectionId, setFilterSectionId] = useState('');
  const [filterStatus, setFilterStatus] = useState<'all' | 'Submitted' | 'Draft' | 'Pending'>('all');
  const [rows, setRows] = useState<MonitoringRow[]>([]);
  const [requests, setRequests] = useState<CorrectionRequestRow[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const requestSeqRef = useRef(0);
  const abortControllerRef = useRef<AbortController | null>(null);

  useEffect(() => {
    return () => {
      abortControllerRef.current?.abort();
    };
  }, []);

  useEffect(() => {
    if (yearExaminations.length === 0) {
      setSelectedExamId(0);
      setRows([]);
      return;
    }
    if (!yearExaminations.some((e) => e.id === selectedExamId)) {
      const preferred =
        yearExaminations.find((e) => e.status === 'Active') ||
        yearExaminations.find((e) => e.status === 'Published') ||
        yearExaminations[0];
      setSelectedExamId(preferred.id);
    }
  }, [selectedAcademicYear, examinations]);

  const loadMonitoring = async () => {
    abortControllerRef.current?.abort();
    if (!selectedExamId) {
      setRows([]);
      return;
    }
    const controller = new AbortController();
    abortControllerRef.current = controller;
    const seq = ++requestSeqRef.current;

    setLoading(true);
    setError(null);
    try {
      const qs = new URLSearchParams({ examinationId: String(selectedExamId) });
      if (filterClassId) qs.set('classId', filterClassId);
      if (filterSectionId) qs.set('sectionId', filterSectionId);
      const [mon, reqs] = await Promise.all([
        apiFetch<MonitoringRow[]>(`/api/admin/monitoring?${qs.toString()}`, { signal: controller.signal }),
        apiFetch<CorrectionRequestRow[]>('/api/admin/correction-requests', { signal: controller.signal }),
      ]);
      if (seq !== requestSeqRef.current) return;
      setRows(mon);
      setRequests(reqs);
    } catch (err) {
      if (isAbortError(err) || seq !== requestSeqRef.current) return;
      setError(extractErrorMessage(err));
    } finally {
      if (seq === requestSeqRef.current) {
        setLoading(false);
      }
    }
  };

  useEffect(() => {
    loadMonitoring();
  }, [selectedExamId, filterClassId, filterSectionId]);

  const handleResolveRequest = async (id: number, decision: 'approved' | 'rejected') => {
    setError(null);
    try {
      await apiFetch(`/api/admin/correction-requests/${id}/resolve`, {
        method: 'POST',
        body: JSON.stringify({ decision }),
      });
      await loadMonitoring();
      await onChanged();
    } catch (err) {
      setError(extractErrorMessage(err));
    }
  };

  const handleUnlockDirect = async (r: MonitoringRow) => {
    setError(null);
    try {
      await apiFetch('/api/admin/marks/unlock', {
        method: 'POST',
        body: JSON.stringify({
          examinationId: r.examinationId,
          examComponentId: r.examComponentId,
          classId: r.classId,
          sectionId: r.sectionId,
          unlockIa: Boolean(r.hasInternalAssessment),
        }),
      });
      await loadMonitoring();
      await onChanged();
    } catch (err) {
      setError(extractErrorMessage(err));
    }
  };

  const visibleRows = rows.filter((r) => filterStatus === 'all' || r.submissionStatus === filterStatus);
  const submittedCount = rows.filter((r) => r.submissionStatus === 'Submitted').length;
  const draftCount = rows.filter((r) => r.submissionStatus === 'Draft').length;
  const pendingCount = rows.filter((r) => r.submissionStatus === 'Pending').length;
  const currentExam = examinations.find((e) => e.id === selectedExamId);
  const filterClassObj = schoolInfo.classes.find((c) => String(c.id) === filterClassId);
  const pendingRequests = requests.filter((r) => r.status === 'pending');

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
        <div>
          <h2 className="text-lg font-bold text-slate-900">Marks Submission Monitoring &amp; Authorizations</h2>
          <p className="text-xs text-slate-500">
            Track teacher submissions across every subject component and approve correction unlock requests
          </p>
        </div>
        <button
          type="button"
          onClick={() => exportSubmissionMonitoringPDF(currentExam?.name || 'Examination', visibleRows, schoolInfo)}
          className="min-h-[40px] inline-flex items-center justify-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-white bg-[#1E3A5F] rounded-lg hover:bg-[#162D4A] cursor-pointer"
        >
          <FileDown className="w-3.5 h-3.5" />
          Download Submission Report PDF
        </button>
      </div>

      {error && (
        <div className="p-3.5 rounded-xl bg-red-50 border border-red-200 flex flex-wrap items-center justify-between gap-2 text-xs text-red-800">
          <span>{error}</span>
          <button
            type="button"
            onClick={() => loadMonitoring()}
            className="min-h-[34px] inline-flex items-center gap-1 px-3 py-1 bg-white border border-red-200 rounded-lg font-semibold text-red-800 hover:bg-red-100 cursor-pointer"
          >
            <RefreshCw className="w-3.5 h-3.5" />
            Retry
          </button>
        </div>
      )}

      {/* Pending Correction Requests Queue */}
      {pendingRequests.length > 0 && (
        <div className="bg-amber-50 border border-amber-200 rounded-xl p-4 space-y-3">
          <div className="text-sm font-bold text-amber-950">
            Pending Marks Correction Requests ({pendingRequests.length})
          </div>
          <div className="space-y-2">
            {pendingRequests.map((req) => (
              <div
                key={req.id}
                className="bg-white border border-amber-200 rounded-lg p-3 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 text-xs"
              >
                <div>
                  <div className="font-semibold text-slate-900">
                    {req.requested_by_name} ·{' '}
                    {formatClassSectionLabel(
                      req.class_name,
                      req.section_name,
                      req.hasSections !== undefined ? req.hasSections : req.has_sections !== 0 && req.has_sections !== false
                    )}{' '}
                    · {req.subject_name} ({req.component_name})
                  </div>
                  <div className="text-slate-600 mt-0.5">
                    {req.examination_name} · Reason: &ldquo;{req.reason}&rdquo;
                  </div>
                </div>
                <div className="flex flex-wrap items-center gap-2">
                  <button
                    type="button"
                    onClick={() => handleResolveRequest(req.id, 'approved')}
                    className="min-h-[38px] inline-flex items-center gap-1 px-3 py-1.5 font-semibold text-white bg-emerald-700 rounded-lg hover:bg-emerald-800 cursor-pointer"
                  >
                    <Check className="w-3.5 h-3.5" />
                    Approve &amp; Unlock
                  </button>
                  <button
                    type="button"
                    onClick={() => handleResolveRequest(req.id, 'rejected')}
                    className="min-h-[38px] inline-flex items-center gap-1 px-3 py-1.5 font-medium text-red-700 bg-red-50 border border-red-200 rounded-lg hover:bg-red-100 cursor-pointer"
                  >
                    <X className="w-3.5 h-3.5" />
                    Reject
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Status Summary Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="bg-white border border-slate-200 rounded-xl p-4 flex items-center justify-between">
          <div>
            <div className="text-xs text-slate-500">Submitted (Complete)</div>
            <div className="text-2xl font-bold font-mono tabular-nums text-emerald-700 mt-0.5">{submittedCount}</div>
          </div>
          <SubmissionStatusLabel status="Submitted" />
        </div>
        <div className="bg-white border border-slate-200 rounded-xl p-4 flex items-center justify-between">
          <div>
            <div className="text-xs text-slate-500">In Draft (Partial / Unlocked)</div>
            <div className="text-2xl font-bold font-mono tabular-nums text-amber-700 mt-0.5">{draftCount}</div>
          </div>
          <SubmissionStatusLabel status="Draft" />
        </div>
        <div className="bg-white border border-slate-200 rounded-xl p-4 flex items-center justify-between">
          <div>
            <div className="text-xs text-slate-500">Pending (No Marks Entered)</div>
            <div className="text-2xl font-bold font-mono tabular-nums text-red-700 mt-0.5">{pendingCount}</div>
          </div>
          <SubmissionStatusLabel status="Pending" />
        </div>
      </div>

      {/* Filters */}
      <div className="bg-white border border-slate-200 rounded-xl p-4 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 text-xs">
        <select
          value={selectedExamId}
          onChange={(e) => setSelectedExamId(Number(e.target.value))}
          className="min-h-[40px] px-3 py-2 border border-slate-300 rounded-lg bg-white font-medium"
        >
          {yearExaminations.length === 0 ? (
            <option value={0}>No exams in {selectedAcademicYear}</option>
          ) : (
            yearExaminations.map((ex) => (
              <option key={ex.id} value={ex.id}>
                {ex.name} ({ex.academic_year})
              </option>
            ))
          )}
        </select>
        <select
          value={filterClassId}
          onChange={(e) => {
            setFilterClassId(e.target.value);
            setFilterSectionId('');
          }}
          className="min-h-[40px] px-3 py-2 border border-slate-300 rounded-lg bg-white"
        >
          <option value="">All Classes</option>
          {schoolInfo.classes.map((c) => (
            <option key={c.id} value={c.id}>
              {c.name}
            </option>
          ))}
        </select>
        <select
          value={filterSectionId}
          onChange={(e) => setFilterSectionId(e.target.value)}
          disabled={!filterClassId || filterClassObj?.hasSections === false}
          className="min-h-[40px] px-3 py-2 border border-slate-300 rounded-lg bg-white disabled:bg-slate-50"
        >
          <option value="">
            {filterClassObj?.hasSections === false ? 'No Sections (Single Cohort)' : 'All Sections'}
          </option>
          {filterClassObj?.hasSections !== false &&
            filterClassObj?.sections.map((s) => (
              <option key={s.id} value={s.id}>
                Section {s.name}
              </option>
            ))}
        </select>
        <select
          value={filterStatus}
          onChange={(e) => setFilterStatus(e.target.value as any)}
          className="min-h-[40px] px-3 py-2 border border-slate-300 rounded-lg bg-white"
        >
          <option value="all">All Statuses</option>
          <option value="Submitted">Submitted (Green)</option>
          <option value="Draft">Draft (Amber)</option>
          <option value="Pending">Pending (Red)</option>
        </select>
      </div>

      {/* Monitoring List (Mobile Cards + Desktop Table) */}
      <div className="bg-white border border-slate-200 rounded-xl overflow-hidden">
        {loading ? (
          <div className="px-4 py-8 text-center text-xs text-slate-500">Loading submission matrix...</div>
        ) : visibleRows.length === 0 ? (
          <div className="px-4 py-8 text-center text-xs text-slate-500">No monitoring records match this filter.</div>
        ) : (
          <>
            {/* Mobile Cards */}
            <div className="md:hidden divide-y divide-slate-200">
              {visibleRows.map((r, i) => (
                <div key={i} className="p-4 space-y-2 text-xs">
                  <div className="flex items-start justify-between gap-2">
                    <div>
                      <div className="font-bold text-slate-900">
                        {formatClassSectionLabel(r.className, r.sectionName, r.hasSections)}
                      </div>
                      <div className="text-slate-700">
                        {r.subjectName} — {r.componentName}{' '}
                        <span className="font-mono text-slate-500">(/{r.maxMarks})</span>
                      </div>
                      <div className="text-slate-600 mt-0.5">
                        Teacher: {r.teacherName || <span className="text-red-600">Unassigned</span>}
                      </div>
                    </div>
                    <SubmissionStatusLabel status={r.submissionStatus} />
                  </div>
                  <div className="flex flex-wrap items-center justify-between gap-2 pt-2 border-t border-slate-100">
                    <div className="font-mono text-[11px] text-slate-600 tabular-nums">
                      Entered: {r.enteredCount}/{r.totalStudents}
                      {r.iaStatus !== 'N/A' && ` · IA: ${r.iaStatus}`}
                    </div>
                    {(r.submittedCount > 0 || r.iaStatus === 'Submitted' || r.submissionStatus === 'Submitted') && (
                      <button
                        type="button"
                        onClick={() => handleUnlockDirect(r)}
                        className="min-h-[36px] inline-flex items-center gap-1 px-3 py-1 text-xs font-medium text-slate-700 border border-slate-300 rounded-lg hover:bg-slate-50 cursor-pointer"
                      >
                        <Unlock className="w-3.5 h-3.5" />
                        Unlock
                      </button>
                    )}
                  </div>
                </div>
              ))}
            </div>

            {/* Desktop Table */}
            <div className="hidden md:block overflow-x-auto max-h-[540px]">
              <table className="w-full text-xs">
                <thead className="bg-slate-50 border-b border-slate-200 text-slate-600 sticky top-0">
                  <tr>
                    <th className="text-left font-semibold px-4 py-2.5">Class &amp; Section</th>
                    <th className="text-left font-semibold px-4 py-2.5">Subject</th>
                    <th className="text-left font-semibold px-4 py-2.5">Component</th>
                    <th className="text-left font-semibold px-4 py-2.5">Assigned Teacher</th>
                    <th className="text-right font-semibold px-4 py-2.5">Entered / Total</th>
                    <th className="text-center font-semibold px-4 py-2.5">Submission Status</th>
                    <th className="text-center font-semibold px-4 py-2.5">IA Status</th>
                    <th className="text-right font-semibold px-4 py-2.5">Admin Action</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200">
                  {visibleRows.map((r, i) => (
                    <tr key={i} className="hover:bg-slate-50/70">
                      <td className="px-4 py-2.5 font-medium text-slate-900">
                        {formatClassSectionLabel(r.className, r.sectionName, r.hasSections)}
                      </td>
                      <td className="px-4 py-2.5 text-slate-800">{r.subjectName}</td>
                      <td className="px-4 py-2.5 text-slate-700">
                        {r.componentName} <span className="font-mono text-slate-400">(/{r.maxMarks})</span>
                      </td>
                      <td className="px-4 py-2.5 font-medium text-slate-800">
                        {r.teacherName || <span className="text-red-600">Unassigned</span>}
                      </td>
                      <td className="px-4 py-2.5 text-right font-mono tabular-nums text-slate-700">
                        <div>
                          {r.enteredCount} / {r.totalStudents}
                        </div>
                        {(r.presentCount !== undefined || r.absentCount !== undefined) && (
                          <div className="text-[10px] text-slate-500">
                            P:{r.presentCount ?? 0} · AB:{r.absentCount ?? 0} · Pend:{r.missingCount}
                          </div>
                        )}
                      </td>
                      <td className="px-4 py-2.5 text-center">
                        <SubmissionStatusLabel status={r.submissionStatus} />
                      </td>
                      <td className="px-4 py-2.5 text-center">
                        {r.iaStatus === 'N/A' ? (
                          <span className="text-slate-400">—</span>
                        ) : (
                          <SubmissionStatusLabel status={r.iaStatus} />
                        )}
                      </td>
                      <td className="px-4 py-2.5 text-right">
                        {r.submittedCount > 0 || r.iaStatus === 'Submitted' || r.submissionStatus === 'Submitted' ? (
                          <button
                            type="button"
                            onClick={() => handleUnlockDirect(r)}
                            className="inline-flex items-center gap-1 px-2.5 py-1 text-[11px] font-medium text-slate-700 border border-slate-300 rounded hover:bg-slate-50 cursor-pointer"
                          >
                            <Unlock className="w-3 h-3" />
                            Unlock
                          </button>
                        ) : (
                          <span className="text-slate-400">—</span>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </>
        )}
      </div>
    </div>
  );
}
