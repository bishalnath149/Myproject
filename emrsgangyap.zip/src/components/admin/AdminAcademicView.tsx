import React, { useEffect, useMemo, useRef, useState } from 'react';
import {
  Plus,
  Trash2,
  X,
  Pencil,
  RotateCcw,
  RefreshCw,
  Search,
  Layers,
  CheckSquare,
} from 'lucide-react';
import type {
  ClassTeacherAssignment,
  ComponentMode,
  IaComponentKey,
  IaTeacherAssignment,
  SchoolInfo,
  SubjectRecord,
  SubjectStreamCategory,
  TeacherAssignment,
} from '../../types';
import { apiFetch, extractErrorMessage, isAbortError } from '../../lib/api';
import { formatClassSectionLabel } from '../../lib/grading';
import {
  BulkActionToolbar,
  BulkConfirmModal,
  PaginationBar,
  UndoBanner,
  usePagination,
  type BulkConfirmItem,
} from '../BulkActions';

interface AdminUserOption {
  id: number;
  username: string;
  full_name: string;
  email?: string;
  employee_code?: string;
  isActive: boolean;
  roles: string[];
}

export function AdminClassesSubjectsView({
  schoolInfo,
  selectedAcademicYear,
  onChanged,
}: {
  schoolInfo: SchoolInfo;
  selectedAcademicYear: string;
  onChanged: () => void;
}) {
  const [viewMode, setViewMode] = useState<'active' | 'archived'>('active');
  const [classes, setClasses] = useState<any[]>([]);
  const [subjects, setSubjects] = useState<SubjectRecord[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [classSearch, setClassSearch] = useState('');
  const [subjectSearch, setSubjectSearch] = useState('');

  // Selection states
  const [selectedClassIds, setSelectedClassIds] = useState<number[]>([]);
  const [selectedSectionIds, setSelectedSectionIds] = useState<number[]>([]);
  const [selectedSubjectIds, setSelectedSubjectIds] = useState<number[]>([]);

  // Bulk confirm & Undo states
  const [bulkConfirm, setBulkConfirm] = useState<{
    scope: 'class' | 'section' | 'subject';
    action: 'delete' | 'archive' | 'restore' | 'activate' | 'deactivate';
    items: BulkConfirmItem[];
    ids: number[];
  } | null>(null);
  const [bulkBusy, setBulkBusy] = useState(false);
  const [undoState, setUndoState] = useState<{
    scope: 'class' | 'section' | 'subject';
    ids: number[];
    message: string;
  } | null>(null);

  const [newClassName, setNewClassName] = useState('');
  const [newClassOrder, setNewClassOrder] = useState(10);
  const [newClassHasSections, setNewClassHasSections] = useState(true);
  const [sectionInputs, setSectionInputs] = useState<Record<number, string>>({});
  const [newSub, setNewSub] = useState<{
    code: string;
    name: string;
    defaultMaxMarks: number;
    componentMode: ComponentMode;
    hasInternalAssessment: boolean;
    hasPractical: boolean;
    streamCategory: SubjectStreamCategory;
    applicableClassIds: number[];
    iaNotebookMax: number;
    iaUnitTestMax: number;
    iaPracticalMax: number;
    iaParticipationMax: number;
    initialComponents: Array<{ name: string; code: string; defaultMaxMarks: number }>;
  }>({
    code: '',
    name: '',
    defaultMaxMarks: 80,
    componentMode: 'single',
    hasInternalAssessment: true,
    hasPractical: false,
    streamCategory: '',
    applicableClassIds: [],
    iaNotebookMax: 5,
    iaUnitTestMax: 5,
    iaPracticalMax: 5,
    iaParticipationMax: 5,
    initialComponents: [{ name: '', code: '', defaultMaxMarks: 80 }],
  });
  const [compForms, setCompForms] = useState<Record<number, { name: string; code: string; max: number }>>({});
  const [editingSubject, setEditingSubject] = useState<{
    id: number;
    name: string;
    code: string;
    componentMode: ComponentMode;
    hasComponents: boolean;
    writtenMaxMarks: number;
    hasInternalAssessment: boolean;
    hasPractical: boolean;
    streamCategory: SubjectStreamCategory;
    applicableClassIds: number[];
    iaNotebookMax: number;
    iaUnitTestMax: number;
    iaPracticalMax: number;
    iaParticipationMax: number;
    components: Array<{ id: number; name: string; code: string; defaultMaxMarks: number }>;
  } | null>(null);
  const [deleteSubjectTarget, setDeleteSubjectTarget] = useState<SubjectRecord | null>(null);
  const [deletingSubject, setDeletingSubject] = useState(false);
  const [deleteComponentTarget, setDeleteComponentTarget] = useState<{
    id: number;
    name: string;
    subjectName: string;
  } | null>(null);
  const [editingClass, setEditingClass] = useState<{
    id: number;
    name: string;
    numericOrder: number;
    hasSections: boolean;
    isActive: boolean;
  } | null>(null);
  const [deleteClassTarget, setDeleteClassTarget] = useState<{ id: number; name: string } | null>(null);
  const [editingSection, setEditingSection] = useState<{
    id: number;
    className: string;
    name: string;
    capacity: number;
  } | null>(null);
  const [deleteSectionTarget, setDeleteSectionTarget] = useState<{
    id: number;
    className: string;
    name: string;
  } | null>(null);
  const [savingSubject, setSavingSubject] = useState(false);

  const loadData = async (mode = viewMode) => {
    setLoading(true);
    setError(null);
    try {
      // Fetch view=all for archived so archived sections inside active classes remain discoverable & restorable
      const classViewParam = mode === 'archived' ? 'all' : 'active';
      const [cls, subs] = await Promise.all([
        apiFetch<any[]>(
          `/api/admin/classes?academicYear=${encodeURIComponent(selectedAcademicYear)}&view=${classViewParam}`
        ),
        apiFetch<SubjectRecord[]>(`/api/admin/subjects?view=${mode}`),
      ]);
      setClasses(cls);
      setSubjects(subs);
      setSelectedClassIds([]);
      setSelectedSectionIds([]);
      setSelectedSubjectIds([]);
    } catch (err) {
      setError(extractErrorMessage(err));
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData(viewMode);
  }, [selectedAcademicYear, viewMode]);

  const filteredClasses = useMemo(() => {
    const q = classSearch.trim().toLowerCase();
    return classes
      .filter((c) => {
        if (viewMode === 'active') return !c.isDeleted;
        return Boolean(c.isDeleted) || (c.sections || []).some((s: any) => Boolean(s.isDeleted));
      })
      .map((c) => {
        if (viewMode === 'active') return c;
        const visibleSections = c.isDeleted
          ? c.sections || []
          : (c.sections || []).filter((s: any) => Boolean(s.isDeleted));
        return { ...c, sections: visibleSections };
      })
      .filter((c) => !q || c.name.toLowerCase().includes(q));
  }, [classes, classSearch, viewMode]);

  const filteredSubjects = useMemo(() => {
    const q = subjectSearch.trim().toLowerCase();
    if (!q) return subjects;
    return subjects.filter(
      (s) =>
        s.name.toLowerCase().includes(q) ||
        s.code.toLowerCase().includes(q) ||
        s.components.some((c) => c.name.toLowerCase().includes(q))
    );
  }, [subjects, subjectSearch]);

  const {
    page: subPage,
    setPage: setSubPage,
    pageSize: subPageSize,
    setPageSize: setSubPageSize,
    pagedItems: pagedSubjects,
  } = usePagination(filteredSubjects, 12);

  useEffect(() => {
    setSubPage(1);
  }, [subjectSearch, viewMode, setSubPage]);

  const visibleClassIds = filteredClasses.filter((c) => (viewMode === 'active' ? !c.isDeleted : Boolean(c.isDeleted))).map((c) => c.id);
  const allVisibleClassesSelected =
    visibleClassIds.length > 0 && visibleClassIds.every((id) => selectedClassIds.includes(id));

  const visibleSectionRows = useMemo(() => {
    const list: Array<{ id: number; label: string; className: string }> = [];
    for (const c of filteredClasses) {
      if (c.hasSections === false) continue;
      for (const s of c.sections || []) {
        if (viewMode === 'active' ? !s.isDeleted : Boolean(s.isDeleted)) {
          list.push({ id: s.id, label: formatClassSectionLabel(c.name, s.name, c.hasSections), className: c.name });
        }
      }
    }
    return list;
  }, [filteredClasses, viewMode]);

  const pagedSubjectIds = pagedSubjects.map((s) => s.id);
  const allPagedSubjectsSelected =
    pagedSubjectIds.length > 0 && pagedSubjectIds.every((id) => selectedSubjectIds.includes(id));

  const toggleClassSelect = (id: number) => {
    setSelectedClassIds((prev) => (prev.includes(id) ? prev.filter((x) => x !== id) : [...prev, id]));
  };

  const toggleSelectAllClasses = () => {
    if (allVisibleClassesSelected) {
      setSelectedClassIds((prev) => prev.filter((id) => !visibleClassIds.includes(id)));
    } else {
      setSelectedClassIds((prev) => Array.from(new Set([...prev, ...visibleClassIds])));
    }
  };

  const toggleSectionSelect = (id: number) => {
    setSelectedSectionIds((prev) => (prev.includes(id) ? prev.filter((x) => x !== id) : [...prev, id]));
  };

  const toggleSubjectSelect = (id: number) => {
    setSelectedSubjectIds((prev) => (prev.includes(id) ? prev.filter((x) => x !== id) : [...prev, id]));
  };

  const toggleSelectAllPagedSubjects = () => {
    if (allPagedSubjectsSelected) {
      setSelectedSubjectIds((prev) => prev.filter((id) => !pagedSubjectIds.includes(id)));
    } else {
      setSelectedSubjectIds((prev) => Array.from(new Set([...prev, ...pagedSubjectIds])));
    }
  };

  const openBulkClassConfirm = (action: 'delete' | 'archive' | 'restore' | 'activate' | 'deactivate') => {
    const chosen = filteredClasses.filter((c) => selectedClassIds.includes(c.id));
    if (chosen.length === 0) return;
    setBulkConfirm({
      scope: 'class',
      action,
      ids: chosen.map((c) => c.id),
      items: chosen.map((c) => ({
        id: c.id,
        label: c.name,
        sublabel: `Order #${c.numeric_order}`,
      })),
    });
  };

  const openBulkSectionConfirm = (action: 'delete' | 'archive' | 'restore') => {
    const chosen = visibleSectionRows.filter((s) => selectedSectionIds.includes(s.id));
    if (chosen.length === 0) return;
    setBulkConfirm({
      scope: 'section',
      action,
      ids: chosen.map((s) => s.id),
      items: chosen.map((s) => ({
        id: s.id,
        label: s.label,
      })),
    });
  };

  const openBulkSubjectConfirm = (action: 'delete' | 'archive' | 'restore' | 'activate' | 'deactivate') => {
    const chosen = subjects.filter((s) => selectedSubjectIds.includes(s.id));
    if (chosen.length === 0) return;
    setBulkConfirm({
      scope: 'subject',
      action,
      ids: chosen.map((s) => s.id),
      items: chosen.map((s) => ({
        id: s.id,
        label: s.name,
        sublabel: `${s.code} · ${s.default_max_marks}m`,
      })),
    });
  };

  const executeBulkAction = async () => {
    if (!bulkConfirm) return;
    setBulkBusy(true);
    setError(null);
    try {
      const endpoint =
        bulkConfirm.scope === 'class'
          ? '/api/admin/classes/bulk-action'
          : bulkConfirm.scope === 'section'
            ? '/api/admin/sections/bulk-action'
            : '/api/admin/subjects/bulk-action';
      await apiFetch(endpoint, {
        method: 'POST',
        body: JSON.stringify({ action: bulkConfirm.action, ids: bulkConfirm.ids }),
      });

      const count = bulkConfirm.ids.length;
      const entity =
        bulkConfirm.scope === 'class' ? 'class' : bulkConfirm.scope === 'section' ? 'section' : 'subject';
      if (bulkConfirm.action === 'delete' || bulkConfirm.action === 'archive') {
        setUndoState({
          scope: bulkConfirm.scope,
          ids: bulkConfirm.ids,
          message: `Archived ${count} ${entity}${count === 1 ? '' : 's'}. Historical marks & enrollments preserved.`,
        });
      } else {
        setUndoState(null);
      }

      setBulkConfirm(null);
      await loadData(viewMode);
      onChanged();
    } catch (err) {
      setError(extractErrorMessage(err));
      setBulkConfirm(null);
    } finally {
      setBulkBusy(false);
    }
  };

  const handleUndo = async () => {
    if (!undoState) return;
    setBulkBusy(true);
    setError(null);
    try {
      const endpoint =
        undoState.scope === 'class'
          ? '/api/admin/classes/bulk-action'
          : undoState.scope === 'section'
            ? '/api/admin/sections/bulk-action'
            : '/api/admin/subjects/bulk-action';
      await apiFetch(endpoint, {
        method: 'POST',
        body: JSON.stringify({ action: 'restore', ids: undoState.ids }),
      });
      setUndoState(null);
      await loadData(viewMode);
      onChanged();
    } catch (err) {
      setError(extractErrorMessage(err));
    } finally {
      setBulkBusy(false);
    }
  };

  const addClass = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    try {
      await apiFetch('/api/admin/classes', {
        method: 'POST',
        body: JSON.stringify({
          name: newClassName,
          numericOrder: newClassOrder,
          hasSections: newClassHasSections,
          defaultSections: newClassHasSections ? ['A', 'B'] : [],
        }),
      });
      setNewClassName('');
      setNewClassHasSections(true);
      await loadData(viewMode);
      onChanged();
    } catch (err) {
      setError(extractErrorMessage(err));
    }
  };

  const addSection = async (classId: number) => {
    const name = (sectionInputs[classId] || '').trim();
    if (!name) return;
    setError(null);
    try {
      await apiFetch('/api/admin/sections', {
        method: 'POST',
        body: JSON.stringify({ classId, name, capacity: 30 }),
      });
      setSectionInputs((p) => ({ ...p, [classId]: '' }));
      await loadData(viewMode);
      onChanged();
    } catch (err) {
      setError(extractErrorMessage(err));
    }
  };

  const handleSaveClass = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingClass) return;
    setError(null);
    try {
      await apiFetch(`/api/admin/classes/${editingClass.id}`, {
        method: 'PUT',
        body: JSON.stringify({
          name: editingClass.name,
          numericOrder: editingClass.numericOrder,
          hasSections: editingClass.hasSections,
          isActive: editingClass.isActive,
        }),
      });
      setEditingClass(null);
      await loadData(viewMode);
      onChanged();
    } catch (err) {
      setError(extractErrorMessage(err));
    }
  };

  const handleDeleteClass = async () => {
    if (!deleteClassTarget) return;
    setError(null);
    try {
      await apiFetch(`/api/admin/classes/${deleteClassTarget.id}`, { method: 'DELETE' });
      const targetId = deleteClassTarget.id;
      const targetName = deleteClassTarget.name;
      setDeleteClassTarget(null);
      setUndoState({
        scope: 'class',
        ids: [targetId],
        message: `Archived class "${targetName}".`,
      });
      await loadData(viewMode);
      onChanged();
    } catch (err) {
      setError(extractErrorMessage(err));
      setDeleteClassTarget(null);
    }
  };

  const handleSaveSection = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingSection) return;
    setError(null);
    try {
      await apiFetch(`/api/admin/sections/${editingSection.id}`, {
        method: 'PUT',
        body: JSON.stringify({
          name: editingSection.name,
          capacity: Number(editingSection.capacity || 30),
        }),
      });
      setEditingSection(null);
      await loadData(viewMode);
      onChanged();
    } catch (err) {
      setError(extractErrorMessage(err));
    }
  };

  const handleDeleteSection = async () => {
    if (!deleteSectionTarget) return;
    setError(null);
    try {
      await apiFetch(`/api/admin/sections/${deleteSectionTarget.id}`, { method: 'DELETE' });
      const tid = deleteSectionTarget.id;
      const tlabel = `${deleteSectionTarget.className} · Section ${deleteSectionTarget.name}`;
      setDeleteSectionTarget(null);
      setUndoState({
        scope: 'section',
        ids: [tid],
        message: `Archived ${tlabel}.`,
      });
      await loadData(viewMode);
      onChanged();
    } catch (err) {
      setError(extractErrorMessage(err));
      setDeleteSectionTarget(null);
    }
  };

  const addSubject = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    const validComps =
      newSub.componentMode === 'single'
        ? undefined
        : newSub.initialComponents
            .filter((c) => c.name.trim() && c.code.trim())
            .map((c) => ({
              name: c.name.trim(),
              code: c.code.trim().toUpperCase(),
              defaultMaxMarks: Number(c.defaultMaxMarks || 80),
            }));
    if (newSub.componentMode !== 'single' && (!validComps || validComps.length === 0)) {
      setError('Add at least one component or sub-option with name and code.');
      return;
    }
    try {
      await apiFetch('/api/admin/subjects', {
        method: 'POST',
        body: JSON.stringify({
          code: newSub.code,
          name: newSub.name,
          defaultMaxMarks: newSub.defaultMaxMarks,
          hasComponents: newSub.componentMode !== 'single',
          componentMode: newSub.componentMode,
          hasInternalAssessment: newSub.hasInternalAssessment,
          hasPractical: newSub.hasPractical,
          streamCategory: newSub.streamCategory,
          applicableClassIds: newSub.applicableClassIds,
          iaNotebookMax: newSub.iaNotebookMax,
          iaUnitTestMax: newSub.iaUnitTestMax,
          iaPracticalMax: newSub.iaPracticalMax,
          iaParticipationMax: newSub.iaParticipationMax,
          components: validComps,
        }),
      });
      setNewSub({
        code: '',
        name: '',
        defaultMaxMarks: 80,
        componentMode: 'single',
        hasInternalAssessment: true,
        hasPractical: false,
        streamCategory: '',
        applicableClassIds: [],
        iaNotebookMax: 5,
        iaUnitTestMax: 5,
        iaPracticalMax: 5,
        iaParticipationMax: 5,
        initialComponents: [{ name: '', code: '', defaultMaxMarks: 80 }],
      });
      await loadData(viewMode);
      onChanged();
    } catch (err) {
      setError(extractErrorMessage(err));
    }
  };

  const handleDeleteSubject = async () => {
    if (!deleteSubjectTarget) return;
    setDeletingSubject(true);
    setError(null);
    try {
      await apiFetch(`/api/admin/subjects/${deleteSubjectTarget.id}`, { method: 'DELETE' });
      const tid = deleteSubjectTarget.id;
      const tname = deleteSubjectTarget.name;
      setDeleteSubjectTarget(null);
      setUndoState({
        scope: 'subject',
        ids: [tid],
        message: `Archived subject "${tname}". Historical examination marks remain preserved.`,
      });
      await loadData(viewMode);
      onChanged();
    } catch (err) {
      setError(extractErrorMessage(err));
      setDeleteSubjectTarget(null);
    } finally {
      setDeletingSubject(false);
    }
  };

  const handleQuickRestore = async (scope: 'class' | 'section' | 'subject', id: number) => {
    setError(null);
    try {
      const endpoint =
        scope === 'class'
          ? '/api/admin/classes/bulk-action'
          : scope === 'section'
            ? '/api/admin/sections/bulk-action'
            : '/api/admin/subjects/bulk-action';
      await apiFetch(endpoint, {
        method: 'POST',
        body: JSON.stringify({ action: 'restore', ids: [id] }),
      });
      await loadData(viewMode);
      onChanged();
    } catch (err) {
      setError(extractErrorMessage(err));
    }
  };

  const addComponent = async (subjectId: number, defaultMax = 25) => {
    const f = compForms[subjectId];
    if (!f || !f.name || !f.code) return;
    setError(null);
    try {
      await apiFetch(`/api/admin/subjects/${subjectId}/components`, {
        method: 'POST',
        body: JSON.stringify({ name: f.name, code: f.code, defaultMaxMarks: Number(f.max || defaultMax) }),
      });
      setCompForms((p) => ({ ...p, [subjectId]: { name: '', code: '', max: defaultMax } }));
      await loadData(viewMode);
      onChanged();
    } catch (err) {
      setError(extractErrorMessage(err));
    }
  };

  const confirmDeleteComponent = async () => {
    if (!deleteComponentTarget) return;
    setError(null);
    try {
      await apiFetch(`/api/admin/components/${deleteComponentTarget.id}`, { method: 'DELETE' });
      setDeleteComponentTarget(null);
      await loadData(viewMode);
      onChanged();
    } catch (err) {
      setError(extractErrorMessage(err));
      setDeleteComponentTarget(null);
    }
  };

  const openEditSubject = (sub: SubjectRecord) => {
    setError(null);
    const mode: ComponentMode =
      sub.componentMode || (sub.hasComponents || sub.components.length > 1 ? 'combined' : 'single');
    const writtenSum =
      mode === 'elective'
        ? Number(sub.components[0]?.default_max_marks || 80)
        : sub.components.reduce((s, c) => s + Number(c.default_max_marks || 0), 0);
    setEditingSubject({
      id: sub.id,
      name: sub.name,
      code: sub.code,
      componentMode: mode,
      hasComponents: mode !== 'single' || sub.components.length > 1,
      writtenMaxMarks: writtenSum || 80,
      hasInternalAssessment: sub.hasInternalAssessment,
      hasPractical: Boolean(sub.hasPractical),
      streamCategory: sub.streamCategory || '',
      applicableClassIds: sub.applicableClassIds || [],
      iaNotebookMax: sub.iaNotebookMax ?? 5,
      iaUnitTestMax: sub.iaUnitTestMax ?? 5,
      iaPracticalMax: sub.iaPracticalMax ?? 5,
      iaParticipationMax: sub.iaParticipationMax ?? 5,
      components: sub.components.map((c) => ({
        id: c.id,
        name: c.name,
        code: c.code,
        defaultMaxMarks: c.default_max_marks,
      })),
    });
  };

  const handleSaveSubjectMarks = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingSubject) return;
    setSavingSubject(true);
    setError(null);
    try {
      const payload = {
        name: editingSubject.name,
        code: editingSubject.code,
        componentMode: editingSubject.componentMode,
        hasInternalAssessment: editingSubject.hasInternalAssessment,
        hasPractical: editingSubject.hasPractical,
        streamCategory: editingSubject.streamCategory,
        applicableClassIds: editingSubject.applicableClassIds,
        iaNotebookMax: Number(editingSubject.iaNotebookMax || 0),
        iaUnitTestMax: Number(editingSubject.iaUnitTestMax || 0),
        iaPracticalMax: Number(editingSubject.iaPracticalMax || 0),
        iaParticipationMax: Number(editingSubject.iaParticipationMax || 0),
        ...(editingSubject.hasComponents
          ? { components: editingSubject.components }
          : { writtenMaxMarks: Number(editingSubject.writtenMaxMarks) }),
      };
      await apiFetch(`/api/admin/subjects/${editingSubject.id}`, {
        method: 'PUT',
        body: JSON.stringify(payload),
      });
      setEditingSubject(null);
      await loadData(viewMode);
      onChanged();
    } catch (err) {
      setError(extractErrorMessage(err));
    } finally {
      setSavingSubject(false);
    }
  };

  return (
    <div className="space-y-8">
      {/* Top Switcher & Error/Undo */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
        <div>
          <h2 className="text-lg font-bold text-slate-900">Classes, Sections &amp; Subjects</h2>
          <p className="text-xs text-slate-500">
            Manage class structures, sections, and subject weightage ({schoolInfo.classes.length} active classes)
          </p>
        </div>
        <div className="inline-flex p-1 bg-slate-100 rounded-xl border border-slate-200 self-start sm:self-auto">
          <button
            type="button"
            onClick={() => setViewMode('active')}
            className={`min-h-[38px] sm:min-h-[34px] px-3.5 py-1.5 text-xs font-semibold rounded-lg transition-colors cursor-pointer ${
              viewMode === 'active'
                ? 'bg-white text-[#1E3A5F] shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Active Records
          </button>
          <button
            type="button"
            onClick={() => setViewMode('archived')}
            className={`min-h-[38px] sm:min-h-[34px] px-3.5 py-1.5 text-xs font-semibold rounded-lg transition-colors cursor-pointer ${
              viewMode === 'archived'
                ? 'bg-white text-[#1E3A5F] shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Archived / Recovery
          </button>
        </div>
      </div>

      {error && (
        <div className="p-3.5 rounded-xl bg-red-50 border border-red-200 flex flex-wrap items-center justify-between gap-2 text-xs text-red-800">
          <span>{error}</span>
          <button
            type="button"
            onClick={() => loadData(viewMode)}
            className="min-h-[34px] inline-flex items-center gap-1 px-3 py-1 bg-white border border-red-200 rounded-lg font-semibold text-red-800 hover:bg-red-100 cursor-pointer"
          >
            <RefreshCw className="w-3.5 h-3.5" />
            Retry
          </button>
        </div>
      )}

      {undoState && (
        <UndoBanner
          message={undoState.message}
          onUndo={handleUndo}
          onDismiss={() => setUndoState(null)}
          busy={bulkBusy}
        />
      )}

      {/* Classes & Sections */}
      <div className="space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
          <div>
            <h3 className="text-base font-bold text-slate-900">
              {viewMode === 'active' ? 'Classes & Sections Management' : 'Archived Classes & Sections'}
            </h3>
            <p className="text-xs text-slate-500">
              {viewMode === 'active'
                ? 'Select classes or sections for bulk activation, deactivation, or archiving'
                : 'Restore soft-deleted classes or sections anytime'}
            </p>
          </div>
          <div className="flex flex-wrap items-center gap-2">
            <div className="relative flex-1 sm:w-56">
              <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={classSearch}
                onChange={(e) => setClassSearch(e.target.value)}
                placeholder="Filter classes..."
                className="w-full min-h-[40px] sm:min-h-[36px] pl-8 pr-3 py-1.5 text-xs bg-white border border-slate-300 rounded-lg"
              />
            </div>
            {visibleClassIds.length > 0 && (
              <label className="min-h-[40px] sm:min-h-[36px] inline-flex items-center gap-2 px-3 py-1.5 bg-white border border-slate-300 rounded-lg text-xs font-medium text-slate-700 cursor-pointer">
                <input
                  type="checkbox"
                  checked={allVisibleClassesSelected}
                  onChange={toggleSelectAllClasses}
                  className="rounded border-slate-300"
                />
                Select All Classes ({visibleClassIds.length})
              </label>
            )}
          </div>
        </div>

        {selectedClassIds.length > 0 && (
          <BulkActionToolbar
            selectedCount={selectedClassIds.length}
            entityLabel="class"
            onClearSelection={() => setSelectedClassIds([])}
            disabled={bulkBusy}
            actions={
              viewMode === 'active'
                ? [
                    {
                      id: 'activate-cls',
                      label: 'Activate',
                      icon: 'activate',
                      variant: 'success',
                      onClick: () => openBulkClassConfirm('activate'),
                    },
                    {
                      id: 'deactivate-cls',
                      label: 'Deactivate',
                      icon: 'deactivate',
                      variant: 'warning',
                      onClick: () => openBulkClassConfirm('deactivate'),
                    },
                    {
                      id: 'archive-cls',
                      label: 'Delete / Archive',
                      icon: 'delete',
                      variant: 'danger',
                      onClick: () => openBulkClassConfirm('delete'),
                    },
                  ]
                : [
                    {
                      id: 'restore-cls',
                      label: 'Restore Selected',
                      icon: 'restore',
                      variant: 'success',
                      onClick: () => openBulkClassConfirm('restore'),
                    },
                  ]
            }
          />
        )}

        {selectedSectionIds.length > 0 && (
          <BulkActionToolbar
            selectedCount={selectedSectionIds.length}
            entityLabel="section"
            onClearSelection={() => setSelectedSectionIds([])}
            disabled={bulkBusy}
            actions={
              viewMode === 'active'
                ? [
                    {
                      id: 'archive-sec',
                      label: 'Archive / Delete Sections',
                      icon: 'delete',
                      variant: 'danger',
                      onClick: () => openBulkSectionConfirm('delete'),
                    },
                  ]
                : [
                    {
                      id: 'restore-sec',
                      label: 'Restore Selected Sections',
                      icon: 'restore',
                      variant: 'success',
                      onClick: () => openBulkSectionConfirm('restore'),
                    },
                  ]
            }
          />
        )}

        {viewMode === 'active' && (
          <form
            onSubmit={addClass}
            className="bg-white border border-slate-200 rounded-xl p-4 grid grid-cols-1 sm:grid-cols-12 gap-3 items-end text-xs"
          >
            <div className="sm:col-span-4">
              <label className="block font-semibold text-slate-700 mb-1">New Class Name</label>
              <input
                type="text"
                required
                value={newClassName}
                onChange={(e) => setNewClassName(e.target.value)}
                placeholder="e.g. Class 11"
                className="w-full min-h-[42px] sm:min-h-[38px] px-3 py-2 border border-slate-300 rounded-lg"
              />
            </div>
            <div className="sm:col-span-2">
              <label className="block font-semibold text-slate-700 mb-1">Order</label>
              <input
                type="number"
                value={newClassOrder}
                onChange={(e) => setNewClassOrder(Number(e.target.value))}
                className="w-full min-h-[42px] sm:min-h-[38px] px-3 py-2 border border-slate-300 rounded-lg font-mono"
              />
            </div>
            <div className="sm:col-span-3 flex items-center min-h-[38px]">
              <label className="inline-flex items-center gap-2 font-medium text-slate-700 cursor-pointer">
                <input
                  type="checkbox"
                  checked={!newClassHasSections}
                  onChange={(e) => setNewClassHasSections(!e.target.checked)}
                  className="rounded border-slate-300"
                />
                No Sections (e.g. Class 11 / 12)
              </label>
            </div>
            <div className="sm:col-span-3">
              <button
                type="submit"
                className="w-full min-h-[42px] sm:min-h-[38px] px-4 py-2 font-semibold text-white bg-[#1E3A5F] rounded-lg hover:bg-[#162D4A] cursor-pointer"
              >
                {newClassHasSections ? 'Add Class (with A & B)' : 'Add Class (No Sections)'}
              </button>
            </div>
          </form>
        )}

        {loading ? (
          <div className="bg-white border border-slate-200 rounded-xl p-8 text-center text-xs text-slate-500">
            Loading classes &amp; subjects...
          </div>
        ) : filteredClasses.length === 0 ? (
          <div className="bg-white border border-slate-200 rounded-xl p-8 text-center text-xs text-slate-500">
            {viewMode === 'archived' ? 'No archived classes or sections.' : 'No matching classes found.'}
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {filteredClasses.map((c) => {
              const classSelectable = viewMode === 'active' ? !c.isDeleted : Boolean(c.isDeleted);
              const classChecked = selectedClassIds.includes(c.id);
              return (
                <div
                  key={c.id}
                  className={`bg-white border rounded-xl p-4 space-y-3 shadow-xs ${
                    classChecked ? 'border-[#1E3A5F] ring-1 ring-[#1E3A5F]/20' : 'border-slate-200'
                  }`}
                >
                  <div className="flex flex-wrap items-center justify-between border-b border-slate-100 pb-2.5 gap-2">
                    <div className="flex items-center gap-2.5 min-w-0">
                      {classSelectable && (
                        <input
                          type="checkbox"
                          checked={classChecked}
                          onChange={() => toggleClassSelect(c.id)}
                          aria-label={`Select ${c.name}`}
                          className="w-4 h-4 rounded border-slate-300 cursor-pointer shrink-0"
                        />
                      )}
                      <span className="font-bold text-sm text-slate-900 truncate">{c.name}</span>
                      <span className="text-[11px] font-mono text-slate-400">#{c.numeric_order}</span>
                      {c.hasSections === false && (
                        <span className="text-[11px] font-medium px-2 py-0.5 rounded bg-indigo-50 text-indigo-700 border border-indigo-200">
                          No Sections
                        </span>
                      )}
                      {!c.is_active && !c.isDeleted && (
                        <span className="text-[11px] font-medium text-amber-700">Inactive</span>
                      )}
                      {c.isDeleted && (
                        <span className="text-[11px] font-medium text-red-700">Archived</span>
                      )}
                    </div>
                    <div className="flex items-center gap-1.5">
                      <span className="text-xs text-slate-500 font-mono mr-1 tabular-nums">
                        {(c.sections || []).reduce((sum: number, s: any) => sum + (s.student_count || 0), 0)} Students
                      </span>
                      {viewMode === 'active' ? (
                        <>
                          <button
                            type="button"
                            onClick={() =>
                              setEditingClass({
                                id: c.id,
                                name: c.name,
                                numericOrder: Number(c.numeric_order || 1),
                                hasSections: c.hasSections !== false,
                                isActive: Boolean(c.is_active),
                              })
                            }
                            className="min-w-[34px] min-h-[34px] inline-flex items-center justify-center p-1.5 text-slate-600 hover:text-slate-900 hover:bg-slate-100 rounded-md transition-colors cursor-pointer"
                            title="Edit Class"
                          >
                            <Pencil className="w-3.5 h-3.5" />
                          </button>
                          <button
                            type="button"
                            onClick={() => setDeleteClassTarget({ id: c.id, name: c.name })}
                            className="min-w-[34px] min-h-[34px] inline-flex items-center justify-center p-1.5 text-red-600 hover:text-red-800 hover:bg-red-50 rounded-md transition-colors cursor-pointer"
                            title="Archive Class"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </>
                      ) : (
                        c.isDeleted && (
                          <button
                            type="button"
                            onClick={() => handleQuickRestore('class', c.id)}
                            className="min-h-[34px] inline-flex items-center gap-1 px-2.5 py-1 text-[11px] font-semibold text-emerald-800 bg-emerald-50 border border-emerald-200 rounded-lg hover:bg-emerald-100 cursor-pointer"
                          >
                            <RotateCcw className="w-3 h-3" />
                            Restore
                          </button>
                        )
                      )}
                    </div>
                  </div>
                  <div className="space-y-1.5">
                    {(c.sections || []).map((s: any) => {
                      const isSectionlessClass = c.hasSections === false;
                      const secSelectable = !isSectionlessClass && (viewMode === 'active' ? !s.isDeleted : Boolean(s.isDeleted));
                      const secChecked = selectedSectionIds.includes(s.id);
                      return (
                        <div
                          key={s.id}
                          className={`flex items-center justify-between text-xs py-2 px-2.5 rounded-lg ${
                            secChecked ? 'bg-sky-50 border border-sky-200' : 'bg-slate-50'
                          }`}
                        >
                          <label className="inline-flex items-center gap-2 font-medium text-slate-800 cursor-pointer">
                            {secSelectable && (
                              <input
                                type="checkbox"
                                checked={secChecked}
                                onChange={() => toggleSectionSelect(s.id)}
                                className="rounded border-slate-300"
                              />
                            )}
                            <span>{isSectionlessClass ? 'Single Cohort (No Sections)' : `Section ${s.name}`}</span>
                          </label>
                          <div className="flex items-center gap-2">
                            <span className="font-mono text-slate-600 tabular-nums">
                              {s.student_count} / {s.capacity}
                            </span>
                            {viewMode === 'active' ? (
                              <>
                                <button
                                  type="button"
                                  onClick={() =>
                                    setEditingSection({
                                      id: s.id,
                                      className: c.name,
                                      name: s.name,
                                      capacity: Number(s.capacity || 30),
                                    })
                                  }
                                  className="min-w-[30px] min-h-[30px] inline-flex items-center justify-center p-1 text-slate-500 hover:text-slate-900 rounded hover:bg-slate-200/70 cursor-pointer"
                                  title={isSectionlessClass ? 'Edit Capacity' : 'Edit Section'}
                                >
                                  <Pencil className="w-3 h-3" />
                                </button>
                                {!isSectionlessClass && (
                                  <button
                                    type="button"
                                    onClick={() =>
                                      setDeleteSectionTarget({ id: s.id, className: c.name, name: s.name })
                                    }
                                    className="min-w-[30px] min-h-[30px] inline-flex items-center justify-center p-1 text-red-600 hover:text-red-800 rounded hover:bg-red-100/70 cursor-pointer"
                                    title="Archive Section"
                                  >
                                    <Trash2 className="w-3 h-3" />
                                  </button>
                                )}
                              </>
                            ) : (
                              s.isDeleted && (
                                <button
                                  type="button"
                                  onClick={() => handleQuickRestore('section', s.id)}
                                  className="inline-flex items-center gap-1 px-2 py-1 text-[11px] font-semibold text-emerald-800 bg-emerald-50 border border-emerald-200 rounded hover:bg-emerald-100 cursor-pointer"
                                >
                                  <RotateCcw className="w-3 h-3" />
                                  Restore
                                </button>
                              )
                            )}
                          </div>
                        </div>
                      );
                    })}
                  </div>
                  {viewMode === 'active' && c.hasSections !== false && (
                    <div className="flex items-center gap-2 pt-1">
                      <input
                        type="text"
                        value={sectionInputs[c.id] || ''}
                        onChange={(e) => setSectionInputs((p) => ({ ...p, [c.id]: e.target.value }))}
                        placeholder="Add section (e.g. C)"
                        className="flex-1 min-h-[38px] px-2.5 py-1.5 text-xs border border-slate-300 rounded-lg"
                      />
                      <button
                        type="button"
                        onClick={() => addSection(c.id)}
                        className="min-h-[38px] px-3 py-1.5 text-xs font-medium border border-slate-300 rounded-lg hover:bg-slate-50 whitespace-nowrap cursor-pointer"
                      >
                        Add Section
                      </button>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Subjects & Components */}
      <div className="space-y-4 pt-6 border-t border-slate-200">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
          <div>
            <h3 className="text-base font-bold text-slate-900">
              {viewMode === 'active' ? 'Subjects & Subject Components' : 'Archived Subjects'}
            </h3>
            <p className="text-xs text-slate-500">
              Configure single papers, combined-component subjects, and elective sub-option subjects
            </p>
          </div>
          <div className="flex flex-wrap items-center gap-2">
            <div className="relative flex-1 sm:w-60">
              <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={subjectSearch}
                onChange={(e) => setSubjectSearch(e.target.value)}
                placeholder="Search subjects or codes..."
                className="w-full min-h-[40px] sm:min-h-[36px] pl-8 pr-3 py-1.5 text-xs bg-white border border-slate-300 rounded-lg"
              />
            </div>
            {pagedSubjectIds.length > 0 && (
              <label className="min-h-[40px] sm:min-h-[36px] inline-flex items-center gap-2 px-3 py-1.5 bg-white border border-slate-300 rounded-lg text-xs font-medium text-slate-700 cursor-pointer">
                <input
                  type="checkbox"
                  checked={allPagedSubjectsSelected}
                  onChange={toggleSelectAllPagedSubjects}
                  className="rounded border-slate-300"
                />
                Select Page ({pagedSubjectIds.length})
              </label>
            )}
          </div>
        </div>

        {selectedSubjectIds.length > 0 && (
          <BulkActionToolbar
            selectedCount={selectedSubjectIds.length}
            entityLabel="subject"
            onClearSelection={() => setSelectedSubjectIds([])}
            disabled={bulkBusy}
            actions={
              viewMode === 'active'
                ? [
                    {
                      id: 'activate-sub',
                      label: 'Activate',
                      icon: 'activate',
                      variant: 'success',
                      onClick: () => openBulkSubjectConfirm('activate'),
                    },
                    {
                      id: 'deactivate-sub',
                      label: 'Deactivate',
                      icon: 'deactivate',
                      variant: 'warning',
                      onClick: () => openBulkSubjectConfirm('deactivate'),
                    },
                    {
                      id: 'archive-sub',
                      label: 'Delete / Archive',
                      icon: 'delete',
                      variant: 'danger',
                      onClick: () => openBulkSubjectConfirm('delete'),
                    },
                  ]
                : [
                    {
                      id: 'restore-sub',
                      label: 'Restore Selected',
                      icon: 'restore',
                      variant: 'success',
                      onClick: () => openBulkSubjectConfirm('restore'),
                    },
                  ]
            }
          />
        )}

        {viewMode === 'active' && (
          <form onSubmit={addSubject} className="bg-white border border-slate-200 rounded-xl p-4 space-y-3 text-xs">
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-6 gap-3 items-end">
              <div>
                <label className="block font-semibold text-slate-700 mb-1">Subject Code</label>
                <input
                  type="text"
                  required
                  value={newSub.code}
                  onChange={(e) => setNewSub({ ...newSub, code: e.target.value })}
                  placeholder="e.g. SANS"
                  className="w-full min-h-[40px] px-3 py-2 border border-slate-300 rounded-lg font-mono uppercase"
                />
              </div>
              <div className="lg:col-span-2">
                <label className="block font-semibold text-slate-700 mb-1">Subject Name</label>
                <input
                  type="text"
                  required
                  value={newSub.name}
                  onChange={(e) => setNewSub({ ...newSub, name: e.target.value })}
                  placeholder="e.g. Sanskrit"
                  className="w-full min-h-[40px] px-3 py-2 border border-slate-300 rounded-lg"
                />
              </div>
              <div className="lg:col-span-2">
                <label className="block font-semibold text-slate-700 mb-1">Structure Mode</label>
                <select
                  value={newSub.componentMode}
                  onChange={(e) => {
                    const mode = e.target.value as ComponentMode;
                    setNewSub({
                      ...newSub,
                      componentMode: mode,
                      initialComponents:
                        mode === 'single'
                          ? [{ name: '', code: '', defaultMaxMarks: 80 }]
                          : mode === 'elective'
                            ? [
                                { name: 'Option 1', code: 'OPT1', defaultMaxMarks: 80 },
                                { name: 'Option 2', code: 'OPT2', defaultMaxMarks: 80 },
                              ]
                            : [
                                { name: 'Component 1', code: 'CMP1', defaultMaxMarks: 40 },
                                { name: 'Component 2', code: 'CMP2', defaultMaxMarks: 40 },
                              ],
                    });
                  }}
                  className="w-full min-h-[40px] px-3 py-2 border border-slate-300 rounded-lg bg-white"
                >
                  <option value="single">Single Subject Paper</option>
                  <option value="combined">Combined Components (Summed)</option>
                  <option value="elective">Elective Sub-Options (1 per Student)</option>
                </select>
              </div>
              {newSub.componentMode === 'single' && (
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Written Exam Max</label>
                  <input
                    type="number"
                    min={1}
                    value={newSub.defaultMaxMarks}
                    onChange={(e) => setNewSub({ ...newSub, defaultMaxMarks: Number(e.target.value) })}
                    className="w-full min-h-[40px] px-3 py-2 border border-slate-300 rounded-lg font-mono"
                  />
                </div>
              )}
            </div>

              <div className="flex flex-wrap items-center gap-2 pt-1 border-t border-slate-100">
                <span className="font-semibold text-slate-600">Quick Marks Presets:</span>
                <button
                  type="button"
                  onClick={() =>
                    setNewSub((p) => ({
                      ...p,
                      defaultMaxMarks: 80,
                      hasInternalAssessment: true,
                      hasPractical: false,
                      iaNotebookMax: 5,
                      iaUnitTestMax: 5,
                      iaPracticalMax: 5,
                      iaParticipationMax: 5,
                    }))
                  }
                  className="px-2.5 py-1 rounded border border-slate-300 bg-slate-50 hover:bg-slate-100 font-medium cursor-pointer"
                >
                  80 Written + 20 IA
                </button>
                <button
                  type="button"
                  onClick={() =>
                    setNewSub((p) => ({
                      ...p,
                      defaultMaxMarks: 70,
                      hasInternalAssessment: true,
                      hasPractical: true,
                      iaNotebookMax: 0,
                      iaUnitTestMax: 0,
                      iaPracticalMax: 30,
                      iaParticipationMax: 0,
                    }))
                  }
                  className="px-2.5 py-1 rounded border border-indigo-200 bg-indigo-50 text-indigo-800 hover:bg-indigo-100 font-medium cursor-pointer"
                >
                  70 Theory + 30 Practical (CBSE)
                </button>
                <button
                  type="button"
                  onClick={() =>
                    setNewSub((p) => ({
                      ...p,
                      defaultMaxMarks: 100,
                      hasInternalAssessment: false,
                      hasPractical: false,
                      iaNotebookMax: 0,
                      iaUnitTestMax: 0,
                      iaPracticalMax: 0,
                      iaParticipationMax: 0,
                    }))
                  }
                  className="px-2.5 py-1 rounded border border-slate-300 bg-slate-50 hover:bg-slate-100 font-medium cursor-pointer"
                >
                  100 Theory (No Practical/IA)
                </button>
                <div className="ml-auto flex flex-wrap items-center gap-3">
                  <div>
                    <label className="font-semibold text-slate-700 mr-1.5">Stream / Group:</label>
                    <select
                      value={newSub.streamCategory}
                      onChange={(e) => setNewSub({ ...newSub, streamCategory: e.target.value as SubjectStreamCategory })}
                      className="min-h-[34px] px-2.5 py-1 border border-slate-300 rounded-lg bg-white"
                    >
                      <option value="">All / Unspecified</option>
                      <option value="Common">Common (All Streams)</option>
                      <option value="Science">Science</option>
                      <option value="Humanities">Humanities</option>
                      <option value="Language">Language / Optional</option>
                    </select>
                  </div>
                  <label className="inline-flex items-center gap-1.5 font-medium text-slate-700 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={newSub.hasPractical}
                      onChange={(e) => setNewSub({ ...newSub, hasPractical: e.target.checked })}
                    />
                    Has Practical Exam
                  </label>
                </div>
              </div>

              <div className="pt-1 border-t border-slate-100">
                <div className="flex flex-wrap items-center gap-2">
                  <span className="font-semibold text-slate-700">Applicable Classes:</span>
                  <span className="text-[11px] text-slate-500">(Leave all unchecked for All Classes)</span>
                  <div className="flex flex-wrap gap-1.5">
                    {classes
                      .filter((c) => !c.isDeleted)
                      .map((c) => {
                        const active = newSub.applicableClassIds.includes(c.id);
                        return (
                          <label
                            key={c.id}
                            className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded border cursor-pointer ${
                              active
                                ? 'bg-[#1E3A5F] text-white border-[#1E3A5F]'
                                : 'bg-white text-slate-700 border-slate-300 hover:bg-slate-50'
                            }`}
                          >
                            <input
                              type="checkbox"
                              checked={active}
                              onChange={(e) =>
                                setNewSub((p) => ({
                                  ...p,
                                  applicableClassIds: e.target.checked
                                    ? [...p.applicableClassIds, c.id]
                                    : p.applicableClassIds.filter((id) => id !== c.id),
                                }))
                              }
                              className="sr-only"
                            />
                            <span>{c.name}</span>
                          </label>
                        );
                      })}
                  </div>
                </div>
              </div>

            <div className="flex flex-wrap items-end gap-3 pt-1">
              <label className="inline-flex items-center gap-2 min-h-[38px] text-slate-700 cursor-pointer">
                <input
                  type="checkbox"
                  checked={newSub.hasInternalAssessment}
                  onChange={(e) => setNewSub({ ...newSub, hasInternalAssessment: e.target.checked })}
                />
                {newSub.hasPractical ? 'Internal Assessment / Practical Marks' : 'Internal Assessment (IA)'}
              </label>
              {newSub.hasInternalAssessment && (
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                  <div>
                    <label className="block font-semibold text-slate-700 mb-1">Notebook</label>
                    <input
                      type="number"
                      min={0}
                      value={newSub.iaNotebookMax}
                      onChange={(e) => setNewSub({ ...newSub, iaNotebookMax: Number(e.target.value) })}
                      className="w-20 min-h-[38px] px-2.5 py-1.5 border border-slate-300 rounded-lg font-mono"
                    />
                  </div>
                  <div>
                    <label className="block font-semibold text-slate-700 mb-1">Unit Test</label>
                    <input
                      type="number"
                      min={0}
                      value={newSub.iaUnitTestMax}
                      onChange={(e) => setNewSub({ ...newSub, iaUnitTestMax: Number(e.target.value) })}
                      className="w-20 min-h-[38px] px-2.5 py-1.5 border border-slate-300 rounded-lg font-mono"
                    />
                  </div>
                  <div>
                    <label className="block font-semibold text-slate-700 mb-1">Practical/Proj</label>
                    <input
                      type="number"
                      min={0}
                      value={newSub.iaPracticalMax}
                      onChange={(e) => setNewSub({ ...newSub, iaPracticalMax: Number(e.target.value) })}
                      className="w-20 min-h-[38px] px-2.5 py-1.5 border border-slate-300 rounded-lg font-mono"
                    />
                  </div>
                  <div>
                    <label className="block font-semibold text-slate-700 mb-1">Partic.</label>
                    <input
                      type="number"
                      min={0}
                      value={newSub.iaParticipationMax}
                      onChange={(e) => setNewSub({ ...newSub, iaParticipationMax: Number(e.target.value) })}
                      className="w-20 min-h-[38px] px-2.5 py-1.5 border border-slate-300 rounded-lg font-mono"
                    />
                  </div>
                </div>
              )}
              <button
                type="submit"
                className="min-h-[40px] px-4 py-2 font-semibold text-white bg-[#1E3A5F] rounded-lg hover:bg-[#162D4A] ml-auto cursor-pointer"
              >
                Add Subject (Total:{' '}
                {(newSub.componentMode === 'single'
                  ? Number(newSub.defaultMaxMarks || 0)
                  : newSub.componentMode === 'elective'
                    ? Number(newSub.initialComponents[0]?.defaultMaxMarks || 0)
                    : newSub.initialComponents.reduce((s, c) => s + Number(c.defaultMaxMarks || 0), 0)) +
                  (newSub.hasInternalAssessment
                    ? Number(newSub.iaNotebookMax || 0) +
                      Number(newSub.iaUnitTestMax || 0) +
                      Number(newSub.iaPracticalMax || 0) +
                      Number(newSub.iaParticipationMax || 0)
                    : 0)}
                )
              </button>
            </div>

            {newSub.componentMode !== 'single' && (
              <div className="pt-3 border-t border-slate-100 space-y-2">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <span className="font-semibold text-slate-800">
                    {newSub.componentMode === 'elective'
                      ? 'Initial Elective Sub-Options (separate teachers, 1 chosen per student)'
                      : 'Initial Subject Components (summed per student)'}
                  </span>
                  <button
                    type="button"
                    onClick={() =>
                      setNewSub((p) => ({
                        ...p,
                        initialComponents: [
                          ...p.initialComponents,
                          { name: '', code: '', defaultMaxMarks: p.componentMode === 'elective' ? 80 : 25 },
                        ],
                      }))
                    }
                    className="min-h-[34px] px-2.5 py-1 text-[11px] font-medium border border-slate-300 rounded hover:bg-slate-50 cursor-pointer"
                  >
                    + Add {newSub.componentMode === 'elective' ? 'Option' : 'Component'}
                  </button>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  {newSub.initialComponents.map((comp, idx) => (
                    <div key={idx} className="flex items-center gap-2 bg-slate-50 border border-slate-200 p-2 rounded-lg">
                      <input
                        type="text"
                        required
                        placeholder={newSub.componentMode === 'elective' ? 'Option Name (e.g. Nepali)' : 'Component Name'}
                        value={comp.name}
                        onChange={(e) => {
                          const next = [...newSub.initialComponents];
                          next[idx] = { ...next[idx], name: e.target.value };
                          setNewSub({ ...newSub, initialComponents: next });
                        }}
                        className="flex-1 min-w-0 px-2 py-1.5 border border-slate-300 rounded bg-white"
                      />
                      <input
                        type="text"
                        required
                        placeholder="Code"
                        value={comp.code}
                        onChange={(e) => {
                          const next = [...newSub.initialComponents];
                          next[idx] = { ...next[idx], code: e.target.value };
                          setNewSub({ ...newSub, initialComponents: next });
                        }}
                        className="w-20 px-2 py-1.5 border border-slate-300 rounded bg-white font-mono uppercase"
                      />
                      <input
                        type="number"
                        min={1}
                        required
                        value={comp.defaultMaxMarks}
                        onChange={(e) => {
                          const next = [...newSub.initialComponents];
                          next[idx] = { ...next[idx], defaultMaxMarks: Number(e.target.value) };
                          setNewSub({ ...newSub, initialComponents: next });
                        }}
                        className="w-16 px-2 py-1.5 border border-slate-300 rounded bg-white font-mono text-right"
                      />
                      {newSub.initialComponents.length > 1 && (
                        <button
                          type="button"
                          onClick={() =>
                            setNewSub({
                              ...newSub,
                              initialComponents: newSub.initialComponents.filter((_, i) => i !== idx),
                            })
                          }
                          className="text-red-600 hover:text-red-800 p-1 cursor-pointer"
                          title="Remove row"
                        >
                          <X className="w-3.5 h-3.5" />
                        </button>
                      )}
                    </div>
                  ))}
                </div>
              </div>
            )}
          </form>
        )}

        {pagedSubjects.length === 0 ? (
          <div className="bg-white border border-slate-200 rounded-xl p-8 text-center text-xs text-slate-500">
            {viewMode === 'archived' ? 'No archived subjects found.' : 'No matching subjects found.'}
          </div>
        ) : (
          <div className="bg-white border border-slate-200 rounded-xl overflow-hidden">
            <div className="p-4 grid grid-cols-1 md:grid-cols-2 gap-4">
              {pagedSubjects.map((sub) => {
                const isElective = sub.componentMode === 'elective';
                const writtenTotal = isElective
                  ? Number(sub.components[0]?.default_max_marks || 0)
                  : sub.components.reduce((s, c) => s + Number(c.default_max_marks || 0), 0);
                const iaTotal = sub.hasInternalAssessment
                  ? Number(sub.iaNotebookMax || 0) +
                    Number(sub.iaUnitTestMax || 0) +
                    Number(sub.iaPracticalMax || 0) +
                    Number(sub.iaParticipationMax || 0)
                  : 0;
                const defaultCompMax = isElective ? writtenTotal || 80 : 25;
                const isSelected = selectedSubjectIds.includes(sub.id);
                return (
                  <div
                    key={sub.id}
                    className={`bg-white border rounded-xl p-4 space-y-3 ${
                      isSelected ? 'border-[#1E3A5F] ring-1 ring-[#1E3A5F]/20' : 'border-slate-200'
                    }`}
                  >
                    <div className="flex flex-wrap items-start justify-between gap-2 border-b border-slate-100 pb-2.5">
                      <div className="flex items-start gap-2.5 min-w-0">
                        <input
                          type="checkbox"
                          checked={isSelected}
                          onChange={() => toggleSubjectSelect(sub.id)}
                          aria-label={`Select ${sub.name}`}
                          className="mt-1 w-4 h-4 rounded border-slate-300 cursor-pointer shrink-0"
                        />
                        <div className="min-w-0">
                          <div className="flex flex-wrap items-center gap-2">
                            <span className="font-bold text-sm text-slate-900">{sub.name}</span>
                            <span className="font-mono text-xs text-slate-500">{sub.code}</span>
                            {sub.streamCategory && (
                              <span className="text-[11px] font-medium px-1.5 py-0.5 rounded bg-slate-100 text-slate-700 border border-slate-200">
                                {sub.streamCategory}
                              </span>
                            )}
                            {sub.hasPractical && (
                              <span className="text-[11px] font-medium px-1.5 py-0.5 rounded bg-indigo-50 text-indigo-700 border border-indigo-200">
                                Practical
                              </span>
                            )}
                            {sub.is_active === 0 && (
                              <span className="text-[11px] font-medium text-amber-700">Inactive</span>
                            )}
                          </div>
                          {sub.applicableClassIds && sub.applicableClassIds.length > 0 && (
                            <div className="text-[11px] text-slate-600 mt-0.5">
                              Classes:{' '}
                              {sub.applicableClassIds
                                .map((cid) => classes.find((c) => c.id === cid)?.name || `#${cid}`)
                                .join(', ')}
                            </div>
                          )}
                          {isElective && (
                            <div className="text-[11px] font-medium text-amber-700 mt-0.5">
                              Elective Sub-Options (1 option per student)
                            </div>
                          )}
                        </div>
                      </div>
                      <div className="flex flex-wrap items-center gap-1.5">
                        <div className="text-xs font-mono font-semibold text-[#1E3A5F] tabular-nums whitespace-nowrap mr-1">
                          Total: {sub.default_max_marks} Marks
                        </div>
                        {viewMode === 'active' ? (
                          <>
                            <button
                              type="button"
                              onClick={() => openEditSubject(sub)}
                              className="min-h-[34px] inline-flex items-center gap-1 px-2.5 py-1 text-[11px] font-medium text-slate-700 bg-white border border-slate-300 rounded-md hover:bg-slate-50 transition-colors whitespace-nowrap cursor-pointer"
                            >
                              <Pencil className="w-3 h-3" />
                              Edit Marks
                            </button>
                            <button
                              type="button"
                              onClick={() => setDeleteSubjectTarget(sub)}
                              title="Archive Subject"
                              className="min-h-[34px] inline-flex items-center gap-1 px-2.5 py-1 text-[11px] font-medium text-red-700 bg-red-50 border border-red-200 rounded-md hover:bg-red-100 transition-colors whitespace-nowrap cursor-pointer"
                            >
                              <Trash2 className="w-3 h-3" />
                              Archive
                            </button>
                          </>
                        ) : (
                          <button
                            type="button"
                            onClick={() => handleQuickRestore('subject', sub.id)}
                            className="min-h-[34px] inline-flex items-center gap-1 px-2.5 py-1 text-[11px] font-semibold text-emerald-800 bg-emerald-50 border border-emerald-200 rounded-md hover:bg-emerald-100 cursor-pointer"
                          >
                            <RotateCcw className="w-3 h-3" />
                            Restore
                          </button>
                        )}
                      </div>
                    </div>
                    <div className="space-y-1.5">
                      {sub.components.map((c) => (
                        <div key={c.id} className="flex items-center justify-between text-xs py-1.5 px-2.5 bg-slate-50 rounded">
                          <span className="font-medium text-slate-800">
                            {c.name} <span className="font-mono text-slate-400">({c.code})</span>
                          </span>
                          <div className="flex items-center gap-3">
                            <span className="font-mono font-semibold tabular-nums">{c.default_max_marks} marks</span>
                            {viewMode === 'active' && sub.components.length > 1 && (
                              <button
                                type="button"
                                onClick={() =>
                                  setDeleteComponentTarget({ id: c.id, name: c.name, subjectName: sub.name })
                                }
                                className="text-red-600 hover:text-red-800 cursor-pointer"
                                title={isElective ? 'Remove sub-option' : 'Remove component'}
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                              </button>
                            )}
                          </div>
                        </div>
                      ))}
                      {sub.hasInternalAssessment && (
                        <div className="flex flex-wrap items-center justify-between gap-2 text-xs py-1.5 px-2.5 bg-sky-50/70 border border-sky-100 rounded">
                          <span className="font-medium text-sky-900">
                            Internal Assessment{' '}
                            <span className="font-mono text-[11px] text-sky-700">
                              (NB {sub.iaNotebookMax} + UT {sub.iaUnitTestMax} + Pr {sub.iaPracticalMax} + OP{' '}
                              {sub.iaParticipationMax})
                            </span>
                          </span>
                          <span className="font-mono font-semibold text-sky-900 tabular-nums">
                            {iaTotal} marks (Exam {writtenTotal}
                            {isElective ? '/opt' : ''} + IA {iaTotal})
                          </span>
                        </div>
                      )}
                    </div>
                    {viewMode === 'active' && (
                      <div className="flex flex-wrap sm:flex-nowrap items-center gap-2 pt-1">
                        <input
                          type="text"
                          placeholder={isElective ? 'Sub-option Name' : 'Component Name'}
                          value={compForms[sub.id]?.name || ''}
                          onChange={(e) =>
                            setCompForms((p) => ({
                              ...p,
                              [sub.id]: {
                                ...p[sub.id],
                                name: e.target.value,
                                code: p[sub.id]?.code || '',
                                max: p[sub.id]?.max ?? defaultCompMax,
                              },
                            }))
                          }
                          className="flex-1 min-w-[120px] min-h-[38px] px-2.5 py-1.5 text-xs border border-slate-300 rounded-lg"
                        />
                        <input
                          type="text"
                          placeholder="Code"
                          value={compForms[sub.id]?.code || ''}
                          onChange={(e) =>
                            setCompForms((p) => ({
                              ...p,
                              [sub.id]: {
                                ...p[sub.id],
                                code: e.target.value,
                                name: p[sub.id]?.name || '',
                                max: p[sub.id]?.max ?? defaultCompMax,
                              },
                            }))
                          }
                          className="w-20 min-h-[38px] px-2.5 py-1.5 text-xs border border-slate-300 rounded-lg font-mono uppercase"
                        />
                        <input
                          type="number"
                          placeholder="Max"
                          value={compForms[sub.id]?.max ?? defaultCompMax}
                          onChange={(e) =>
                            setCompForms((p) => ({
                              ...p,
                              [sub.id]: {
                                ...p[sub.id],
                                max: Number(e.target.value),
                                name: p[sub.id]?.name || '',
                                code: p[sub.id]?.code || '',
                              },
                            }))
                          }
                          className="w-16 min-h-[38px] px-2.5 py-1.5 text-xs border border-slate-300 rounded-lg font-mono"
                        />
                        <button
                          type="button"
                          onClick={() => addComponent(sub.id, defaultCompMax)}
                          className="min-h-[38px] px-3 py-1.5 text-xs font-medium border border-slate-300 rounded-lg hover:bg-slate-50 whitespace-nowrap cursor-pointer"
                        >
                          {isElective ? '+ Sub-Option' : '+ Component'}
                        </button>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
            <PaginationBar
              totalItems={filteredSubjects.length}
              page={subPage}
              pageSize={subPageSize}
              onPageChange={setSubPage}
              onPageSizeChange={setSubPageSize}
            />
          </div>
        )}
      </div>

      {/* Bulk Confirm Modal */}
      <BulkConfirmModal
        open={Boolean(bulkConfirm)}
        title={
          bulkConfirm
            ? `${
                bulkConfirm.action === 'restore'
                  ? 'Restore'
                  : bulkConfirm.action === 'activate'
                    ? 'Activate'
                    : bulkConfirm.action === 'deactivate'
                      ? 'Deactivate'
                      : 'Archive / Soft-Delete'
              } ${bulkConfirm.items.length} ${
                bulkConfirm.scope === 'class'
                  ? 'Class(es)'
                  : bulkConfirm.scope === 'section'
                    ? 'Section(s)'
                    : 'Subject(s)'
              }?`
            : ''
        }
        confirmLabel={
          bulkConfirm?.action === 'restore'
            ? 'Confirm Restore'
            : bulkConfirm?.action === 'activate'
              ? 'Confirm Activate'
              : bulkConfirm?.action === 'deactivate'
                ? 'Confirm Deactivate'
                : 'Confirm Archive / Delete'
        }
        description={
          bulkConfirm?.action === 'delete' || bulkConfirm?.action === 'archive'
            ? `${bulkConfirm.items.length} selected record(s) will be archived and removed from active selection lists.`
            : `This will update ${bulkConfirm?.items.length || 0} selected record(s).`
        }
        safetyNote={
          bulkConfirm?.action === 'delete' || bulkConfirm?.action === 'archive'
            ? 'Historical student marks, attendance logs, and examination reports are strictly preserved. Records can be restored anytime.'
            : undefined
        }
        items={bulkConfirm?.items || []}
        variant={
          bulkConfirm?.action === 'restore' || bulkConfirm?.action === 'activate'
            ? 'primary'
            : bulkConfirm?.action === 'deactivate'
              ? 'warning'
              : 'danger'
        }
        busy={bulkBusy}
        onCancel={() => setBulkConfirm(null)}
        onConfirm={executeBulkAction}
      />

      {/* Edit Subject & Total Marks Modal */}
      {editingSubject && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/50 p-4">
          <form
            onSubmit={handleSaveSubjectMarks}
            className="bg-white border border-slate-200 rounded-xl w-full max-w-lg max-h-[90vh] overflow-y-auto p-6 space-y-4 shadow-xl text-xs"
          >
            <div className="flex items-center justify-between">
              <h3 className="text-base font-bold text-slate-900">
                Edit Subject &amp; Total Marks — {editingSubject.name}
              </h3>
              <button type="button" onClick={() => setEditingSubject(null)} className="p-1 cursor-pointer">
                <X className="w-4 h-4 text-slate-400" />
              </button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div className="sm:col-span-2">
                <label className="block font-semibold text-slate-700 mb-1">Subject Name *</label>
                <input
                  type="text"
                  required
                  value={editingSubject.name}
                  onChange={(e) => setEditingSubject({ ...editingSubject, name: e.target.value })}
                  className="w-full min-h-[40px] px-3 py-2 border border-slate-300 rounded-lg"
                />
              </div>
              <div>
                <label className="block font-semibold text-slate-700 mb-1">Code *</label>
                <input
                  type="text"
                  required
                  value={editingSubject.code}
                  onChange={(e) => setEditingSubject({ ...editingSubject, code: e.target.value })}
                  className="w-full min-h-[40px] px-3 py-2 border border-slate-300 rounded-lg font-mono uppercase"
                />
              </div>
            </div>

            {editingSubject.hasComponents ? (
              <div className="space-y-2.5 pt-2 border-t border-slate-100">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <span className="font-semibold text-slate-800">
                    {editingSubject.componentMode === 'elective'
                      ? 'Edit Elective Sub-Option Marks'
                      : 'Edit Written Component Marks'}
                  </span>
                  <span className="font-mono font-semibold text-slate-700 tabular-nums">
                    Written Exam:{' '}
                    {editingSubject.componentMode === 'elective'
                      ? Number(editingSubject.components[0]?.defaultMaxMarks || 0)
                      : editingSubject.components.reduce((sum, c) => sum + Number(c.defaultMaxMarks || 0), 0)}
                    {editingSubject.componentMode === 'elective' ? ' (1 opt/student)' : ''}
                  </span>
                </div>
                <div className="space-y-2">
                  {editingSubject.components.map((comp, idx) => (
                    <div
                      key={comp.id}
                      className="grid grid-cols-1 sm:grid-cols-12 gap-2 items-center bg-slate-50 border border-slate-200 p-2 rounded-lg"
                    >
                      <input
                        type="text"
                        required
                        value={comp.name}
                        onChange={(e) => {
                          const next = [...editingSubject.components];
                          next[idx] = { ...next[idx], name: e.target.value };
                          setEditingSubject({ ...editingSubject, components: next });
                        }}
                        className="sm:col-span-5 px-2.5 py-1.5 border border-slate-300 rounded bg-white font-medium"
                      />
                      <input
                        type="text"
                        required
                        value={comp.code}
                        onChange={(e) => {
                          const next = [...editingSubject.components];
                          next[idx] = { ...next[idx], code: e.target.value };
                          setEditingSubject({ ...editingSubject, components: next });
                        }}
                        className="sm:col-span-3 px-2.5 py-1.5 border border-slate-300 rounded bg-white font-mono uppercase"
                      />
                      <div className="sm:col-span-4 flex items-center justify-end gap-1.5">
                        <span className="text-slate-500">Max:</span>
                        <input
                          type="number"
                          required
                          min={1}
                          step="1"
                          value={comp.defaultMaxMarks}
                          onChange={(e) => {
                            const next = [...editingSubject.components];
                            next[idx] = { ...next[idx], defaultMaxMarks: Number(e.target.value) };
                            setEditingSubject({ ...editingSubject, components: next });
                          }}
                          className="w-20 px-2.5 py-1.5 border border-slate-300 rounded bg-white font-mono font-semibold text-right tabular-nums"
                        />
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            ) : (
              <div className="pt-2 border-t border-slate-100">
                <label className="block font-semibold text-slate-700 mb-1">Written Examination Maximum Marks *</label>
                <input
                  type="number"
                  required
                  min={1}
                  step="1"
                  value={editingSubject.writtenMaxMarks}
                  onChange={(e) =>
                    setEditingSubject({ ...editingSubject, writtenMaxMarks: Number(e.target.value) })
                  }
                  className="w-full min-h-[40px] px-3 py-2 border border-slate-300 rounded-lg font-mono font-semibold tabular-nums"
                />
              </div>
            )}

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2 border-t border-slate-100">
              <div>
                <label className="block font-semibold text-slate-700 mb-1">Stream / Category</label>
                <select
                  value={editingSubject.streamCategory}
                  onChange={(e) =>
                    setEditingSubject({ ...editingSubject, streamCategory: e.target.value as SubjectStreamCategory })
                  }
                  className="w-full min-h-[38px] px-3 py-1.5 border border-slate-300 rounded-lg bg-white"
                >
                  <option value="">All / Unspecified</option>
                  <option value="Common">Common (All Streams)</option>
                  <option value="Science">Science</option>
                  <option value="Humanities">Humanities</option>
                  <option value="Language">Language / Optional</option>
                </select>
              </div>
              <div className="flex items-end pb-2">
                <label className="inline-flex items-center gap-2 font-semibold text-slate-700 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={editingSubject.hasPractical}
                    onChange={(e) => setEditingSubject({ ...editingSubject, hasPractical: e.target.checked })}
                  />
                  Has Practical Examination
                </label>
              </div>
            </div>

            <div className="pt-2 border-t border-slate-100 space-y-1.5">
              <div className="flex items-center justify-between">
                <span className="font-semibold text-slate-700">Applicable Classes</span>
                <span className="text-[11px] text-slate-500">(Leave unchecked = All Classes)</span>
              </div>
              <div className="flex flex-wrap gap-1.5">
                {classes
                  .filter((c) => !c.isDeleted)
                  .map((c) => {
                    const active = editingSubject.applicableClassIds.includes(c.id);
                    return (
                      <label
                        key={c.id}
                        className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded border cursor-pointer ${
                          active
                            ? 'bg-[#1E3A5F] text-white border-[#1E3A5F]'
                            : 'bg-white text-slate-700 border-slate-300 hover:bg-slate-50'
                        }`}
                      >
                        <input
                          type="checkbox"
                          checked={active}
                          onChange={(e) =>
                            setEditingSubject((p) =>
                              p
                                ? {
                                    ...p,
                                    applicableClassIds: e.target.checked
                                      ? [...p.applicableClassIds, c.id]
                                      : p.applicableClassIds.filter((id) => id !== c.id),
                                  }
                                : null
                            )
                          }
                          className="sr-only"
                        />
                        <span>{c.name}</span>
                      </label>
                    );
                  })}
              </div>
            </div>

            <div className="space-y-3 pt-3 border-t border-slate-100">
              {!editingSubject.hasComponents && (
                <div className="flex flex-wrap items-center gap-1.5">
                  <span className="text-[11px] font-semibold text-slate-500 mr-1">Presets:</span>
                  <button
                    type="button"
                    onClick={() =>
                      setEditingSubject({
                        ...editingSubject,
                        writtenMaxMarks: 80,
                        hasInternalAssessment: true,
                        hasPractical: false,
                        iaNotebookMax: 5,
                        iaUnitTestMax: 5,
                        iaPracticalMax: 5,
                        iaParticipationMax: 5,
                      })
                    }
                    className="px-2 py-1 rounded border border-slate-300 bg-slate-50 hover:bg-slate-100 text-[11px] cursor-pointer"
                  >
                    80 + 20 IA
                  </button>
                  <button
                    type="button"
                    onClick={() =>
                      setEditingSubject({
                        ...editingSubject,
                        writtenMaxMarks: 70,
                        hasInternalAssessment: true,
                        hasPractical: true,
                        iaNotebookMax: 0,
                        iaUnitTestMax: 0,
                        iaPracticalMax: 30,
                        iaParticipationMax: 0,
                      })
                    }
                    className="px-2 py-1 rounded border border-indigo-200 bg-indigo-50 text-indigo-800 hover:bg-indigo-100 text-[11px] cursor-pointer"
                  >
                    70 Theory + 30 Practical
                  </button>
                  <button
                    type="button"
                    onClick={() =>
                      setEditingSubject({
                        ...editingSubject,
                        writtenMaxMarks: 100,
                        hasInternalAssessment: false,
                        hasPractical: false,
                        iaNotebookMax: 0,
                        iaUnitTestMax: 0,
                        iaPracticalMax: 0,
                        iaParticipationMax: 0,
                      })
                    }
                    className="px-2 py-1 rounded border border-slate-300 bg-slate-50 hover:bg-slate-100 text-[11px] cursor-pointer"
                  >
                    100 Theory
                  </button>
                </div>
              )}
              <div className="flex flex-wrap items-center justify-between gap-2">
                <label className="inline-flex items-center gap-2 font-semibold text-slate-800 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={editingSubject.hasInternalAssessment}
                    onChange={(e) =>
                      setEditingSubject({ ...editingSubject, hasInternalAssessment: e.target.checked })
                    }
                  />
                  Include Internal Assessment / Practical Marks
                </label>
                <span className="font-mono font-bold text-[#1E3A5F] tabular-nums">
                  Subject Total:{' '}
                  {(editingSubject.hasComponents
                    ? editingSubject.componentMode === 'elective'
                      ? Number(editingSubject.components[0]?.defaultMaxMarks || 0)
                      : editingSubject.components.reduce((sum, c) => sum + Number(c.defaultMaxMarks || 0), 0)
                    : Number(editingSubject.writtenMaxMarks || 0)) +
                    (editingSubject.hasInternalAssessment
                      ? Number(editingSubject.iaNotebookMax || 0) +
                        Number(editingSubject.iaUnitTestMax || 0) +
                        Number(editingSubject.iaPracticalMax || 0) +
                        Number(editingSubject.iaParticipationMax || 0)
                      : 0)}{' '}
                  Marks
                </span>
              </div>

              {editingSubject.hasInternalAssessment && (
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 bg-sky-50/60 border border-sky-200 p-3 rounded-lg">
                  <div>
                    <label className="block font-semibold text-slate-700 mb-1">Notebook Max</label>
                    <input
                      type="number"
                      min={0}
                      required
                      value={editingSubject.iaNotebookMax}
                      onChange={(e) =>
                        setEditingSubject({ ...editingSubject, iaNotebookMax: Number(e.target.value) })
                      }
                      className="w-full px-2.5 py-1.5 border border-slate-300 rounded bg-white font-mono font-semibold tabular-nums"
                    />
                  </div>
                  <div>
                    <label className="block font-semibold text-slate-700 mb-1">Unit Test Max</label>
                    <input
                      type="number"
                      min={0}
                      required
                      value={editingSubject.iaUnitTestMax}
                      onChange={(e) =>
                        setEditingSubject({ ...editingSubject, iaUnitTestMax: Number(e.target.value) })
                      }
                      className="w-full px-2.5 py-1.5 border border-slate-300 rounded bg-white font-mono font-semibold tabular-nums"
                    />
                  </div>
                  <div>
                    <label className="block font-semibold text-slate-700 mb-1">Practical/Proj Max</label>
                    <input
                      type="number"
                      min={0}
                      required
                      value={editingSubject.iaPracticalMax}
                      onChange={(e) =>
                        setEditingSubject({ ...editingSubject, iaPracticalMax: Number(e.target.value) })
                      }
                      className="w-full px-2.5 py-1.5 border border-slate-300 rounded bg-white font-mono font-semibold tabular-nums"
                    />
                  </div>
                  <div>
                    <label className="block font-semibold text-slate-700 mb-1">Participation Max</label>
                    <input
                      type="number"
                      min={0}
                      required
                      value={editingSubject.iaParticipationMax}
                      onChange={(e) =>
                        setEditingSubject({ ...editingSubject, iaParticipationMax: Number(e.target.value) })
                      }
                      className="w-full px-2.5 py-1.5 border border-slate-300 rounded bg-white font-mono font-semibold tabular-nums"
                    />
                  </div>
                </div>
              )}
            </div>

            <div className="flex flex-col-reverse sm:flex-row sm:justify-end gap-2 pt-2">
              <button
                type="button"
                disabled={savingSubject}
                onClick={() => setEditingSubject(null)}
                className="min-h-[40px] px-3.5 py-2 border border-slate-300 rounded-lg hover:bg-slate-50 cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={savingSubject}
                className="min-h-[40px] px-4 py-2 font-semibold text-white bg-[#1E3A5F] rounded-lg hover:bg-[#162D4A] disabled:opacity-50 cursor-pointer"
              >
                {savingSubject ? 'Saving...' : 'Save Subject'}
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Archive Subject Confirmation Modal */}
      {deleteSubjectTarget && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/50 p-4">
          <div className="bg-white border border-slate-200 rounded-xl w-full max-w-sm p-6 space-y-4 shadow-xl text-xs">
            <h3 className="text-base font-bold text-slate-900">Archive / Soft-Delete Subject</h3>
            <p className="text-slate-600 leading-relaxed">
              Archive <span className="font-semibold text-slate-900">{deleteSubjectTarget.name}</span> (
              <span className="font-mono">{deleteSubjectTarget.code}</span>)?
            </p>
            <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-lg text-emerald-900">
              All historical examination marks, IA scores, and report cards for this subject are preserved. You can
              restore it anytime from Archived / Recovery.
            </div>
            <div className="flex flex-col-reverse sm:flex-row sm:justify-end gap-2">
              <button
                type="button"
                disabled={deletingSubject}
                onClick={() => setDeleteSubjectTarget(null)}
                className="min-h-[40px] px-3.5 py-2 border border-slate-300 rounded-lg hover:bg-slate-50 cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="button"
                disabled={deletingSubject}
                onClick={handleDeleteSubject}
                className="min-h-[40px] px-4 py-2 font-semibold text-white bg-red-600 rounded-lg hover:bg-red-700 disabled:opacity-50 cursor-pointer"
              >
                {deletingSubject ? 'Archiving...' : 'Archive Subject'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Edit Class Modal */}
      {editingClass && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/50 p-4">
          <form
            onSubmit={handleSaveClass}
            className="bg-white border border-slate-200 rounded-xl w-full max-w-sm p-6 space-y-4 shadow-xl text-xs"
          >
            <div className="flex items-center justify-between">
              <h3 className="text-base font-bold text-slate-900">Edit Class</h3>
              <button type="button" onClick={() => setEditingClass(null)} className="p-1 cursor-pointer">
                <X className="w-4 h-4 text-slate-400" />
              </button>
            </div>
            <div className="space-y-3">
              <div>
                <label className="block font-semibold text-slate-700 mb-1">Class Name *</label>
                <input
                  type="text"
                  required
                  value={editingClass.name}
                  onChange={(e) => setEditingClass({ ...editingClass, name: e.target.value })}
                  className="w-full min-h-[40px] px-3 py-2 border border-slate-300 rounded-lg"
                />
              </div>
              <div>
                <label className="block font-semibold text-slate-700 mb-1">Display Order</label>
                <input
                  type="number"
                  required
                  value={editingClass.numericOrder}
                  onChange={(e) => setEditingClass({ ...editingClass, numericOrder: Number(e.target.value) })}
                  className="w-full min-h-[40px] px-3 py-2 border border-slate-300 rounded-lg font-mono"
                />
              </div>
              <div className="space-y-2 pt-1">
                <label className="flex items-center gap-2 font-medium text-slate-700 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={!editingClass.hasSections}
                    onChange={(e) => setEditingClass({ ...editingClass, hasSections: !e.target.checked })}
                  />
                  No Sections (Single Cohort, e.g. Class 11 / 12)
                </label>
                <label className="flex items-center gap-2 font-medium text-slate-700 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={editingClass.isActive}
                    onChange={(e) => setEditingClass({ ...editingClass, isActive: e.target.checked })}
                  />
                  Active Class
                </label>
              </div>
            </div>
            <div className="flex flex-col-reverse sm:flex-row sm:justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setEditingClass(null)}
                className="min-h-[40px] px-3.5 py-2 border border-slate-300 rounded-lg hover:bg-slate-50 cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="min-h-[40px] px-4 py-2 font-semibold text-white bg-[#1E3A5F] rounded-lg hover:bg-[#162D4A] cursor-pointer"
              >
                Save Class
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Archive Class Confirmation Modal */}
      {deleteClassTarget && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/50 p-4">
          <div className="bg-white border border-slate-200 rounded-xl w-full max-w-sm p-6 space-y-4 shadow-xl text-xs">
            <h3 className="text-base font-bold text-slate-900">Archive / Soft-Delete Class</h3>
            <p className="text-slate-600 leading-relaxed">
              Archive <span className="font-semibold text-slate-900">{deleteClassTarget.name}</span>? Classes with
              currently active enrolled students cannot be archived until students are transferred or archived.
            </p>
            <div className="flex flex-col-reverse sm:flex-row sm:justify-end gap-2">
              <button
                type="button"
                onClick={() => setDeleteClassTarget(null)}
                className="min-h-[40px] px-3.5 py-2 border border-slate-300 rounded-lg hover:bg-slate-50 cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleDeleteClass}
                className="min-h-[40px] px-4 py-2 font-semibold text-white bg-red-600 rounded-lg hover:bg-red-700 cursor-pointer"
              >
                Archive Class
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Edit Section Modal */}
      {editingSection && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/50 p-4">
          <form
            onSubmit={handleSaveSection}
            className="bg-white border border-slate-200 rounded-xl w-full max-w-sm p-6 space-y-4 shadow-xl text-xs"
          >
            <div className="flex items-center justify-between">
              <h3 className="text-base font-bold text-slate-900">Edit Section — {editingSection.className}</h3>
              <button type="button" onClick={() => setEditingSection(null)} className="p-1 cursor-pointer">
                <X className="w-4 h-4 text-slate-400" />
              </button>
            </div>
            <div className="space-y-3">
              <div>
                <label className="block font-semibold text-slate-700 mb-1">Section Name *</label>
                <input
                  type="text"
                  required
                  value={editingSection.name}
                  onChange={(e) => setEditingSection({ ...editingSection, name: e.target.value })}
                  className="w-full min-h-[40px] px-3 py-2 border border-slate-300 rounded-lg uppercase"
                />
              </div>
              <div>
                <label className="block font-semibold text-slate-700 mb-1">Seat Capacity</label>
                <input
                  type="number"
                  min={1}
                  required
                  value={editingSection.capacity}
                  onChange={(e) => setEditingSection({ ...editingSection, capacity: Number(e.target.value) })}
                  className="w-full min-h-[40px] px-3 py-2 border border-slate-300 rounded-lg font-mono"
                />
              </div>
            </div>
            <div className="flex flex-col-reverse sm:flex-row sm:justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setEditingSection(null)}
                className="min-h-[40px] px-3.5 py-2 border border-slate-300 rounded-lg hover:bg-slate-50 cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="min-h-[40px] px-4 py-2 font-semibold text-white bg-[#1E3A5F] rounded-lg hover:bg-[#162D4A] cursor-pointer"
              >
                Save Section
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Archive Section Confirmation Modal */}
      {deleteSectionTarget && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/50 p-4">
          <div className="bg-white border border-slate-200 rounded-xl w-full max-w-sm p-6 space-y-4 shadow-xl text-xs">
            <h3 className="text-base font-bold text-slate-900">Archive / Soft-Delete Section</h3>
            <p className="text-slate-600 leading-relaxed">
              Archive{' '}
              <span className="font-semibold text-slate-900">
                {deleteSectionTarget.className} · Section {deleteSectionTarget.name}
              </span>
              ? Sections with active students must be cleared first.
            </p>
            <div className="flex flex-col-reverse sm:flex-row sm:justify-end gap-2">
              <button
                type="button"
                onClick={() => setDeleteSectionTarget(null)}
                className="min-h-[40px] px-3.5 py-2 border border-slate-300 rounded-lg hover:bg-slate-50 cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleDeleteSection}
                className="min-h-[40px] px-4 py-2 font-semibold text-white bg-red-600 rounded-lg hover:bg-red-700 cursor-pointer"
              >
                Archive Section
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Delete Subject Component Confirmation Modal */}
      {deleteComponentTarget && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/50 p-4">
          <div className="bg-white border border-slate-200 rounded-xl w-full max-w-sm p-6 space-y-4 shadow-xl text-xs">
            <h3 className="text-base font-bold text-slate-900">Remove Subject Component</h3>
            <p className="text-slate-600 leading-relaxed">
              Remove <span className="font-semibold text-slate-900">{deleteComponentTarget.name}</span> from{' '}
              <span className="font-semibold text-slate-900">{deleteComponentTarget.subjectName}</span>? Any marks and
              teacher assignments linked to this paper will also be removed.
            </p>
            <div className="flex flex-col-reverse sm:flex-row sm:justify-end gap-2">
              <button
                type="button"
                onClick={() => setDeleteComponentTarget(null)}
                className="min-h-[40px] px-3.5 py-2 border border-slate-300 rounded-lg hover:bg-slate-50 cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={confirmDeleteComponent}
                className="min-h-[40px] px-4 py-2 font-semibold text-white bg-red-600 rounded-lg hover:bg-red-700 cursor-pointer"
              >
                Remove Component
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export function AdminTeacherAssignmentsView({
  schoolInfo,
  selectedAcademicYear,
  onChanged,
}: {
  schoolInfo: SchoolInfo;
  selectedAcademicYear: string;
  onChanged?: () => Promise<void> | void;
}) {
  const [assignments, setAssignments] = useState<TeacherAssignment[]>([]);
  const [classTeachers, setClassTeachers] = useState<ClassTeacherAssignment[]>([]);
  const [iaAssignments, setIaAssignments] = useState<IaTeacherAssignment[]>([]);
  const [users, setUsers] = useState<AdminUserOption[]>([]);
  const [subjects, setSubjects] = useState<SubjectRecord[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [modalError, setModalError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);
  const requestSeqRef = useRef(0);
  const abortControllerRef = useRef<AbortController | null>(null);

  const [filterTeacherId, setFilterTeacherId] = useState('');
  const [filterClassId, setFilterClassId] = useState('');
  const [filterSubjectId, setFilterSubjectId] = useState('');

  // Bulk Selection States
  const [selectedCtIds, setSelectedCtIds] = useState<number[]>([]);
  const [selectedSubIds, setSelectedSubIds] = useState<number[]>([]);
  const [selectedIaIds, setSelectedIaIds] = useState<number[]>([]);
  const [bulkDeleteConfirm, setBulkDeleteConfirm] = useState<{
    type: 'sub' | 'ct' | 'ia';
    ids: number[];
    items: BulkConfirmItem[];
  } | null>(null);
  const [bulkBusy, setBulkBusy] = useState(false);

  // Batch Multi-Class/Section Assign Modal
  const [batchModalOpen, setBatchModalOpen] = useState(false);
  const [batchForm, setBatchForm] = useState<{
    teacherId: number;
    subjectId: number;
    componentId: number;
    classSectionKeys: string[]; // "classId:sectionId"
  }>({
    teacherId: 0,
    subjectId: 0,
    componentId: 0,
    classSectionKeys: [],
  });
  const [savingBatch, setSavingBatch] = useState(false);

  const [deleteConfirm, setDeleteConfirm] = useState<{
    type: 'sub' | 'ct' | 'ia';
    id: number;
    label: string;
  } | null>(null);

  const [subForm, setSubForm] = useState({
    teacherId: 0,
    subjectId: 0,
    componentId: 0,
    classId: schoolInfo.classes[0]?.id || 1,
    sectionId: schoolInfo.classes[0]?.sections[0]?.id || 1,
  });

  const [ctForm, setCtForm] = useState({
    teacherId: 0,
    classId: schoolInfo.classes[0]?.id || 1,
    sectionId: schoolInfo.classes[0]?.sections[0]?.id || 1,
  });

  const ALL_IA_PARTS: Array<{ key: IaComponentKey; label: string }> = [
    { key: 'notebook', label: 'Notebook' },
    { key: 'unit_test', label: 'Unit Test' },
    { key: 'practical', label: 'Practical / Project' },
    { key: 'participation', label: 'Overall Performance' },
  ];

  const formatIaComponentLabel = (component: string) =>
    ALL_IA_PARTS.find((part) => part.key === component)?.label || component.replace('_', ' ');

  const [iaForm, setIaForm] = useState<{
    teacherId: number;
    subjectId: number;
    iaComponents: IaComponentKey[];
    classId: number;
    sectionId: number;
  }>({
    teacherId: 0,
    subjectId: 0,
    iaComponents: ['notebook', 'unit_test', 'practical', 'participation'],
    classId: schoolInfo.classes[0]?.id || 1,
    sectionId: schoolInfo.classes[0]?.sections[0]?.id || 1,
  });

  useEffect(() => {
    return () => {
      abortControllerRef.current?.abort();
    };
  }, []);

  const loadAll = async () => {
    abortControllerRef.current?.abort();
    const controller = new AbortController();
    abortControllerRef.current = controller;
    const seq = ++requestSeqRef.current;

    setLoading(true);
    setError(null);
    try {
      const ayQs = `?academicYear=${encodeURIComponent(selectedAcademicYear)}`;
      const [ta, cta, iaa, us, subs] = await Promise.all([
        apiFetch<TeacherAssignment[]>(`/api/admin/teacher-assignments${ayQs}`, { signal: controller.signal }),
        apiFetch<ClassTeacherAssignment[]>(`/api/admin/class-teacher-assignments${ayQs}`, { signal: controller.signal }),
        apiFetch<IaTeacherAssignment[]>(`/api/admin/ia-assignments${ayQs}`, { signal: controller.signal }),
        apiFetch<AdminUserOption[]>('/api/admin/users', { signal: controller.signal }),
        apiFetch<SubjectRecord[]>('/api/admin/subjects', { signal: controller.signal }),
      ]);
      if (seq !== requestSeqRef.current) return;
      setAssignments(ta);
      setClassTeachers(cta);
      setIaAssignments(iaa);
      const teachersOnly = us.filter((u) => u.roles.includes('teacher') && u.isActive);
      setUsers(teachersOnly);
      setSubjects(subs);

      setSelectedCtIds([]);
      setSelectedSubIds([]);
      setSelectedIaIds([]);

      const formatIaDefaultsSubjectId = subs.find((s) => s.hasInternalAssessment)?.id || subs[0]?.id || 0;

      if (teachersOnly.length > 0 && subForm.teacherId === 0) {
        setSubForm((p) => ({
          ...p,
          teacherId: teachersOnly[0].id,
          subjectId: subs[0]?.id || 0,
          componentId: subs[0]?.components[0]?.id || 0,
        }));
        setCtForm((p) => ({ ...p, teacherId: teachersOnly[0].id }));
        setIaForm((p) => ({
          ...p,
          teacherId: teachersOnly[0].id,
          subjectId: formatIaDefaultsSubjectId,
        }));
        setBatchForm((p) => ({
          ...p,
          teacherId: teachersOnly[0].id,
          subjectId: subs[0]?.id || 0,
          componentId: subs[0]?.components[0]?.id || 0,
        }));
      } else {
        setIaForm((p) => {
          const validTeacher = teachersOnly.some((t) => t.id === p.teacherId) ? p.teacherId : teachersOnly[0]?.id || 0;
          const iaSubs = subs.filter((s) => s.hasInternalAssessment);
          const validSubject = iaSubs.some((s) => s.id === p.subjectId) ? p.subjectId : formatIaDefaultsSubjectId;
          if (validTeacher === p.teacherId && validSubject === p.subjectId) return p;
          return { ...p, teacherId: validTeacher, subjectId: validSubject };
        });
      }
    } catch (err) {
      if (isAbortError(err) || seq !== requestSeqRef.current) return;
      setError(extractErrorMessage(err));
    } finally {
      if (seq === requestSeqRef.current) {
        setLoading(false);
      }
    }
  };

  useEffect(() => {
    loadAll();
  }, [selectedAcademicYear, schoolInfo.classes.length]);

  const selectedSubject = subjects.find((s) => s.id === Number(subForm.subjectId));
  const selectedSubClass = schoolInfo.classes.find((c) => c.id === Number(subForm.classId));
  const selectedCtClass = schoolInfo.classes.find((c) => c.id === Number(ctForm.classId));
  const selectedIaClass = schoolInfo.classes.find((c) => c.id === Number(iaForm.classId));
  const batchSubject = subjects.find((s) => s.id === Number(batchForm.subjectId));

  const assignSubjectTeacher = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setNotice(null);
    try {
      await apiFetch('/api/admin/teacher-assignments', {
        method: 'POST',
        body: JSON.stringify({ ...subForm, academicYear: selectedAcademicYear }),
      });
      setNotice('Subject assignment saved.');
      await loadAll();
      await onChanged?.();
    } catch (err) {
      setError(extractErrorMessage(err));
    }
  };

  const assignClassTeacher = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setNotice(null);
    try {
      await apiFetch('/api/admin/class-teacher-assignments', {
        method: 'POST',
        body: JSON.stringify({ ...ctForm, academicYear: selectedAcademicYear }),
      });
      setNotice('Class Teacher assignment saved.');
      await loadAll();
      await onChanged?.();
    } catch (err) {
      setError(extractErrorMessage(err));
    }
  };

  const assignIaTeacher = async (e?: React.FormEvent, overrideAllFour = false) => {
    if (e) e.preventDefault();
    const targetParts: IaComponentKey[] = overrideAllFour
      ? ['notebook', 'unit_test', 'practical', 'participation']
      : iaForm.iaComponents;
    if (!iaForm.teacherId || !iaForm.subjectId || !iaForm.classId || targetParts.length === 0) {
      setError('Select a teacher, subject, class/section, and at least one IA section.');
      return;
    }
    setError(null);
    setNotice(null);
    try {
      const targetClass = schoolInfo.classes.find((c) => c.id === Number(iaForm.classId));
      const resolvedSecId =
        targetClass?.hasSections === false
          ? targetClass.sections[0]?.id || iaForm.sectionId
          : iaForm.sectionId || targetClass?.sections[0]?.id || 1;
      const res = await apiFetch<{ createdCount?: number; updatedCount?: number }>('/api/admin/ia-assignments', {
        method: 'POST',
        body: JSON.stringify({
          teacherId: iaForm.teacherId,
          subjectId: iaForm.subjectId,
          classId: iaForm.classId,
          sectionId: resolvedSecId,
          iaComponents: targetParts,
          academicYear: selectedAcademicYear,
        }),
      });
      const count = targetParts.length;
      setNotice(
        count === 4
          ? `Assigned all 4 IA sections (Notebook, Unit Test, Practical/Project, Overall Performance) (${res.createdCount ?? 0} added, ${res.updatedCount ?? 0} updated).`
          : `Saved ${count} IA section assignment(s) (${res.createdCount ?? 0} added, ${res.updatedCount ?? 0} updated).`
      );
      await loadAll();
      await onChanged?.();
    } catch (err) {
      setError(extractErrorMessage(err));
    }
  };

  const handleBatchAssign = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!batchForm.teacherId || !batchForm.subjectId || !batchForm.componentId || batchForm.classSectionKeys.length === 0) {
      setModalError('Select a teacher, subject/component, and at least one class & section.');
      return;
    }
    setSavingBatch(true);
    setError(null);
    setModalError(null);
    setNotice(null);
    try {
      const payloadAssignments = batchForm.classSectionKeys.map((k) => {
        const [cid, sid] = k.split(':').map(Number);
        return {
          subjectId: batchForm.subjectId,
          componentId: batchForm.componentId,
          classId: cid,
          sectionId: sid,
        };
      });
      const res = await apiFetch<{ createdCount: number; updatedCount: number }>('/api/admin/teacher-assignments/batch', {
        method: 'POST',
        body: JSON.stringify({
          teacherId: batchForm.teacherId,
          academicYear: selectedAcademicYear,
          assignments: payloadAssignments,
        }),
      });
      setBatchModalOpen(false);
      setBatchForm((p) => ({ ...p, classSectionKeys: [] }));
      setNotice(`Multi-class assignment saved (${res.createdCount} added, ${res.updatedCount} updated).`);
      await loadAll();
      await onChanged?.();
    } catch (err) {
      setModalError(extractErrorMessage(err));
    } finally {
      setSavingBatch(false);
    }
  };

  const handleConfirmDeleteAssign = async () => {
    if (!deleteConfirm) return;
    setError(null);
    try {
      const endpoint =
        deleteConfirm.type === 'sub'
          ? `/api/admin/teacher-assignments/${deleteConfirm.id}`
          : deleteConfirm.type === 'ct'
            ? `/api/admin/class-teacher-assignments/${deleteConfirm.id}`
            : `/api/admin/ia-assignments/${deleteConfirm.id}`;
      await apiFetch(endpoint, { method: 'DELETE' });
      setDeleteConfirm(null);
      await loadAll();
      await onChanged?.();
    } catch (err) {
      setError(extractErrorMessage(err));
      setDeleteConfirm(null);
    }
  };

  const handleExecuteBulkDelete = async () => {
    if (!bulkDeleteConfirm) return;
    setBulkBusy(true);
    setError(null);
    try {
      const endpoint =
        bulkDeleteConfirm.type === 'sub'
          ? '/api/admin/teacher-assignments/bulk-delete'
          : bulkDeleteConfirm.type === 'ct'
            ? '/api/admin/class-teacher-assignments/bulk-delete'
            : '/api/admin/ia-assignments/bulk-delete';
      await apiFetch(endpoint, {
        method: 'POST',
        body: JSON.stringify({ ids: bulkDeleteConfirm.ids }),
      });
      setBulkDeleteConfirm(null);
      setNotice(`Removed ${bulkDeleteConfirm.ids.length} selected assignment(s). Existing submitted marks remain intact.`);
      await loadAll();
      await onChanged?.();
    } catch (err) {
      setError(extractErrorMessage(err));
      setBulkDeleteConfirm(null);
    } finally {
      setBulkBusy(false);
    }
  };

  const filteredAssignments = useMemo(() => {
    return assignments.filter((a) => {
      if (filterTeacherId && String(a.teacher_id) !== filterTeacherId) return false;
      if (filterClassId && String(a.class_id) !== filterClassId) return false;
      if (filterSubjectId && String(a.subject_id) !== filterSubjectId) return false;
      return true;
    });
  }, [assignments, filterTeacherId, filterClassId, filterSubjectId]);

  const {
    page: subAssignPage,
    setPage: setSubAssignPage,
    pageSize: subAssignPageSize,
    setPageSize: setSubAssignPageSize,
    pagedItems: pagedAssignments,
  } = usePagination(filteredAssignments, 25);

  useEffect(() => {
    setSubAssignPage(1);
  }, [filterTeacherId, filterClassId, filterSubjectId, selectedAcademicYear, setSubAssignPage]);

  const pagedAssignmentIds = pagedAssignments.map((a) => a.id);
  const allPagedSubSelected =
    pagedAssignmentIds.length > 0 && pagedAssignmentIds.every((id) => selectedSubIds.includes(id));

  const allCtIds = classTeachers.map((c) => c.id);
  const allCtSelected = allCtIds.length > 0 && allCtIds.every((id) => selectedCtIds.includes(id));

  const allIaIds = iaAssignments.map((i) => i.id);
  const allIaSelected = allIaIds.length > 0 && allIaIds.every((id) => selectedIaIds.includes(id));

  return (
    <div className="space-y-8">
      {error && (
        <div className="p-3.5 rounded-xl bg-red-50 border border-red-200 flex flex-wrap items-center justify-between gap-2 text-xs text-red-800">
          <span>{error}</span>
          <button
            type="button"
            onClick={() => loadAll()}
            className="min-h-[34px] inline-flex items-center gap-1 px-3 py-1 bg-white border border-red-200 rounded-lg font-semibold text-red-800 hover:bg-red-100 cursor-pointer"
          >
            <RefreshCw className="w-3.5 h-3.5" />
            Retry
          </button>
        </div>
      )}

      {notice && (
        <div className="p-3 rounded-xl bg-emerald-50 border border-emerald-200 flex items-center justify-between gap-2 text-xs font-medium text-emerald-900">
          <span>{notice}</span>
          <button type="button" onClick={() => setNotice(null)} className="text-emerald-700 hover:text-emerald-950 cursor-pointer">
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* Class Teacher Assignment Module */}
      <div className="space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div>
            <h2 className="text-lg font-bold text-slate-900">
              Class Teacher Assignments{' '}
              <span className="font-mono text-sm font-semibold text-[#1E3A5F]">({selectedAcademicYear})</span>
            </h2>
            <p className="text-xs text-slate-500">
              Assign one Class Teacher per class and section for Academic Year {selectedAcademicYear}
            </p>
          </div>
          {classTeachers.length > 0 && (
            <label className="min-h-[38px] inline-flex items-center gap-2 px-3 py-1.5 bg-white border border-slate-300 rounded-lg text-xs font-medium text-slate-700 cursor-pointer">
              <input
                type="checkbox"
                checked={allCtSelected}
                onChange={() => setSelectedCtIds(allCtSelected ? [] : allCtIds)}
                className="rounded border-slate-300"
              />
              Select All ({classTeachers.length})
            </label>
          )}
        </div>

        {selectedCtIds.length > 0 && (
          <BulkActionToolbar
            selectedCount={selectedCtIds.length}
            entityLabel="class teacher assignment"
            onClearSelection={() => setSelectedCtIds([])}
            disabled={bulkBusy}
            actions={[
              {
                id: 'bulk-del-ct',
                label: 'Remove Selected',
                icon: 'delete',
                variant: 'danger',
                onClick: () => {
                  const items = classTeachers
                    .filter((c) => selectedCtIds.includes(c.id))
                    .map((c) => ({
                      id: c.id,
                      label: c.teacher_name,
                      sublabel: formatClassSectionLabel(c.class_name, c.section_name, c.hasSections ?? true),
                    }));
                  setBulkDeleteConfirm({ type: 'ct', ids: selectedCtIds, items });
                },
              },
            ]}
          />
        )}

        <form
          onSubmit={assignClassTeacher}
          className="bg-white border border-slate-200 rounded-xl p-4 grid grid-cols-1 sm:grid-cols-4 gap-3 items-end text-xs"
        >
          <div>
            <label className="block font-semibold text-slate-700 mb-1">Teacher</label>
            <select
              value={ctForm.teacherId}
              onChange={(e) => setCtForm({ ...ctForm, teacherId: Number(e.target.value) })}
              className="w-full min-h-[40px] px-3 py-2 border border-slate-300 rounded-lg bg-white"
            >
              {users.map((u) => (
                <option key={u.id} value={u.id}>
                  {u.full_name} ({u.username})
                </option>
              ))}
            </select>
          </div>
          <div>
            <label className="block font-semibold text-slate-700 mb-1">Class</label>
            <select
              value={ctForm.classId}
              onChange={(e) => {
                const cid = Number(e.target.value);
                const cls = schoolInfo.classes.find((c) => c.id === cid);
                setCtForm({ ...ctForm, classId: cid, sectionId: cls?.sections[0]?.id || 1 });
              }}
              className="w-full min-h-[40px] px-3 py-2 border border-slate-300 rounded-lg bg-white"
            >
              {schoolInfo.classes.map((c) => (
                <option key={c.id} value={c.id}>
                  {c.name}
                </option>
              ))}
            </select>
          </div>
          <div>
            <label className="block font-semibold text-slate-700 mb-1">Section</label>
            {selectedCtClass?.hasSections === false ? (
              <div className="w-full min-h-[40px] px-3 py-2 border border-slate-200 rounded-lg bg-slate-50 text-slate-500 flex items-center">
                No Sections (Single Cohort)
              </div>
            ) : (
              <select
                value={ctForm.sectionId}
                onChange={(e) => setCtForm({ ...ctForm, sectionId: Number(e.target.value) })}
                className="w-full min-h-[40px] px-3 py-2 border border-slate-300 rounded-lg bg-white"
              >
                {selectedCtClass?.sections.map((s) => (
                  <option key={s.id} value={s.id}>
                    Section {s.name}
                  </option>
                ))}
              </select>
            )}
          </div>
          <button
            type="submit"
            className="min-h-[40px] px-4 py-2 font-semibold text-white bg-[#1E3A5F] rounded-lg hover:bg-[#162D4A] cursor-pointer"
          >
            Assign Class Teacher
          </button>
        </form>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
          {classTeachers.map((ct) => {
            const checked = selectedCtIds.includes(ct.id);
            const ctLabel = formatClassSectionLabel(ct.class_name, ct.section_name, ct.hasSections);
            return (
              <div
                key={ct.id}
                className={`bg-white border rounded-xl p-3.5 flex items-start justify-between gap-2 ${
                  checked ? 'border-[#1E3A5F] ring-1 ring-[#1E3A5F]/20' : 'border-slate-200'
                }`}
              >
                <div className="flex items-start gap-2.5 min-w-0">
                  <input
                    type="checkbox"
                    checked={checked}
                    onChange={() =>
                      setSelectedCtIds((prev) => (prev.includes(ct.id) ? prev.filter((x) => x !== ct.id) : [...prev, ct.id]))
                    }
                    className="mt-0.5 rounded border-slate-300 cursor-pointer shrink-0"
                  />
                  <div className="min-w-0">
                    <div className="text-xs font-bold text-[#1E3A5F]">{ctLabel}</div>
                    <div className="text-sm font-semibold text-slate-900 mt-1 truncate">{ct.teacher_name}</div>
                    <div className="text-[11px] font-mono text-slate-500">@{ct.username}</div>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() =>
                    setDeleteConfirm({
                      type: 'ct',
                      id: ct.id,
                      label: `${ct.teacher_name} (${ctLabel})`,
                    })
                  }
                  className="text-slate-400 hover:text-red-600 p-1.5 cursor-pointer shrink-0"
                  title="Remove class teacher"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            );
          })}
        </div>
      </div>

      {/* Subject Teacher Assignment Module */}
      <div className="space-y-4 pt-6 border-t border-slate-200">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
          <div>
            <h2 className="text-lg font-bold text-slate-900">Subject &amp; Component Teacher Assignments</h2>
            <p className="text-xs text-slate-500">
              Assign teachers to specific subjects or components across multiple classes and sections
            </p>
          </div>
          <button
            type="button"
            onClick={() => {
              setError(null);
              setModalError(null);
              setBatchModalOpen(true);
            }}
            className="min-h-[40px] inline-flex items-center justify-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-[#1E3A5F] bg-sky-50 border border-sky-200 rounded-lg hover:bg-sky-100 cursor-pointer"
          >
            <Layers className="w-3.5 h-3.5" />
            Batch Assign Multiple Classes / Sections
          </button>
        </div>

        <form
          onSubmit={assignSubjectTeacher}
          className="bg-white border border-slate-200 rounded-xl p-4 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-6 gap-3 items-end text-xs"
        >
          <div className="lg:col-span-2">
            <label className="block font-semibold text-slate-700 mb-1">Teacher</label>
            <select
              value={subForm.teacherId}
              onChange={(e) => setSubForm({ ...subForm, teacherId: Number(e.target.value) })}
              className="w-full min-h-[40px] px-3 py-2 border border-slate-300 rounded-lg bg-white"
            >
              {users.map((u) => (
                <option key={u.id} value={u.id}>
                  {u.full_name}
                </option>
              ))}
            </select>
          </div>
          <div>
            <label className="block font-semibold text-slate-700 mb-1">Subject</label>
            <select
              value={subForm.subjectId}
              onChange={(e) => {
                const sid = Number(e.target.value);
                const sub = subjects.find((s) => s.id === sid);
                setSubForm({ ...subForm, subjectId: sid, componentId: sub?.components[0]?.id || 0 });
              }}
              className="w-full min-h-[40px] px-3 py-2 border border-slate-300 rounded-lg bg-white"
            >
              {subjects.map((s) => (
                <option key={s.id} value={s.id}>
                  {s.name}
                </option>
              ))}
            </select>
          </div>
          <div>
            <label className="block font-semibold text-slate-700 mb-1">Component</label>
            <select
              value={subForm.componentId}
              onChange={(e) => setSubForm({ ...subForm, componentId: Number(e.target.value) })}
              className="w-full min-h-[40px] px-3 py-2 border border-slate-300 rounded-lg bg-white"
            >
              {selectedSubject?.components.map((c) => (
                <option key={c.id} value={c.id}>
                  {c.name}
                </option>
              ))}
            </select>
          </div>
          <div>
            <label className="block font-semibold text-slate-700 mb-1">Class &amp; Sec</label>
            <div className="flex gap-1.5">
              <select
                value={subForm.classId}
                onChange={(e) => {
                  const cid = Number(e.target.value);
                  const cls = schoolInfo.classes.find((c) => c.id === cid);
                  setSubForm({ ...subForm, classId: cid, sectionId: cls?.sections[0]?.id || 1 });
                }}
                className="w-full min-h-[40px] px-2 py-2 border border-slate-300 rounded-lg bg-white"
              >
                {schoolInfo.classes.map((c) => (
                  <option key={c.id} value={c.id}>
                    {c.name}
                  </option>
                ))}
              </select>
              {selectedSubClass?.hasSections !== false && (
                <select
                  value={subForm.sectionId}
                  onChange={(e) => setSubForm({ ...subForm, sectionId: Number(e.target.value) })}
                  className="w-20 min-h-[40px] px-2 py-2 border border-slate-300 rounded-lg bg-white"
                >
                  {selectedSubClass?.sections.map((s) => (
                    <option key={s.id} value={s.id}>
                      {s.name}
                    </option>
                  ))}
                </select>
              )}
            </div>
          </div>
          <button
            type="submit"
            className="min-h-[40px] inline-flex items-center justify-center gap-1 px-3 py-2 font-semibold text-white bg-[#1E3A5F] rounded-lg hover:bg-[#162D4A] cursor-pointer"
          >
            <Plus className="w-3.5 h-3.5" />
            Assign
          </button>
        </form>

        {selectedSubIds.length > 0 && (
          <BulkActionToolbar
            selectedCount={selectedSubIds.length}
            entityLabel="subject assignment"
            onClearSelection={() => setSelectedSubIds([])}
            disabled={bulkBusy}
            actions={[
              {
                id: 'bulk-del-sub',
                label: 'Remove Selected',
                icon: 'delete',
                variant: 'danger',
                onClick: () => {
                  const items = assignments
                    .filter((a) => selectedSubIds.includes(a.id))
                    .map((a) => ({
                      id: a.id,
                      label: `${a.teacher_name} — ${a.subject_name}`,
                      sublabel: `${formatClassSectionLabel(a.class_name, a.section_name, a.hasSections)}${a.has_components ? ` · ${a.component_name}` : ''}`,
                    }));
                  setBulkDeleteConfirm({ type: 'sub', ids: selectedSubIds, items });
                },
              },
            ]}
          />
        )}

        <div className="bg-white border border-slate-200 rounded-xl overflow-hidden">
          <div className="px-4 py-3 border-b border-slate-200 grid grid-cols-1 sm:grid-cols-3 gap-2.5">
            <select
              value={filterTeacherId}
              onChange={(e) => setFilterTeacherId(e.target.value)}
              className="min-h-[38px] px-3 py-1.5 text-xs border border-slate-300 rounded-lg bg-white"
            >
              <option value="">All Teachers ({assignments.length})</option>
              {users.map((u) => (
                <option key={u.id} value={u.id}>
                  {u.full_name}
                </option>
              ))}
            </select>
            <select
              value={filterSubjectId}
              onChange={(e) => setFilterSubjectId(e.target.value)}
              className="min-h-[38px] px-3 py-1.5 text-xs border border-slate-300 rounded-lg bg-white"
            >
              <option value="">All Subjects</option>
              {subjects.map((s) => (
                <option key={s.id} value={s.id}>
                  {s.name}
                </option>
              ))}
            </select>
            <select
              value={filterClassId}
              onChange={(e) => setFilterClassId(e.target.value)}
              className="min-h-[38px] px-3 py-1.5 text-xs border border-slate-300 rounded-lg bg-white"
            >
              <option value="">All Classes</option>
              {schoolInfo.classes.map((c) => (
                <option key={c.id} value={c.id}>
                  {c.name}
                </option>
              ))}
            </select>
          </div>

          {loading ? (
            <div className="p-8 text-center text-xs text-slate-500">Loading assignments...</div>
          ) : pagedAssignments.length === 0 ? (
            <div className="p-8 text-center text-xs text-slate-500">No subject assignments match the active filter.</div>
          ) : (
            <>
              {/* Mobile Cards (<768px) */}
              <div className="md:hidden divide-y divide-slate-200">
                <div className="px-4 py-2.5 bg-slate-50 flex items-center justify-between text-xs text-slate-600">
                  <label className="inline-flex items-center gap-2 font-medium cursor-pointer">
                    <input
                      type="checkbox"
                      checked={allPagedSubSelected}
                      onChange={() => {
                        if (allPagedSubSelected) {
                          setSelectedSubIds((p) => p.filter((id) => !pagedAssignmentIds.includes(id)));
                        } else {
                          setSelectedSubIds((p) => Array.from(new Set([...p, ...pagedAssignmentIds])));
                        }
                      }}
                      className="rounded border-slate-300"
                    />
                    Select Page ({pagedAssignmentIds.length})
                  </label>
                </div>
                {pagedAssignments.map((a) => {
                  const checked = selectedSubIds.includes(a.id);
                  return (
                    <div key={a.id} className={`p-3.5 space-y-1.5 text-xs ${checked ? 'bg-sky-50/50' : ''}`}>
                      <div className="flex items-start justify-between gap-2">
                        <label className="flex items-start gap-2.5 min-w-0 cursor-pointer">
                          <input
                            type="checkbox"
                            checked={checked}
                            onChange={() =>
                              setSelectedSubIds((p) => (p.includes(a.id) ? p.filter((x) => x !== a.id) : [...p, a.id]))
                            }
                            className="mt-0.5 rounded border-slate-300 shrink-0"
                          />
                          <div className="min-w-0">
                            <div className="font-semibold text-slate-900">{a.teacher_name}</div>
                            <div className="text-slate-700 mt-0.5">
                              {a.subject_name} · {a.has_components ? a.component_name : 'Full Subject'}
                            </div>
                            <div className="text-[11px] font-mono text-slate-500">
                              {formatClassSectionLabel(a.class_name, a.section_name, a.hasSections)}
                            </div>
                          </div>
                        </label>
                        <button
                          type="button"
                          onClick={() =>
                            setDeleteConfirm({
                              type: 'sub',
                              id: a.id,
                              label: `${a.teacher_name} — ${a.subject_name} (${formatClassSectionLabel(a.class_name, a.section_name, a.hasSections)})`,
                            })
                          }
                          className="min-w-[34px] min-h-[34px] inline-flex items-center justify-center text-red-600 hover:bg-red-50 rounded-lg cursor-pointer shrink-0"
                          title="Remove assignment"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>

              {/* Desktop Table (>=768px) */}
              <div className="hidden md:block overflow-x-auto">
                <table className="w-full text-xs">
                  <thead className="bg-slate-50 border-b border-slate-200 text-slate-600">
                    <tr>
                      <th className="w-10 px-4 py-2.5 text-center">
                        <input
                          type="checkbox"
                          checked={allPagedSubSelected}
                          onChange={() => {
                            if (allPagedSubSelected) {
                              setSelectedSubIds((p) => p.filter((id) => !pagedAssignmentIds.includes(id)));
                            } else {
                              setSelectedSubIds((p) => Array.from(new Set([...p, ...pagedAssignmentIds])));
                            }
                          }}
                          aria-label="Select all visible assignments"
                          className="rounded border-slate-300 cursor-pointer"
                        />
                      </th>
                      <th className="text-left font-semibold px-4 py-2.5">Teacher</th>
                      <th className="text-left font-semibold px-4 py-2.5">Subject</th>
                      <th className="text-left font-semibold px-4 py-2.5">Component</th>
                      <th className="text-left font-semibold px-4 py-2.5">Class</th>
                      <th className="text-left font-semibold px-4 py-2.5">Section</th>
                      <th className="text-right font-semibold px-4 py-2.5">Remove</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-200">
                    {pagedAssignments.map((a) => {
                      const checked = selectedSubIds.includes(a.id);
                      return (
                        <tr key={a.id} className={`hover:bg-slate-50/70 ${checked ? 'bg-sky-50/50' : ''}`}>
                          <td className="px-4 py-2 text-center">
                            <input
                              type="checkbox"
                              checked={checked}
                              onChange={() =>
                                setSelectedSubIds((p) => (p.includes(a.id) ? p.filter((x) => x !== a.id) : [...p, a.id]))
                              }
                              className="rounded border-slate-300 cursor-pointer"
                            />
                          </td>
                          <td className="px-4 py-2 font-semibold text-slate-900">{a.teacher_name}</td>
                          <td className="px-4 py-2 text-slate-800">{a.subject_name}</td>
                          <td className="px-4 py-2 text-slate-600">
                            {a.has_components ? a.component_name : 'Full Subject'}
                          </td>
                          <td className="px-4 py-2 text-slate-700">{a.class_name}</td>
                          <td className="px-4 py-2 text-slate-700">
                            {a.hasSections === false ? '— (No Sections)' : `Section ${a.section_name}`}
                          </td>
                          <td className="px-4 py-2 text-right">
                            <button
                              type="button"
                              onClick={() =>
                                setDeleteConfirm({
                                  type: 'sub',
                                  id: a.id,
                                  label: `${a.teacher_name} — ${a.subject_name} (${formatClassSectionLabel(a.class_name, a.section_name, a.hasSections)})`,
                                })
                              }
                              className="text-red-600 hover:text-red-800 p-1.5 rounded hover:bg-red-50 cursor-pointer"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
              <PaginationBar
                totalItems={filteredAssignments.length}
                page={subAssignPage}
                pageSize={subAssignPageSize}
                onPageChange={setSubAssignPage}
                onPageSizeChange={setSubAssignPageSize}
              />
            </>
          )}
        </div>
      </div>

      {/* Optional IA Component Teacher Assignments */}
      <div className="space-y-4 pt-6 border-t border-slate-200">
        <div>
          <h2 className="text-lg font-bold text-slate-900">Internal Assessment (IA) Component Teacher Assignments</h2>
          <p className="text-xs text-slate-500">
            Assign a teacher to all 4 IA sections (Notebook, Unit Test, Practical/Project, Overall Performance) in 1 click or select individual sections
          </p>
        </div>

        <form
          onSubmit={(e) => assignIaTeacher(e, false)}
          className="bg-white border border-slate-200 rounded-xl p-4 space-y-3 text-xs"
        >
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 items-end">
            <div>
              <label className="block font-semibold text-slate-700 mb-1">Teacher</label>
              <select
                value={iaForm.teacherId}
                onChange={(e) => setIaForm({ ...iaForm, teacherId: Number(e.target.value) })}
                className="w-full min-h-[40px] px-3 py-2 border border-slate-300 rounded-lg bg-white"
              >
                {users.map((u) => (
                  <option key={u.id} value={u.id}>
                    {u.full_name}
                  </option>
                ))}
              </select>
            </div>
            <div>
              <label className="block font-semibold text-slate-700 mb-1">Subject</label>
              <select
                value={iaForm.subjectId}
                onChange={(e) => setIaForm({ ...iaForm, subjectId: Number(e.target.value) })}
                className="w-full min-h-[40px] px-3 py-2 border border-slate-300 rounded-lg bg-white"
              >
                {subjects
                  .filter((s) => s.hasInternalAssessment)
                  .map((s) => (
                    <option key={s.id} value={s.id}>
                      {s.name}
                    </option>
                  ))}
              </select>
            </div>
            <div>
              <label className="block font-semibold text-slate-700 mb-1">Class &amp; Sec</label>
              <div className="flex gap-1.5">
                <select
                  value={iaForm.classId}
                  onChange={(e) => {
                    const cid = Number(e.target.value);
                    const cls = schoolInfo.classes.find((c) => c.id === cid);
                    setIaForm({ ...iaForm, classId: cid, sectionId: cls?.sections[0]?.id || 1 });
                  }}
                  className="w-full min-h-[40px] px-2 py-2 border border-slate-300 rounded-lg bg-white"
                >
                  {schoolInfo.classes.map((c) => (
                    <option key={c.id} value={c.id}>
                      {c.name}
                    </option>
                  ))}
                </select>
                {selectedIaClass?.hasSections !== false && (
                  <select
                    value={iaForm.sectionId}
                    onChange={(e) => setIaForm({ ...iaForm, sectionId: Number(e.target.value) })}
                    className="w-24 min-h-[40px] px-2 py-2 border border-slate-300 rounded-lg bg-white"
                  >
                    {selectedIaClass?.sections.map((s) => (
                      <option key={s.id} value={s.id}>
                        Sec {s.name}
                      </option>
                    ))}
                  </select>
                )}
              </div>
            </div>
            <div className="flex flex-wrap items-center gap-2">
              <button
                type="button"
                onClick={() => assignIaTeacher(undefined, true)}
                className="flex-1 min-h-[40px] inline-flex items-center justify-center gap-1.5 px-3.5 py-2 font-semibold text-white bg-[#1E3A5F] rounded-lg hover:bg-[#162D4A] cursor-pointer whitespace-nowrap"
              >
                <Plus className="w-3.5 h-3.5" />
                Assign All 4 (1-Click)
              </button>
              {iaForm.iaComponents.length > 0 && iaForm.iaComponents.length < 4 && (
                <button
                  type="submit"
                  className="min-h-[40px] inline-flex items-center justify-center gap-1 px-3 py-2 font-semibold text-[#1E3A5F] bg-sky-50 border border-sky-200 rounded-lg hover:bg-sky-100 cursor-pointer whitespace-nowrap"
                >
                  Assign Selected ({iaForm.iaComponents.length})
                </button>
              )}
            </div>
          </div>

          <div className="pt-2 border-t border-slate-100 flex flex-wrap items-center justify-between gap-2">
            <div className="flex flex-wrap items-center gap-2">
              <span className="font-semibold text-slate-700 mr-1">IA Sections:</span>
              {ALL_IA_PARTS.map((part) => {
                const checked = iaForm.iaComponents.includes(part.key);
                return (
                  <label
                    key={part.key}
                    className={`min-h-[34px] inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg border cursor-pointer transition-colors ${
                      checked
                        ? 'bg-sky-50 text-[#1E3A5F] border-sky-300 font-semibold'
                        : 'bg-white text-slate-600 border-slate-300 hover:bg-slate-50'
                    }`}
                  >
                    <input
                      type="checkbox"
                      checked={checked}
                      onChange={(e) => {
                        setIaForm((prev) => ({
                          ...prev,
                          iaComponents: e.target.checked
                            ? Array.from(new Set([...prev.iaComponents, part.key]))
                            : prev.iaComponents.filter((k) => k !== part.key),
                        }));
                      }}
                      className="rounded border-slate-300 text-[#1E3A5F]"
                    />
                    <span>{part.label}</span>
                  </label>
                );
              })}
            </div>
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() =>
                  setIaForm((prev) => ({
                    ...prev,
                    iaComponents: ['notebook', 'unit_test', 'practical', 'participation'],
                  }))
                }
                className="px-2.5 py-1 text-[11px] font-medium border border-slate-300 rounded-md hover:bg-slate-50 cursor-pointer"
              >
                Select All 4
              </button>
              <button
                type="button"
                onClick={() => setIaForm((prev) => ({ ...prev, iaComponents: [] }))}
                className="px-2.5 py-1 text-[11px] font-medium border border-slate-300 rounded-md hover:bg-slate-50 cursor-pointer"
              >
                Clear
              </button>
            </div>
          </div>
        </form>

        {selectedIaIds.length > 0 && (
          <BulkActionToolbar
            selectedCount={selectedIaIds.length}
            entityLabel="IA assignment"
            onClearSelection={() => setSelectedIaIds([])}
            disabled={bulkBusy}
            actions={[
              {
                id: 'bulk-del-ia',
                label: 'Remove Selected',
                icon: 'delete',
                variant: 'danger',
                onClick: () => {
                  const items = iaAssignments
                    .filter((ia) => selectedIaIds.includes(ia.id))
                    .map((ia) => ({
                      id: ia.id,
                      label: `${ia.teacher_name} — ${ia.subject_name}`,
                      sublabel: `${formatIaComponentLabel(ia.ia_component)} · ${formatClassSectionLabel(ia.class_name, ia.section_name, ia.hasSections)}`,
                    }));
                  setBulkDeleteConfirm({ type: 'ia', ids: selectedIaIds, items });
                },
              },
            ]}
          />
        )}

        {iaAssignments.length > 0 && (
          <div className="bg-white border border-slate-200 rounded-xl overflow-hidden">
            {/* Mobile Cards */}
            <div className="md:hidden divide-y divide-slate-200">
              <div className="px-4 py-2.5 bg-slate-50 flex items-center justify-between text-xs text-slate-600">
                <label className="inline-flex items-center gap-2 font-medium cursor-pointer">
                  <input
                    type="checkbox"
                    checked={allIaSelected}
                    onChange={() => setSelectedIaIds(allIaSelected ? [] : allIaIds)}
                    className="rounded border-slate-300"
                  />
                  Select All IA Assignments ({iaAssignments.length})
                </label>
              </div>
              {iaAssignments.map((ia) => {
                const checked = selectedIaIds.includes(ia.id);
                return (
                  <div key={ia.id} className={`p-3.5 flex items-start justify-between gap-2 text-xs ${checked ? 'bg-sky-50/50' : ''}`}>
                    <label className="flex items-start gap-2.5 min-w-0 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={checked}
                        onChange={() =>
                          setSelectedIaIds((p) => (p.includes(ia.id) ? p.filter((x) => x !== ia.id) : [...p, ia.id]))
                        }
                        className="mt-0.5 rounded border-slate-300 shrink-0"
                      />
                      <div>
                        <div className="font-semibold text-slate-900">{ia.teacher_name}</div>
                        <div className="text-slate-700">
                          {ia.subject_name} · {formatIaComponentLabel(ia.ia_component)}
                        </div>
                        <div className="text-[11px] font-mono text-slate-500">
                          {formatClassSectionLabel(ia.class_name, ia.section_name, ia.hasSections)}
                        </div>
                      </div>
                    </label>
                    <button
                      type="button"
                      onClick={() =>
                        setDeleteConfirm({
                          type: 'ia',
                          id: ia.id,
                          label: `${ia.teacher_name} — ${ia.subject_name} (${formatIaComponentLabel(ia.ia_component)})`,
                        })
                      }
                      className="min-w-[34px] min-h-[34px] inline-flex items-center justify-center text-red-600 hover:bg-red-50 rounded-lg cursor-pointer"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                );
              })}
            </div>

            {/* Desktop Table */}
            <div className="hidden md:block overflow-x-auto max-h-[340px]">
              <table className="w-full text-xs">
                <thead className="bg-slate-50 border-b border-slate-200 text-slate-600 sticky top-0">
                  <tr>
                    <th className="w-10 px-4 py-2.5 text-center">
                      <input
                        type="checkbox"
                        checked={allIaSelected}
                        onChange={() => setSelectedIaIds(allIaSelected ? [] : allIaIds)}
                        className="rounded border-slate-300 cursor-pointer"
                      />
                    </th>
                    <th className="text-left font-semibold px-4 py-2.5">Teacher</th>
                    <th className="text-left font-semibold px-4 py-2.5">Subject</th>
                    <th className="text-left font-semibold px-4 py-2.5">IA Component</th>
                    <th className="text-left font-semibold px-4 py-2.5">Class &amp; Section</th>
                    <th className="text-right font-semibold px-4 py-2.5">Remove</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200">
                  {iaAssignments.map((ia) => {
                    const checked = selectedIaIds.includes(ia.id);
                    return (
                      <tr key={ia.id} className={`hover:bg-slate-50/70 ${checked ? 'bg-sky-50/50' : ''}`}>
                        <td className="px-4 py-2 text-center">
                          <input
                            type="checkbox"
                            checked={checked}
                            onChange={() =>
                              setSelectedIaIds((p) => (p.includes(ia.id) ? p.filter((x) => x !== ia.id) : [...p, ia.id]))
                            }
                            className="rounded border-slate-300 cursor-pointer"
                          />
                        </td>
                        <td className="px-4 py-2 font-semibold text-slate-900">{ia.teacher_name}</td>
                        <td className="px-4 py-2 text-slate-800">{ia.subject_name}</td>
                        <td className="px-4 py-2 font-medium text-sky-900">
                          {formatIaComponentLabel(ia.ia_component)}
                        </td>
                        <td className="px-4 py-2 text-slate-700">
                          {formatClassSectionLabel(ia.class_name, ia.section_name, ia.hasSections)}
                        </td>
                        <td className="px-4 py-2 text-right">
                          <button
                            type="button"
                            onClick={() =>
                              setDeleteConfirm({
                                type: 'ia',
                                id: ia.id,
                                label: `${ia.teacher_name} — ${ia.subject_name} (${formatIaComponentLabel(ia.ia_component)})`,
                              })
                            }
                            className="text-red-600 hover:text-red-800 p-1.5 rounded hover:bg-red-50 cursor-pointer"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        )}
      </div>

      {/* Batch Multi-Class / Multi-Section Assignment Modal */}
      {batchModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/50 p-4">
          <form
            onSubmit={handleBatchAssign}
            className="bg-white border border-slate-200 rounded-xl w-full max-w-2xl max-h-[90vh] flex flex-col shadow-xl text-xs"
          >
            <div className="px-5 py-4 border-b border-slate-200 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <CheckSquare className="w-4 h-4 text-[#1E3A5F]" />
                <h3 className="text-base font-bold text-slate-900">
                  Batch Assign Subject Across Classes &amp; Sections ({selectedAcademicYear})
                </h3>
              </div>
              <button type="button" onClick={() => setBatchModalOpen(false)} className="p-1 cursor-pointer">
                <X className="w-4 h-4 text-slate-400" />
              </button>
            </div>

            <div className="p-5 space-y-4 overflow-y-auto">
              {modalError && (
                <div className="p-2.5 rounded-lg bg-red-50 border border-red-200 text-red-800 font-medium">
                  {modalError}
                </div>
              )}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Teacher *</label>
                  <select
                    value={batchForm.teacherId}
                    onChange={(e) => setBatchForm({ ...batchForm, teacherId: Number(e.target.value) })}
                    className="w-full min-h-[40px] px-3 py-2 border border-slate-300 rounded-lg bg-white"
                  >
                    {users.map((u) => (
                      <option key={u.id} value={u.id}>
                        {u.full_name}
                      </option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Subject *</label>
                  <select
                    value={batchForm.subjectId}
                    onChange={(e) => {
                      const sid = Number(e.target.value);
                      const sub = subjects.find((s) => s.id === sid);
                      setBatchForm({
                        ...batchForm,
                        subjectId: sid,
                        componentId: sub?.components[0]?.id || 0,
                      });
                    }}
                    className="w-full min-h-[40px] px-3 py-2 border border-slate-300 rounded-lg bg-white"
                  >
                    {subjects.map((s) => (
                      <option key={s.id} value={s.id}>
                        {s.name}
                      </option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Component *</label>
                  <select
                    value={batchForm.componentId}
                    onChange={(e) => setBatchForm({ ...batchForm, componentId: Number(e.target.value) })}
                    className="w-full min-h-[40px] px-3 py-2 border border-slate-300 rounded-lg bg-white"
                  >
                    {batchSubject?.components.map((c) => (
                      <option key={c.id} value={c.id}>
                        {c.name}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="space-y-2">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <span className="font-semibold text-slate-800">
                    Select Target Classes &amp; Sections ({batchForm.classSectionKeys.length} selected)
                  </span>
                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={() => {
                        const allKeys = schoolInfo.classes.flatMap((c) =>
                          c.sections.map((s) => `${c.id}:${s.id}`)
                        );
                        setBatchForm((p) => ({ ...p, classSectionKeys: allKeys }));
                      }}
                      className="px-2.5 py-1 border border-slate-300 rounded hover:bg-slate-50 cursor-pointer"
                    >
                      Select All
                    </button>
                    <button
                      type="button"
                      onClick={() => setBatchForm((p) => ({ ...p, classSectionKeys: [] }))}
                      className="px-2.5 py-1 border border-slate-300 rounded hover:bg-slate-50 cursor-pointer"
                    >
                      Clear
                    </button>
                  </div>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                  {schoolInfo.classes.map((c) => (
                    <div key={c.id} className="p-3 bg-slate-50 border border-slate-200 rounded-lg space-y-2">
                      <div className="font-semibold text-slate-900">{c.name}</div>
                      <div className="flex flex-wrap gap-2">
                        {c.sections.map((s) => {
                          const key = `${c.id}:${s.id}`;
                          const checked = batchForm.classSectionKeys.includes(key);
                          return (
                            <label
                              key={key}
                              className={`min-h-[34px] inline-flex items-center gap-1.5 px-2.5 py-1 rounded border cursor-pointer ${
                                checked
                                  ? 'bg-[#1E3A5F] text-white border-[#1E3A5F]'
                                  : 'bg-white text-slate-700 border-slate-300'
                              }`}
                            >
                              <input
                                type="checkbox"
                                checked={checked}
                                onChange={(e) =>
                                  setBatchForm((p) => ({
                                    ...p,
                                    classSectionKeys: e.target.checked
                                      ? [...p.classSectionKeys, key]
                                      : p.classSectionKeys.filter((x) => x !== key),
                                  }))
                                }
                                className="sr-only"
                              />
                              <span className="font-medium">
                                {c.hasSections === false ? 'No Sections (Single Cohort)' : `Sec ${s.name}`}
                              </span>
                            </label>
                          );
                        })}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            <div className="px-5 py-3.5 border-t border-slate-200 bg-slate-50 flex flex-col-reverse sm:flex-row sm:justify-end gap-2">
              <button
                type="button"
                disabled={savingBatch}
                onClick={() => setBatchModalOpen(false)}
                className="min-h-[40px] px-4 py-2 border border-slate-300 rounded-lg bg-white hover:bg-slate-100 cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={savingBatch || batchForm.classSectionKeys.length === 0}
                className="min-h-[40px] px-4 py-2 font-semibold text-white bg-[#1E3A5F] rounded-lg hover:bg-[#162D4A] disabled:opacity-50 cursor-pointer"
              >
                {savingBatch ? 'Assigning...' : `Assign ${batchForm.classSectionKeys.length} Slot(s)`}
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Bulk Delete Assignment Confirmation */}
      <BulkConfirmModal
        open={Boolean(bulkDeleteConfirm)}
        title={`Remove ${bulkDeleteConfirm?.items.length || 0} Assignment(s)?`}
        confirmLabel="Remove Selected"
        description="Selected teacher assignments will be removed for the current academic year."
        safetyNote="Existing submitted student marks entered by these teachers are strictly preserved."
        items={bulkDeleteConfirm?.items || []}
        variant="danger"
        busy={bulkBusy}
        onCancel={() => setBulkDeleteConfirm(null)}
        onConfirm={handleExecuteBulkDelete}
      />

      {/* Single Delete Assignment Confirmation Modal */}
      {deleteConfirm && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/50 p-4">
          <div className="bg-white border border-slate-200 rounded-xl w-full max-w-sm p-6 space-y-4 shadow-xl text-xs">
            <h3 className="text-base font-bold text-slate-900">Remove Assignment</h3>
            <p className="text-slate-600 leading-relaxed">
              Remove assignment for <span className="font-semibold text-slate-900">{deleteConfirm.label}</span>?
            </p>
            <div className="flex flex-col-reverse sm:flex-row sm:justify-end gap-2">
              <button
                type="button"
                onClick={() => setDeleteConfirm(null)}
                className="min-h-[40px] px-3.5 py-2 border border-slate-300 rounded-lg hover:bg-slate-50 cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleConfirmDeleteAssign}
                className="min-h-[40px] px-4 py-2 font-semibold text-white bg-red-600 rounded-lg hover:bg-red-700 cursor-pointer"
              >
                Remove
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
