import React, { useEffect, useMemo, useRef, useState } from 'react';
import {
  Archive,
  BookOpen,
  CheckCircle2,
  Eye,
  KeyRound,
  Layers,
  Pencil,
  Plus,
  Power,
  RefreshCw,
  RotateCcw,
  Search,
  Trash2,
  UserPlus,
  Users,
  X,
} from 'lucide-react';
import type {
  BulkActionResponse,
  SchoolInfo,
  SubjectRecord,
  TeacherProfileResponse,
  UserRecord,
} from '../../types';
import { apiFetch, extractErrorMessage, isAbortError } from '../../lib/api';
import { formatClassSectionLabel } from '../../lib/grading';
import {
  BulkActionToolbar,
  BulkConfirmModal,
  PaginationBar,
  UndoBanner,
  usePagination,
} from '../BulkActions';

interface AssignmentDraftSlot {
  subjectId: number;
  subjectName: string;
  componentId: number;
  componentName: string;
  classId: number;
  className: string;
  sectionId: number;
  sectionName: string;
}

export function AdminTeachersView({
  schoolInfo,
  selectedAcademicYear,
  onChanged,
}: {
  schoolInfo: SchoolInfo;
  selectedAcademicYear: string;
  onChanged: () => Promise<void> | void;
}) {
  const [users, setUsers] = useState<UserRecord[]>([]);
  const [subjects, setSubjects] = useState<SubjectRecord[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [reloadTick, setReloadTick] = useState(0);
  const [error, setError] = useState<string | null>(null);
  const [modalError, setModalError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);

  // Filters, search & sort
  const [viewMode, setViewMode] = useState<'active' | 'archived'>('active');
  const [search, setSearch] = useState('');
  const [debouncedSearch, setDebouncedSearch] = useState('');
  const [filterRole, setFilterRole] = useState<'' | 'teacher' | 'admin'>('');
  const [filterSubjectId, setFilterSubjectId] = useState('');
  const [filterClassId, setFilterClassId] = useState('');
  const [filterSectionId, setFilterSectionId] = useState('');
  const [filterStatus, setFilterStatus] = useState<'' | 'active' | 'inactive'>('');
  const [sortBy, setSortBy] = useState<'name_asc' | 'name_desc' | 'code_asc' | 'recent'>('name_asc');

  // Bulk selection & undo
  const [selectedIds, setSelectedIds] = useState<Set<number>>(new Set());
  const [bulkBusy, setBulkBusy] = useState(false);
  const [confirmBulkAction, setConfirmBulkAction] = useState<{
    action: 'delete' | 'archive' | 'permanent_delete' | 'restore' | 'activate' | 'deactivate';
    ids: number[];
    title: string;
    description: string;
    confirmLabel: string;
    variant: 'danger' | 'warning' | 'primary';
  } | null>(null);
  const [undoState, setUndoState] = useState<{ ids: number[]; message: string } | null>(null);

  // Create Modal
  const [createOpen, setCreateOpen] = useState(false);
  const [creating, setCreating] = useState(false);
  const [createForm, setCreateForm] = useState({
    fullName: '',
    username: '',
    password: '',
    email: '',
    employeeCode: '',
    role: 'teacher' as 'teacher' | 'admin',
  });

  // Edit Modal
  const [editTarget, setEditTarget] = useState<UserRecord | null>(null);
  const [savingEdit, setSavingEdit] = useState(false);
  const [editForm, setEditForm] = useState({
    username: '',
    fullName: '',
    email: '',
    employeeCode: '',
    role: 'teacher' as 'teacher' | 'admin',
    isActive: true,
  });

  // Reset Password Modal
  const [resetTarget, setResetTarget] = useState<UserRecord | null>(null);
  const [newPassword, setNewPassword] = useState('');
  const [resettingPass, setResettingPass] = useState(false);

  // Profile Modal
  const [profileOpen, setProfileOpen] = useState(false);
  const [profileLoading, setProfileLoading] = useState(false);
  const [profileData, setProfileData] = useState<TeacherProfileResponse | null>(null);

  // Multi-Subject / Multi-Class / Multi-Section Assignment Modal
  const [assignTarget, setAssignTarget] = useState<UserRecord | null>(null);
  const [assignYear, setAssignYear] = useState(selectedAcademicYear || schoolInfo.currentAcademicYear);
  const [assignSlots, setAssignSlots] = useState<AssignmentDraftSlot[]>([]);
  const [assignCtKeys, setAssignCtKeys] = useState<Set<string>>(new Set());
  const [builderSubjectId, setBuilderSubjectId] = useState<number>(0);
  const [builderComponentId, setBuilderComponentId] = useState<number>(0);
  const [builderClassSectionKeys, setBuilderClassSectionKeys] = useState<Set<string>>(new Set());
  const [savingAssignments, setSavingAssignments] = useState(false);

  const requestSeqRef = useRef(0);
  const abortControllerRef = useRef<AbortController | null>(null);
  const nextLoadBackgroundRef = useRef(false);

  useEffect(() => {
    const trimmed = search.trim();
    if (!trimmed) {
      setDebouncedSearch('');
      return;
    }
    const timer = window.setTimeout(() => {
      setDebouncedSearch(trimmed);
    }, 200);
    return () => window.clearTimeout(timer);
  }, [search]);

  useEffect(() => {
    return () => {
      abortControllerRef.current?.abort();
    };
  }, []);

  const loadUsers = async (overrides?: {
    view?: 'active' | 'archived';
    clearFilters?: boolean;
    background?: boolean;
  }) => {
    abortControllerRef.current?.abort();
    const controller = new AbortController();
    abortControllerRef.current = controller;
    const seq = ++requestSeqRef.current;

    const effView = overrides?.view ?? viewMode;
    const effClear = Boolean(overrides?.clearFilters);

    if (overrides?.background) {
      setRefreshing(true);
    } else {
      setLoading(true);
    }
    setError(null);
    try {
      const qs = new URLSearchParams();
      qs.set('view', effView);
      qs.set('academicYear', selectedAcademicYear || schoolInfo.currentAcademicYear);
      qs.set('sort', sortBy);
      if (!effClear) {
        if (debouncedSearch.trim()) qs.set('search', debouncedSearch.trim());
        if (filterRole) qs.set('role', filterRole);
        if (filterSubjectId) qs.set('subjectId', filterSubjectId);
        if (filterClassId) qs.set('classId', filterClassId);
        if (filterSectionId) qs.set('sectionId', filterSectionId);
        if (filterStatus) qs.set('status', filterStatus);
      }

      const rows = await apiFetch<UserRecord[]>(`/api/admin/users?${qs.toString()}`, {
        signal: controller.signal,
      });
      if (seq !== requestSeqRef.current) return;
      setUsers(rows);
      setSelectedIds((prev) => {
        const valid = new Set(rows.map((r) => r.id));
        const next = new Set<number>();
        prev.forEach((id) => {
          if (valid.has(id)) next.add(id);
        });
        return next;
      });
    } catch (err: unknown) {
      if (isAbortError(err) || seq !== requestSeqRef.current) return;
      setError(extractErrorMessage(err, 'Failed to load teacher directory.'));
    } finally {
      if (seq === requestSeqRef.current) {
        setLoading(false);
        setRefreshing(false);
      }
    }
  };

  useEffect(() => {
    const background = nextLoadBackgroundRef.current;
    nextLoadBackgroundRef.current = false;
    loadUsers({ background });
    return () => {
      abortControllerRef.current?.abort();
    };
  }, [
    viewMode,
    debouncedSearch,
    filterRole,
    filterSubjectId,
    filterClassId,
    filterSectionId,
    filterStatus,
    sortBy,
    selectedAcademicYear,
    reloadTick,
  ]);

  useEffect(() => {
    apiFetch<SubjectRecord[]>('/api/admin/subjects')
      .then((subs) => {
        setSubjects(subs);
        if (subs.length > 0 && builderSubjectId === 0) {
          setBuilderSubjectId(subs[0].id);
          setBuilderComponentId(subs[0].components[0]?.id || 0);
        }
      })
      .catch(() => {});
  }, [schoolInfo]);

  const {
    page,
    setPage,
    pageSize,
    setPageSize,
    pagedItems,
  } = usePagination(users, 25);

  const filterClassObj = schoolInfo.classes.find((c) => String(c.id) === filterClassId);
  const allSectionNames = useMemo(() => {
    if (filterClassObj) {
      return filterClassObj.hasSections === false ? [] : filterClassObj.sections;
    }
    const seen = new Map<number, { id: number; name: string }>();
    for (const c of schoolInfo.classes) {
      if (c.hasSections === false) continue;
      for (const s of c.sections) {
        seen.set(s.id, { id: s.id, name: formatClassSectionLabel(c.name, s.name, c.hasSections) });
      }
    }
    return Array.from(seen.values());
  }, [schoolInfo.classes, filterClassObj]);

  const hasActiveFilters = Boolean(
    search.trim() || filterRole || filterSubjectId || filterClassId || filterSectionId || filterStatus
  );

  const clearFilters = () => {
    setSearch('');
    setDebouncedSearch('');
    setFilterRole('');
    setFilterSubjectId('');
    setFilterClassId('');
    setFilterSectionId('');
    setFilterStatus('');
  };

  // Page-scoped selection helpers
  const allPageSelected =
    pagedItems.length > 0 && pagedItems.every((u) => selectedIds.has(u.id));

  const toggleSelectPage = () => {
    setSelectedIds((prev) => {
      const next = new Set(prev);
      if (allPageSelected) {
        pagedItems.forEach((u) => next.delete(u.id));
      } else {
        pagedItems.forEach((u) => next.add(u.id));
      }
      return next;
    });
  };

  const toggleSelectRow = (id: number) => {
    setSelectedIds((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  };

  const selectedUsers = useMemo(
    () => users.filter((u) => selectedIds.has(u.id)),
    [users, selectedIds]
  );

  const openBulkConfirm = (
    action: 'delete' | 'archive' | 'permanent_delete' | 'restore' | 'activate' | 'deactivate',
    ids: number[]
  ) => {
    if (ids.length === 0) return;
    const labelMap = {
      delete: {
        title: `Archive ${ids.length} Account(s)`,
        description:
          'Selected faculty accounts will be moved to the Archived directory and cannot sign in until restored.',
        confirmLabel: 'Confirm Archive',
        variant: 'warning' as const,
      },
      archive: {
        title: `Archive ${ids.length} Account(s)`,
        description: 'Selected accounts will be moved to the Archived directory.',
        confirmLabel: 'Archive Selected',
        variant: 'warning' as const,
      },
      permanent_delete: {
        title: `Permanently Delete ${ids.length} Teacher/User Account(s) from Database`,
        description:
          'This action cannot be undone. Selected account(s), login credentials, sessions, and subject/class assignments will be permanently removed from the portal and database.',
        confirmLabel: 'Permanently Delete Forever',
        variant: 'danger' as const,
      },
      restore: {
        title: `Restore ${ids.length} Account(s)`,
        description: 'Selected archived accounts will be restored to active directory status.',
        confirmLabel: 'Restore Selected',
        variant: 'primary' as const,
      },
      activate: {
        title: `Activate ${ids.length} Account(s)`,
        description: 'Selected faculty accounts will be enabled for portal login.',
        confirmLabel: 'Activate Selected',
        variant: 'primary' as const,
      },
      deactivate: {
        title: `Deactivate ${ids.length} Account(s)`,
        description: 'Selected faculty accounts will be blocked from signing in while preserving their records.',
        confirmLabel: 'Deactivate Selected',
        variant: 'warning' as const,
      },
    }[action];

    setConfirmBulkAction({
      action,
      ids,
      ...labelMap,
    });
  };

  const sortUsersList = (list: UserRecord[]) => {
    return [...list].sort((a, b) => {
      if (sortBy === 'name_desc') {
        const cmp = b.full_name.localeCompare(a.full_name, undefined, { sensitivity: 'base' });
        if (cmp !== 0) return cmp;
        return a.id - b.id;
      }
      if (sortBy === 'code_asc') {
        const cmp = (a.employee_code || '').localeCompare(b.employee_code || '', undefined, {
          sensitivity: 'base',
        });
        if (cmp !== 0) return cmp;
        return a.full_name.localeCompare(b.full_name, undefined, { sensitivity: 'base' });
      }
      if (sortBy === 'recent') {
        return b.id - a.id;
      }
      const cmp = a.full_name.localeCompare(b.full_name, undefined, { sensitivity: 'base' });
      if (cmp !== 0) return cmp;
      return a.id - b.id;
    });
  };

  const upsertUserLocally = (record: UserRecord) => {
    setUsers((prev) => {
      const idx = prev.findIndex((u) => u.id === record.id);
      const next = idx >= 0 ? prev.map((u) => (u.id === record.id ? record : u)) : [...prev, record];
      return sortUsersList(next);
    });
  };

  const triggerBackgroundReload = () => {
    nextLoadBackgroundRef.current = true;
    setReloadTick((t) => t + 1);
  };

  const executeBulkAction = async () => {
    if (!confirmBulkAction) return;
    setBulkBusy(true);
    setError(null);
    setNotice(null);
    try {
      const action = confirmBulkAction.action;
      const targetIds = confirmBulkAction.ids;
      const res = await apiFetch<BulkActionResponse>('/api/admin/users/bulk-action', {
        method: 'POST',
        body: JSON.stringify({
          action,
          ids: targetIds,
        }),
      });
      const count = res.affectedCount ?? targetIds.length;
      if (action === 'permanent_delete') {
        setUndoState(null);
        setNotice(`Permanently deleted ${count} teacher/user account(s) from portal & database.`);
      } else if (action === 'delete' || action === 'archive') {
        setUndoState({
          ids: targetIds,
          message: `Archived ${count} account(s). Submitted marks and audit logs remain preserved.`,
        });
      } else {
        setNotice(`Updated ${count} account(s) (${action}).`);
      }

      const idSet = new Set(targetIds);
      if (
        action === 'permanent_delete' ||
        action === 'delete' ||
        action === 'archive' ||
        action === 'restore'
      ) {
        setUsers((prev) => prev.filter((u) => !idSet.has(u.id)));
      } else if (action === 'activate' || action === 'deactivate') {
        const nextActive = action === 'activate';
        setUsers((prev) =>
          prev.map((u) =>
            idSet.has(u.id) ? { ...u, isActive: nextActive, is_active: nextActive ? 1 : 0 } : u
          )
        );
      }

      setConfirmBulkAction(null);
      setSelectedIds(new Set());
      triggerBackgroundReload();
      void onChanged();
    } catch (err: unknown) {
      setError(extractErrorMessage(err, 'Bulk operation failed.'));
      setConfirmBulkAction(null);
    } finally {
      setBulkBusy(false);
    }
  };

  const handleUndoRestore = async () => {
    if (!undoState) return;
    setBulkBusy(true);
    setError(null);
    try {
      await apiFetch<BulkActionResponse>('/api/admin/users/bulk-action', {
        method: 'POST',
        body: JSON.stringify({ action: 'restore', ids: undoState.ids }),
      });
      setNotice(`Restored ${undoState.ids.length} account(s).`);
      setUndoState(null);
      triggerBackgroundReload();
      void onChanged();
    } catch (err: unknown) {
      setError(extractErrorMessage(err, 'Failed to restore archived accounts.'));
    } finally {
      setBulkBusy(false);
    }
  };

  const handleExportSelectedCsv = () => {
    const rows = selectedUsers.length > 0 ? selectedUsers : users;
    const headers = [
      'Teacher ID',
      'Full Name',
      'Username',
      'Email',
      'Roles',
      'Assigned Subjects',
      'Assigned Classes',
      'Assigned Sections',
      'Class Teacher Of',
      'Status',
      'Submitted Marks Rows',
    ];
    const esc = (val: string | number) => `"${String(val ?? '').replace(/"/g, '""')}"`;
    const csv = [
      headers.map(esc).join(','),
      ...rows.map((u) =>
        [
          u.employee_code || '',
          u.full_name,
          u.username,
          u.email || '',
          u.roles.join('; '),
          u.assignedSubjects.join('; '),
          u.assignedClasses.join('; '),
          u.assignedSections.join('; '),
          u.classTeacherSections.join('; '),
          u.isDeleted ? 'Archived' : u.isActive ? 'Active' : 'Inactive',
          u.submittedMarksCount,
        ]
          .map(esc)
          .join(',')
      ),
    ].join('\n');

    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `teachers-directory-${new Date().toISOString().slice(0, 10)}.csv`;
    document.body.appendChild(link);
    link.click();
    link.remove();
    URL.revokeObjectURL(url);
  };

  // Single actions
  const handleCreate = async (e: React.FormEvent) => {
    e.preventDefault();
    setCreating(true);
    setError(null);
    setModalError(null);
    setNotice(null);
    try {
      const res = await apiFetch<{
        id: number;
        employeeCode: string;
        user?: UserRecord;
      }>('/api/admin/users', {
        method: 'POST',
        body: JSON.stringify({
          ...createForm,
          academicYear: selectedAcademicYear || schoolInfo.currentAcademicYear,
        }),
      });
      if (res.user) {
        upsertUserLocally(res.user);
      }
      setCreateOpen(false);
      setCreateForm({
        fullName: '',
        username: '',
        password: '',
        email: '',
        employeeCode: '',
        role: 'teacher',
      });
      setViewMode('active');
      clearFilters();
      setPage(1);
      setNotice('Faculty account created and saved to database.');
      triggerBackgroundReload();
      void onChanged();
    } catch (err: unknown) {
      setModalError(extractErrorMessage(err, 'Failed to create teacher account.'));
    } finally {
      setCreating(false);
    }
  };

  const openEditUser = (u: UserRecord) => {
    setError(null);
    setModalError(null);
    setEditTarget(u);
    setEditForm({
      username: u.username,
      fullName: u.full_name,
      email: u.email || '',
      employeeCode: u.employee_code || '',
      role: u.roles.includes('admin') ? 'admin' : 'teacher',
      isActive: u.isActive,
    });
  };

  const handleSaveEditUser = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editTarget) return;
    setSavingEdit(true);
    setError(null);
    setModalError(null);
    setNotice(null);
    try {
      const res = await apiFetch<{ success: boolean; user?: UserRecord }>(
        `/api/admin/users/${editTarget.id}`,
        {
          method: 'PUT',
          body: JSON.stringify({
            ...editForm,
            academicYear: selectedAcademicYear || schoolInfo.currentAcademicYear,
          }),
        }
      );
      if (res.user) {
        upsertUserLocally(res.user);
      }
      setEditTarget(null);
      setNotice('Teacher profile details updated.');
      triggerBackgroundReload();
      void onChanged();
    } catch (err: unknown) {
      setModalError(extractErrorMessage(err, 'Failed to update teacher details.'));
    } finally {
      setSavingEdit(false);
    }
  };

  const handleResetPassword = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!resetTarget) return;
    setResettingPass(true);
    setError(null);
    setModalError(null);
    setNotice(null);
    try {
      await apiFetch(`/api/admin/users/${resetTarget.id}/reset-password`, {
        method: 'POST',
        body: JSON.stringify({ newPassword }),
      });
      const targetName = resetTarget.full_name;
      setResetTarget(null);
      setNewPassword('');
      setNotice(`Temporary password reset for ${targetName}.`);
      triggerBackgroundReload();
    } catch (err: unknown) {
      setModalError(extractErrorMessage(err, 'Failed to reset password.'));
    } finally {
      setResettingPass(false);
    }
  };

  const toggleQuickStatus = async (u: UserRecord) => {
    setError(null);
    setNotice(null);
    try {
      const res = await apiFetch<{ success: boolean; user?: UserRecord }>(
        `/api/admin/users/${u.id}`,
        {
          method: 'PUT',
          body: JSON.stringify({
            isActive: !u.isActive,
            academicYear: selectedAcademicYear || schoolInfo.currentAcademicYear,
          }),
        }
      );
      if (res.user) {
        upsertUserLocally(res.user);
      }
      setNotice(`${u.full_name} marked ${!u.isActive ? 'Active' : 'Inactive'}.`);
      triggerBackgroundReload();
      void onChanged();
    } catch (err: unknown) {
      setError(extractErrorMessage(err, 'Failed to update status.'));
    }
  };

  const openProfile = async (u: UserRecord) => {
    setProfileOpen(true);
    setProfileLoading(true);
    setProfileData(null);
    try {
      const prof = await apiFetch<TeacherProfileResponse>(`/api/admin/users/${u.id}/profile`);
      setProfileData(prof);
    } catch (err: unknown) {
      setProfileOpen(false);
      setError(extractErrorMessage(err, 'Failed to load teacher profile.'));
    } finally {
      setProfileLoading(false);
    }
  };

  const openAssignModal = (u: UserRecord) => {
    setError(null);
    setModalError(null);
    const yr = selectedAcademicYear || schoolInfo.currentAcademicYear;
    setAssignTarget(u);
    setAssignYear(yr);
    setAssignSlots(
      (u.assignments || [])
        .filter((a) => a.academic_year === yr)
        .map((a) => ({
          subjectId: a.subject_id,
          subjectName: a.subject_name,
          componentId: a.component_id,
          componentName: a.component_name,
          classId: a.class_id,
          className: a.class_name,
          sectionId: a.section_id,
          sectionName: a.section_name,
        }))
    );
    setAssignCtKeys(
      new Set(
        (u.classTeacherAssignments || [])
          .filter((ct) => ct.academic_year === yr)
          .map((ct) => `${ct.class_id}:${ct.section_id}`)
      )
    );
    setBuilderClassSectionKeys(new Set());
    if (subjects.length > 0 && builderSubjectId === 0) {
      setBuilderSubjectId(subjects[0].id);
      setBuilderComponentId(subjects[0].components[0]?.id || 0);
    }
  };

  const handleAssignYearChange = (nextYear: string) => {
    setAssignYear(nextYear);
    if (!assignTarget) return;
    setAssignSlots(
      (assignTarget.assignments || [])
        .filter((a) => a.academic_year === nextYear)
        .map((a) => ({
          subjectId: a.subject_id,
          subjectName: a.subject_name,
          componentId: a.component_id,
          componentName: a.component_name,
          classId: a.class_id,
          className: a.class_name,
          sectionId: a.section_id,
          sectionName: a.section_name,
        }))
    );
    setAssignCtKeys(
      new Set(
        (assignTarget.classTeacherAssignments || [])
          .filter((ct) => ct.academic_year === nextYear)
          .map((ct) => `${ct.class_id}:${ct.section_id}`)
      )
    );
  };

  const builderSubject = subjects.find((s) => s.id === builderSubjectId);

  const toggleBuilderClassSection = (classId: number, sectionId: number) => {
    const key = `${classId}:${sectionId}`;
    setBuilderClassSectionKeys((prev) => {
      const next = new Set(prev);
      if (next.has(key)) next.delete(key);
      else next.add(key);
      return next;
    });
  };

  const handleAddBuiltSlots = () => {
    if (!builderSubject || builderClassSectionKeys.size === 0) return;
    const comp =
      builderSubject.components.find((c) => c.id === builderComponentId) ||
      builderSubject.components[0];
    if (!comp) return;

    const additions: AssignmentDraftSlot[] = [];
    for (const cls of schoolInfo.classes) {
      for (const sec of cls.sections) {
        const key = `${cls.id}:${sec.id}`;
        if (!builderClassSectionKeys.has(key)) continue;
        const already = assignSlots.some(
          (s) =>
            s.subjectId === builderSubject.id &&
            s.componentId === comp.id &&
            s.classId === cls.id &&
            s.sectionId === sec.id
        );
        if (!already) {
          additions.push({
            subjectId: builderSubject.id,
            subjectName: builderSubject.name,
            componentId: comp.id,
            componentName: comp.name,
            classId: cls.id,
            className: cls.name,
            sectionId: sec.id,
            sectionName: sec.name,
          });
        }
      }
    }
    if (additions.length > 0) {
      setAssignSlots((prev) => [...prev, ...additions]);
    }
    setBuilderClassSectionKeys(new Set());
  };

  const handleSaveAssignments = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!assignTarget) return;
    setSavingAssignments(true);
    setError(null);
    setModalError(null);
    setNotice(null);
    try {
      const ctPayload = Array.from(assignCtKeys).map((k) => {
        const [classId, sectionId] = k.split(':').map(Number);
        return { classId, sectionId };
      });
      const res = await apiFetch<{
        success: boolean;
        academicYear: string;
        user?: UserRecord;
      }>(`/api/admin/users/${assignTarget.id}/assignments`, {
        method: 'PUT',
        body: JSON.stringify({
          academicYear: assignYear,
          subjectAssignments: assignSlots.map((s) => ({
            subjectId: s.subjectId,
            componentId: s.componentId,
            classId: s.classId,
            sectionId: s.sectionId,
          })),
          classTeacherSections: ctPayload,
        }),
      });
      if (res.user && assignYear === (selectedAcademicYear || schoolInfo.currentAcademicYear)) {
        upsertUserLocally(res.user);
      }
      const targetName = assignTarget.full_name;
      setAssignTarget(null);
      setNotice(`Saved assignments for ${targetName} (${assignYear}).`);
      triggerBackgroundReload();
      void onChanged();
    } catch (err: unknown) {
      setModalError(extractErrorMessage(err, 'Failed to save teacher assignments.'));
    } finally {
      setSavingAssignments(false);
    }
  };

  const activeFilterCount =
    (filterRole ? 1 : 0) +
    (filterSubjectId ? 1 : 0) +
    (filterClassId ? 1 : 0) +
    (filterSectionId ? 1 : 0) +
    (filterStatus ? 1 : 0);

  return (
    <div className="space-y-4">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
        <div>
          <h2 className="text-lg font-bold text-slate-900">Teacher &amp; Faculty Management</h2>
          <p className="text-xs text-slate-500">
            Manage teacher profiles, multi-class/section subject assignments, credentials, and directory status
          </p>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <div className="inline-flex rounded-lg border border-slate-200 bg-white p-0.5 text-xs">
            <button
              type="button"
              onClick={() => {
                setViewMode('active');
                setSelectedIds(new Set());
                setPage(1);
              }}
              className={`min-h-[38px] sm:min-h-[32px] px-3 py-1.5 rounded-md font-medium transition-colors cursor-pointer ${
                viewMode === 'active'
                  ? 'bg-[#1E3A5F] text-white'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Active Directory
            </button>
            <button
              type="button"
              onClick={() => {
                setViewMode('archived');
                setSelectedIds(new Set());
                setPage(1);
              }}
              className={`min-h-[38px] sm:min-h-[32px] px-3 py-1.5 rounded-md font-medium transition-colors cursor-pointer ${
                viewMode === 'archived'
                  ? 'bg-[#1E3A5F] text-white'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Archived
            </button>
          </div>

          <button
            type="button"
            onClick={() => {
              setError(null);
              setModalError(null);
              setCreateOpen(true);
            }}
            className="min-h-[42px] sm:min-h-[36px] inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-white bg-[#1E3A5F] rounded-lg hover:bg-[#162D4A] whitespace-nowrap cursor-pointer"
          >
            <UserPlus className="w-3.5 h-3.5" />
            Add Teacher / User
          </button>
        </div>
      </div>

      {undoState && (
        <UndoBanner
          message={undoState.message}
          onUndo={handleUndoRestore}
          onDismiss={() => setUndoState(null)}
          busy={bulkBusy}
        />
      )}

      {notice && (
        <div className="flex items-center justify-between gap-2 p-3 rounded-xl bg-emerald-50 border border-emerald-200 text-xs font-medium text-emerald-900">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-700 shrink-0" />
            <span>{notice}</span>
          </div>
          <button type="button" onClick={() => setNotice(null)} className="text-emerald-700 hover:text-emerald-900 cursor-pointer">
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      )}

      {error && (
        <div className="flex flex-wrap items-center justify-between gap-2 p-3 rounded-xl bg-red-50 border border-red-200 text-xs font-medium text-red-900">
          <span>{error}</span>
          <button
            type="button"
            onClick={() => loadUsers()}
            className="px-3 py-1.5 bg-red-800 text-white rounded-lg hover:bg-red-900 cursor-pointer"
          >
            Retry
          </button>
        </div>
      )}

      {/* Search, Filter & Sort Controls */}
      <div className="bg-white border border-slate-200 rounded-xl p-4 space-y-3 text-xs">
        <div className="grid grid-cols-1 md:grid-cols-12 gap-2.5">
          <div className="relative md:col-span-4">
            <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={search}
              onChange={(e) => {
                setSearch(e.target.value);
                setPage(1);
              }}
              placeholder="Search name, Teacher ID, username, email..."
              className="w-full min-h-[42px] sm:min-h-[36px] pl-8 pr-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:border-[#1E3A5F]"
            />
          </div>

          <select
            value={filterSubjectId}
            onChange={(e) => {
              setFilterSubjectId(e.target.value);
              setPage(1);
            }}
            className="min-h-[42px] sm:min-h-[36px] md:col-span-2 px-2.5 py-2 border border-slate-300 rounded-lg bg-white"
          >
            <option value="">All Subjects</option>
            {subjects.map((s) => (
              <option key={s.id} value={s.id}>
                {s.name}
              </option>
            ))}
          </select>

          <select
            value={filterClassId}
            onChange={(e) => {
              setFilterClassId(e.target.value);
              setFilterSectionId('');
              setPage(1);
            }}
            className="min-h-[42px] sm:min-h-[36px] md:col-span-2 px-2.5 py-2 border border-slate-300 rounded-lg bg-white"
          >
            <option value="">All Classes</option>
            {schoolInfo.classes.map((c) => (
              <option key={c.id} value={c.id}>
                {c.name}
              </option>
            ))}
          </select>

          <select
            value={filterSectionId}
            disabled={filterClassObj?.hasSections === false}
            onChange={(e) => {
              setFilterSectionId(e.target.value);
              setPage(1);
            }}
            className="min-h-[42px] sm:min-h-[36px] md:col-span-2 px-2.5 py-2 border border-slate-300 rounded-lg bg-white disabled:bg-slate-100 disabled:text-slate-400"
          >
            <option value="">{filterClassObj?.hasSections === false ? 'No Sections' : 'All Sections'}</option>
            {allSectionNames.map((sec) => (
              <option key={sec.id} value={sec.id}>
                {filterClassId ? `Section ${sec.name}` : sec.name}
              </option>
            ))}
          </select>

          <select
            value={sortBy}
            onChange={(e) => setSortBy(e.target.value as any)}
            className="min-h-[42px] sm:min-h-[36px] md:col-span-2 px-2.5 py-2 border border-slate-300 rounded-lg bg-white"
          >
            <option value="name_asc">Sort: Name A–Z</option>
            <option value="name_desc">Sort: Name Z–A</option>
            <option value="code_asc">Sort: Teacher ID</option>
            <option value="recent">Sort: Newest</option>
          </select>
        </div>

        <div className="flex flex-wrap items-center justify-between gap-2 pt-1 border-t border-slate-100">
          <div className="flex flex-wrap items-center gap-2">
            <select
              value={filterRole}
              onChange={(e) => {
                setFilterRole(e.target.value as any);
                setPage(1);
              }}
              className="min-h-[38px] sm:min-h-[32px] px-2.5 py-1 border border-slate-300 rounded-lg bg-white"
            >
              <option value="">All Roles</option>
              <option value="teacher">Teachers Only</option>
              <option value="admin">Administrators</option>
            </select>

            <select
              value={filterStatus}
              onChange={(e) => {
                setFilterStatus(e.target.value as any);
                setPage(1);
              }}
              className="min-h-[38px] sm:min-h-[32px] px-2.5 py-1 border border-slate-300 rounded-lg bg-white"
            >
              <option value="">All Account Statuses</option>
              <option value="active">Active Only</option>
              <option value="inactive">Inactive Only</option>
            </select>

            {hasActiveFilters && (
              <button
                type="button"
                onClick={clearFilters}
                className="min-h-[38px] sm:min-h-[32px] inline-flex items-center gap-1 px-2.5 py-1 text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg font-medium cursor-pointer"
              >
                <X className="w-3 h-3" />
                Clear Filters{activeFilterCount > 0 ? ` (${activeFilterCount})` : ''}
              </button>
            )}
            <button
              type="button"
              onClick={() => loadUsers({ background: users.length > 0 })}
              disabled={loading || refreshing}
              title="Refresh teacher directory"
              className="min-h-[38px] sm:min-h-[32px] inline-flex items-center gap-1 px-2.5 py-1 text-slate-700 bg-white border border-slate-300 hover:bg-slate-50 rounded-lg font-medium disabled:opacity-50 cursor-pointer"
            >
              <RefreshCw className={`w-3 h-3 ${loading || refreshing ? 'animate-spin' : ''}`} />
              Refresh
            </button>
          </div>
          <div className="text-[11px] font-mono text-slate-500 tabular-nums">
            {users.length} account{users.length === 1 ? '' : 's'} · AY{' '}
            {selectedAcademicYear || schoolInfo.currentAcademicYear}
          </div>
        </div>
      </div>

      {/* Bulk Action Toolbar */}
      <BulkActionToolbar
        selectedCount={selectedIds.size}
        entityLabel="teacher"
        onClearSelection={() => setSelectedIds(new Set())}
        disabled={bulkBusy}
        actions={
          viewMode === 'archived'
            ? [
                {
                  id: 'restore',
                  label: 'Restore Selected',
                  icon: 'restore',
                  variant: 'success',
                  onClick: () => openBulkConfirm('restore', Array.from(selectedIds)),
                },
                {
                  id: 'export',
                  label: 'Export CSV',
                  icon: 'export',
                  onClick: handleExportSelectedCsv,
                },
                {
                  id: 'permanent_delete',
                  label: 'Delete Permanently',
                  icon: 'delete',
                  variant: 'danger',
                  onClick: () => openBulkConfirm('permanent_delete', Array.from(selectedIds)),
                },
              ]
            : [
                {
                  id: 'activate',
                  label: 'Activate',
                  icon: 'activate',
                  variant: 'success',
                  onClick: () => openBulkConfirm('activate', Array.from(selectedIds)),
                },
                {
                  id: 'deactivate',
                  label: 'Deactivate',
                  icon: 'deactivate',
                  variant: 'warning',
                  onClick: () => openBulkConfirm('deactivate', Array.from(selectedIds)),
                },
                {
                  id: 'export',
                  label: 'Export Selected',
                  icon: 'export',
                  onClick: handleExportSelectedCsv,
                },
                {
                  id: 'archive',
                  label: 'Archive Selected',
                  icon: 'archive',
                  variant: 'warning',
                  onClick: () => openBulkConfirm('archive', Array.from(selectedIds)),
                },
                {
                  id: 'permanent_delete',
                  label: 'Delete Permanently',
                  icon: 'delete',
                  variant: 'danger',
                  onClick: () => openBulkConfirm('permanent_delete', Array.from(selectedIds)),
                },
              ]
        }
      />

      {/* Mobile Select All Bar */}
      <div className="md:hidden bg-white border border-slate-200 rounded-xl px-4 py-2.5 flex items-center justify-between text-xs">
        <label className="inline-flex items-center gap-2 font-medium text-slate-700 cursor-pointer">
          <input
            type="checkbox"
            checked={allPageSelected}
            disabled={pagedItems.length === 0}
            onChange={toggleSelectPage}
            className="w-4 h-4 rounded border-slate-300 text-[#1E3A5F]"
          />
          <span>Select All on Page ({pagedItems.length})</span>
        </label>
        <span className="font-mono text-[11px] text-slate-500">Page {page}</span>
      </div>

      {/* Responsive Mobile Cards (<768px) */}
      <div className="md:hidden space-y-3">
        {loading ? (
          <div className="bg-white border border-slate-200 rounded-xl p-8 text-center text-xs text-slate-500">
            Loading teacher directory...
          </div>
        ) : pagedItems.length === 0 ? (
          <div className="bg-white border border-slate-200 rounded-xl p-8 text-center space-y-2 text-xs text-slate-500">
            <div>No teacher accounts match your current filters.</div>
            {hasActiveFilters && (
              <button
                type="button"
                onClick={clearFilters}
                className="px-3 py-1.5 font-medium text-[#1E3A5F] bg-slate-100 rounded-lg"
              >
                Reset Filters
              </button>
            )}
          </div>
        ) : (
          pagedItems.map((u) => {
            const isSelected = selectedIds.has(u.id);
            const isAdminRole = u.roles.includes('admin');
            return (
              <div
                key={u.id}
                className={`bg-white border rounded-xl p-4 space-y-3 text-xs ${
                  isSelected ? 'border-[#1E3A5F] ring-1 ring-[#1E3A5F]/20' : 'border-slate-200'
                }`}
              >
                <div className="flex items-start justify-between gap-3">
                  <div className="flex items-start gap-2.5 min-w-0">
                    <input
                      type="checkbox"
                      aria-label={`Select ${u.full_name}`}
                      checked={isSelected}
                      onChange={() => toggleSelectRow(u.id)}
                      className="mt-0.5 w-4 h-4 rounded border-slate-300 text-[#1E3A5F]"
                    />
                    <div className="min-w-0">
                      <div className="font-bold text-sm text-slate-900 truncate">{u.full_name}</div>
                      <div className="text-[11px] font-mono text-slate-500">
                        {u.employee_code || 'NO-ID'} · @{u.username}
                      </div>
                      {u.email && <div className="text-[11px] text-slate-500 truncate">{u.email}</div>}
                    </div>
                  </div>
                  <span
                    className={`shrink-0 px-2 py-0.5 rounded border text-[11px] font-medium ${
                      u.isDeleted
                        ? 'bg-amber-50 text-amber-800 border-amber-200'
                        : u.isActive
                          ? 'bg-emerald-50 text-emerald-800 border-emerald-200'
                          : 'bg-slate-100 text-slate-600 border-slate-200'
                    }`}
                  >
                    {u.isDeleted ? 'Archived' : u.isActive ? 'Active' : 'Inactive'}
                  </span>
                </div>

                {!isAdminRole ? (
                  <div className="bg-slate-50 border border-slate-100 rounded-lg p-2.5 space-y-1 text-[11px]">
                    <div>
                      <span className="font-semibold text-slate-700">Subjects:</span>{' '}
                      <span className="text-slate-600">
                        {u.assignedSubjects.length > 0 ? u.assignedSubjects.join(', ') : 'None assigned'}
                      </span>
                    </div>
                    <div>
                      <span className="font-semibold text-slate-700">Classes:</span>{' '}
                      <span className="text-slate-600">
                        {u.assignedClasses.length > 0 ? u.assignedClasses.join(', ') : '—'}
                      </span>
                      {' · '}
                      <span className="font-semibold text-slate-700">Sections:</span>{' '}
                      <span className="text-slate-600">
                        {u.assignedSections.length > 0 ? u.assignedSections.join(', ') : '—'}
                      </span>
                    </div>
                    {u.classTeacherSections.length > 0 && (
                      <div className="text-[#1E3A5F] font-medium">
                        Class Teacher: {u.classTeacherSections.join(', ')}
                      </div>
                    )}
                  </div>
                ) : (
                  <div className="text-[11px] text-slate-500 bg-slate-50 rounded-lg p-2">
                    Administrator · Full portal permissions
                  </div>
                )}

                <div className="grid grid-cols-2 gap-2 pt-1">
                  <button
                    type="button"
                    onClick={() => openProfile(u)}
                    className="min-h-[40px] inline-flex items-center justify-center gap-1.5 px-2.5 py-1.5 font-medium text-slate-700 bg-white border border-slate-300 rounded-lg hover:bg-slate-50"
                  >
                    <Eye className="w-3.5 h-3.5" />
                    Profile
                  </button>
                  {!u.isDeleted && (
                    <button
                      type="button"
                      onClick={() => openAssignModal(u)}
                      className="min-h-[40px] inline-flex items-center justify-center gap-1.5 px-2.5 py-1.5 font-semibold text-[#1E3A5F] bg-sky-50 border border-sky-200 rounded-lg hover:bg-sky-100"
                    >
                      <BookOpen className="w-3.5 h-3.5" />
                      Assign
                    </button>
                  )}
                  <button
                    type="button"
                    onClick={() => openEditUser(u)}
                    className="min-h-[40px] inline-flex items-center justify-center gap-1.5 px-2.5 py-1.5 font-medium text-slate-700 bg-white border border-slate-300 rounded-lg hover:bg-slate-50"
                  >
                    <Pencil className="w-3.5 h-3.5" />
                    Edit
                  </button>
                  {!u.isDeleted ? (
                    <button
                      type="button"
                      onClick={() => {
                        setModalError(null);
                        setResetTarget(u);
                        setNewPassword('');
                      }}
                      className="min-h-[40px] inline-flex items-center justify-center gap-1.5 px-2.5 py-1.5 font-medium text-slate-700 bg-white border border-slate-300 rounded-lg hover:bg-slate-50"
                    >
                      <KeyRound className="w-3.5 h-3.5" />
                      Reset Password
                    </button>
                  ) : (
                    <button
                      type="button"
                      onClick={() => openBulkConfirm('restore', [u.id])}
                      className="min-h-[40px] inline-flex items-center justify-center gap-1.5 px-2.5 py-1.5 font-semibold text-emerald-800 bg-emerald-50 border border-emerald-200 rounded-lg"
                    >
                      <RotateCcw className="w-3.5 h-3.5" />
                      Restore
                    </button>
                  )}
                  {!u.isDeleted ? (
                    <>
                      <button
                        type="button"
                        onClick={() => toggleQuickStatus(u)}
                        className="min-h-[40px] inline-flex items-center justify-center gap-1.5 px-2.5 py-1.5 font-medium text-slate-700 bg-white border border-slate-300 rounded-lg hover:bg-slate-50"
                      >
                        <Power className="w-3.5 h-3.5" />
                        {u.isActive ? 'Deactivate' : 'Activate'}
                      </button>
                      <button
                        type="button"
                        onClick={() => openBulkConfirm('archive', [u.id])}
                        className="min-h-[40px] inline-flex items-center justify-center gap-1.5 px-2.5 py-1.5 font-medium text-amber-800 bg-amber-50 border border-amber-200 rounded-lg hover:bg-amber-100"
                      >
                        <Archive className="w-3.5 h-3.5" />
                        Archive
                      </button>
                      <button
                        type="button"
                        onClick={() => openBulkConfirm('permanent_delete', [u.id])}
                        className="col-span-2 min-h-[40px] inline-flex items-center justify-center gap-1.5 px-2.5 py-1.5 font-semibold text-red-700 bg-red-50 border border-red-200 rounded-lg hover:bg-red-100"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                        Delete Permanently
                      </button>
                    </>
                  ) : (
                    <button
                      type="button"
                      onClick={() => openBulkConfirm('permanent_delete', [u.id])}
                      className="col-span-2 min-h-[40px] inline-flex items-center justify-center gap-1.5 px-2.5 py-1.5 font-semibold text-red-700 bg-red-50 border border-red-200 rounded-lg hover:bg-red-100"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                      Delete Permanently
                    </button>
                  )}
                </div>
              </div>
            );
          })
        )}
      </div>

      {/* Desktop & Tablet Data Table (>=768px) */}
      <div className="hidden md:block bg-white border border-slate-200 rounded-xl overflow-hidden">
        <div className="overflow-x-auto max-h-[620px]">
          <table className="w-full text-xs">
            <thead className="bg-slate-50 border-b border-slate-200 text-slate-600 sticky top-0 z-10">
              <tr>
                <th className="w-10 px-3 py-2.5 text-center">
                  <input
                    type="checkbox"
                    aria-label="Select all teachers on current page"
                    checked={allPageSelected}
                    disabled={pagedItems.length === 0}
                    onChange={toggleSelectPage}
                    className="w-4 h-4 rounded border-slate-300 text-[#1E3A5F] cursor-pointer"
                  />
                </th>
                <th className="text-left font-semibold px-3 py-2.5">Teacher ID</th>
                <th className="text-left font-semibold px-3 py-2.5">Teacher Name &amp; Contact</th>
                <th className="text-left font-semibold px-3 py-2.5">Assigned Subject(s)</th>
                <th className="text-left font-semibold px-3 py-2.5">Classes &amp; Sections</th>
                <th className="text-center font-semibold px-3 py-2.5">Status</th>
                <th className="text-right font-semibold px-4 py-2.5">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200">
              {loading ? (
                <tr>
                  <td colSpan={7} className="px-4 py-10 text-center text-slate-500">
                    Loading teacher directory...
                  </td>
                </tr>
              ) : pagedItems.length === 0 ? (
                <tr>
                  <td colSpan={7} className="px-4 py-10 text-center text-slate-500">
                    <div className="space-y-2">
                      <div>
                        {viewMode === 'archived'
                          ? 'No archived teacher or user accounts.'
                          : 'No teachers match your current filters.'}
                      </div>
                      {hasActiveFilters && (
                        <button
                          type="button"
                          onClick={clearFilters}
                          className="px-3 py-1.5 text-xs font-medium text-[#1E3A5F] bg-slate-100 hover:bg-slate-200 rounded-lg cursor-pointer"
                        >
                          Clear Filters
                        </button>
                      )}
                    </div>
                  </td>
                </tr>
              ) : (
                pagedItems.map((u) => {
                  const isSelected = selectedIds.has(u.id);
                  const isAdminRole = u.roles.includes('admin');
                  return (
                    <tr
                      key={u.id}
                      className={isSelected ? 'bg-sky-50/40' : 'hover:bg-slate-50/70'}
                    >
                      <td className="px-3 py-2.5 text-center">
                        <input
                          type="checkbox"
                          aria-label={`Select ${u.full_name}`}
                          checked={isSelected}
                          onChange={() => toggleSelectRow(u.id)}
                          className="w-4 h-4 rounded border-slate-300 text-[#1E3A5F] cursor-pointer"
                        />
                      </td>
                      <td className="px-3 py-2.5 font-mono text-slate-600 whitespace-nowrap">
                        <div>{u.employee_code || '—'}</div>
                        <div className="text-[11px] text-slate-400">@{u.username}</div>
                      </td>
                      <td className="px-3 py-2.5">
                        <button
                          type="button"
                          onClick={() => openProfile(u)}
                          className="font-semibold text-slate-900 hover:text-[#1E3A5F] hover:underline text-left cursor-pointer"
                        >
                          {u.full_name}
                        </button>
                        <div className="text-[11px] text-slate-500">
                          {u.email || 'No email'} ·{' '}
                          <span className="capitalize">{u.roles.join(', ')}</span>
                        </div>
                      </td>
                      <td className="px-3 py-2.5 text-slate-700 max-w-[220px]">
                        {isAdminRole ? (
                          <span className="text-slate-500">Full System Access</span>
                        ) : u.assignedSubjects.length > 0 ? (
                          <span>{u.assignedSubjects.join(' · ')}</span>
                        ) : (
                          <span className="text-slate-400">Unassigned</span>
                        )}
                      </td>
                      <td className="px-3 py-2.5 text-slate-700 max-w-[230px]">
                        {isAdminRole ? (
                          <span className="text-slate-400">All Classes</span>
                        ) : (
                          <div className="space-y-0.5">
                            <div>
                              {u.assignedClasses.length > 0
                                ? `${u.assignedClasses.join(', ')} (${u.assignedSections.join(', ')})`
                                : 'No subject classes'}
                            </div>
                            {u.classTeacherSections.length > 0 && (
                              <div className="text-[11px] font-medium text-[#1E3A5F]">
                                Class Teacher: {u.classTeacherSections.join(', ')}
                              </div>
                            )}
                          </div>
                        )}
                      </td>
                      <td className="px-3 py-2.5 text-center whitespace-nowrap">
                        <span
                          className={`px-2 py-0.5 rounded border text-[11px] font-medium ${
                            u.isDeleted
                              ? 'bg-amber-50 text-amber-800 border-amber-200'
                              : u.isActive
                                ? 'bg-emerald-50 text-emerald-800 border-emerald-200'
                                : 'bg-slate-100 text-slate-600 border-slate-200'
                          }`}
                        >
                          {u.isDeleted ? 'Archived' : u.isActive ? 'Active' : 'Inactive'}
                        </span>
                      </td>
                      <td className="px-4 py-2.5 text-right whitespace-nowrap">
                        <div className="inline-flex items-center gap-1.5">
                          <button
                            type="button"
                            onClick={() => openProfile(u)}
                            title="View Teacher Profile"
                            className="p-1.5 text-slate-600 hover:text-slate-900 border border-slate-200 rounded hover:bg-slate-100 cursor-pointer"
                          >
                            <Eye className="w-3.5 h-3.5" />
                          </button>
                          {!u.isDeleted && (
                            <button
                              type="button"
                              onClick={() => openAssignModal(u)}
                              title="Assign Subjects, Classes & Sections"
                              className="inline-flex items-center gap-1 px-2 py-1 text-[11px] font-semibold text-[#1E3A5F] bg-sky-50 border border-sky-200 rounded hover:bg-sky-100 cursor-pointer"
                            >
                              <Layers className="w-3 h-3" />
                              Assign
                            </button>
                          )}
                          <button
                            type="button"
                            onClick={() => openEditUser(u)}
                            title="Edit Details"
                            className="p-1.5 text-slate-600 hover:text-slate-900 border border-slate-200 rounded hover:bg-slate-100 cursor-pointer"
                          >
                            <Pencil className="w-3.5 h-3.5" />
                          </button>
                          {!u.isDeleted ? (
                            <>
                              <button
                                type="button"
                                onClick={() => {
                                  setModalError(null);
                                  setResetTarget(u);
                                  setNewPassword('');
                                }}
                                title="Reset Password"
                                className="p-1.5 text-slate-600 hover:text-slate-900 border border-slate-200 rounded hover:bg-slate-100 cursor-pointer"
                              >
                                <KeyRound className="w-3.5 h-3.5" />
                              </button>
                              <button
                                type="button"
                                onClick={() => toggleQuickStatus(u)}
                                className="px-2 py-1 text-[11px] font-medium border border-slate-300 rounded hover:bg-slate-50 cursor-pointer"
                              >
                                {u.isActive ? 'Deactivate' : 'Activate'}
                              </button>
                              <button
                                type="button"
                                onClick={() => openBulkConfirm('archive', [u.id])}
                                title="Archive Account (Preserve History)"
                                className="p-1.5 text-amber-700 hover:text-amber-900 bg-amber-50 border border-amber-200 rounded hover:bg-amber-100 cursor-pointer"
                              >
                                <Archive className="w-3.5 h-3.5" />
                              </button>
                              <button
                                type="button"
                                onClick={() => openBulkConfirm('permanent_delete', [u.id])}
                                title="Delete Permanently from Database"
                                className="p-1.5 text-red-600 hover:text-red-800 bg-red-50 border border-red-200 rounded hover:bg-red-100 cursor-pointer"
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                              </button>
                            </>
                          ) : (
                            <>
                              <button
                                type="button"
                                onClick={() => openBulkConfirm('restore', [u.id])}
                                className="inline-flex items-center gap-1 px-2.5 py-1 text-[11px] font-semibold text-emerald-800 bg-emerald-50 border border-emerald-200 rounded hover:bg-emerald-100 cursor-pointer"
                              >
                                <RotateCcw className="w-3 h-3" />
                                Restore
                              </button>
                              <button
                                type="button"
                                onClick={() => openBulkConfirm('permanent_delete', [u.id])}
                                title="Delete Permanently from Database"
                                className="inline-flex items-center gap-1 px-2.5 py-1 text-[11px] font-semibold text-red-700 bg-red-50 border border-red-200 rounded hover:bg-red-100 cursor-pointer"
                              >
                                <Trash2 className="w-3 h-3" />
                                Delete Permanently
                              </button>
                            </>
                          )}
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Pagination Bar */}
      <div className="bg-white border border-slate-200 rounded-xl overflow-hidden">
        <PaginationBar
          totalItems={users.length}
          page={page}
          pageSize={pageSize}
          onPageChange={setPage}
          onPageSizeChange={setPageSize}
        />
      </div>

      {/* Create Teacher / User Modal */}
      {createOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/50 p-4">
          <form
            onSubmit={handleCreate}
            className="bg-white border border-slate-200 rounded-xl w-full max-w-md max-h-[90vh] overflow-y-auto p-6 space-y-4 shadow-xl text-xs"
          >
            <div className="flex items-center justify-between">
              <h3 className="text-base font-bold text-slate-900">Add Teacher / User Account</h3>
              <button type="button" onClick={() => setCreateOpen(false)} className="cursor-pointer">
                <X className="w-4 h-4 text-slate-400" />
              </button>
            </div>
            {modalError && (
              <div className="p-2.5 rounded-lg bg-red-50 border border-red-200 text-red-800 font-medium">
                {modalError}
              </div>
            )}
            <div className="space-y-3">
              <div>
                <label className="block font-semibold text-slate-700 mb-1">Full Name *</label>
                <input
                  type="text"
                  required
                  value={createForm.fullName}
                  onChange={(e) => setCreateForm({ ...createForm, fullName: e.target.value })}
                  placeholder="e.g. Mrs. Sunita Menon"
                  className="w-full min-h-[42px] px-3 py-2 border border-slate-300 rounded-lg"
                />
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Username *</label>
                  <input
                    type="text"
                    required
                    value={createForm.username}
                    onChange={(e) => setCreateForm({ ...createForm, username: e.target.value })}
                    placeholder="e.g. menon"
                    className="w-full min-h-[42px] px-3 py-2 border border-slate-300 rounded-lg font-mono"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Temporary Password *</label>
                  <input
                    type="text"
                    required
                    minLength={6}
                    value={createForm.password}
                    onChange={(e) => setCreateForm({ ...createForm, password: e.target.value })}
                    placeholder="Min 6 characters"
                    className="w-full min-h-[42px] px-3 py-2 border border-slate-300 rounded-lg font-mono"
                  />
                </div>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Teacher ID (Auto if blank)</label>
                  <input
                    type="text"
                    value={createForm.employeeCode}
                    onChange={(e) => setCreateForm({ ...createForm, employeeCode: e.target.value })}
                    placeholder="e.g. TCH-112"
                    className="w-full min-h-[42px] px-3 py-2 border border-slate-300 rounded-lg font-mono"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Role *</label>
                  <select
                    value={createForm.role}
                    onChange={(e) => setCreateForm({ ...createForm, role: e.target.value as 'teacher' | 'admin' })}
                    className="w-full min-h-[42px] px-3 py-2 border border-slate-300 rounded-lg bg-white"
                  >
                    <option value="teacher">Teacher (Subject / Class Teacher)</option>
                    <option value="admin">Administrator</option>
                  </select>
                </div>
              </div>
              <div>
                <label className="block font-semibold text-slate-700 mb-1">Email / Contact</label>
                <input
                  type="email"
                  value={createForm.email}
                  onChange={(e) => setCreateForm({ ...createForm, email: e.target.value })}
                  placeholder="teacher@emrsgangyap.edu.in"
                  className="w-full min-h-[42px] px-3 py-2 border border-slate-300 rounded-lg"
                />
              </div>
            </div>
            <div className="flex flex-col-reverse sm:flex-row sm:justify-end gap-2 pt-2">
              <button
                type="button"
                disabled={creating}
                onClick={() => setCreateOpen(false)}
                className="min-h-[42px] px-3.5 py-2 border border-slate-300 rounded-lg cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={creating}
                className="min-h-[42px] px-4 py-2 font-semibold text-white bg-[#1E3A5F] rounded-lg disabled:opacity-50 cursor-pointer"
              >
                {creating ? 'Creating...' : 'Create Account'}
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Edit Teacher Modal */}
      {editTarget && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/50 p-4">
          <form
            onSubmit={handleSaveEditUser}
            className="bg-white border border-slate-200 rounded-xl w-full max-w-md max-h-[90vh] overflow-y-auto p-6 space-y-4 shadow-xl text-xs"
          >
            <div className="flex items-center justify-between">
              <h3 className="text-base font-bold text-slate-900">Edit Teacher Details</h3>
              <button type="button" onClick={() => setEditTarget(null)} className="cursor-pointer">
                <X className="w-4 h-4 text-slate-400" />
              </button>
            </div>
            {modalError && (
              <div className="p-2.5 rounded-lg bg-red-50 border border-red-200 text-red-800 font-medium">
                {modalError}
              </div>
            )}
            <div className="space-y-3">
              <div>
                <label className="block font-semibold text-slate-700 mb-1">Full Name *</label>
                <input
                  type="text"
                  required
                  value={editForm.fullName}
                  onChange={(e) => setEditForm({ ...editForm, fullName: e.target.value })}
                  className="w-full min-h-[42px] px-3 py-2 border border-slate-300 rounded-lg"
                />
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Username *</label>
                  <input
                    type="text"
                    required
                    value={editForm.username}
                    onChange={(e) => setEditForm({ ...editForm, username: e.target.value })}
                    className="w-full min-h-[42px] px-3 py-2 border border-slate-300 rounded-lg font-mono"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Teacher ID</label>
                  <input
                    type="text"
                    value={editForm.employeeCode}
                    onChange={(e) => setEditForm({ ...editForm, employeeCode: e.target.value })}
                    className="w-full min-h-[42px] px-3 py-2 border border-slate-300 rounded-lg font-mono"
                  />
                </div>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Role *</label>
                  <select
                    value={editForm.role}
                    onChange={(e) => setEditForm({ ...editForm, role: e.target.value as 'teacher' | 'admin' })}
                    className="w-full min-h-[42px] px-3 py-2 border border-slate-300 rounded-lg bg-white"
                  >
                    <option value="teacher">Teacher (Subject / Class Teacher)</option>
                    <option value="admin">Administrator</option>
                  </select>
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Account Status</label>
                  <select
                    value={editForm.isActive ? 'active' : 'inactive'}
                    onChange={(e) => setEditForm({ ...editForm, isActive: e.target.value === 'active' })}
                    className="w-full min-h-[42px] px-3 py-2 border border-slate-300 rounded-lg bg-white"
                  >
                    <option value="active">Active</option>
                    <option value="inactive">Inactive</option>
                  </select>
                </div>
              </div>
              <div>
                <label className="block font-semibold text-slate-700 mb-1">Email / Contact</label>
                <input
                  type="email"
                  value={editForm.email}
                  onChange={(e) => setEditForm({ ...editForm, email: e.target.value })}
                  className="w-full min-h-[42px] px-3 py-2 border border-slate-300 rounded-lg"
                />
              </div>
            </div>
            <div className="flex flex-col-reverse sm:flex-row sm:justify-end gap-2 pt-2">
              <button
                type="button"
                disabled={savingEdit}
                onClick={() => setEditTarget(null)}
                className="min-h-[42px] px-3.5 py-2 border border-slate-300 rounded-lg hover:bg-slate-50 cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={savingEdit}
                className="min-h-[42px] px-4 py-2 font-semibold text-white bg-[#1E3A5F] rounded-lg hover:bg-[#162D4A] disabled:opacity-50 cursor-pointer"
              >
                {savingEdit ? 'Saving...' : 'Save Changes'}
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Multi-Subject / Class / Section Assignment Modal */}
      {assignTarget && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/50 p-4">
          <form
            onSubmit={handleSaveAssignments}
            className="bg-white border border-slate-200 rounded-xl w-full max-w-3xl max-h-[90vh] flex flex-col shadow-xl text-xs"
          >
            <div className="px-5 py-4 border-b border-slate-200 flex items-center justify-between gap-3">
              <div>
                <h3 className="text-base font-bold text-slate-900">
                  Assign Subjects, Classes &amp; Sections — {assignTarget.full_name}
                </h3>
                <p className="text-[11px] text-slate-500">
                  Teacher ID {assignTarget.employee_code || '—'} · Different teachers can be assigned to the same subject across different sections
                </p>
              </div>
              <button type="button" onClick={() => setAssignTarget(null)} className="p-1.5 cursor-pointer">
                <X className="w-4 h-4 text-slate-400" />
              </button>
            </div>

            <div className="p-5 space-y-5 overflow-y-auto flex-1">
              {modalError && (
                <div className="p-2.5 rounded-lg bg-red-50 border border-red-200 text-red-800 font-medium">
                  {modalError}
                </div>
              )}
              <div className="flex flex-wrap items-center gap-3">
                <label className="font-semibold text-slate-700">Academic Year:</label>
                <select
                  value={assignYear}
                  onChange={(e) => handleAssignYearChange(e.target.value)}
                  className="min-h-[38px] px-3 py-1.5 border border-slate-300 rounded-lg bg-white font-mono"
                >
                  {(schoolInfo.academicYears || []).map((ay) => (
                    <option key={ay.name} value={ay.name}>
                      {ay.name} {ay.isCurrent ? '(Current)' : ''}
                    </option>
                  ))}
                </select>
              </div>

              {/* Quick Batch Slot Builder */}
              <div className="p-4 bg-slate-50 border border-slate-200 rounded-xl space-y-3">
                <div className="font-bold text-slate-800">Add Subject / Component Across Multiple Classes &amp; Sections</div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block font-semibold text-slate-700 mb-1">Subject</label>
                    <select
                      value={builderSubjectId}
                      onChange={(e) => {
                        const sid = Number(e.target.value);
                        const sub = subjects.find((s) => s.id === sid);
                        setBuilderSubjectId(sid);
                        setBuilderComponentId(sub?.components[0]?.id || 0);
                      }}
                      className="w-full min-h-[40px] px-3 py-2 border border-slate-300 rounded-lg bg-white"
                    >
                      {subjects.map((s) => (
                        <option key={s.id} value={s.id}>
                          {s.name} ({s.code})
                        </option>
                      ))}
                    </select>
                  </div>
                  <div>
                    <label className="block font-semibold text-slate-700 mb-1">Paper / Component</label>
                    <select
                      value={builderComponentId}
                      onChange={(e) => setBuilderComponentId(Number(e.target.value))}
                      className="w-full min-h-[40px] px-3 py-2 border border-slate-300 rounded-lg bg-white"
                    >
                      {builderSubject?.components.map((c) => (
                        <option key={c.id} value={c.id}>
                          {c.name} ({c.code})
                        </option>
                      ))}
                    </select>
                  </div>
                </div>

                <div>
                  <div className="font-semibold text-slate-700 mb-1.5">
                    Select Classes &amp; Sections ({builderClassSectionKeys.size} ticked)
                  </div>
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 max-h-40 overflow-y-auto p-2 bg-white border border-slate-200 rounded-lg">
                    {schoolInfo.classes.map((cls) =>
                      cls.sections.map((sec) => {
                        const key = `${cls.id}:${sec.id}`;
                        const checked = builderClassSectionKeys.has(key);
                        return (
                          <label
                            key={key}
                            className={`flex items-center gap-2 px-2.5 py-1.5 rounded-lg border cursor-pointer ${
                              checked
                                ? 'bg-sky-50 border-sky-300 text-slate-900 font-medium'
                                : 'bg-white border-slate-200 text-slate-700'
                            }`}
                          >
                            <input
                              type="checkbox"
                              checked={checked}
                              onChange={() => toggleBuilderClassSection(cls.id, sec.id)}
                              className="rounded border-slate-300 text-[#1E3A5F]"
                            />
                            <span className="truncate">
                              {formatClassSectionLabel(cls.name, sec.name, cls.hasSections)}
                            </span>
                          </label>
                        );
                      })
                    )}
                  </div>
                </div>

                <div className="flex justify-end">
                  <button
                    type="button"
                    disabled={builderClassSectionKeys.size === 0}
                    onClick={handleAddBuiltSlots}
                    className="min-h-[38px] inline-flex items-center gap-1.5 px-3.5 py-1.5 font-semibold text-white bg-[#1E3A5F] rounded-lg hover:bg-[#162D4A] disabled:opacity-40 cursor-pointer"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    Add Ticked Slots ({builderClassSectionKeys.size})
                  </button>
                </div>
              </div>

              {/* Current Draft Subject Slots */}
              <div className="space-y-2">
                <div className="font-bold text-slate-800">
                  Assigned Subject Slots ({assignSlots.length})
                </div>
                {assignSlots.length === 0 ? (
                  <div className="p-4 text-center text-slate-500 border border-dashed border-slate-300 rounded-xl">
                    No subject teaching slots assigned for {assignYear}.
                  </div>
                ) : (
                  <div className="border border-slate-200 rounded-xl divide-y divide-slate-100 max-h-48 overflow-y-auto">
                    {assignSlots.map((slot, idx) => (
                      <div
                        key={`${slot.subjectId}-${slot.componentId}-${slot.classId}-${slot.sectionId}`}
                        className="px-3.5 py-2 flex items-center justify-between gap-2"
                      >
                        <div>
                          <span className="font-semibold text-slate-900">{slot.subjectName}</span>
                          {slot.componentName && slot.componentName !== slot.subjectName && (
                            <span className="text-slate-600"> · {slot.componentName}</span>
                          )}
                          <span className="text-slate-500">
                            {' '}
                            —{' '}
                            {formatClassSectionLabel(
                              slot.className,
                              slot.sectionName,
                              schoolInfo.classes.find((c) => c.id === slot.classId)?.hasSections ?? true
                            )}
                          </span>
                        </div>
                        <button
                          type="button"
                          onClick={() =>
                            setAssignSlots((prev) => prev.filter((_, i) => i !== idx))
                          }
                          className="p-1.5 text-red-600 hover:bg-red-50 rounded cursor-pointer"
                          title="Remove slot"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              {/* Class Teacher Assignment Checkboxes */}
              <div className="space-y-2">
                <div className="font-bold text-slate-800">
                  Class Teacher Responsibility (Optional — {assignCtKeys.size} selected)
                </div>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                  {schoolInfo.classes.map((cls) =>
                    cls.sections.map((sec) => {
                      const key = `${cls.id}:${sec.id}`;
                      const checked = assignCtKeys.has(key);
                      return (
                        <label
                          key={key}
                          className={`flex items-center gap-2 px-2.5 py-1.5 rounded-lg border cursor-pointer ${
                            checked
                              ? 'bg-emerald-50 border-emerald-300 text-emerald-900 font-medium'
                              : 'bg-white border-slate-200 text-slate-700'
                          }`}
                        >
                          <input
                            type="checkbox"
                            checked={checked}
                            onChange={() =>
                              setAssignCtKeys((prev) => {
                                const next = new Set(prev);
                                if (next.has(key)) next.delete(key);
                                else next.add(key);
                                return next;
                              })
                            }
                            className="rounded border-slate-300 text-emerald-700"
                          />
                          <span className="truncate">
                            {formatClassSectionLabel(cls.name, sec.name, cls.hasSections)}
                          </span>
                        </label>
                      );
                    })
                  )}
                </div>
              </div>
            </div>

            <div className="px-5 py-3.5 border-t border-slate-200 bg-slate-50 flex flex-col-reverse sm:flex-row sm:justify-end gap-2">
              <button
                type="button"
                disabled={savingAssignments}
                onClick={() => setAssignTarget(null)}
                className="min-h-[42px] sm:min-h-[36px] px-4 py-2 border border-slate-300 bg-white rounded-lg cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={savingAssignments}
                className="min-h-[42px] sm:min-h-[36px] px-4 py-2 font-semibold text-white bg-[#1E3A5F] rounded-lg hover:bg-[#162D4A] disabled:opacity-50 cursor-pointer"
              >
                {savingAssignments ? 'Saving...' : 'Save Teacher Assignments'}
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Reset Password Modal */}
      {resetTarget && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/50 p-4">
          <form
            onSubmit={handleResetPassword}
            className="bg-white border border-slate-200 rounded-xl w-full max-w-sm p-6 space-y-4 shadow-xl text-xs"
          >
            <div className="flex items-center justify-between">
              <h3 className="text-base font-bold text-slate-900">Reset Teacher Password</h3>
              <button type="button" onClick={() => setResetTarget(null)} className="cursor-pointer">
                <X className="w-4 h-4 text-slate-400" />
              </button>
            </div>
            {modalError && (
              <div className="p-2.5 rounded-lg bg-red-50 border border-red-200 text-red-800 font-medium">
                {modalError}
              </div>
            )}
            <p className="text-slate-600">
              Assign a new temporary password for <span className="font-semibold text-slate-900">{resetTarget.full_name}</span>{' '}
              (<span className="font-mono">@{resetTarget.username}</span>). The teacher will be prompted to update it on next sign-in.
            </p>
            <input
              type="text"
              required
              minLength={6}
              value={newPassword}
              onChange={(e) => setNewPassword(e.target.value)}
              placeholder="New temporary password (min 6 chars)"
              className="w-full min-h-[42px] px-3 py-2 border border-slate-300 rounded-lg font-mono"
            />
            <div className="flex flex-col-reverse sm:flex-row sm:justify-end gap-2">
              <button
                type="button"
                disabled={resettingPass}
                onClick={() => setResetTarget(null)}
                className="min-h-[42px] px-3.5 py-2 border border-slate-300 rounded-lg cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={resettingPass}
                className="min-h-[42px] px-4 py-2 font-semibold text-white bg-[#1E3A5F] rounded-lg disabled:opacity-50 cursor-pointer"
              >
                {resettingPass ? 'Updating...' : 'Update Password'}
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Individual Teacher Profile Modal */}
      {profileOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/50 p-4">
          <div className="bg-white border border-slate-200 rounded-xl w-full max-w-2xl max-h-[90vh] flex flex-col shadow-xl text-xs">
            <div className="px-5 py-4 border-b border-slate-200 flex items-center justify-between gap-3">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-lg bg-[#1E3A5F]/10 text-[#1E3A5F] flex items-center justify-center">
                  <Users className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="text-base font-bold text-slate-900">
                    {profileData ? profileData.full_name : 'Teacher Profile'}
                  </h3>
                  {profileData && (
                    <p className="text-[11px] font-mono text-slate-500">
                      {profileData.employee_code || 'NO-ID'} · @{profileData.username}
                    </p>
                  )}
                </div>
              </div>
              <button
                type="button"
                onClick={() => setProfileOpen(false)}
                className="p-1.5 text-slate-400 hover:text-slate-700 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="p-5 overflow-y-auto space-y-4">
              {profileLoading || !profileData ? (
                <div className="py-10 text-center text-slate-500">Loading profile details...</div>
              ) : (
                <>
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                    <div className="p-3 bg-slate-50 border border-slate-200 rounded-lg">
                      <div className="text-[11px] text-slate-500">Contact &amp; Role</div>
                      <div className="font-semibold text-slate-900 mt-0.5 truncate">
                        {profileData.email || 'No email on record'}
                      </div>
                      <div className="text-[11px] text-slate-600 capitalize mt-0.5">
                        Role: {profileData.roles.join(', ')}
                      </div>
                    </div>
                    <div className="p-3 bg-slate-50 border border-slate-200 rounded-lg">
                      <div className="text-[11px] text-slate-500">Account Status</div>
                      <div className="font-semibold text-slate-900 mt-0.5">
                        {profileData.isDeleted
                          ? 'Archived'
                          : profileData.isActive
                            ? 'Active'
                            : 'Inactive'}
                      </div>
                      <div className="text-[11px] text-slate-500 mt-0.5">
                        {profileData.mustChangePassword ? 'Password reset pending' : 'Password active'}
                      </div>
                    </div>
                    <div className="p-3 bg-slate-50 border border-slate-200 rounded-lg">
                      <div className="text-[11px] text-slate-500">Submitted Marks Preserved</div>
                      <div className="font-mono font-bold text-base text-[#1E3A5F] mt-0.5 tabular-nums">
                        {profileData.marksStats.submitted_rows} / {profileData.marksStats.total_rows}
                      </div>
                      <div className="text-[11px] text-slate-500 mt-0.5">
                        {profileData.marksStats.last_activity_at
                          ? `Last: ${profileData.marksStats.last_activity_at.slice(0, 10)}`
                          : 'No marks entered yet'}
                      </div>
                    </div>
                  </div>

                  <div>
                    <div className="font-bold text-slate-800 mb-2">
                      Subject Teaching Assignments ({profileData.assignments.length})
                    </div>
                    {profileData.assignments.length === 0 ? (
                      <div className="p-3 bg-slate-50 border border-slate-200 rounded-lg text-slate-500">
                        No active subject teaching assignments.
                      </div>
                    ) : (
                      <div className="border border-slate-200 rounded-lg divide-y divide-slate-100 max-h-44 overflow-y-auto">
                        {profileData.assignments.map((a) => (
                          <div key={a.id} className="px-3 py-2 flex items-center justify-between gap-2">
                            <div>
                              <span className="font-semibold text-slate-900">{a.subject_name}</span>
                              {a.component_name !== a.subject_name && (
                                <span className="text-slate-600"> · {a.component_name}</span>
                              )}
                              <span className="text-slate-600">
                                {' '}
                                — {formatClassSectionLabel(a.class_name, a.section_name, a.hasSections ?? true)}
                              </span>
                            </div>
                            <span className="font-mono text-[11px] text-slate-500">{a.academic_year}</span>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>

                  {profileData.classTeacherAssignments.length > 0 && (
                    <div>
                      <div className="font-bold text-slate-800 mb-2">Class Teacher Sections</div>
                      <div className="flex flex-wrap gap-2">
                        {profileData.classTeacherAssignments.map((ct) => (
                          <div
                            key={ct.id}
                            className="px-3 py-1.5 bg-emerald-50 border border-emerald-200 rounded-lg text-emerald-900 font-medium"
                          >
                            {formatClassSectionLabel(ct.class_name, ct.section_name, ct.hasSections ?? true)} ({ct.academic_year})
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  {profileData.recentLogs.length > 0 && (
                    <div>
                      <div className="font-bold text-slate-800 mb-2">Recent Activity Log</div>
                      <div className="border border-slate-200 rounded-lg divide-y divide-slate-100 max-h-36 overflow-y-auto">
                        {profileData.recentLogs.map((l) => (
                          <div key={l.id} className="px-3 py-1.5 flex items-center justify-between gap-2">
                            <span className="font-mono text-[#1E3A5F] font-medium">{l.action}</span>
                            <span className="font-mono text-[11px] text-slate-400">{l.created_at}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </>
              )}
            </div>

            <div className="px-5 py-3.5 border-t border-slate-200 bg-slate-50 flex justify-end">
              <button
                type="button"
                onClick={() => setProfileOpen(false)}
                className="min-h-[38px] px-4 py-1.5 font-medium bg-white border border-slate-300 rounded-lg hover:bg-slate-100 cursor-pointer"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Bulk / Single Action Safety Confirmation Modal */}
      {confirmBulkAction && (
        <BulkConfirmModal
          open={true}
          title={confirmBulkAction.title}
          description={confirmBulkAction.description}
          confirmLabel={confirmBulkAction.confirmLabel}
          variant={confirmBulkAction.variant}
          busy={bulkBusy}
          safetyNoteTone={confirmBulkAction.action === 'permanent_delete' ? 'danger' : 'success'}
          safetyNote={
            confirmBulkAction.action === 'permanent_delete'
              ? 'PERMANENT DATABASE DELETION: Selected teacher/user account(s), login credentials, and assignments will be permanently removed from school.db (existing student marks remain intact with teacher attribution cleared). Cannot be undone.'
              : 'Historical student marks, attendance, report cards, and audit logs entered by these teachers are permanently preserved.'
          }
          items={confirmBulkAction.ids.map((id) => {
            const u = users.find((x) => x.id === id);
            return {
              id,
              label: u ? u.full_name : `User #${id}`,
              sublabel: u ? `${u.employee_code || '—'} · @${u.username}` : undefined,
            };
          })}
          onCancel={() => setConfirmBulkAction(null)}
          onConfirm={executeBulkAction}
        />
      )}
    </div>
  );
}
