import React, { useEffect, useState } from 'react';
import {
  Database,
  Download,
  Save,
  CheckCircle2,
  CalendarRange,
  ArrowRightCircle,
  History,
  Upload,
  Trash2,
  Palette,
  LayoutList,
  ArrowUp,
  ArrowDown,
  Plus,
  Type,
  Tag,
  X,
  RefreshCw,
  RotateCcw,
} from 'lucide-react';
import type {
  AcademicYearSummary,
  GradeRule,
  PortalSectionConfig,
  SchoolInfo,
  SiteContent,
  ThemeConfig,
} from '../../types';
import { apiFetch, downloadAuthorizedFile, extractErrorMessage } from '../../lib/api';
import { DEFAULT_SCHOOL_LOGO_PATH, SchoolLogo } from '../SchoolLogo';
import {
  BulkActionToolbar,
  BulkConfirmModal,
  UndoBanner,
  type BulkConfirmItem,
} from '../BulkActions';

interface AuditRow {
  id: number;
  username: string;
  user_role: string;
  action: string;
  entity_type: string;
  entity_id: string | null;
  details: string;
  created_at: string;
}

export function AdminAuditLogsView() {
  const [logs, setLogs] = useState<AuditRow[]>([]);
  const [actionFilter, setActionFilter] = useState('');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const loadLogs = async () => {
    setLoading(true);
    setError(null);
    try {
      const qs = actionFilter ? `?action=${encodeURIComponent(actionFilter)}` : '';
      const rows = await apiFetch<AuditRow[]>(`/api/admin/audit-logs${qs}`);
      setLogs(rows);
    } catch (err) {
      setError(extractErrorMessage(err));
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadLogs();
  }, [actionFilter]);

  return (
    <div className="space-y-4">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
        <div>
          <h2 className="text-lg font-bold text-slate-900">System Audit Logs</h2>
          <p className="text-xs text-slate-500">
            Activity records for logins, marks submissions, bulk actions, unlocks, student transfers, and system updates
          </p>
        </div>
        <select
          value={actionFilter}
          onChange={(e) => setActionFilter(e.target.value)}
          className="min-h-[40px] px-3 py-2 text-xs border border-slate-300 rounded-lg bg-white"
        >
          <option value="">All Actions</option>
          <option value="LOGIN">Logins</option>
          <option value="SAVE_MARKS_DRAFT">Save Marks Draft</option>
          <option value="SUBMIT_MARKS">Submit Marks</option>
          <option value="REQUEST_MARKS_CORRECTION">Correction Requests</option>
          <option value="RESOLVE_CORRECTION_REQUEST">Correction Approvals</option>
          <option value="TRANSFER_STUDENT">Student Transfers</option>
          <option value="PROMOTE_STUDENTS_NEXT_CLASS">Class-Wise Promotions</option>
          <option value="BULK_DELETE">Bulk Archive / Delete</option>
          <option value="BULK_RESTORE">Bulk Restore</option>
          <option value="CREATE_EXAMINATION">Examination Creation</option>
          <option value="UPDATE_SETTINGS">Website &amp; Settings Updates</option>
          <option value="DATABASE_BACKUP">Database Backups</option>
        </select>
      </div>

      {error && (
        <div className="p-3.5 rounded-xl bg-red-50 border border-red-200 flex flex-wrap items-center justify-between gap-2 text-xs text-red-800">
          <span>{error}</span>
          <button
            type="button"
            onClick={loadLogs}
            className="min-h-[34px] inline-flex items-center gap-1 px-3 py-1 bg-white border border-red-200 rounded-lg font-semibold text-red-800 hover:bg-red-100 cursor-pointer"
          >
            <RefreshCw className="w-3.5 h-3.5" />
            Retry
          </button>
        </div>
      )}

      <div className="bg-white border border-slate-200 rounded-xl overflow-hidden">
        {loading ? (
          <div className="p-8 text-center text-xs text-slate-500">Loading audit logs...</div>
        ) : logs.length === 0 ? (
          <div className="p-8 text-center text-xs text-slate-500">No audit entries match the selected filter.</div>
        ) : (
          <>
            {/* Mobile Cards */}
            <div className="md:hidden divide-y divide-slate-200">
              {logs.map((l) => (
                <div key={l.id} className="p-3.5 space-y-1 text-xs">
                  <div className="flex items-center justify-between gap-2">
                    <span className="font-mono font-semibold text-[#1E3A5F]">{l.action}</span>
                    <span className="font-mono text-[11px] text-slate-500">{l.created_at}</span>
                  </div>
                  <div className="text-slate-800">
                    <span className="font-semibold">{l.username}</span>{' '}
                    <span className="text-slate-500 capitalize">({l.user_role})</span> · {l.entity_type}{' '}
                    {l.entity_id ? `#${l.entity_id}` : ''}
                  </div>
                  {l.details && (
                    <div className="font-mono text-[11px] text-slate-500 break-all">{l.details}</div>
                  )}
                </div>
              ))}
            </div>

            {/* Desktop Table */}
            <div className="hidden md:block overflow-x-auto max-h-[600px]">
              <table className="w-full text-xs">
                <thead className="bg-slate-50 border-b border-slate-200 text-slate-600 sticky top-0">
                  <tr>
                    <th className="text-left font-semibold px-4 py-2.5">Timestamp (UTC)</th>
                    <th className="text-left font-semibold px-4 py-2.5">User</th>
                    <th className="text-left font-semibold px-4 py-2.5">Role</th>
                    <th className="text-left font-semibold px-4 py-2.5">Action</th>
                    <th className="text-left font-semibold px-4 py-2.5">Entity</th>
                    <th className="text-left font-semibold px-4 py-2.5">Details</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200">
                  {logs.map((l) => (
                    <tr key={l.id} className="hover:bg-slate-50/70">
                      <td className="px-4 py-2 font-mono text-slate-500 whitespace-nowrap">{l.created_at}</td>
                      <td className="px-4 py-2 font-semibold text-slate-900">{l.username}</td>
                      <td className="px-4 py-2 text-slate-600 capitalize">{l.user_role}</td>
                      <td className="px-4 py-2 font-mono text-[#1E3A5F] font-medium">{l.action}</td>
                      <td className="px-4 py-2 text-slate-600">
                        {l.entity_type} {l.entity_id ? `#${l.entity_id}` : ''}
                      </td>
                      <td className="px-4 py-2 font-mono text-[11px] text-slate-500 max-w-md truncate">{l.details}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </>
        )}
      </div>
    </div>
  );
}

function suggestNextAcademicYear(current: string): string {
  const match = current.match(/^(\d{4})-(\d{2,4})$/);
  if (!match) return '';
  const start = Number(match[1]) + 1;
  if (match[2].length === 2) {
    return `${start}-${String((start + 1) % 100).padStart(2, '0')}`;
  }
  return `${start}-${start + 1}`;
}

export function AdminSettingsView({
  schoolInfo,
  selectedAcademicYear,
  onSelectAcademicYear,
  onSaved,
}: {
  schoolInfo: SchoolInfo;
  selectedAcademicYear?: string;
  onSelectAcademicYear?: (year: string) => void;
  onSaved: (nextSelectedYear?: string) => void;
}) {
  const [schoolName, setSchoolName] = useState(schoolInfo.schoolName);
  const [schoolAddress, setSchoolAddress] = useState(schoolInfo.schoolAddress);
  const [schoolMotto, setSchoolMotto] = useState(schoolInfo.schoolMotto);
  const [schoolLogo, setSchoolLogo] = useState(schoolInfo.schoolLogo || '');
  const [academicYear, setAcademicYear] = useState(schoolInfo.currentAcademicYear);
  const [passPct, setPassPct] = useState(schoolInfo.defaultPassPercentage);
  const [gradingScale, setGradingScale] = useState<GradeRule[]>(schoolInfo.gradingScale);
  const [themeConfig, setThemeConfig] = useState<ThemeConfig>(
    schoolInfo.themeConfig || {
      primaryColor: '#1E3A5F',
      accentColor: '#0284C7',
      secondaryColor: '#10B981',
      headerBg: '#FFFFFF',
    }
  );
  const [siteContent, setSiteContent] = useState<SiteContent>(
    schoolInfo.siteContent || {
      portalTitle: 'Examination & Marks Portal',
      portalSubtitle: 'EMRS Gangyap',
      loginHeading: 'Portal Sign In',
      loginButtonLabel: 'Sign In',
      reportCardTitle: 'Statement of Marks',
      reportCardFooterLeft: 'Class Teacher',
      reportCardFooterCenter: 'Controller of Examinations',
      reportCardFooterRight: 'Principal',
    }
  );
  const [portalSections, setPortalSections] = useState<PortalSectionConfig[]>(
    [...(schoolInfo.portalSections || [])].sort((a, b) => a.order - b.order)
  );
  const [examinationTypes, setExaminationTypes] = useState<string[]>(
    schoolInfo.examinationTypes || ['Unit Test', 'Periodic Test', 'Half-Yearly', 'Pre-Board', 'Annual']
  );
  const [newExamType, setNewExamType] = useState('');
  const [savedNotice, setSavedNotice] = useState<string | null>(null);
  const [settingsError, setSettingsError] = useState<string | null>(null);
  const [logoError, setLogoError] = useState<string | null>(null);

  // Add/Edit Custom Section modal
  const [customSecOpen, setCustomSecOpen] = useState(false);
  const [customSecForm, setCustomSecForm] = useState({
    id: '',
    label: '',
    description: '',
    customHeading: '',
    customBody: '',
  });
  const [confirmRemoveSection, setConfirmRemoveSection] = useState<PortalSectionConfig | null>(null);
  const [confirmRemoveLogo, setConfirmRemoveLogo] = useState(false);

  // Academic Year Archive & Bulk Management
  const [yearViewMode, setYearViewMode] = useState<'active' | 'archived'>('active');
  const [academicYearRows, setAcademicYearRows] = useState<AcademicYearSummary[]>(schoolInfo.academicYears || []);
  const [selectedYearNames, setSelectedYearNames] = useState<string[]>([]);
  const [yearBulkConfirm, setYearBulkConfirm] = useState<{
    action: 'archive' | 'restore';
    names: string[];
    items: BulkConfirmItem[];
  } | null>(null);
  const [yearBulkBusy, setYearBulkBusy] = useState(false);
  const [yearUndoState, setYearUndoState] = useState<{ names: string[]; message: string } | null>(null);

  // Academic Year Rollover
  const [newYearName, setNewYearName] = useState(() =>
    suggestNextAcademicYear(schoolInfo.currentAcademicYear)
  );
  const [sourceYear, setSourceYear] = useState(schoolInfo.currentAcademicYear);
  const [promoteStudents, setPromoteStudents] = useState(true);
  const [copyTeacherAssignments, setCopyTeacherAssignments] = useState(true);
  const [copyClassTeachers, setCopyClassTeachers] = useState(true);
  const [setAsCurrent, setSetAsCurrent] = useState(true);
  const [confirmRolloverOpen, setConfirmRolloverOpen] = useState(false);
  const [transitioning, setTransitioning] = useState(false);
  const [transitionMessage, setTransitionMessage] = useState<string | null>(null);
  const [transitionError, setTransitionError] = useState<string | null>(null);

  useEffect(() => {
    setSchoolName(schoolInfo.schoolName);
    setSchoolAddress(schoolInfo.schoolAddress);
    setSchoolMotto(schoolInfo.schoolMotto);
    setSchoolLogo(schoolInfo.schoolLogo || '');
    setAcademicYear(schoolInfo.currentAcademicYear);
    setSourceYear(schoolInfo.currentAcademicYear);
    setNewYearName(suggestNextAcademicYear(schoolInfo.currentAcademicYear));
    setPassPct(schoolInfo.defaultPassPercentage);
    if (schoolInfo.gradingScale) setGradingScale(schoolInfo.gradingScale);
    if (schoolInfo.themeConfig) setThemeConfig(schoolInfo.themeConfig);
    if (schoolInfo.siteContent) setSiteContent(schoolInfo.siteContent);
    if (schoolInfo.portalSections) {
      setPortalSections([...schoolInfo.portalSections].sort((a, b) => a.order - b.order));
    }
    if (schoolInfo.examinationTypes) setExaminationTypes(schoolInfo.examinationTypes);
  }, [schoolInfo]);

  const loadAcademicYears = async (mode = yearViewMode) => {
    setTransitionError(null);
    try {
      const rows = await apiFetch<AcademicYearSummary[]>(`/api/admin/academic-years?view=${mode}`);
      setAcademicYearRows(rows);
      setSelectedYearNames([]);
    } catch (err) {
      setTransitionError(extractErrorMessage(err));
    }
  };

  useEffect(() => {
    loadAcademicYears(yearViewMode);
  }, [yearViewMode, schoolInfo.academicYears?.length]);

  const handleSaveSettings = async (
    overrides?: Partial<{
      schoolLogo: string;
      portalSections: PortalSectionConfig[];
      examinationTypes: string[];
      themeConfig: ThemeConfig;
      siteContent: SiteContent;
    }>,
    message = 'Website branding, sections, and system settings saved.'
  ): Promise<boolean> => {
    setSavedNotice(null);
    setSettingsError(null);
    try {
      await apiFetch('/api/admin/settings', {
        method: 'PUT',
        body: JSON.stringify({
          schoolName,
          schoolAddress,
          schoolMotto,
          schoolLogo: overrides?.schoolLogo !== undefined ? overrides.schoolLogo : schoolLogo,
          currentAcademicYear: academicYear,
          defaultPassPercentage: passPct,
          gradingScale,
          themeConfig: overrides?.themeConfig || themeConfig,
          siteContent: overrides?.siteContent || siteContent,
          portalSections: overrides?.portalSections || portalSections,
          examinationTypes: overrides?.examinationTypes || examinationTypes,
        }),
      });
      setSavedNotice(message);
      await onSaved();
      return true;
    } catch (err) {
      const msg = extractErrorMessage(err);
      setSettingsError(msg);
      if (overrides?.schoolLogo !== undefined) {
        setLogoError(msg);
      }
      return false;
    }
  };

  const handleFormSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    await handleSaveSettings();
  };

  const compressLogoToDataUrl = (file: File): Promise<string> =>
    new Promise((resolve, reject) => {
      if (file.type === 'image/svg+xml') {
        const reader = new FileReader();
        reader.onload = () => resolve(String(reader.result || ''));
        reader.onerror = () => reject(new Error('Could not read SVG file.'));
        reader.readAsDataURL(file);
        return;
      }

      const objectUrl = URL.createObjectURL(file);
      const img = new Image();
      img.onload = () => {
        try {
          const maxDim = 512;
          let { width, height } = img;
          if (width > maxDim || height > maxDim) {
            const scale = Math.min(maxDim / width, maxDim / height);
            width = Math.max(1, Math.round(width * scale));
            height = Math.max(1, Math.round(height * scale));
          }
          const canvas = document.createElement('canvas');
          canvas.width = width;
          canvas.height = height;
          const ctx = canvas.getContext('2d');
          if (!ctx) {
            URL.revokeObjectURL(objectUrl);
            reject(new Error('Canvas compression unavailable.'));
            return;
          }
          ctx.drawImage(img, 0, 0, width, height);
          let out = canvas.toDataURL('image/png');
          if (out.length > 300_000) {
            out = canvas.toDataURL('image/webp', 0.88);
          }
          URL.revokeObjectURL(objectUrl);
          resolve(out);
        } catch (err) {
          URL.revokeObjectURL(objectUrl);
          reject(err);
        }
      };
      img.onerror = () => {
        URL.revokeObjectURL(objectUrl);
        reject(new Error('Could not decode the selected image file.'));
      };
      img.src = objectUrl;
    });

  const handleLogoUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    setLogoError(null);
    const file = e.target.files?.[0];
    e.target.value = '';
    if (!file) return;
    if (!file.type.startsWith('image/')) {
      setLogoError('Please select a valid image file (PNG, JPG, SVG, or WebP).');
      return;
    }
    if (file.size > 4 * 1024 * 1024) {
      setLogoError('Image must be under 4 MB.');
      return;
    }
    try {
      const result = await compressLogoToDataUrl(file);
      const previous = schoolLogo;
      setSchoolLogo(result);
      const ok = await handleSaveSettings({ schoolLogo: result }, 'School logo updated successfully.');
      if (!ok) setSchoolLogo(previous);
    } catch (err) {
      setLogoError(extractErrorMessage(err, 'Failed to process selected logo image.'));
    }
  };

  const handleResetDefaultLogo = async () => {
    setLogoError(null);
    const previous = schoolLogo;
    setSchoolLogo(DEFAULT_SCHOOL_LOGO_PATH);
    const ok = await handleSaveSettings(
      { schoolLogo: DEFAULT_SCHOOL_LOGO_PATH },
      'Restored default school emblem.'
    );
    if (!ok) setSchoolLogo(previous);
  };

  const handleConfirmRemoveLogo = async () => {
    setLogoError(null);
    const previous = schoolLogo;
    setSchoolLogo('');
    setConfirmRemoveLogo(false);
    const ok = await handleSaveSettings({ schoolLogo: '' }, 'School logo removed.');
    if (!ok) setSchoolLogo(previous);
  };

  const moveSection = (index: number, direction: -1 | 1) => {
    const targetIdx = index + direction;
    if (targetIdx < 0 || targetIdx >= portalSections.length) return;
    const copy = [...portalSections];
    const [moved] = copy.splice(index, 1);
    copy.splice(targetIdx, 0, moved);
    const reindexed = copy.map((sec, i) => ({ ...sec, order: i + 1 }));
    setPortalSections(reindexed);
  };

  const toggleSection = (id: string) => {
    setPortalSections((prev) =>
      prev.map((s) => (s.id === id ? { ...s, enabled: !s.enabled } : s))
    );
  };

  const updateSectionField = (id: string, field: 'label' | 'description', value: string) => {
    setPortalSections((prev) => prev.map((s) => (s.id === id ? { ...s, [field]: value } : s)));
  };

  const handleSaveCustomSection = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!customSecForm.label.trim()) return;
    let nextSections: PortalSectionConfig[];
    if (customSecForm.id) {
      nextSections = portalSections.map((s) =>
        s.id === customSecForm.id
          ? {
              ...s,
              label: customSecForm.label.trim(),
              description: customSecForm.description.trim(),
              customHeading: customSecForm.customHeading.trim() || customSecForm.label.trim(),
              customBody: customSecForm.customBody,
            }
          : s
      );
    } else {
      const slug = `custom-${Date.now()}`;
      nextSections = [
        ...portalSections,
        {
          id: slug,
          label: customSecForm.label.trim(),
          description: customSecForm.description.trim(),
          enabled: true,
          order: portalSections.length + 1,
          custom: true,
          customHeading: customSecForm.customHeading.trim() || customSecForm.label.trim(),
          customBody: customSecForm.customBody,
        },
      ];
    }
    setPortalSections(nextSections);
    setCustomSecOpen(false);
    await handleSaveSettings({ portalSections: nextSections }, 'Portal sections updated.');
  };

  const handleDeleteSection = async () => {
    if (!confirmRemoveSection) return;
    const nextSections = portalSections
      .filter((s) => s.id !== confirmRemoveSection.id)
      .map((s, i) => ({ ...s, order: i + 1 }));
    setPortalSections(nextSections);
    setConfirmRemoveSection(null);
    await handleSaveSettings({ portalSections: nextSections }, 'Section removed.');
  };

  const handleAddExamType = async () => {
    const clean = newExamType.trim();
    if (!clean || examinationTypes.includes(clean)) return;
    const next = [...examinationTypes, clean];
    setExaminationTypes(next);
    setNewExamType('');
    await handleSaveSettings({ examinationTypes: next }, `Added examination type "${clean}".`);
  };

  const handleRemoveExamType = async (typeName: string) => {
    const next = examinationTypes.filter((t) => t !== typeName);
    setExaminationTypes(next);
    await handleSaveSettings({ examinationTypes: next }, `Removed examination type "${typeName}".`);
  };

  const handleActivateYear = async (yearName: string) => {
    setTransitionError(null);
    setTransitionMessage(null);
    try {
      await apiFetch('/api/admin/academic-years/active', {
        method: 'PUT',
        body: JSON.stringify({ academicYear: yearName }),
      });
      setTransitionMessage(`Active academic year switched to ${yearName}. All previous session data remains intact.`);
      await loadAcademicYears(yearViewMode);
      onSaved(yearName);
    } catch (err) {
      setTransitionError(extractErrorMessage(err));
    }
  };

  const handleExecuteRollover = async () => {
    setTransitioning(true);
    setTransitionError(null);
    setTransitionMessage(null);
    try {
      const res = await apiFetch<{
        success: boolean;
        newAcademicYear: string;
        promotedCount: number;
        graduatedCount: number;
        copiedAssignments: number;
        copiedClassTeachers: number;
      }>('/api/admin/academic-years/transition', {
        method: 'POST',
        body: JSON.stringify({
          newAcademicYear: newYearName.trim(),
          sourceAcademicYear: sourceYear,
          promoteStudents,
          copyTeacherAssignments,
          copyClassTeachers,
          setAsCurrent,
        }),
      });
      setConfirmRolloverOpen(false);
      setTransitionMessage(
        `Academic Year ${res.newAcademicYear} initialized: ${res.promotedCount} promoted, ${res.graduatedCount} graduated, ${res.copiedAssignments} subject assignment(s) and ${res.copiedClassTeachers} class teacher(s) carried forward.`
      );
      await loadAcademicYears(yearViewMode);
      onSaved(setAsCurrent ? res.newAcademicYear : undefined);
    } catch (err) {
      setTransitionError(extractErrorMessage(err));
      setConfirmRolloverOpen(false);
    } finally {
      setTransitioning(false);
    }
  };

  const handleYearBulkConfirm = async () => {
    if (!yearBulkConfirm) return;
    setYearBulkBusy(true);
    setTransitionError(null);
    try {
      await apiFetch('/api/admin/academic-years/bulk-action', {
        method: 'POST',
        body: JSON.stringify({ action: yearBulkConfirm.action, names: yearBulkConfirm.names }),
      });
      if (yearBulkConfirm.action === 'archive') {
        setYearUndoState({
          names: yearBulkConfirm.names,
          message: `Archived ${yearBulkConfirm.names.length} academic year record(s). Historical enrollments & marks remain preserved.`,
        });
      } else {
        setYearUndoState(null);
      }
      setYearBulkConfirm(null);
      await loadAcademicYears(yearViewMode);
      onSaved();
    } catch (err) {
      setTransitionError(extractErrorMessage(err));
      setYearBulkConfirm(null);
    } finally {
      setYearBulkBusy(false);
    }
  };

  const handleYearUndo = async () => {
    if (!yearUndoState) return;
    setYearBulkBusy(true);
    setTransitionError(null);
    try {
      await apiFetch('/api/admin/academic-years/bulk-action', {
        method: 'POST',
        body: JSON.stringify({ action: 'restore', names: yearUndoState.names }),
      });
      setYearUndoState(null);
      await loadAcademicYears(yearViewMode);
      onSaved();
    } catch (err) {
      setTransitionError(extractErrorMessage(err));
    } finally {
      setYearBulkBusy(false);
    }
  };

  const handleQuickRestoreYear = async (yearName: string) => {
    setTransitionError(null);
    try {
      await apiFetch('/api/admin/academic-years/bulk-action', {
        method: 'POST',
        body: JSON.stringify({ action: 'restore', names: [yearName] }),
      });
      await loadAcademicYears(yearViewMode);
      onSaved();
    } catch (err) {
      setTransitionError(extractErrorMessage(err));
    }
  };

  const selectableYears = academicYearRows.filter((ay) => (yearViewMode === 'active' ? !ay.isCurrent : true));
  const allYearsSelected =
    selectableYears.length > 0 && selectableYears.every((ay) => selectedYearNames.includes(ay.name));

  const activeCohortYears = schoolInfo.academicYears || [];

  return (
    <div className="space-y-6 max-w-5xl">
      <div>
        <h2 className="text-lg font-bold text-slate-900">Website Branding, Sections &amp; System Settings</h2>
        <p className="text-xs text-slate-500">
          Manage school identity, logo, colors, labels, navigation sections, exam types, grading, and backups
        </p>
      </div>

      {savedNotice && (
        <div className="flex items-center gap-2 p-3 rounded-xl bg-emerald-50 border border-emerald-200 text-xs font-medium text-emerald-800">
          <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
          <span>{savedNotice}</span>
        </div>
      )}

      {settingsError && (
        <div className="p-3 rounded-xl bg-red-50 border border-red-200 text-xs font-medium text-red-800">
          {settingsError}
        </div>
      )}

      {/* Main Identity, Logo, Colors, Labels & Grading Form */}
      <form onSubmit={handleFormSubmit} className="space-y-6 text-xs">
        {/* School Identity & Logo */}
        <div className="bg-white border border-slate-200 rounded-2xl p-4 sm:p-6 space-y-5 shadow-xs">
          <div className="flex flex-wrap items-center justify-between gap-4 border-b border-slate-100 pb-4">
            <div>
              <h3 className="text-sm font-bold text-slate-900">School Identity &amp; Logo</h3>
              <p className="text-[11px] text-slate-500">Upload, replace, or remove the school emblem</p>
            </div>
            <div className="flex flex-wrap items-center gap-3">
              {schoolLogo ? (
                <SchoolLogo
                  src={schoolLogo}
                  alt={schoolName}
                  allowDefaultWhenEmpty={false}
                  className="w-12 h-12 rounded-xl border border-slate-200 object-contain p-1 bg-white"
                />
              ) : (
                <div className="w-12 h-12 rounded-xl border border-dashed border-slate-300 bg-slate-50 flex items-center justify-center text-[10px] text-slate-400">
                  No Logo
                </div>
              )}
              <label className="min-h-[40px] inline-flex items-center gap-1.5 px-3 py-2 font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg cursor-pointer">
                <Upload className="w-3.5 h-3.5" />
                {schoolLogo ? 'Replace Logo' : 'Upload Logo'}
                <input type="file" accept="image/*" onChange={handleLogoUpload} className="hidden" />
              </label>
              {schoolLogo !== DEFAULT_SCHOOL_LOGO_PATH && (
                <button
                  type="button"
                  onClick={handleResetDefaultLogo}
                  className="min-h-[40px] inline-flex items-center gap-1 px-3 py-2 font-medium text-sky-800 bg-sky-50 border border-sky-200 rounded-lg hover:bg-sky-100 cursor-pointer"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                  Use Default Emblem
                </button>
              )}
              {schoolLogo && (
                <button
                  type="button"
                  onClick={() => setConfirmRemoveLogo(true)}
                  className="min-h-[40px] inline-flex items-center gap-1 px-3 py-2 font-medium text-red-700 bg-red-50 border border-red-200 rounded-lg hover:bg-red-100 cursor-pointer"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                  Remove Logo
                </button>
              )}
            </div>
          </div>

          {logoError && (
            <div className="p-2.5 bg-red-50 border border-red-200 rounded-lg text-red-800">{logoError}</div>
          )}

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block font-semibold text-slate-700 mb-1">School Name</label>
              <input
                type="text"
                value={schoolName}
                onChange={(e) => setSchoolName(e.target.value)}
                className="w-full min-h-[40px] px-3 py-2 border border-slate-300 rounded-lg"
              />
            </div>
            <div>
              <label className="block font-semibold text-slate-700 mb-1">Current Academic Year</label>
              <input
                type="text"
                value={academicYear}
                onChange={(e) => setAcademicYear(e.target.value)}
                className="w-full min-h-[40px] px-3 py-2 border border-slate-300 rounded-lg font-mono"
              />
            </div>
            <div className="sm:col-span-2">
              <label className="block font-semibold text-slate-700 mb-1">School Address</label>
              <input
                type="text"
                value={schoolAddress}
                onChange={(e) => setSchoolAddress(e.target.value)}
                className="w-full min-h-[40px] px-3 py-2 border border-slate-300 rounded-lg"
              />
            </div>
            <div>
              <label className="block font-semibold text-slate-700 mb-1">Motto / Tagline</label>
              <input
                type="text"
                value={schoolMotto}
                onChange={(e) => setSchoolMotto(e.target.value)}
                className="w-full min-h-[40px] px-3 py-2 border border-slate-300 rounded-lg"
              />
            </div>
            <div>
              <label className="block font-semibold text-slate-700 mb-1">Default Passing Percentage (%)</label>
              <input
                type="number"
                min={1}
                max={100}
                value={passPct}
                onChange={(e) => setPassPct(Number(e.target.value))}
                className="w-full min-h-[40px] px-3 py-2 border border-slate-300 rounded-lg font-mono"
              />
            </div>
          </div>
        </div>

        {/* Website Colours & Visual Settings */}
        <div className="bg-white border border-slate-200 rounded-2xl p-4 sm:p-6 space-y-4 shadow-xs">
          <div className="flex items-center justify-between gap-2 border-b border-slate-100 pb-3">
            <div className="flex items-center gap-2">
              <Palette className="w-4 h-4 text-sky-600" />
              <h3 className="text-sm font-bold text-slate-900">Website Branding Colours</h3>
            </div>
            <button
              type="button"
              onClick={() =>
                setThemeConfig({
                  primaryColor: '#1E3A5F',
                  accentColor: '#0284C7',
                  secondaryColor: '#10B981',
                  headerBg: '#FFFFFF',
                })
              }
              className="text-[11px] font-medium text-slate-600 hover:underline cursor-pointer"
            >
              Reset Default Colours
            </button>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <label className="flex items-center justify-between p-3 border border-slate-200 rounded-xl bg-slate-50/70">
              <div>
                <div className="font-semibold text-slate-800">Primary Colour</div>
                <div className="font-mono text-[11px] text-slate-500">{themeConfig.primaryColor}</div>
              </div>
              <input
                type="color"
                value={themeConfig.primaryColor}
                onChange={(e) => setThemeConfig({ ...themeConfig, primaryColor: e.target.value })}
                className="w-9 h-9 rounded cursor-pointer border-0 bg-transparent"
              />
            </label>
            <label className="flex items-center justify-between p-3 border border-slate-200 rounded-xl bg-slate-50/70">
              <div>
                <div className="font-semibold text-slate-800">Accent Colour</div>
                <div className="font-mono text-[11px] text-slate-500">{themeConfig.accentColor}</div>
              </div>
              <input
                type="color"
                value={themeConfig.accentColor}
                onChange={(e) => setThemeConfig({ ...themeConfig, accentColor: e.target.value })}
                className="w-9 h-9 rounded cursor-pointer border-0 bg-transparent"
              />
            </label>
            <label className="flex items-center justify-between p-3 border border-slate-200 rounded-xl bg-slate-50/70">
              <div>
                <div className="font-semibold text-slate-800">Secondary / Success</div>
                <div className="font-mono text-[11px] text-slate-500">{themeConfig.secondaryColor}</div>
              </div>
              <input
                type="color"
                value={themeConfig.secondaryColor}
                onChange={(e) => setThemeConfig({ ...themeConfig, secondaryColor: e.target.value })}
                className="w-9 h-9 rounded cursor-pointer border-0 bg-transparent"
              />
            </label>
          </div>
        </div>

        {/* Website Headings & Labels */}
        <div className="bg-white border border-slate-200 rounded-2xl p-4 sm:p-6 space-y-4 shadow-xs">
          <div className="flex items-center gap-2 border-b border-slate-100 pb-3">
            <Type className="w-4 h-4 text-violet-600" />
            <h3 className="text-sm font-bold text-slate-900">Website Headings &amp; Labels</h3>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            <div>
              <label className="block font-semibold text-slate-700 mb-1">Portal Title</label>
              <input
                type="text"
                value={siteContent.portalTitle}
                onChange={(e) => setSiteContent({ ...siteContent, portalTitle: e.target.value })}
                className="w-full min-h-[40px] px-3 py-2 border border-slate-300 rounded-lg"
              />
            </div>
            <div>
              <label className="block font-semibold text-slate-700 mb-1">Login Heading</label>
              <input
                type="text"
                value={siteContent.loginHeading}
                onChange={(e) => setSiteContent({ ...siteContent, loginHeading: e.target.value })}
                className="w-full min-h-[40px] px-3 py-2 border border-slate-300 rounded-lg"
              />
            </div>
            <div>
              <label className="block font-semibold text-slate-700 mb-1">Login Button Label</label>
              <input
                type="text"
                value={siteContent.loginButtonLabel}
                onChange={(e) => setSiteContent({ ...siteContent, loginButtonLabel: e.target.value })}
                className="w-full min-h-[40px] px-3 py-2 border border-slate-300 rounded-lg"
              />
            </div>
            <div>
              <label className="block font-semibold text-slate-700 mb-1">Report Card Heading</label>
              <input
                type="text"
                value={siteContent.reportCardTitle}
                onChange={(e) => setSiteContent({ ...siteContent, reportCardTitle: e.target.value })}
                className="w-full min-h-[40px] px-3 py-2 border border-slate-300 rounded-lg"
              />
            </div>
            <div>
              <label className="block font-semibold text-slate-700 mb-1">Left Signatory Label</label>
              <input
                type="text"
                value={siteContent.reportCardFooterLeft}
                onChange={(e) => setSiteContent({ ...siteContent, reportCardFooterLeft: e.target.value })}
                className="w-full min-h-[40px] px-3 py-2 border border-slate-300 rounded-lg"
              />
            </div>
            <div>
              <label className="block font-semibold text-slate-700 mb-1">Center Signatory Label</label>
              <input
                type="text"
                value={siteContent.reportCardFooterCenter}
                onChange={(e) => setSiteContent({ ...siteContent, reportCardFooterCenter: e.target.value })}
                className="w-full min-h-[40px] px-3 py-2 border border-slate-300 rounded-lg"
              />
            </div>
            <div>
              <label className="block font-semibold text-slate-700 mb-1">Right Signatory Label</label>
              <input
                type="text"
                value={siteContent.reportCardFooterRight}
                onChange={(e) => setSiteContent({ ...siteContent, reportCardFooterRight: e.target.value })}
                className="w-full min-h-[40px] px-3 py-2 border border-slate-300 rounded-lg"
              />
            </div>
          </div>
        </div>

        {/* Grading Scale */}
        <div className="bg-white border border-slate-200 rounded-2xl p-4 sm:p-6 space-y-3 shadow-xs">
          <div className="font-bold text-sm text-slate-900">Grading Scale Configuration</div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
            {gradingScale.map((rule, idx) => (
              <div key={idx} className="flex flex-wrap sm:flex-nowrap items-center gap-2 p-2 bg-slate-50 border border-slate-200 rounded-lg">
                <input
                  type="text"
                  value={rule.grade}
                  onChange={(e) => {
                    const copy = [...gradingScale];
                    copy[idx] = { ...copy[idx], grade: e.target.value };
                    setGradingScale(copy);
                  }}
                  className="w-14 px-2 py-1.5 border border-slate-300 rounded font-mono font-bold bg-white"
                />
                <span className="text-slate-500">Min %:</span>
                <input
                  type="number"
                  step="0.1"
                  value={rule.minPct}
                  onChange={(e) => {
                    const copy = [...gradingScale];
                    copy[idx] = { ...copy[idx], minPct: Number(e.target.value) };
                    setGradingScale(copy);
                  }}
                  className="w-16 px-2 py-1.5 border border-slate-300 rounded font-mono bg-white"
                />
                <input
                  type="text"
                  value={rule.remark}
                  onChange={(e) => {
                    const copy = [...gradingScale];
                    copy[idx] = { ...copy[idx], remark: e.target.value };
                    setGradingScale(copy);
                  }}
                  className="flex-1 min-w-[120px] px-2 py-1.5 border border-slate-300 rounded bg-white"
                />
              </div>
            ))}
          </div>
          <div className="flex justify-end pt-2">
            <button
              type="submit"
              className="min-h-[42px] inline-flex items-center gap-1.5 px-4 py-2 font-semibold text-white bg-[#1E3A5F] rounded-lg hover:bg-[#162D4A] cursor-pointer"
            >
              <Save className="w-3.5 h-3.5" />
              Save All Branding &amp; Settings
            </button>
          </div>
        </div>
      </form>

      {/* Configurable Portal Sections Manager */}
      <div className="bg-white border border-slate-200 rounded-2xl p-4 sm:p-6 space-y-4 text-xs shadow-xs">
        <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-100 pb-3">
          <div className="flex items-center gap-2">
            <LayoutList className="w-4 h-4 text-emerald-600" />
            <div>
              <h3 className="text-sm font-bold text-slate-900">Portal Sections Management</h3>
              <p className="text-[11px] text-slate-500">
                Enable, disable, rename, reorder, or add custom sections in the portal navigation
              </p>
            </div>
          </div>
          <div className="flex flex-wrap items-center gap-2">
            <button
              type="button"
              onClick={() => {
                setCustomSecForm({ id: '', label: '', description: '', customHeading: '', customBody: '' });
                setCustomSecOpen(true);
              }}
              className="min-h-[38px] inline-flex items-center gap-1 px-3 py-1.5 font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg cursor-pointer"
            >
              <Plus className="w-3.5 h-3.5" />
              Add Custom Section
            </button>
            <button
              type="button"
              onClick={() => handleSaveSettings({ portalSections }, 'Section layout saved.')}
              className="min-h-[38px] inline-flex items-center gap-1.5 px-3.5 py-1.5 font-semibold text-white bg-[#1E3A5F] rounded-lg hover:bg-[#162D4A] cursor-pointer"
            >
              <Save className="w-3.5 h-3.5" />
              Save Section Order
            </button>
          </div>
        </div>

        <div className="space-y-2">
          {portalSections.map((sec, idx) => (
            <div
              key={sec.id}
              className={`flex flex-wrap items-center justify-between gap-3 p-3 rounded-xl border ${
                sec.enabled ? 'bg-white border-slate-200' : 'bg-slate-50 border-slate-200/80 opacity-75'
              }`}
            >
              <div className="flex flex-wrap items-center gap-2.5 min-w-0 flex-1">
                <input
                  type="checkbox"
                  checked={sec.enabled}
                  onChange={() => toggleSection(sec.id)}
                  className="rounded border-slate-300 text-[#1E3A5F] cursor-pointer"
                />
                <input
                  type="text"
                  value={sec.label}
                  onChange={(e) => updateSectionField(sec.id, 'label', e.target.value)}
                  className="px-2.5 py-1.5 border border-slate-300 rounded-lg font-semibold text-slate-900 w-full sm:w-44"
                />
                <input
                  type="text"
                  value={sec.description}
                  onChange={(e) => updateSectionField(sec.id, 'description', e.target.value)}
                  placeholder="Section description"
                  className="px-2.5 py-1.5 border border-slate-200 rounded-lg text-slate-600 flex-1 min-w-[160px]"
                />
                {sec.custom && <span className="text-[11px] font-semibold text-sky-700">Custom</span>}
              </div>

              <div className="flex items-center gap-1.5 shrink-0">
                <button
                  type="button"
                  disabled={idx === 0}
                  onClick={() => moveSection(idx, -1)}
                  className="min-w-[34px] min-h-[34px] inline-flex items-center justify-center p-1.5 border border-slate-200 rounded-lg hover:bg-slate-100 disabled:opacity-30 cursor-pointer"
                  title="Move Up"
                >
                  <ArrowUp className="w-3.5 h-3.5" />
                </button>
                <button
                  type="button"
                  disabled={idx === portalSections.length - 1}
                  onClick={() => moveSection(idx, 1)}
                  className="min-w-[34px] min-h-[34px] inline-flex items-center justify-center p-1.5 border border-slate-200 rounded-lg hover:bg-slate-100 disabled:opacity-30 cursor-pointer"
                  title="Move Down"
                >
                  <ArrowDown className="w-3.5 h-3.5" />
                </button>
                {sec.custom && (
                  <button
                    type="button"
                    onClick={() => {
                      setCustomSecForm({
                        id: sec.id,
                        label: sec.label,
                        description: sec.description,
                        customHeading: sec.customHeading || sec.label,
                        customBody: sec.customBody || '',
                      });
                      setCustomSecOpen(true);
                    }}
                    className="min-h-[34px] px-2.5 py-1 text-[11px] font-medium border border-slate-200 rounded-lg hover:bg-slate-100 cursor-pointer"
                  >
                    Edit Content
                  </button>
                )}
                <button
                  type="button"
                  onClick={() => setConfirmRemoveSection(sec)}
                  className="min-w-[34px] min-h-[34px] inline-flex items-center justify-center p-1.5 text-red-600 border border-red-200 rounded-lg hover:bg-red-50 cursor-pointer"
                  title="Remove Section"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Examination Types Manager */}
      <div className="bg-white border border-slate-200 rounded-2xl p-4 sm:p-6 space-y-4 text-xs shadow-xs">
        <div className="flex items-center gap-2 border-b border-slate-100 pb-3">
          <Tag className="w-4 h-4 text-amber-600" />
          <div>
            <h3 className="text-sm font-bold text-slate-900">Examination Types</h3>
            <p className="text-[11px] text-slate-500">Add or remove examination categories available when scheduling exams</p>
          </div>
        </div>
        <div className="flex flex-wrap gap-2">
          {examinationTypes.map((et) => (
            <span
              key={et}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-slate-100 border border-slate-200 rounded-lg font-medium text-slate-800"
            >
              {et}
              {examinationTypes.length > 1 && (
                <button
                  type="button"
                  onClick={() => handleRemoveExamType(et)}
                  className="text-slate-400 hover:text-red-600 cursor-pointer"
                  title="Remove type"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              )}
            </span>
          ))}
        </div>
        <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2 max-w-sm">
          <input
            type="text"
            value={newExamType}
            onChange={(e) => setNewExamType(e.target.value)}
            placeholder="New examination type (e.g. Monthly Test)"
            className="flex-1 min-h-[40px] px-3 py-2 border border-slate-300 rounded-lg"
          />
          <button
            type="button"
            onClick={handleAddExamType}
            className="min-h-[40px] inline-flex items-center justify-center gap-1 px-3.5 py-2 font-semibold text-white bg-[#1E3A5F] rounded-lg hover:bg-[#162D4A] cursor-pointer"
          >
            <Plus className="w-3.5 h-3.5" />
            Add
          </button>
        </div>
      </div>

      {/* Academic Year History & Rollover */}
      <div className="bg-white border border-slate-200 rounded-2xl p-4 sm:p-6 space-y-5 text-xs shadow-xs">
        <div className="flex flex-col sm:flex-row sm:items-start sm:justify-between gap-3 border-b border-slate-100 pb-4">
          <div className="flex items-start gap-3">
            <CalendarRange className="w-5 h-5 text-[#1E3A5F] mt-0.5 shrink-0" />
            <div>
              <h3 className="text-sm font-bold text-slate-900">Academic Year Archive &amp; Session Rollover</h3>
              <p className="text-xs text-slate-500 mt-0.5">
                Switch active years, archive old sessions, or initialize a new academic year while preserving all prior
                enrollments, exams, and marks.
              </p>
            </div>
          </div>
          <div className="flex flex-wrap items-center gap-2">
            {selectedAcademicYear && (
              <span className="font-mono text-[11px] font-semibold text-slate-700">
                Viewing: {selectedAcademicYear}
              </span>
            )}
            <div className="inline-flex p-1 bg-slate-100 rounded-xl border border-slate-200">
              <button
                type="button"
                onClick={() => setYearViewMode('active')}
                className={`min-h-[34px] px-3 py-1 text-xs font-semibold rounded-lg transition-colors cursor-pointer ${
                  yearViewMode === 'active' ? 'bg-white text-[#1E3A5F] shadow-xs' : 'text-slate-600'
                }`}
              >
                Active Sessions
              </button>
              <button
                type="button"
                onClick={() => setYearViewMode('archived')}
                className={`min-h-[34px] px-3 py-1 text-xs font-semibold rounded-lg transition-colors cursor-pointer ${
                  yearViewMode === 'archived' ? 'bg-white text-[#1E3A5F] shadow-xs' : 'text-slate-600'
                }`}
              >
                Archived
              </button>
            </div>
          </div>
        </div>

        {transitionMessage && (
          <div className="flex items-center gap-2 p-3 rounded-lg bg-emerald-50 border border-emerald-200 text-xs font-medium text-emerald-800">
            <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
            <span>{transitionMessage}</span>
          </div>
        )}
        {transitionError && (
          <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-xs font-medium text-red-800">
            {transitionError}
          </div>
        )}

        {yearUndoState && (
          <UndoBanner
            message={yearUndoState.message}
            onUndo={handleYearUndo}
            onDismiss={() => setYearUndoState(null)}
            busy={yearBulkBusy}
          />
        )}

        {selectedYearNames.length > 0 && (
          <BulkActionToolbar
            selectedCount={selectedYearNames.length}
            entityLabel="academic year"
            onClearSelection={() => setSelectedYearNames([])}
            disabled={yearBulkBusy}
            actions={
              yearViewMode === 'active'
                ? [
                    {
                      id: 'archive-ay',
                      label: 'Archive Selected',
                      icon: 'archive',
                      variant: 'danger',
                      onClick: () =>
                        setYearBulkConfirm({
                          action: 'archive',
                          names: selectedYearNames,
                          items: academicYearRows
                            .filter((ay) => selectedYearNames.includes(ay.name))
                            .map((ay) => ({
                              id: ay.name,
                              label: ay.name,
                              sublabel: `${ay.studentCount} enrolled · ${ay.examCount} exams`,
                            })),
                        }),
                    },
                  ]
                : [
                    {
                      id: 'restore-ay',
                      label: 'Restore Selected',
                      icon: 'restore',
                      variant: 'success',
                      onClick: () =>
                        setYearBulkConfirm({
                          action: 'restore',
                          names: selectedYearNames,
                          items: academicYearRows
                            .filter((ay) => selectedYearNames.includes(ay.name))
                            .map((ay) => ({
                              id: ay.name,
                              label: ay.name,
                              sublabel: `${ay.studentCount} enrolled · ${ay.examCount} exams`,
                            })),
                        }),
                    },
                  ]
            }
          />
        )}

        <div className="border border-slate-200 rounded-xl overflow-hidden">
          {academicYearRows.length === 0 ? (
            <div className="p-6 text-center text-xs text-slate-500">
              {yearViewMode === 'archived'
                ? 'No archived academic years.'
                : 'No academic years configured.'}
            </div>
          ) : (
            <>
              {/* Mobile Cards */}
              <div className="md:hidden divide-y divide-slate-200">
                {selectableYears.length > 0 && (
                  <div className="px-3.5 py-2.5 bg-slate-50 flex items-center justify-between">
                    <label className="inline-flex items-center gap-2 font-medium text-slate-700 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={allYearsSelected}
                        onChange={() =>
                          setSelectedYearNames(allYearsSelected ? [] : selectableYears.map((y) => y.name))
                        }
                        className="rounded border-slate-300"
                      />
                      Select All ({selectableYears.length})
                    </label>
                  </div>
                )}
                {academicYearRows.map((ay) => {
                  const canSelect = yearViewMode === 'archived' || !ay.isCurrent;
                  const checked = selectedYearNames.includes(ay.name);
                  return (
                    <div key={ay.name} className={`p-3.5 space-y-2 ${checked ? 'bg-sky-50/50' : ''}`}>
                      <div className="flex items-center justify-between gap-2">
                        <label className="inline-flex items-center gap-2 font-mono font-bold text-slate-900">
                          {canSelect && (
                            <input
                              type="checkbox"
                              checked={checked}
                              onChange={() =>
                                setSelectedYearNames((prev) =>
                                  prev.includes(ay.name) ? prev.filter((n) => n !== ay.name) : [...prev, ay.name]
                                )
                              }
                              className="rounded border-slate-300"
                            />
                          )}
                          <span>{ay.name}</span>
                        </label>
                        <span
                          className={`text-[11px] font-semibold ${
                            ay.isCurrent ? 'text-emerald-700' : 'text-amber-700'
                          }`}
                        >
                          {ay.isCurrent ? 'Current Active' : ay.isDeleted ? 'Archived' : 'Past Session'}
                        </span>
                      </div>
                      <div className="grid grid-cols-2 gap-1.5 font-mono text-[11px] text-slate-600">
                        <div>Enrolled: {ay.studentCount}</div>
                        <div>Graduated: {ay.graduatedCount ?? 0}</div>
                        <div>Exams: {ay.examCount}</div>
                        <div>Assignments: {ay.assignmentCount}</div>
                      </div>
                      <div className="flex flex-wrap gap-2 pt-1">
                        {yearViewMode === 'active' ? (
                          <>
                            {onSelectAcademicYear && (
                              <button
                                type="button"
                                onClick={() => onSelectAcademicYear(ay.name)}
                                className="min-h-[36px] inline-flex items-center gap-1 px-2.5 py-1 text-[11px] font-medium text-[#1E3A5F] bg-white border border-slate-300 rounded cursor-pointer"
                              >
                                <History className="w-3 h-3" />
                                View Session
                              </button>
                            )}
                            {!ay.isCurrent && (
                              <button
                                type="button"
                                onClick={() => handleActivateYear(ay.name)}
                                className="min-h-[36px] px-2.5 py-1 text-[11px] font-medium text-slate-700 bg-white border border-slate-300 rounded cursor-pointer"
                              >
                                Set Active
                              </button>
                            )}
                          </>
                        ) : (
                          <button
                            type="button"
                            onClick={() => handleQuickRestoreYear(ay.name)}
                            className="min-h-[36px] inline-flex items-center gap-1 px-2.5 py-1 text-[11px] font-semibold text-emerald-800 bg-emerald-50 border border-emerald-200 rounded cursor-pointer"
                          >
                            <RotateCcw className="w-3 h-3" />
                            Restore
                          </button>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>

              {/* Desktop Table */}
              <div className="hidden md:block overflow-x-auto">
                <table className="w-full text-xs">
                  <thead className="bg-slate-50 border-b border-slate-200 text-slate-600">
                    <tr>
                      <th className="w-10 px-3.5 py-2.5 text-center">
                        {selectableYears.length > 0 && (
                          <input
                            type="checkbox"
                            checked={allYearsSelected}
                            onChange={() =>
                              setSelectedYearNames(allYearsSelected ? [] : selectableYears.map((y) => y.name))
                            }
                            aria-label="Select all academic years"
                            className="rounded border-slate-300 cursor-pointer"
                          />
                        )}
                      </th>
                      <th className="text-left font-semibold px-3.5 py-2.5">Academic Year</th>
                      <th className="text-center font-semibold px-3.5 py-2.5">Status</th>
                      <th className="text-right font-semibold px-3.5 py-2.5">Enrolled</th>
                      <th className="text-right font-semibold px-3.5 py-2.5">Graduated</th>
                      <th className="text-right font-semibold px-3.5 py-2.5">Examinations</th>
                      <th className="text-right font-semibold px-3.5 py-2.5">Assignments</th>
                      <th className="text-right font-semibold px-3.5 py-2.5">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-200">
                    {academicYearRows.map((ay) => {
                      const canSelect = yearViewMode === 'archived' || !ay.isCurrent;
                      const checked = selectedYearNames.includes(ay.name);
                      return (
                        <tr key={ay.name} className={`hover:bg-slate-50/70 ${checked ? 'bg-sky-50/50' : ''}`}>
                          <td className="px-3.5 py-2.5 text-center">
                            {canSelect && (
                              <input
                                type="checkbox"
                                checked={checked}
                                onChange={() =>
                                  setSelectedYearNames((prev) =>
                                    prev.includes(ay.name) ? prev.filter((n) => n !== ay.name) : [...prev, ay.name]
                                  )
                                }
                                className="rounded border-slate-300 cursor-pointer"
                              />
                            )}
                          </td>
                          <td className="px-3.5 py-2.5 font-mono font-bold text-slate-900">{ay.name}</td>
                          <td className="px-3.5 py-2.5 text-center">
                            <span
                              className={`text-[11px] font-semibold ${
                                ay.isCurrent ? 'text-emerald-700' : 'text-amber-700'
                              }`}
                            >
                              {ay.isCurrent ? 'Current Active' : ay.isDeleted ? 'Archived' : 'Past Session'}
                            </span>
                          </td>
                          <td className="px-3.5 py-2.5 text-right font-mono tabular-nums text-slate-800">
                            {ay.studentCount}
                          </td>
                          <td className="px-3.5 py-2.5 text-right font-mono tabular-nums text-slate-600">
                            {ay.graduatedCount ?? 0}
                          </td>
                          <td className="px-3.5 py-2.5 text-right font-mono tabular-nums text-slate-800">
                            {ay.examCount}
                          </td>
                          <td className="px-3.5 py-2.5 text-right font-mono tabular-nums text-slate-800">
                            {ay.assignmentCount}
                          </td>
                          <td className="px-3.5 py-2.5 text-right whitespace-nowrap space-x-2">
                            {yearViewMode === 'active' ? (
                              <>
                                {onSelectAcademicYear && (
                                  <button
                                    type="button"
                                    onClick={() => onSelectAcademicYear(ay.name)}
                                    className="inline-flex items-center gap-1 px-2.5 py-1 text-[11px] font-medium text-[#1E3A5F] bg-white border border-slate-300 rounded hover:bg-slate-50 cursor-pointer"
                                  >
                                    <History className="w-3 h-3" />
                                    View Session
                                  </button>
                                )}
                                {!ay.isCurrent && (
                                  <button
                                    type="button"
                                    onClick={() => handleActivateYear(ay.name)}
                                    className="px-2.5 py-1 text-[11px] font-medium text-slate-700 bg-white border border-slate-300 rounded hover:bg-slate-50 cursor-pointer"
                                  >
                                    Set Active
                                  </button>
                                )}
                              </>
                            ) : (
                              <button
                                type="button"
                                onClick={() => handleQuickRestoreYear(ay.name)}
                                className="inline-flex items-center gap-1 px-2.5 py-1 text-[11px] font-semibold text-emerald-800 bg-emerald-50 border border-emerald-200 rounded hover:bg-emerald-100 cursor-pointer"
                              >
                                <RotateCcw className="w-3 h-3" />
                                Restore
                              </button>
                            )}
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </>
          )}
        </div>

        <form
          onSubmit={(e) => {
            e.preventDefault();
            if (!newYearName.trim()) return;
            setConfirmRolloverOpen(true);
          }}
          className="bg-slate-50 border border-slate-200 rounded-xl p-4 space-y-4"
        >
          <div className="font-semibold text-slate-900">Start New Academic Year / Promote Students</div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block font-semibold text-slate-700 mb-1">New Academic Year Name *</label>
              <input
                type="text"
                required
                value={newYearName}
                onChange={(e) => setNewYearName(e.target.value)}
                placeholder="e.g. 2026-27"
                className="w-full min-h-[40px] px-3 py-2 border border-slate-300 rounded-lg font-mono bg-white"
              />
            </div>
            <div>
              <label className="block font-semibold text-slate-700 mb-1">Carry Forward Cohort From</label>
              <select
                value={sourceYear}
                onChange={(e) => setSourceYear(e.target.value)}
                className="w-full min-h-[40px] px-3 py-2 border border-slate-300 rounded-lg font-mono bg-white"
              >
                {activeCohortYears.map((ay) => (
                  <option key={ay.name} value={ay.name}>
                    {ay.name} ({ay.studentCount} active students)
                  </option>
                ))}
              </select>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 pt-1">
            <label className="flex items-start gap-2 text-slate-700">
              <input
                type="checkbox"
                checked={promoteStudents}
                onChange={(e) => setPromoteStudents(e.target.checked)}
                className="mt-0.5 rounded border-slate-300 text-[#1E3A5F]"
              />
              <span>Promote students to next class</span>
            </label>
            <label className="flex items-start gap-2 text-slate-700">
              <input
                type="checkbox"
                checked={copyTeacherAssignments}
                onChange={(e) => setCopyTeacherAssignments(e.target.checked)}
                className="mt-0.5 rounded border-slate-300 text-[#1E3A5F]"
              />
              <span>Carry forward Subject Teacher assignments</span>
            </label>
            <label className="flex items-start gap-2 text-slate-700">
              <input
                type="checkbox"
                checked={copyClassTeachers}
                onChange={(e) => setCopyClassTeachers(e.target.checked)}
                className="mt-0.5 rounded border-slate-300 text-[#1E3A5F]"
              />
              <span>Carry forward Class Teacher assignments</span>
            </label>
            <label className="flex items-start gap-2 text-slate-700">
              <input
                type="checkbox"
                checked={setAsCurrent}
                onChange={(e) => setSetAsCurrent(e.target.checked)}
                className="mt-0.5 rounded border-slate-300 text-[#1E3A5F]"
              />
              <span>Switch active session to {newYearName || 'new academic year'}</span>
            </label>
          </div>

          <div className="flex justify-end">
            <button
              type="submit"
              className="min-h-[42px] inline-flex items-center gap-1.5 px-4 py-2 font-semibold text-white bg-[#1E3A5F] rounded-lg hover:bg-[#162D4A] cursor-pointer"
            >
              <ArrowRightCircle className="w-3.5 h-3.5" />
              Initialize Academic Year {newYearName || ''}
            </button>
          </div>
        </form>
      </div>

      {/* Database Backup Section */}
      <div className="bg-white border border-slate-200 rounded-2xl p-4 sm:p-6 flex flex-wrap items-center justify-between gap-4 shadow-xs">
        <div className="flex items-start gap-3">
          <Database className="w-5 h-5 text-[#1E3A5F] mt-0.5 shrink-0" />
          <div>
            <h3 className="text-sm font-bold text-slate-900">Database Backup &amp; Export</h3>
            <p className="text-xs text-slate-500 mt-0.5">
              Download a full consistent snapshot of all students, examinations, marks, and settings.
            </p>
          </div>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <button
            type="button"
            onClick={() =>
              downloadAuthorizedFile(
                '/api/admin/backup?format=sqlite',
                `emrs-gangyap-backup-${new Date().toISOString().slice(0, 10)}.db`
              )
            }
            className="min-h-[40px] inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-white bg-[#1E3A5F] rounded-lg hover:bg-[#162D4A] cursor-pointer"
          >
            <Download className="w-3.5 h-3.5" />
            Download SQLite Backup (.db)
          </button>
          <button
            type="button"
            onClick={() =>
              downloadAuthorizedFile(
                '/api/admin/backup?format=json',
                `emrs-gangyap-snapshot-${new Date().toISOString().slice(0, 10)}.json`
              )
            }
            className="min-h-[40px] inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-medium text-slate-700 bg-white border border-slate-300 rounded-lg hover:bg-slate-50 cursor-pointer"
          >
            Export JSON Snapshot
          </button>
        </div>
      </div>

      {/* Bulk Academic Year Confirmation Modal */}
      <BulkConfirmModal
        open={Boolean(yearBulkConfirm)}
        title={
          yearBulkConfirm?.action === 'restore'
            ? `Restore ${yearBulkConfirm.names.length} Academic Year(s)?`
            : `Archive ${yearBulkConfirm?.names.length || 0} Academic Year(s)?`
        }
        confirmLabel={yearBulkConfirm?.action === 'restore' ? 'Confirm Restore' : 'Confirm Archive'}
        description={
          yearBulkConfirm?.action === 'restore'
            ? 'Selected academic years will be restored to the active session history list.'
            : 'Selected academic years will be moved to the Archived list.'
        }
        safetyNote="All historical student enrollments, examinations, and marks linked to these academic years remain strictly preserved."
        items={yearBulkConfirm?.items || []}
        variant={yearBulkConfirm?.action === 'restore' ? 'primary' : 'danger'}
        busy={yearBulkBusy}
        onCancel={() => setYearBulkConfirm(null)}
        onConfirm={handleYearBulkConfirm}
      />

      {/* Add / Edit Custom Section Modal */}
      {customSecOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/50 p-4">
          <form
            onSubmit={handleSaveCustomSection}
            className="bg-white border border-slate-200 rounded-2xl w-full max-w-md max-h-[90vh] overflow-y-auto p-6 space-y-4 shadow-xl text-xs"
          >
            <div className="flex items-center justify-between">
              <h3 className="text-base font-bold text-slate-900">
                {customSecForm.id ? 'Edit Custom Section' : 'Add Custom Section'}
              </h3>
              <button type="button" onClick={() => setCustomSecOpen(false)} className="text-slate-400 hover:text-slate-700 p-1 cursor-pointer">
                <X className="w-4 h-4" />
              </button>
            </div>
            <div>
              <label className="block font-semibold text-slate-700 mb-1">Navigation Label *</label>
              <input
                type="text"
                required
                value={customSecForm.label}
                onChange={(e) => setCustomSecForm({ ...customSecForm, label: e.target.value })}
                placeholder="e.g. Exam Guidelines"
                className="w-full min-h-[40px] px-3 py-2 border border-slate-300 rounded-lg"
              />
            </div>
            <div>
              <label className="block font-semibold text-slate-700 mb-1">Page Heading</label>
              <input
                type="text"
                value={customSecForm.customHeading}
                onChange={(e) => setCustomSecForm({ ...customSecForm, customHeading: e.target.value })}
                placeholder="Heading shown on section page"
                className="w-full min-h-[40px] px-3 py-2 border border-slate-300 rounded-lg"
              />
            </div>
            <div>
              <label className="block font-semibold text-slate-700 mb-1">Short Description</label>
              <input
                type="text"
                value={customSecForm.description}
                onChange={(e) => setCustomSecForm({ ...customSecForm, description: e.target.value })}
                className="w-full min-h-[40px] px-3 py-2 border border-slate-300 rounded-lg"
              />
            </div>
            <div>
              <label className="block font-semibold text-slate-700 mb-1">Section Content</label>
              <textarea
                rows={4}
                value={customSecForm.customBody}
                onChange={(e) => setCustomSecForm({ ...customSecForm, customBody: e.target.value })}
                placeholder="Enter notices, schedules, or guidelines..."
                className="w-full px-3 py-2 border border-slate-300 rounded-lg"
              />
            </div>
            <div className="flex flex-col-reverse sm:flex-row sm:justify-end gap-2">
              <button
                type="button"
                onClick={() => setCustomSecOpen(false)}
                className="min-h-[40px] px-3.5 py-2 border border-slate-300 rounded-lg cursor-pointer"
              >
                Cancel
              </button>
              <button type="submit" className="min-h-[40px] px-4 py-2 font-semibold text-white bg-[#1E3A5F] rounded-lg cursor-pointer">
                Save Section
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Confirm Remove Logo Modal */}
      {confirmRemoveLogo && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/50 p-4">
          <div className="bg-white border border-slate-200 rounded-2xl w-full max-w-sm p-6 space-y-4 shadow-xl text-xs">
            <h3 className="text-base font-bold text-slate-900">Remove School Logo?</h3>
            <p className="text-slate-600">
              This will remove the school emblem from the portal sidebar and printed report cards until you upload a new logo.
            </p>
            <div className="flex flex-col-reverse sm:flex-row sm:justify-end gap-2">
              <button
                type="button"
                onClick={() => setConfirmRemoveLogo(false)}
                className="min-h-[40px] px-3.5 py-2 border border-slate-300 rounded-lg cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleConfirmRemoveLogo}
                className="min-h-[40px] px-4 py-2 font-semibold text-white bg-red-600 rounded-lg hover:bg-red-700 cursor-pointer"
              >
                Remove Logo
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Confirm Remove Portal Section Modal */}
      {confirmRemoveSection && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/50 p-4">
          <div className="bg-white border border-slate-200 rounded-2xl w-full max-w-sm p-6 space-y-4 shadow-xl text-xs">
            <h3 className="text-base font-bold text-slate-900">Remove Section &ldquo;{confirmRemoveSection.label}&rdquo;?</h3>
            <p className="text-slate-600">
              Are you sure you want to remove this section from navigation? You can also disable it instead if you want to keep it for later.
            </p>
            <div className="flex flex-col-reverse sm:flex-row sm:justify-end gap-2">
              <button
                type="button"
                onClick={() => setConfirmRemoveSection(null)}
                className="min-h-[40px] px-3.5 py-2 border border-slate-300 rounded-lg cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleDeleteSection}
                className="min-h-[40px] px-4 py-2 font-semibold text-white bg-red-600 rounded-lg hover:bg-red-700 cursor-pointer"
              >
                Confirm Remove
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Confirm Rollover Modal */}
      {confirmRolloverOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/50 p-4">
          <div className="bg-white border border-slate-200 rounded-2xl w-full max-w-md p-6 space-y-4 shadow-xl text-xs">
            <h3 className="text-base font-bold text-slate-900">
              Confirm Academic Year Transition ({newYearName})
            </h3>
            <p className="text-slate-600 leading-relaxed">
              This will initialize <span className="font-mono font-semibold text-slate-900">{newYearName}</span> from{' '}
              <span className="font-mono font-semibold text-slate-900">{sourceYear}</span> while keeping all historical records intact.
            </p>
            <div className="flex flex-col-reverse sm:flex-row sm:justify-end gap-2 pt-1">
              <button
                type="button"
                disabled={transitioning}
                onClick={() => setConfirmRolloverOpen(false)}
                className="min-h-[40px] px-3.5 py-2 border border-slate-300 rounded-lg hover:bg-slate-50 cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="button"
                disabled={transitioning}
                onClick={handleExecuteRollover}
                className="min-h-[40px] px-4 py-2 font-semibold text-white bg-[#1E3A5F] rounded-lg hover:bg-[#162D4A] disabled:opacity-50 cursor-pointer"
              >
                {transitioning ? 'Initializing...' : 'Confirm & Initialize'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
