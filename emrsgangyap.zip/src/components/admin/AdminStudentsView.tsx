import React, { useEffect, useMemo, useRef, useState } from 'react';
import {
  Archive,
  FileDown,
  Plus,
  Search,
  ArrowRightLeft,
  Pencil,
  Trash2,
  X,
  GraduationCap,
  CheckCircle2,
  Users,
  RotateCcw,
  RefreshCw,
} from 'lucide-react';
import type {
  BulkActionResponse,
  CombinedTermClassReport,
  ConsolidatedClassReport,
  ExaminationRecord,
  SchoolInfo,
  StudentRecord,
  StudentStream,
  SubjectRecord,
} from '../../types';
import { apiFetch, extractErrorMessage, isAbortError } from '../../lib/api';
import { doesSubjectApplyToClass, formatClassSectionLabel } from '../../lib/grading';
import {
  exportClassAllFinalMarksheetsPDF,
  exportCombinedReportCardPDF,
  exportIndividualReportCardPDF,
  type BatchFinalMarksheetEntry,
} from '../../lib/exports';
import {
  BulkActionToolbar,
  BulkConfirmModal,
  PaginationBar,
  UndoBanner,
  usePagination,
} from '../BulkActions';
import { ClassWisePromotionPanel } from '../ClassWisePromotionPanel';
import { StudentPhotoField } from '../StudentPhotoField';

export function AdminStudentsView({
  schoolInfo,
  examinations = [],
  selectedAcademicYear,
  onChanged,
}: {
  schoolInfo: SchoolInfo;
  examinations?: ExaminationRecord[];
  selectedAcademicYear: string;
  onChanged: () => Promise<void> | void;
}) {
  const [viewMode, setViewMode] = useState<'directory' | 'promotion'>('directory');
  const [directoryView, setDirectoryView] = useState<'active' | 'archived'>('active');
  const [yearFilter, setYearFilter] = useState<string>(selectedAcademicYear);
  const [students, setStudents] = useState<StudentRecord[]>([]);
  const [allSubjects, setAllSubjects] = useState<SubjectRecord[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [saving, setSaving] = useState(false);
  const [reloadTick, setReloadTick] = useState(0);
  const [filterClassId, setFilterClassId] = useState<string>('');
  const [filterSectionId, setFilterSectionId] = useState<string>('');
  const [filterStatus, setFilterStatus] = useState<string>('');
  const [filterStream, setFilterStream] = useState<string>('');
  const [sortBy, setSortBy] = useState<'roll' | 'name_asc' | 'name_desc' | 'code_asc' | 'code_desc'>('roll');
  const [search, setSearch] = useState('');
  const [debouncedSearch, setDebouncedSearch] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [modalError, setModalError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);
  const requestSeqRef = useRef(0);
  const abortControllerRef = useRef<AbortController | null>(null);
  const rollLookupSeqRef = useRef(0);
  const nextLoadBackgroundRef = useRef(false);

  // Bulk Selection & Undo
  const [selectedIds, setSelectedIds] = useState<Set<number>>(new Set());
  const [bulkBusy, setBulkBusy] = useState(false);
  const [bulkConfirm, setBulkConfirm] = useState<{
    action: 'delete' | 'archive' | 'permanent_delete' | 'restore' | 'activate' | 'deactivate';
    ids: number[];
    title: string;
    description: string;
    confirmLabel: string;
    variant: 'danger' | 'warning' | 'primary';
  } | null>(null);
  const [bulkEditOpen, setBulkEditOpen] = useState(false);
  const [bulkEditForm, setBulkEditForm] = useState<{
    classId: string;
    sectionId: string;
    status: string;
    stream: '__KEEP__' | StudentStream;
  }>({
    classId: '',
    sectionId: '',
    status: '',
    stream: '__KEEP__',
  });
  const [undoState, setUndoState] = useState<{ ids: number[]; message: string } | null>(null);

  const [formOpen, setFormOpen] = useState(false);
  const [editingStudent, setEditingStudent] = useState<StudentRecord | null>(null);
  const [transferStudent, setTransferStudent] = useState<StudentRecord | null>(null);
  const [electiveSelections, setElectiveSelections] = useState<Record<number, number>>({});
  const [enrolledSubjectIds, setEnrolledSubjectIds] = useState<number[]>([]);
  const [batchPdfClassId, setBatchPdfClassId] = useState<string>(() =>
    schoolInfo.classes[0]?.id ? String(schoolInfo.classes[0].id) : ''
  );
  const [batchPdfBusy, setBatchPdfBusy] = useState(false);
  const [studentPdfBusyId, setStudentPdfBusyId] = useState<number | null>(null);

  const [formData, setFormData] = useState({
    studentCode: '',
    fullName: '',
    rollNumber: 1,
    classId: schoolInfo.classes[0]?.id || 1,
    sectionId: schoolInfo.classes[0]?.sections[0]?.id || 1,
    academicYear: selectedAcademicYear,
    gender: 'Male',
    guardianName: '',
    guardianPhone: '',
    fatherName: '',
    motherName: '',
    residentialAddress: '',
    contactNo: '',
    aapaarId: '',
    photoUrl: '',
    status: 'active',
    stream: '' as StudentStream,
  });

  const [transferData, setTransferData] = useState({
    targetClassId: schoolInfo.classes[0]?.id || 1,
    targetSectionId: schoolInfo.classes[0]?.sections[0]?.id || 1,
    newRollNumber: '',
  });

  useEffect(() => {
    setYearFilter(selectedAcademicYear);
  }, [selectedAcademicYear]);

  useEffect(() => {
    if (!search.trim()) {
      setDebouncedSearch('');
      return;
    }
    const timer = window.setTimeout(() => setDebouncedSearch(search), 200);
    return () => window.clearTimeout(timer);
  }, [search]);

  const loadStudents = async (overrides?: {
    year?: string;
    view?: 'active' | 'archived';
    classId?: string;
    sectionId?: string;
    status?: string;
    stream?: string;
    search?: string;
    sortBy?: typeof sortBy;
    background?: boolean;
  }) => {
    abortControllerRef.current?.abort();
    const controller = new AbortController();
    abortControllerRef.current = controller;
    const seq = ++requestSeqRef.current;

    if (overrides?.background) {
      setRefreshing(true);
    } else {
      setLoading(true);
    }
    setError(null);
    try {
      const effectiveYear = overrides?.year !== undefined ? overrides.year : yearFilter;
      const effectiveView = overrides?.view !== undefined ? overrides.view : directoryView;
      const effectiveClass = overrides?.classId !== undefined ? overrides.classId : filterClassId;
      const effectiveSection = overrides?.sectionId !== undefined ? overrides.sectionId : filterSectionId;
      const effectiveStatus = overrides?.status !== undefined ? overrides.status : filterStatus;
      const effectiveStream = overrides?.stream !== undefined ? overrides.stream : filterStream;
      const effectiveSearch = overrides?.search !== undefined ? overrides.search : debouncedSearch;
      const effectiveSort = overrides?.sortBy !== undefined ? overrides.sortBy : sortBy;

      const qs = new URLSearchParams();
      qs.set('academicYear', effectiveYear || 'all');
      qs.set('view', effectiveView);
      qs.set('sortBy', effectiveSort);
      if (effectiveClass) qs.set('classId', effectiveClass);
      if (effectiveSection) qs.set('sectionId', effectiveSection);
      if (effectiveStatus) qs.set('status', effectiveStatus);
      if (effectiveStream) qs.set('stream', effectiveStream);
      if (effectiveSearch.trim()) qs.set('search', effectiveSearch.trim());

      const rows = await apiFetch<StudentRecord[]>(`/api/admin/students?${qs.toString()}`, {
        signal: controller.signal,
      });
      if (seq !== requestSeqRef.current) return;
      setStudents(rows);
      setSelectedIds((prev) => {
        const valid = new Set(rows.map((r) => r.id));
        const next = new Set<number>();
        prev.forEach((id) => {
          if (valid.has(id)) next.add(id);
        });
        return next;
      });
    } catch (err: unknown) {
      if (isAbortError(err) || seq !== requestSeqRef.current) return;
      setError(extractErrorMessage(err, 'Failed to load student records.'));
    } finally {
      if (seq === requestSeqRef.current) {
        setLoading(false);
        setRefreshing(false);
      }
    }
  };

  useEffect(() => {
    const background = nextLoadBackgroundRef.current;
    nextLoadBackgroundRef.current = false;
    loadStudents({ background });
    return () => {
      abortControllerRef.current?.abort();
    };
  }, [filterClassId, filterSectionId, filterStatus, filterStream, sortBy, debouncedSearch, yearFilter, directoryView, reloadTick]);

  useEffect(() => {
    apiFetch<SubjectRecord[]>('/api/admin/subjects')
      .then((subs) => setAllSubjects(subs))
      .catch(() => {});
  }, [schoolInfo]);

  const electiveSubjects = useMemo(
    () => allSubjects.filter((s) => s.componentMode === 'elective'),
    [allSubjects]
  );

  const formApplicableSubjects = useMemo(
    () => allSubjects.filter((s) => doesSubjectApplyToClass(s.applicableClassIds, Number(formData.classId))),
    [allSubjects, formData.classId]
  );

  const formElectiveSubjects = useMemo(
    () => electiveSubjects.filter((s) => doesSubjectApplyToClass(s.applicableClassIds, Number(formData.classId))),
    [electiveSubjects, formData.classId]
  );

  const { page, setPage, pageSize, setPageSize, pagedItems } = usePagination(students, 25);

  const filterClassObj = schoolInfo.classes.find((c) => String(c.id) === filterClassId);
  const formClassObj = schoolInfo.classes.find((c) => c.id === Number(formData.classId));
  const transferClassObj = schoolInfo.classes.find((c) => c.id === Number(transferData.targetClassId));
  const bulkEditClassObj = schoolInfo.classes.find((c) => String(c.id) === bulkEditForm.classId);

  const otherPopulatedYears = useMemo(
    () =>
      (schoolInfo.academicYears || []).filter(
        (ay) => ay.name !== yearFilter && ay.studentCount > 0
      ),
    [schoolInfo.academicYears, yearFilter]
  );

  const hasActiveFilters = Boolean(filterClassId || filterSectionId || filterStatus || filterStream || search.trim());

  const clearFilters = () => {
    setSearch('');
    setFilterClassId('');
    setFilterSectionId('');
    setFilterStatus('');
    setFilterStream('');
  };

  const allPageSelected =
    pagedItems.length > 0 && pagedItems.every((st) => selectedIds.has(st.id));

  const toggleSelectPage = () => {
    setSelectedIds((prev) => {
      const next = new Set(prev);
      if (allPageSelected) {
        pagedItems.forEach((st) => next.delete(st.id));
      } else {
        pagedItems.forEach((st) => next.add(st.id));
      }
      return next;
    });
  };

  const toggleSelectRow = (id: number) => {
    setSelectedIds((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  };

  const openBulkConfirm = (
    action: 'delete' | 'archive' | 'permanent_delete' | 'restore' | 'activate' | 'deactivate',
    ids: number[]
  ) => {
    if (ids.length === 0) return;
    const cfg = {
      delete: {
        title: `Archive ${ids.length} Student(s)`,
        description:
          'Selected students will be moved to the Archived Students tab while keeping all historical exam marks intact.',
        confirmLabel: 'Confirm Archive',
        variant: 'warning' as const,
      },
      archive: {
        title: `Archive ${ids.length} Student(s)`,
        description: 'Selected students will be archived from active rosters.',
        confirmLabel: 'Archive Selected',
        variant: 'warning' as const,
      },
      permanent_delete: {
        title: `Permanently Delete ${ids.length} Student(s) from Database`,
        description:
          'This action cannot be undone. Selected student record(s), enrollments, electives, and all linked examination & IA marks will be permanently removed from the portal and database.',
        confirmLabel: 'Permanently Delete Forever',
        variant: 'danger' as const,
      },
      restore: {
        title: `Restore ${ids.length} Student(s)`,
        description: 'Selected archived students will be restored to their active rosters.',
        confirmLabel: 'Restore Selected',
        variant: 'primary' as const,
      },
      activate: {
        title: `Activate ${ids.length} Student(s)`,
        description: 'Selected students will be set to Active status.',
        confirmLabel: 'Activate Selected',
        variant: 'primary' as const,
      },
      deactivate: {
        title: `Deactivate ${ids.length} Student(s)`,
        description: 'Selected students will be marked Inactive without removing any marks history.',
        confirmLabel: 'Deactivate Selected',
        variant: 'warning' as const,
      },
    }[action];
    setBulkConfirm({ action, ids, ...cfg });
  };

  const sortStudentsList = (list: StudentRecord[]) => {
    const classOrder = new Map(schoolInfo.classes.map((c) => [c.id, c.numeric_order]));
    return [...list].sort((a, b) => {
      if (sortBy === 'name_asc') {
        const cmp = a.full_name.localeCompare(b.full_name, undefined, { sensitivity: 'base' });
        if (cmp !== 0) return cmp;
      } else if (sortBy === 'name_desc') {
        const cmp = b.full_name.localeCompare(a.full_name, undefined, { sensitivity: 'base' });
        if (cmp !== 0) return cmp;
      } else if (sortBy === 'code_asc') {
        return a.student_code.localeCompare(b.student_code, undefined, { sensitivity: 'base' });
      } else if (sortBy === 'code_desc') {
        return b.student_code.localeCompare(a.student_code, undefined, { sensitivity: 'base' });
      }
      const orderDiff = (classOrder.get(a.class_id) ?? 999) - (classOrder.get(b.class_id) ?? 999);
      if (orderDiff !== 0) return orderDiff;
      const secCmp = String(a.section_name || '').localeCompare(String(b.section_name || ''));
      if (secCmp !== 0) return secCmp;
      const rollDiff = Number(a.roll_number || 0) - Number(b.roll_number || 0);
      if (rollDiff !== 0) return rollDiff;
      return String(a.student_code || '').localeCompare(String(b.student_code || ''));
    });
  };

  const upsertStudentLocally = (record: StudentRecord) => {
    setStudents((prev) => {
      const idx = prev.findIndex((s) => s.id === record.id);
      const next = idx >= 0 ? prev.map((s) => (s.id === record.id ? record : s)) : [...prev, record];
      return sortStudentsList(next);
    });
  };

  const triggerBackgroundReload = () => {
    nextLoadBackgroundRef.current = true;
    setReloadTick((t) => t + 1);
  };

  const executeBulkAction = async () => {
    if (!bulkConfirm) return;
    setBulkBusy(true);
    setError(null);
    setNotice(null);
    try {
      const effectiveYear =
        yearFilter && yearFilter !== 'all' ? yearFilter : schoolInfo.currentAcademicYear;
      const action = bulkConfirm.action;
      const targetIds = bulkConfirm.ids;
      const res = await apiFetch<BulkActionResponse>('/api/admin/students/bulk-action', {
        method: 'POST',
        body: JSON.stringify({
          action,
          ids: targetIds,
          academicYear: effectiveYear,
        }),
      });
      const count = res.affectedCount ?? targetIds.length;
      if (action === 'permanent_delete') {
        setUndoState(null);
        setNotice(`Permanently deleted ${count} student record(s) from portal & database.`);
      } else if (action === 'delete' || action === 'archive') {
        setUndoState({
          ids: targetIds,
          message: `Archived ${count} student(s). All historical exam marks, attendance & enrollment history preserved.`,
        });
      } else {
        setNotice(`Updated ${count} student record(s) (${action}).`);
      }

      const idSet = new Set(targetIds);
      if (
        action === 'permanent_delete' ||
        action === 'delete' ||
        action === 'archive' ||
        action === 'restore'
      ) {
        setStudents((prev) => prev.filter((s) => !idSet.has(s.id)));
      } else if (action === 'activate' || action === 'deactivate') {
        const nextStatus = action === 'activate' ? 'active' : 'inactive';
        setStudents((prev) =>
          prev.map((s) => (idSet.has(s.id) ? { ...s, status: nextStatus } : s))
        );
      }

      setBulkConfirm(null);
      setSelectedIds(new Set());
      triggerBackgroundReload();
      void onChanged();
    } catch (err: unknown) {
      setError(extractErrorMessage(err, 'Bulk student operation failed.'));
      setBulkConfirm(null);
    } finally {
      setBulkBusy(false);
    }
  };

  const handleBulkEditSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (selectedIds.size === 0) return;
    if (!bulkEditForm.classId && !bulkEditForm.status && bulkEditForm.stream === '__KEEP__') {
      setModalError('Select a new class/section, stream, or status to apply.');
      return;
    }
    setBulkBusy(true);
    setModalError(null);
    setError(null);
    setNotice(null);
    try {
      const effectiveYear =
        yearFilter && yearFilter !== 'all' ? yearFilter : schoolInfo.currentAcademicYear;
      const updates: { classId?: number; sectionId?: number; status?: string; stream?: StudentStream } = {};
      if (bulkEditForm.classId) {
        updates.classId = Number(bulkEditForm.classId);
        if (bulkEditForm.sectionId) updates.sectionId = Number(bulkEditForm.sectionId);
      }
      if (bulkEditForm.status) updates.status = bulkEditForm.status;
      if (bulkEditForm.stream !== '__KEEP__') updates.stream = bulkEditForm.stream;

      const targetIds = Array.from(selectedIds);
      const res = await apiFetch<BulkActionResponse>('/api/admin/students/bulk-action', {
        method: 'POST',
        body: JSON.stringify({
          action: 'update',
          ids: targetIds,
          academicYear: effectiveYear,
          updates,
        }),
      });

      const idSet = new Set(targetIds);
      const nextCls = updates.classId
        ? schoolInfo.classes.find((c) => c.id === updates.classId)
        : undefined;
      const nextSec =
        nextCls && updates.sectionId
          ? nextCls.sections.find((sec) => sec.id === updates.sectionId)
          : nextCls?.sections[0];
      setStudents((prev) =>
        sortStudentsList(
          prev.map((s) => {
            if (!idSet.has(s.id)) return s;
            return {
              ...s,
              class_id: nextCls ? nextCls.id : s.class_id,
              class_name: nextCls ? nextCls.name : s.class_name,
              hasSections: nextCls ? nextCls.hasSections : s.hasSections,
              section_id: nextSec ? nextSec.id : s.section_id,
              section_name: nextSec ? nextSec.name : s.section_name,
              status: (updates.status as StudentRecord['status']) || s.status,
              stream: updates.stream !== undefined ? updates.stream : s.stream,
            };
          })
        )
      );

      setBulkEditOpen(false);
      setBulkEditForm({ classId: '', sectionId: '', status: '', stream: '__KEEP__' });
      setNotice(`Updated ${res.affectedCount ?? selectedIds.size} student record(s).`);
      setSelectedIds(new Set());
      triggerBackgroundReload();
      void onChanged();
    } catch (err: unknown) {
      setModalError(extractErrorMessage(err, 'Bulk student edit failed.'));
    } finally {
      setBulkBusy(false);
    }
  };

  const handleUndoRestore = async () => {
    if (!undoState) return;
    setBulkBusy(true);
    setError(null);
    try {
      await apiFetch('/api/admin/students/bulk-action', {
        method: 'POST',
        body: JSON.stringify({ action: 'restore', ids: undoState.ids }),
      });
      setNotice(`Restored ${undoState.ids.length} student(s) to active rosters.`);
      setUndoState(null);
      triggerBackgroundReload();
      void onChanged();
    } catch (err: unknown) {
      setError(extractErrorMessage(err, 'Failed to restore archived students.'));
    } finally {
      setBulkBusy(false);
    }
  };

  const handleExportCsv = () => {
    const selectedRows =
      selectedIds.size > 0 ? students.filter((s) => selectedIds.has(s.id)) : students;
    const headers = [
      'Student ID',
      'Roll Number',
      'Full Name',
      'Class',
      'Section',
      'Stream',
      'Academic Year',
      'Status',
      'Gender',
      "Father's Name",
      "Mother's Name",
      'Contact No.',
      'AAPAAR ID',
      'Residential Address',
      'Guardian Name',
      'Guardian Phone',
    ];
    const esc = (v: string | number) => `"${String(v ?? '').replace(/"/g, '""')}"`;
    const csv = [
      headers.map(esc).join(','),
      ...selectedRows.map((s) =>
        [
          s.student_code,
          s.roll_number,
          s.full_name,
          s.class_name,
          s.hasSections === false ? 'No Sections' : s.section_name,
          s.stream || 'General',
          s.academic_year,
          s.isDeleted ? 'archived' : s.status,
          s.gender || '',
          s.father_name || '',
          s.mother_name || '',
          s.contact_no || s.guardian_phone || '',
          s.aapaar_id || '',
          s.residential_address || '',
          s.guardian_name || '',
          s.guardian_phone || '',
        ]
          .map(esc)
          .join(',')
      ),
    ].join('\n');
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `students-${yearFilter || 'all'}-${new Date().toISOString().slice(0, 10)}.csv`;
    document.body.appendChild(link);
    link.click();
    link.remove();
    URL.revokeObjectURL(url);
  };

  const computeNextRollNumber = async (
    targetClassId: number,
    targetSectionId: number,
    targetYear: string
  ) => {
    const seq = ++rollLookupSeqRef.current;
    const localMax = students
      .filter(
        (s) =>
          !s.isDeleted &&
          s.status === 'active' &&
          s.class_id === targetClassId &&
          s.section_id === targetSectionId &&
          s.academic_year === targetYear
      )
      .reduce((m, s) => Math.max(m, Number(s.roll_number) || 0), 0);

    try {
      const qs = new URLSearchParams({
        academicYear: targetYear,
        classId: String(targetClassId),
        sectionId: String(targetSectionId),
        view: 'active',
        status: 'active',
      });
      const sectionRows = await apiFetch<StudentRecord[]>(`/api/admin/students?${qs.toString()}`);
      if (seq !== rollLookupSeqRef.current) return;
      const serverMax = sectionRows.reduce((m, s) => Math.max(m, Number(s.roll_number) || 0), 0);
      const nextRoll = Math.max(localMax, serverMax) + 1;
      setFormData((prev) =>
        prev.classId === targetClassId &&
        prev.sectionId === targetSectionId &&
        prev.academicYear === targetYear
          ? { ...prev, rollNumber: nextRoll }
          : prev
      );
    } catch {
      if (seq !== rollLookupSeqRef.current) return;
      if (localMax > 0) {
        setFormData((prev) => ({ ...prev, rollNumber: localMax + 1 }));
      }
    }
  };

  const openAdd = () => {
    setEditingStudent(null);
    const defaultClassId = filterClassId
      ? Number(filterClassId)
      : schoolInfo.classes[0]?.id || 1;
    const defaultClass =
      schoolInfo.classes.find((c) => c.id === defaultClassId) || schoolInfo.classes[0];
    const defaultSectionId = filterSectionId
      ? Number(filterSectionId)
      : defaultClass?.sections[0]?.id || 1;
    const targetYear =
      yearFilter && yearFilter !== 'all' ? yearFilter : schoolInfo.currentAcademicYear;
    const initialLocalMax = students
      .filter(
        (s) =>
          !s.isDeleted &&
          s.status === 'active' &&
          s.class_id === (defaultClass?.id || 1) &&
          s.section_id === defaultSectionId &&
          s.academic_year === targetYear
      )
      .reduce((m, s) => Math.max(m, Number(s.roll_number) || 0), 0);

    setFormData({
      studentCode: '',
      fullName: '',
      rollNumber: initialLocalMax + 1,
      classId: defaultClass?.id || 1,
      sectionId: defaultSectionId,
      academicYear: targetYear,
      gender: 'Male',
      guardianName: '',
      guardianPhone: '',
      fatherName: '',
      motherName: '',
      residentialAddress: '',
      contactNo: '',
      aapaarId: '',
      photoUrl: '',
      status: 'active',
      stream: filterStream === 'Science' || filterStream === 'Humanities' ? filterStream : '',
    });
    const initElectives: Record<number, number> = {};
    for (const es of electiveSubjects) {
      if (es.components[0]?.id) initElectives[es.id] = es.components[0].id;
    }
    setElectiveSelections(initElectives);
    setEnrolledSubjectIds([]);
    setModalError(null);
    setError(null);
    setFormOpen(true);
    void computeNextRollNumber(defaultClass?.id || 1, defaultSectionId, targetYear);
  };

  const openEdit = (st: StudentRecord) => {
    setEditingStudent(st);
    setFormData({
      studentCode: st.student_code,
      fullName: st.full_name,
      rollNumber: st.roll_number,
      classId: st.class_id,
      sectionId: st.section_id,
      academicYear: st.academic_year,
      gender: st.gender || 'Male',
      guardianName: st.guardian_name || '',
      guardianPhone: st.guardian_phone || '',
      fatherName: st.father_name || '',
      motherName: st.mother_name || '',
      residentialAddress: st.residential_address || '',
      contactNo: st.contact_no || st.guardian_phone || '',
      aapaarId: st.aapaar_id || '',
      photoUrl: st.photo_url || '',
      status: st.status || 'active',
      stream: st.stream || '',
    });
    const optOutSet = new Set(st.electiveOptOutSubjectIds || []);
    const initElectives: Record<number, number> = {};
    for (const es of electiveSubjects) {
      if (optOutSet.has(es.id)) {
        initElectives[es.id] = -1;
      } else {
        const existing = st.electives?.find((e) => e.subjectId === es.id);
        if (existing) initElectives[es.id] = existing.componentId;
        else if (es.components[0]?.id) initElectives[es.id] = es.components[0].id;
      }
    }
    setElectiveSelections(initElectives);
    setEnrolledSubjectIds(st.enrolledSubjectIds ? [...st.enrolledSubjectIds] : []);
    setModalError(null);
    setError(null);
    setFormOpen(true);
  };

  const openTransfer = (st: StudentRecord) => {
    setTransferStudent(st);
    setTransferData({
      targetClassId: st.class_id,
      targetSectionId: st.section_id,
      newRollNumber: '',
    });
    setModalError(null);
    setError(null);
  };

  const handleSaveStudent = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    setModalError(null);
    setError(null);
    setNotice(null);
    const applicableElectiveIds = new Set(formElectiveSubjects.map((es) => es.id));
    const optOutIds: number[] = [];
    const electivesPayload: Array<{ subjectId: number; componentId: number }> = [];
    for (const [subIdStr, compIdRaw] of Object.entries(electiveSelections)) {
      const subjectId = Number(subIdStr);
      const componentId = Number(compIdRaw);
      if (!applicableElectiveIds.has(subjectId)) continue;
      if (componentId === -1) {
        optOutIds.push(subjectId);
      } else if (componentId > 0) {
        electivesPayload.push({ subjectId, componentId });
      }
    }
    const applicableIds = new Set(formApplicableSubjects.map((s) => s.id));
    const cleanEnrolledIds = enrolledSubjectIds.filter((id) => applicableIds.has(id) && !optOutIds.includes(id));

    try {
      if (editingStudent) {
        const res = await apiFetch<{
          success: boolean;
          academicYear?: string;
          student?: StudentRecord;
        }>(`/api/admin/students/${editingStudent.id}`, {
          method: 'PUT',
          body: JSON.stringify({
            ...formData,
            electives: electivesPayload,
            electiveOptOutSubjectIds: optOutIds,
            enrolledSubjectIds: cleanEnrolledIds,
          }),
        });
        const savedYear = res?.academicYear || formData.academicYear;
        if (res.student) {
          upsertStudentLocally(res.student);
        }
        setFormOpen(false);
        setNotice(`Saved changes for ${formData.fullName}.`);
        if (yearFilter !== 'all' && yearFilter !== savedYear) {
          setYearFilter(savedYear);
        }
        triggerBackgroundReload();
        void onChanged();
      } else {
        const res = await apiFetch<{
          id: number;
          studentCode: string;
          academicYear?: string;
          student?: StudentRecord;
        }>('/api/admin/students', {
          method: 'POST',
          body: JSON.stringify({
            ...formData,
            electives: electivesPayload,
            electiveOptOutSubjectIds: optOutIds,
            enrolledSubjectIds: cleanEnrolledIds,
          }),
        });
        const savedYear = res?.academicYear || formData.academicYear;
        const nextYear = yearFilter === 'all' ? 'all' : savedYear;
        const nextClassFilter =
          filterClassId && Number(filterClassId) !== Number(formData.classId) ? '' : filterClassId;
        const nextSectionFilter =
          filterSectionId && Number(filterSectionId) !== Number(formData.sectionId)
            ? ''
            : nextClassFilter
              ? filterSectionId
              : '';
        const nextStatusFilter =
          filterStatus && filterStatus !== 'active' ? '' : filterStatus;

        if (res.student) {
          upsertStudentLocally(res.student);
        }

        setFormOpen(false);
        if (directoryView !== 'active') setDirectoryView('active');
        if (nextYear !== yearFilter) setYearFilter(nextYear);
        if (nextClassFilter !== filterClassId) setFilterClassId(nextClassFilter);
        if (nextSectionFilter !== filterSectionId) setFilterSectionId(nextSectionFilter);
        if (nextStatusFilter !== filterStatus) setFilterStatus(nextStatusFilter);
        if (search.trim()) {
          setSearch('');
          setDebouncedSearch('');
        }
        setPage(1);
        setNotice(`Enrolled student ${formData.fullName} (${res.studentCode}).`);
        triggerBackgroundReload();
        void onChanged();
      }
    } catch (err: unknown) {
      setModalError(extractErrorMessage(err, 'Failed to save student record.'));
    } finally {
      setSaving(false);
    }
  };

  const handleTransfer = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!transferStudent) return;
    setSaving(true);
    setModalError(null);
    setError(null);
    setNotice(null);
    try {
      const res = await apiFetch<{
        success: boolean;
        newRollNumber: number;
        student?: StudentRecord;
      }>(`/api/admin/students/${transferStudent.id}/transfer`, {
        method: 'POST',
        body: JSON.stringify({
          targetClassId: Number(transferData.targetClassId),
          targetSectionId: Number(transferData.targetSectionId),
          newRollNumber: transferData.newRollNumber ? Number(transferData.newRollNumber) : undefined,
          academicYear: transferStudent.academic_year || selectedAcademicYear,
        }),
      });
      if (res.student) {
        upsertStudentLocally(res.student);
      }
      setNotice(`Transferred ${transferStudent.full_name} to new class/section.`);
      setTransferStudent(null);
      triggerBackgroundReload();
      void onChanged();
    } catch (err: unknown) {
      setModalError(extractErrorMessage(err, 'Failed to transfer student.'));
    } finally {
      setSaving(false);
    }
  };

  const pickFallbackExamForYear = (academicYear: string): number => {
    const yearPool = examinations.filter((ex) => ex.academic_year === academicYear);
    const pool = yearPool.length > 0 ? yearPool : examinations;
    const annual = pool.find((ex) => /annual|final/i.test(ex.name));
    if (annual) return annual.id;
    const published = pool.find((ex) => ex.status === 'Published');
    if (published) return published.id;
    return pool[pool.length - 1]?.id || 0;
  };

  const handleDownloadClassAllMarksheets = async () => {
    const effectiveClassId = Number(filterClassId || batchPdfClassId);
    const targetClass = schoolInfo.classes.find((c) => c.id === effectiveClassId);
    if (!targetClass) {
      setError('Please select a class first to download class-wise marksheets.');
      return;
    }

    const targetYear = yearFilter && yearFilter !== 'all' ? yearFilter : selectedAcademicYear;
    const targetSections =
      filterClassId && Number(filterClassId) === targetClass.id && filterSectionId
        ? targetClass.sections.filter((s) => s.id === Number(filterSectionId))
        : targetClass.sections;

    if (targetSections.length === 0) {
      setError(`No sections configured for ${targetClass.name}.`);
      return;
    }

    setBatchPdfBusy(true);
    setError(null);
    setNotice(null);
    try {
      const entries: BatchFinalMarksheetEntry[] = [];
      const fallbackExamId = pickFallbackExamForYear(targetYear);

      for (const sec of targetSections) {
        let addedForSection = false;
        try {
          const comb = await apiFetch<CombinedTermClassReport>(
            `/api/results/combined?classId=${targetClass.id}&sectionId=${sec.id}&academicYear=${encodeURIComponent(
              targetYear
            )}`
          );
          if (comb.students.length > 0 && (comb.term1Exam || comb.term2Exam)) {
            for (const st of comb.students) {
              entries.push({ mode: 'combined', student: st, report: comb });
            }
            addedForSection = true;
          }
        } catch {
          // try fallback single examination below
        }

        if (!addedForSection && fallbackExamId > 0) {
          const singleRep = await apiFetch<ConsolidatedClassReport>(
            `/api/results/consolidated?examinationId=${fallbackExamId}&classId=${targetClass.id}&sectionId=${sec.id}`
          );
          for (const st of singleRep.students) {
            entries.push({ mode: 'single', student: st, report: singleRep });
          }
        }
      }

      if (entries.length === 0) {
        setError(
          `No examination marksheets found for ${targetClass.name} in AY ${targetYear}. Ensure marks/examinations exist.`
        );
        return;
      }

      const secSlug =
        targetSections.length === 1 && targetClass.hasSections !== false
          ? `Sec_${targetSections[0].name}`
          : 'All_Sections';
      const filename = await exportClassAllFinalMarksheetsPDF(
        entries,
        schoolInfo,
        `${targetClass.name}_${secSlug}_Final_Marksheets_${targetYear}`
      );
      setNotice(`Downloaded ${entries.length} complete Final Marksheet(s) into ${filename}.`);
    } catch (err: unknown) {
      setError(extractErrorMessage(err, 'Failed to generate class Final Marksheets PDF.'));
    } finally {
      setBatchPdfBusy(false);
    }
  };

  const handleDownloadIndividualFinalMarksheet = async (st: StudentRecord) => {
    const targetYear = st.academic_year || (yearFilter !== 'all' ? yearFilter : selectedAcademicYear);
    setStudentPdfBusyId(st.id);
    setError(null);
    setNotice(null);
    try {
      let exported = false;
      try {
        const comb = await apiFetch<CombinedTermClassReport>(
          `/api/results/combined?classId=${st.class_id}&sectionId=${st.section_id}&academicYear=${encodeURIComponent(
            targetYear
          )}`
        );
        const match = comb.students.find((item) => item.studentId === st.id);
        if (match && (comb.term1Exam || comb.term2Exam)) {
          await exportCombinedReportCardPDF(match, comb, schoolInfo);
          exported = true;
        }
      } catch {
        // fallback below
      }

      if (!exported) {
        const fallbackExamId = pickFallbackExamForYear(targetYear);
        if (!fallbackExamId) {
          throw new Error(`No examinations found for AY ${targetYear}.`);
        }
        const rep = await apiFetch<ConsolidatedClassReport>(
          `/api/results/consolidated?examinationId=${fallbackExamId}&classId=${st.class_id}&sectionId=${st.section_id}`
        );
        const match = rep.students.find((item) => item.studentId === st.id);
        if (!match) {
          throw new Error(`Student record not found in ${rep.examination.name} results.`);
        }
        await exportIndividualReportCardPDF(match, rep, schoolInfo);
      }

      setNotice(`Downloaded Final Marksheet PDF for ${st.full_name} (${st.student_code}).`);
    } catch (err: unknown) {
      setError(extractErrorMessage(err, `Failed to export Final Marksheet PDF for ${st.full_name}.`));
    } finally {
      setStudentPdfBusyId(null);
    }
  };

  return (
    <div className="space-y-4">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
        <div>
          <h2 className="text-lg font-bold text-slate-900">Student Directory &amp; Class-Wise Promotion</h2>
          <p className="text-xs text-slate-500">
            {viewMode === 'directory'
              ? `Showing ${students.length} ${directoryView === 'archived' ? 'archived' : 'student'} record(s) · `
              : 'Tick or mark passed students class-wise and transfer them to the next academic year · Base Year '}
            <span className="font-mono font-semibold">
              {viewMode === 'directory'
                ? yearFilter === 'all'
                  ? 'All Academic Years'
                  : yearFilter
                : selectedAcademicYear}
            </span>
          </p>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <div className="inline-flex rounded-lg border border-slate-200 bg-white p-0.5 text-xs">
            <button
              type="button"
              onClick={() => setViewMode('directory')}
              className={`min-h-[38px] sm:min-h-[32px] inline-flex items-center gap-1.5 px-3 py-1.5 rounded-md font-medium transition-colors cursor-pointer ${
                viewMode === 'directory'
                  ? 'bg-[#1E3A5F] text-white'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <Users className="w-3.5 h-3.5" />
              Directory
            </button>
            <button
              type="button"
              onClick={() => setViewMode('promotion')}
              className={`min-h-[38px] sm:min-h-[32px] inline-flex items-center gap-1.5 px-3 py-1.5 rounded-md font-medium transition-colors cursor-pointer ${
                viewMode === 'promotion'
                  ? 'bg-[#1E3A5F] text-white'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <GraduationCap className="w-3.5 h-3.5" />
              Promote Students
            </button>
          </div>
          {viewMode === 'directory' && (
            <button
              type="button"
              onClick={openAdd}
              className="min-h-[42px] sm:min-h-[36px] inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-white bg-[#1E3A5F] rounded-lg hover:bg-[#162D4A] whitespace-nowrap cursor-pointer"
            >
              <Plus className="w-3.5 h-3.5" />
              Add Student
            </button>
          )}
        </div>
      </div>

      {viewMode === 'promotion' ? (
        <ClassWisePromotionPanel
          schoolInfo={schoolInfo}
          selectedAcademicYear={selectedAcademicYear}
          onPromoted={() => {
            loadStudents();
            onChanged();
          }}
        />
      ) : (
        <>
          {undoState && (
            <UndoBanner
              message={undoState.message}
              onUndo={handleUndoRestore}
              onDismiss={() => setUndoState(null)}
              busy={bulkBusy}
            />
          )}

          {notice && (
            <div className="flex items-center justify-between gap-2 p-3 rounded-xl bg-emerald-50 border border-emerald-200 text-xs font-medium text-emerald-900">
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-700 shrink-0" />
                <span>{notice}</span>
              </div>
              <button type="button" onClick={() => setNotice(null)} className="cursor-pointer">
                <X className="w-3.5 h-3.5" />
              </button>
            </div>
          )}

          {error && (
            <div className="flex flex-wrap items-center justify-between gap-2 p-3 rounded-xl bg-red-50 border border-red-200 text-xs font-medium text-red-900">
              <span>{error}</span>
              <button
                type="button"
                onClick={() => loadStudents()}
                className="px-3 py-1.5 bg-red-800 text-white rounded-lg hover:bg-red-900 cursor-pointer"
              >
                Retry
              </button>
            </div>
          )}

          {/* Filters & View Switcher */}
          <div className="bg-white border border-slate-200 rounded-xl p-4 space-y-3 text-xs">
            <div className="grid grid-cols-1 md:grid-cols-12 gap-2.5">
              <div className="relative md:col-span-4">
                <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  value={search}
                  onChange={(e) => {
                    setSearch(e.target.value);
                    setPage(1);
                  }}
                  placeholder="Search Student Name, ID, or Guardian..."
                  className="w-full min-h-[42px] sm:min-h-[36px] pl-8 pr-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:border-[#1E3A5F]"
                />
              </div>

              <select
                value={yearFilter}
                onChange={(e) => {
                  setYearFilter(e.target.value);
                  setPage(1);
                }}
                className="min-h-[42px] sm:min-h-[36px] md:col-span-2 px-2.5 py-2 border border-slate-300 rounded-lg bg-white font-mono"
              >
                <option value="all">All Academic Years</option>
                {(schoolInfo.academicYears || []).map((ay) => (
                  <option key={ay.name} value={ay.name}>
                    {ay.name} ({ay.studentCount})
                  </option>
                ))}
              </select>

              <select
                value={filterClassId}
                onChange={(e) => {
                  setFilterClassId(e.target.value);
                  setFilterSectionId('');
                  setPage(1);
                }}
                className="min-h-[42px] sm:min-h-[36px] md:col-span-2 px-2.5 py-2 border border-slate-300 rounded-lg bg-white"
              >
                <option value="">All Classes</option>
                {schoolInfo.classes.map((c) => (
                  <option key={c.id} value={c.id}>
                    {c.name}
                  </option>
                ))}
              </select>

              <select
                value={filterSectionId}
                onChange={(e) => {
                  setFilterSectionId(e.target.value);
                  setPage(1);
                }}
                disabled={!filterClassId || filterClassObj?.hasSections === false}
                className="min-h-[42px] sm:min-h-[36px] md:col-span-2 px-2.5 py-2 border border-slate-300 rounded-lg bg-white disabled:bg-slate-50"
              >
                <option value="">
                  {filterClassObj?.hasSections === false ? 'No Sections (Single Cohort)' : 'All Sections'}
                </option>
                {filterClassObj?.hasSections !== false &&
                  filterClassObj?.sections.map((s) => (
                    <option key={s.id} value={s.id}>
                      Section {s.name}
                    </option>
                  ))}
              </select>

              <select
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value as any)}
                className="min-h-[42px] sm:min-h-[36px] md:col-span-2 px-2.5 py-2 border border-slate-300 rounded-lg bg-white"
              >
                <option value="roll">Sort: Roll / Class</option>
                <option value="name_asc">Sort: Name A–Z</option>
                <option value="name_desc">Sort: Name Z–A</option>
                <option value="code_asc">Sort: ID Ascending</option>
                <option value="code_desc">Sort: ID Descending</option>
              </select>
            </div>

            <div className="flex flex-wrap items-center justify-between gap-2 pt-2 border-t border-slate-100">
              <div className="flex flex-wrap items-center gap-2">
                <div className="inline-flex rounded-lg border border-slate-200 bg-slate-50 p-0.5">
                  <button
                    type="button"
                    onClick={() => {
                      setDirectoryView('active');
                      setSelectedIds(new Set());
                      setPage(1);
                    }}
                    className={`min-h-[34px] px-3 py-1 rounded-md font-medium cursor-pointer ${
                      directoryView === 'active'
                        ? 'bg-white text-slate-900 shadow-xs'
                        : 'text-slate-600 hover:text-slate-900'
                    }`}
                  >
                    Active Roster
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setDirectoryView('archived');
                      setSelectedIds(new Set());
                      setPage(1);
                    }}
                    className={`min-h-[34px] px-3 py-1 rounded-md font-medium cursor-pointer ${
                      directoryView === 'archived'
                        ? 'bg-white text-slate-900 shadow-xs'
                        : 'text-slate-600 hover:text-slate-900'
                    }`}
                  >
                    Archived Students
                  </button>
                </div>

                <select
                  value={filterStatus}
                  onChange={(e) => {
                    setFilterStatus(e.target.value);
                    setPage(1);
                  }}
                  className="min-h-[36px] px-2.5 py-1 border border-slate-300 rounded-lg bg-white"
                >
                  <option value="">All Statuses</option>
                  <option value="active">Active</option>
                  <option value="inactive">Inactive</option>
                  <option value="transferred">Transferred</option>
                  <option value="promoted">Promoted</option>
                  <option value="graduated">Graduated</option>
                </select>

                <select
                  value={filterStream}
                  onChange={(e) => {
                    setFilterStream(e.target.value);
                    setPage(1);
                  }}
                  className="min-h-[36px] px-2.5 py-1 border border-slate-300 rounded-lg bg-white"
                >
                  <option value="">All Streams</option>
                  <option value="Science">Science Stream</option>
                  <option value="Humanities">Humanities Stream</option>
                  <option value="none">No Stream / General</option>
                </select>

                {hasActiveFilters && (
                  <button
                    type="button"
                    onClick={clearFilters}
                    className="min-h-[36px] inline-flex items-center gap-1 px-2.5 py-1 text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg font-medium cursor-pointer"
                  >
                    <X className="w-3 h-3" />
                    Clear Filters
                  </button>
                )}
                <button
                  type="button"
                  onClick={() => loadStudents({ background: students.length > 0 })}
                  disabled={loading || refreshing}
                  className="min-h-[36px] inline-flex items-center gap-1 px-2.5 py-1 text-slate-700 bg-white border border-slate-300 hover:bg-slate-50 rounded-lg font-medium disabled:opacity-50 cursor-pointer"
                >
                  <RefreshCw className={`w-3 h-3 ${loading || refreshing ? 'animate-spin' : ''}`} />
                  Refresh
                </button>
              </div>
              <div className="text-[11px] text-slate-500">
                Historical marks &amp; exam results remain linked across transfers and archival
              </div>
            </div>

            {directoryView === 'active' && schoolInfo.classes.length > 0 && (
              <div className="flex flex-wrap items-center justify-between gap-2.5 pt-2.5 border-t border-slate-100">
                <div className="text-[11px] text-slate-600">
                  <span className="font-semibold text-slate-800">One-Click Class Final Marksheets (PDF):</span>{' '}
                  Downloads every student&apos;s complete single-page A4 marksheet (scholastic, co-scholastic, attendance, remarks, photo &amp; result date) in one PDF.
                </div>
                <div className="flex flex-wrap items-center gap-2 w-full sm:w-auto">
                  {!filterClassId && (
                    <select
                      value={batchPdfClassId}
                      onChange={(e) => setBatchPdfClassId(e.target.value)}
                      aria-label="Class for Batch Final Marksheets PDF"
                      className="min-h-[38px] px-2.5 py-1.5 border border-slate-300 rounded-lg bg-white text-xs flex-1 sm:flex-initial"
                    >
                      {schoolInfo.classes.map((c) => (
                        <option key={c.id} value={c.id}>
                          {c.name}
                        </option>
                      ))}
                    </select>
                  )}
                  <button
                    type="button"
                    disabled={batchPdfBusy}
                    onClick={handleDownloadClassAllMarksheets}
                    className="min-h-[38px] inline-flex items-center justify-center gap-1.5 px-3.5 py-1.5 text-xs font-semibold text-white bg-[#1E3A5F] hover:bg-[#162D4A] rounded-lg disabled:opacity-50 transition-colors cursor-pointer whitespace-nowrap flex-1 sm:flex-initial"
                  >
                    <FileDown className="w-3.5 h-3.5" />
                    {batchPdfBusy
                      ? 'Building Class PDF...'
                      : `Download ${
                          schoolInfo.classes.find((c) => String(c.id) === (filterClassId || batchPdfClassId))?.name ||
                          'Class'
                        }${filterSectionId && filterClassObj?.hasSections !== false ? ' Section' : ' All'} Final PDF`}
                  </button>
                </div>
              </div>
            )}
          </div>

          {/* Bulk Action Toolbar */}
          <BulkActionToolbar
            selectedCount={selectedIds.size}
            entityLabel="student"
            onClearSelection={() => setSelectedIds(new Set())}
            disabled={bulkBusy}
            actions={
              directoryView === 'archived'
                ? [
                    {
                      id: 'restore',
                      label: 'Restore Selected',
                      icon: 'restore',
                      variant: 'success',
                      onClick: () => openBulkConfirm('restore', Array.from(selectedIds)),
                    },
                    {
                      id: 'export',
                      label: 'Export CSV',
                      icon: 'export',
                      onClick: handleExportCsv,
                    },
                    {
                      id: 'permanent_delete',
                      label: 'Delete Permanently',
                      icon: 'delete',
                      variant: 'danger',
                      onClick: () => openBulkConfirm('permanent_delete', Array.from(selectedIds)),
                    },
                  ]
                : [
                    {
                      id: 'edit',
                      label: 'Bulk Edit',
                      icon: 'edit',
                      variant: 'primary',
                      onClick: () => {
                        setModalError(null);
                        setBulkEditForm({ classId: '', sectionId: '', status: '', stream: '__KEEP__' });
                        setBulkEditOpen(true);
                      },
                    },
                    {
                      id: 'activate',
                      label: 'Activate',
                      icon: 'activate',
                      variant: 'success',
                      onClick: () => openBulkConfirm('activate', Array.from(selectedIds)),
                    },
                    {
                      id: 'deactivate',
                      label: 'Deactivate',
                      icon: 'deactivate',
                      variant: 'warning',
                      onClick: () => openBulkConfirm('deactivate', Array.from(selectedIds)),
                    },
                    {
                      id: 'export',
                      label: 'Export Selected',
                      icon: 'export',
                      onClick: handleExportCsv,
                    },
                    {
                      id: 'archive',
                      label: 'Archive Selected',
                      icon: 'archive',
                      variant: 'warning',
                      onClick: () => openBulkConfirm('archive', Array.from(selectedIds)),
                    },
                    {
                      id: 'permanent_delete',
                      label: 'Delete Permanently',
                      icon: 'delete',
                      variant: 'danger',
                      onClick: () => openBulkConfirm('permanent_delete', Array.from(selectedIds)),
                    },
                  ]
            }
          />

          {/* Smart Empty-Year Helper when current year has 0 enrollments */}
          {!loading && students.length === 0 && yearFilter !== 'all' && otherPopulatedYears.length > 0 && !hasActiveFilters && directoryView === 'active' && (
            <div className="p-4 bg-sky-50 border border-sky-200 rounded-xl flex flex-wrap items-center justify-between gap-3 text-xs text-sky-950">
              <div>
                <span className="font-semibold">No students enrolled yet for Academic Year {yearFilter}.</span>{' '}
                Existing students are stored in{' '}
                {otherPopulatedYears.map((ay) => `${ay.name} (${ay.studentCount})`).join(', ')}.
              </div>
              <div className="flex flex-wrap items-center gap-2">
                {otherPopulatedYears.map((ay) => (
                  <button
                    key={ay.name}
                    type="button"
                    onClick={() => setYearFilter(ay.name)}
                    className="min-h-[36px] px-3 py-1.5 font-semibold bg-[#1E3A5F] text-white rounded-lg hover:bg-[#162D4A] cursor-pointer"
                  >
                    View {ay.name} ({ay.studentCount})
                  </button>
                ))}
                <button
                  type="button"
                  onClick={() => setYearFilter('all')}
                  className="min-h-[36px] px-3 py-1.5 font-medium bg-white border border-sky-300 text-sky-900 rounded-lg hover:bg-sky-100 cursor-pointer"
                >
                  Show All Years
                </button>
              </div>
            </div>
          )}

          {/* Mobile Select All Bar (<768px) */}
          <div className="md:hidden bg-white border border-slate-200 rounded-xl px-4 py-2.5 flex items-center justify-between text-xs">
            <label className="inline-flex items-center gap-2 font-medium text-slate-700 cursor-pointer">
              <input
                type="checkbox"
                checked={allPageSelected}
                disabled={pagedItems.length === 0}
                onChange={toggleSelectPage}
                className="w-4 h-4 rounded border-slate-300 text-[#1E3A5F]"
              />
              <span>Select Page ({pagedItems.length})</span>
            </label>
            <span className="font-mono text-[11px] text-slate-500">Page {page}</span>
          </div>

          {/* Mobile Cards (<768px) */}
          <div className="md:hidden space-y-3">
            {loading ? (
              <div className="bg-white border border-slate-200 rounded-xl p-8 text-center text-xs text-slate-500">
                Loading student records...
              </div>
            ) : pagedItems.length === 0 ? (
              <div className="bg-white border border-slate-200 rounded-xl p-8 text-center text-xs text-slate-500">
                No students match the selected filters.
              </div>
            ) : (
              pagedItems.map((st) => {
                const isSelected = selectedIds.has(st.id);
                return (
                  <div
                    key={st.id}
                    className={`bg-white border rounded-xl p-4 space-y-3 text-xs ${
                      isSelected ? 'border-[#1E3A5F] ring-1 ring-[#1E3A5F]/20' : 'border-slate-200'
                    }`}
                  >
                    <div className="flex items-start justify-between gap-2">
                      <div className="flex items-start gap-2.5 min-w-0">
                        <input
                          type="checkbox"
                          aria-label={`Select ${st.full_name}`}
                          checked={isSelected}
                          onChange={() => toggleSelectRow(st.id)}
                          className="mt-1 w-4 h-4 rounded border-slate-300 text-[#1E3A5F]"
                        />
                        {st.photo_url && (
                          <img
                            src={st.photo_url}
                            alt={st.full_name}
                            className="w-9 h-11 rounded object-cover border border-slate-300 bg-white shrink-0"
                          />
                        )}
                        <div className="min-w-0">
                          <div className="font-bold text-sm text-slate-900 truncate">{st.full_name}</div>
                          <div className="font-mono text-[11px] text-slate-500">
                            {st.student_code} · Roll {String(st.roll_number).padStart(2, '0')} · {st.academic_year}
                          </div>
                        </div>
                      </div>
                      <span
                        className={`shrink-0 px-2 py-0.5 rounded border text-[11px] font-medium capitalize ${
                          st.isDeleted
                            ? 'bg-amber-50 text-amber-800 border-amber-200'
                            : st.status === 'active'
                              ? 'bg-emerald-50 text-emerald-800 border-emerald-200'
                              : 'bg-slate-100 text-slate-600 border-slate-200'
                        }`}
                      >
                        {st.isDeleted ? 'Archived' : st.status}
                      </span>
                    </div>

                    <div className="bg-slate-50 border border-slate-100 rounded-lg p-2.5 text-[11px] space-y-1">
                      <div className="flex flex-wrap items-center gap-1.5">
                        <span className="font-semibold text-slate-700">Class:</span>{' '}
                        <span>{formatClassSectionLabel(st.class_name, st.section_name, st.hasSections)}</span>
                        {st.stream && (
                          <span className="px-1.5 py-0.5 rounded bg-indigo-50 text-indigo-800 border border-indigo-200 font-semibold text-[10px]">
                            {st.stream}
                          </span>
                        )}
                      </div>
                      <div>
                        <span className="font-semibold text-slate-700">Parents / Guardian:</span>{' '}
                        {[
                          st.father_name ? `F: ${st.father_name}` : '',
                          st.mother_name ? `M: ${st.mother_name}` : '',
                          !st.father_name && !st.mother_name ? st.guardian_name || '—' : '',
                        ]
                          .filter(Boolean)
                          .join(' · ')}
                      </div>
                      {(st.contact_no || st.guardian_phone || st.aapaar_id) && (
                        <div className="font-mono text-slate-600">
                          {st.contact_no || st.guardian_phone
                            ? `Ph: ${st.contact_no || st.guardian_phone}`
                            : ''}
                          {(st.contact_no || st.guardian_phone) && st.aapaar_id ? ' · ' : ''}
                          {st.aapaar_id ? `AAPAAR: ${st.aapaar_id}` : ''}
                        </div>
                      )}
                      {st.residential_address && (
                        <div className="text-slate-600">
                          <span className="font-semibold text-slate-700">Address:</span> {st.residential_address}
                        </div>
                      )}
                      {st.electives && st.electives.length > 0 && (
                        <div className="text-slate-600">
                          {st.electives.map((el) => `${el.subjectName}: ${el.componentName}`).join(' · ')}
                        </div>
                      )}
                      {st.enrolledSubjectIds && st.enrolledSubjectIds.length > 0 && (
                        <div className="text-indigo-700">
                          Custom Subjects: {st.enrolledSubjectIds.length} selected
                        </div>
                      )}
                    </div>

                    <div className="flex flex-wrap gap-2">
                      {!st.isDeleted ? (
                        <>
                          <button
                            type="button"
                            disabled={studentPdfBusyId === st.id}
                            onClick={() => handleDownloadIndividualFinalMarksheet(st)}
                            className="flex-1 min-h-[40px] inline-flex items-center justify-center gap-1 px-2.5 py-1.5 font-semibold text-[#1E3A5F] bg-sky-50 border border-sky-200 rounded-lg hover:bg-sky-100 disabled:opacity-50"
                          >
                            <FileDown className="w-3.5 h-3.5" />
                            {studentPdfBusyId === st.id ? 'PDF...' : 'Final PDF'}
                          </button>
                          <button
                            type="button"
                            onClick={() => openTransfer(st)}
                            className="flex-1 min-h-[40px] inline-flex items-center justify-center gap-1 px-2.5 py-1.5 font-medium text-slate-700 border border-slate-300 rounded-lg hover:bg-slate-50"
                          >
                            <ArrowRightLeft className="w-3.5 h-3.5" />
                            Transfer
                          </button>
                          <button
                            type="button"
                            onClick={() => openEdit(st)}
                            className="flex-1 min-h-[40px] inline-flex items-center justify-center gap-1 px-2.5 py-1.5 font-medium text-slate-700 border border-slate-300 rounded-lg hover:bg-slate-50"
                          >
                            <Pencil className="w-3.5 h-3.5" />
                            Edit
                          </button>
                          <button
                            type="button"
                            onClick={() => openBulkConfirm('archive', [st.id])}
                            title="Archive Student"
                            className="min-h-[40px] inline-flex items-center justify-center gap-1 px-3 py-1.5 font-medium text-amber-800 bg-amber-50 border border-amber-200 rounded-lg hover:bg-amber-100"
                          >
                            <Archive className="w-3.5 h-3.5" />
                          </button>
                          <button
                            type="button"
                            onClick={() => openBulkConfirm('permanent_delete', [st.id])}
                            title="Delete Permanently from Database"
                            className="min-h-[40px] inline-flex items-center justify-center gap-1 px-3 py-1.5 font-medium text-red-700 bg-red-50 border border-red-200 rounded-lg hover:bg-red-100"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </>
                      ) : (
                        <>
                          <button
                            type="button"
                            onClick={() => openBulkConfirm('restore', [st.id])}
                            className="flex-1 min-h-[40px] inline-flex items-center justify-center gap-1.5 px-3 py-1.5 font-semibold text-emerald-800 bg-emerald-50 border border-emerald-200 rounded-lg"
                          >
                            <RotateCcw className="w-3.5 h-3.5" />
                            Restore
                          </button>
                          <button
                            type="button"
                            onClick={() => openBulkConfirm('permanent_delete', [st.id])}
                            className="flex-1 min-h-[40px] inline-flex items-center justify-center gap-1.5 px-3 py-1.5 font-semibold text-red-700 bg-red-50 border border-red-200 rounded-lg hover:bg-red-100"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                            Delete Permanently
                          </button>
                        </>
                      )}
                    </div>
                  </div>
                );
              })
            )}
          </div>

          {/* Desktop & Tablet Table (>=768px) */}
          <div className="hidden md:block bg-white border border-slate-200 rounded-xl overflow-hidden">
            <div className="overflow-x-auto max-h-[600px]">
              <table className="w-full text-xs">
                <thead className="bg-slate-50 border-b border-slate-200 text-slate-600 sticky top-0 z-10">
                  <tr>
                    <th className="w-10 px-3 py-2.5 text-center">
                      <input
                        type="checkbox"
                        aria-label="Select all students on current page"
                        checked={allPageSelected}
                        disabled={pagedItems.length === 0}
                        onChange={toggleSelectPage}
                        className="w-4 h-4 rounded border-slate-300 text-[#1E3A5F] cursor-pointer"
                      />
                    </th>
                    <th className="text-left font-semibold px-3 py-2.5">Student ID</th>
                    <th className="text-left font-semibold px-3 py-2.5">Roll</th>
                    <th className="text-left font-semibold px-3 py-2.5">Student Name</th>
                    <th className="text-left font-semibold px-3 py-2.5">Class &amp; Section</th>
                    <th className="text-left font-semibold px-3 py-2.5">Year</th>
                    <th className="text-left font-semibold px-3 py-2.5">Parents, Contact &amp; AAPAAR</th>
                    <th className="text-center font-semibold px-3 py-2.5">Status</th>
                    <th className="text-right font-semibold px-4 py-2.5">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200">
                  {loading ? (
                    <tr>
                      <td colSpan={9} className="px-4 py-10 text-center text-slate-500">
                        Loading student records...
                      </td>
                    </tr>
                  ) : pagedItems.length === 0 ? (
                    <tr>
                      <td colSpan={9} className="px-4 py-10 text-center text-slate-500">
                        {directoryView === 'archived'
                          ? 'No archived student records found.'
                          : 'No students match the selected filters.'}
                      </td>
                    </tr>
                  ) : (
                    pagedItems.map((st) => {
                      const isSelected = selectedIds.has(st.id);
                      return (
                        <tr
                          key={st.id}
                          className={isSelected ? 'bg-sky-50/40' : 'hover:bg-slate-50/70'}
                        >
                          <td className="px-3 py-2.5 text-center">
                            <input
                              type="checkbox"
                              aria-label={`Select ${st.full_name}`}
                              checked={isSelected}
                              onChange={() => toggleSelectRow(st.id)}
                              className="w-4 h-4 rounded border-slate-300 text-[#1E3A5F] cursor-pointer"
                            />
                          </td>
                          <td className="px-3 py-2.5 font-mono text-slate-600">{st.student_code}</td>
                          <td className="px-3 py-2.5 font-mono font-semibold tabular-nums">
                            {String(st.roll_number).padStart(2, '0')}
                          </td>
                          <td className="px-3 py-2.5 font-medium text-slate-900">
                            <div className="flex items-center gap-2">
                              {st.photo_url && (
                                <img
                                  src={st.photo_url}
                                  alt={st.full_name}
                                  className="w-7 h-8 rounded object-cover border border-slate-300 bg-white shrink-0"
                                />
                              )}
                              <div>
                                <div className="flex flex-wrap items-center gap-1.5">
                                  <span>{st.full_name}</span>
                                  {st.stream && (
                                    <span className="px-1.5 py-0.5 rounded bg-indigo-50 text-indigo-800 border border-indigo-200 text-[10px] font-semibold">
                                      {st.stream}
                                    </span>
                                  )}
                                </div>
                                {st.electives && st.electives.length > 0 && (
                                  <div className="text-[11px] font-normal text-slate-500">
                                    {st.electives.map((el) => `${el.subjectName}: ${el.componentName}`).join(' · ')}
                                  </div>
                                )}
                                {st.enrolledSubjectIds && st.enrolledSubjectIds.length > 0 && (
                                  <div className="text-[10px] font-normal text-indigo-700">
                                    Custom Combination ({st.enrolledSubjectIds.length} subjects)
                                  </div>
                                )}
                              </div>
                            </div>
                          </td>
                          <td className="px-3 py-2.5 text-slate-700">
                            {formatClassSectionLabel(st.class_name, st.section_name, st.hasSections)}
                          </td>
                          <td className="px-3 py-2.5 font-mono text-slate-500">{st.academic_year}</td>
                          <td className="px-3 py-2.5 text-slate-600 max-w-[260px]">
                            <div className="text-slate-800">
                              {st.father_name || st.mother_name ? (
                                <>
                                  {st.father_name ? `F: ${st.father_name}` : ''}
                                  {st.father_name && st.mother_name ? ' · ' : ''}
                                  {st.mother_name ? `M: ${st.mother_name}` : ''}
                                </>
                              ) : (
                                st.guardian_name || '—'
                              )}
                            </div>
                            {(st.contact_no || st.guardian_phone || st.aapaar_id) && (
                              <div className="font-mono text-[11px] text-slate-500">
                                {st.contact_no || st.guardian_phone || ''}
                                {(st.contact_no || st.guardian_phone) && st.aapaar_id ? ' · ' : ''}
                                {st.aapaar_id ? `AAPAAR: ${st.aapaar_id}` : ''}
                              </div>
                            )}
                            {st.residential_address && (
                              <div className="text-[11px] text-slate-400 truncate" title={st.residential_address}>
                                {st.residential_address}
                              </div>
                            )}
                          </td>
                          <td className="px-3 py-2.5 text-center">
                            <span
                              className={`px-2 py-0.5 rounded border text-[11px] font-medium capitalize ${
                                st.isDeleted
                                  ? 'bg-amber-50 text-amber-800 border-amber-200'
                                  : st.status === 'active'
                                    ? 'bg-emerald-50 text-emerald-800 border-emerald-200'
                                    : 'bg-slate-100 text-slate-600 border-slate-200'
                              }`}
                            >
                              {st.isDeleted ? 'Archived' : st.status}
                            </span>
                          </td>
                          <td className="px-4 py-2.5 text-right whitespace-nowrap">
                            {!st.isDeleted ? (
                              <>
                                <button
                                  type="button"
                                  disabled={studentPdfBusyId === st.id}
                                  onClick={() => handleDownloadIndividualFinalMarksheet(st)}
                                  title="Download Complete Final Marksheet (PDF)"
                                  className="inline-flex items-center gap-1 px-2 py-1 text-[11px] font-semibold text-[#1E3A5F] bg-sky-50 border border-sky-200 rounded hover:bg-sky-100 disabled:opacity-50 mr-1.5 cursor-pointer"
                                >
                                  <FileDown className="w-3 h-3" />
                                  {studentPdfBusyId === st.id ? '...' : 'Final PDF'}
                                </button>
                                <button
                                  type="button"
                                  onClick={() => openTransfer(st)}
                                  title="Transfer Class / Section"
                                  className="inline-flex items-center gap-1 px-2 py-1 text-[11px] font-medium text-slate-700 border border-slate-200 rounded hover:bg-slate-100 mr-1.5 cursor-pointer"
                                >
                                  <ArrowRightLeft className="w-3 h-3" />
                                  Transfer
                                </button>
                                <button
                                  type="button"
                                  onClick={() => openEdit(st)}
                                  title="Edit Student"
                                  className="p-1.5 text-slate-600 hover:text-slate-900 rounded hover:bg-slate-100 mr-1 cursor-pointer"
                                >
                                  <Pencil className="w-3.5 h-3.5" />
                                </button>
                                <button
                                  type="button"
                                  onClick={() => openBulkConfirm('archive', [st.id])}
                                  title="Archive Student (Preserve History)"
                                  className="p-1.5 text-amber-700 hover:text-amber-900 rounded hover:bg-amber-50 mr-1 cursor-pointer"
                                >
                                  <Archive className="w-3.5 h-3.5" />
                                </button>
                                <button
                                  type="button"
                                  onClick={() => openBulkConfirm('permanent_delete', [st.id])}
                                  title="Delete Permanently from Database"
                                  className="p-1.5 text-red-600 hover:text-red-800 rounded hover:bg-red-50 cursor-pointer"
                                >
                                  <Trash2 className="w-3.5 h-3.5" />
                                </button>
                              </>
                            ) : (
                              <div className="inline-flex items-center gap-1.5">
                                <button
                                  type="button"
                                  onClick={() => openBulkConfirm('restore', [st.id])}
                                  className="inline-flex items-center gap-1 px-2.5 py-1 text-[11px] font-semibold text-emerald-800 bg-emerald-50 border border-emerald-200 rounded hover:bg-emerald-100 cursor-pointer"
                                >
                                  <RotateCcw className="w-3 h-3" />
                                  Restore
                                </button>
                                <button
                                  type="button"
                                  onClick={() => openBulkConfirm('permanent_delete', [st.id])}
                                  title="Delete Permanently from Database"
                                  className="inline-flex items-center gap-1 px-2.5 py-1 text-[11px] font-semibold text-red-700 bg-red-50 border border-red-200 rounded hover:bg-red-100 cursor-pointer"
                                >
                                  <Trash2 className="w-3 h-3" />
                                  Delete Permanently
                                </button>
                              </div>
                            )}
                          </td>
                        </tr>
                      );
                    })
                  )}
                </tbody>
              </table>
            </div>
          </div>

          <div className="bg-white border border-slate-200 rounded-xl overflow-hidden">
            <PaginationBar
              totalItems={students.length}
              page={page}
              pageSize={pageSize}
              onPageChange={setPage}
              onPageSizeChange={setPageSize}
            />
          </div>

          {/* Bulk Confirm Modal (single & multi) */}
          {bulkConfirm && (
            <BulkConfirmModal
              open={true}
              title={bulkConfirm.title}
              description={bulkConfirm.description}
              confirmLabel={bulkConfirm.confirmLabel}
              variant={bulkConfirm.variant}
              busy={bulkBusy}
              safetyNoteTone={bulkConfirm.action === 'permanent_delete' ? 'danger' : 'success'}
              safetyNote={
                bulkConfirm.action === 'permanent_delete'
                  ? 'PERMANENT DATABASE DELETION: Selected student record(s), enrollments, electives, and all linked examination/IA marks will be permanently deleted from school.db and cannot be recovered.'
                  : 'Important: Historical examination marks, attendance records, report cards, and academic enrollment history for these students are strictly preserved.'
              }
              items={bulkConfirm.ids.map((id) => {
                const st = students.find((s) => s.id === id);
                return {
                  id,
                  label: st ? st.full_name : `Student #${id}`,
                  sublabel: st ? `${st.student_code} · ${formatClassSectionLabel(st.class_name, st.section_name, st.hasSections)}` : undefined,
                };
              })}
              onCancel={() => setBulkConfirm(null)}
              onConfirm={executeBulkAction}
            />
          )}

          {/* Bulk Edit Modal */}
          {bulkEditOpen && (
            <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/50 p-4">
              <form
                onSubmit={handleBulkEditSubmit}
                className="bg-white border border-slate-200 rounded-xl w-full max-w-md max-h-[90vh] overflow-y-auto p-6 space-y-4 shadow-xl text-xs"
              >
                <div className="flex items-center justify-between">
                  <h3 className="text-base font-bold text-slate-900">
                    Bulk Edit {selectedIds.size} Selected Student(s)
                  </h3>
                  <button type="button" onClick={() => setBulkEditOpen(false)} className="cursor-pointer">
                    <X className="w-4 h-4 text-slate-400" />
                  </button>
                </div>
                <p className="text-slate-600">
                  Leave any field unchanged to keep each student&apos;s existing value.
                </p>
                {modalError && (
                  <div className="p-2.5 rounded-lg bg-red-50 border border-red-200 text-red-900 font-medium">
                    {modalError}
                  </div>
                )}
                <div className="space-y-3">
                  <div>
                    <label className="block font-semibold text-slate-700 mb-1">Reassign Class (Optional)</label>
                    <select
                      value={bulkEditForm.classId}
                      onChange={(e) => {
                        const cid = e.target.value;
                        const cls = schoolInfo.classes.find((c) => String(c.id) === cid);
                        setBulkEditForm({
                          ...bulkEditForm,
                          classId: cid,
                          sectionId: cls?.sections[0]?.id ? String(cls.sections[0].id) : '',
                        });
                      }}
                      className="w-full min-h-[42px] px-3 py-2 border border-slate-300 rounded-lg bg-white"
                    >
                      <option value="">Keep Existing Class</option>
                      {schoolInfo.classes.map((c) => (
                        <option key={c.id} value={c.id}>
                          {c.name}
                        </option>
                      ))}
                    </select>
                  </div>
                  {bulkEditForm.classId && bulkEditClassObj?.hasSections !== false && (
                    <div>
                      <label className="block font-semibold text-slate-700 mb-1">Target Section</label>
                      <select
                        value={bulkEditForm.sectionId}
                        onChange={(e) => setBulkEditForm({ ...bulkEditForm, sectionId: e.target.value })}
                        className="w-full min-h-[42px] px-3 py-2 border border-slate-300 rounded-lg bg-white"
                      >
                        {bulkEditClassObj?.sections.map((s) => (
                          <option key={s.id} value={s.id}>
                            Section {s.name}
                          </option>
                        ))}
                      </select>
                    </div>
                  )}
                  <div>
                    <label className="block font-semibold text-slate-700 mb-1">Academic Stream (Optional)</label>
                    <select
                      value={bulkEditForm.stream}
                      onChange={(e) =>
                        setBulkEditForm({ ...bulkEditForm, stream: e.target.value as '__KEEP__' | StudentStream })
                      }
                      className="w-full min-h-[42px] px-3 py-2 border border-slate-300 rounded-lg bg-white"
                    >
                      <option value="__KEEP__">Keep Existing Stream</option>
                      <option value="">No Stream / General</option>
                      <option value="Science">Science</option>
                      <option value="Humanities">Humanities</option>
                    </select>
                  </div>
                  <div>
                    <label className="block font-semibold text-slate-700 mb-1">Account Status (Optional)</label>
                    <select
                      value={bulkEditForm.status}
                      onChange={(e) => setBulkEditForm({ ...bulkEditForm, status: e.target.value })}
                      className="w-full min-h-[42px] px-3 py-2 border border-slate-300 rounded-lg bg-white"
                    >
                      <option value="">Keep Existing Status</option>
                      <option value="active">Active</option>
                      <option value="inactive">Inactive</option>
                      <option value="transferred">Transferred</option>
                      <option value="graduated">Graduated</option>
                    </select>
                  </div>
                </div>
                <div className="flex flex-col-reverse sm:flex-row sm:justify-end gap-2 pt-2">
                  <button
                    type="button"
                    disabled={bulkBusy}
                    onClick={() => setBulkEditOpen(false)}
                    className="min-h-[42px] px-3.5 py-2 border border-slate-300 rounded-lg cursor-pointer"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    disabled={bulkBusy}
                    className="min-h-[42px] px-4 py-2 font-semibold text-white bg-[#1E3A5F] rounded-lg hover:bg-[#162D4A] disabled:opacity-50 cursor-pointer"
                  >
                    {bulkBusy ? 'Updating...' : 'Apply Changes'}
                  </button>
                </div>
              </form>
            </div>
          )}

          {/* Add/Edit Student Modal */}
          {formOpen && (
            <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/50 p-4">
              <form
                onSubmit={handleSaveStudent}
                className="bg-white border border-slate-200 rounded-xl w-full max-w-lg max-h-[90vh] overflow-y-auto p-6 space-y-4 shadow-xl"
              >
                <div className="flex items-center justify-between">
                  <h3 className="text-base font-bold text-slate-900">
                    {editingStudent ? 'Edit Student Record' : 'Enroll New Student'}
                  </h3>
                  <button type="button" onClick={() => setFormOpen(false)} className="text-slate-400 hover:text-slate-700 cursor-pointer">
                    <X className="w-4 h-4" />
                  </button>
                </div>
                {modalError && (
                  <div className="p-2.5 rounded-lg bg-red-50 border border-red-200 text-xs font-medium text-red-900">
                    {modalError}
                  </div>
                )}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                  <div className="sm:col-span-2 p-3 rounded-lg bg-slate-50 border border-slate-200 space-y-1.5">
                    <label className="block font-semibold text-slate-700">
                      Student Photo (Optional · File or Live Camera · Under 100 KB)
                    </label>
                    <StudentPhotoField
                      value={formData.photoUrl}
                      studentName={formData.fullName}
                      onChange={(nextUrl) => setFormData((prev) => ({ ...prev, photoUrl: nextUrl }))}
                      onError={(msg) => setModalError(msg)}
                    />
                  </div>
                  <div>
                    <label className="block font-semibold text-slate-700 mb-1">Student ID (Auto if blank)</label>
                    <input
                      type="text"
                      value={formData.studentCode}
                      onChange={(e) => setFormData({ ...formData, studentCode: e.target.value })}
                      placeholder="e.g. ST242"
                      className="w-full min-h-[42px] px-3 py-2 border border-slate-300 rounded-lg font-mono"
                    />
                  </div>
                  <div>
                    <label className="block font-semibold text-slate-700 mb-1">Roll Number *</label>
                    <input
                      type="number"
                      required
                      min={1}
                      value={formData.rollNumber}
                      onChange={(e) => setFormData({ ...formData, rollNumber: Number(e.target.value) })}
                      className="w-full min-h-[42px] px-3 py-2 border border-slate-300 rounded-lg font-mono"
                    />
                  </div>
                  <div className="sm:col-span-2">
                    <label className="block font-semibold text-slate-700 mb-1">Full Name *</label>
                    <input
                      type="text"
                      required
                      value={formData.fullName}
                      onChange={(e) => setFormData({ ...formData, fullName: e.target.value })}
                      className="w-full min-h-[42px] px-3 py-2 border border-slate-300 rounded-lg"
                    />
                  </div>
                  <div>
                    <label className="block font-semibold text-slate-700 mb-1">Class *</label>
                    <select
                      value={formData.classId}
                      onChange={(e) => {
                        const cid = Number(e.target.value);
                        const cls = schoolInfo.classes.find((c) => c.id === cid);
                        const nextSecId = cls?.sections[0]?.id || 1;
                        setFormData({
                          ...formData,
                          classId: cid,
                          sectionId: nextSecId,
                        });
                        if (!editingStudent) {
                          void computeNextRollNumber(cid, nextSecId, formData.academicYear);
                        }
                      }}
                      className="w-full min-h-[42px] px-3 py-2 border border-slate-300 rounded-lg bg-white"
                    >
                      {schoolInfo.classes.map((c) => (
                        <option key={c.id} value={c.id}>
                          {c.name}
                        </option>
                      ))}
                    </select>
                  </div>
                  <div>
                    <label className="block font-semibold text-slate-700 mb-1">Section *</label>
                    {formClassObj?.hasSections === false ? (
                      <div className="w-full min-h-[42px] px-3 py-2 border border-slate-200 rounded-lg bg-slate-50 text-slate-600 flex items-center">
                        Single Cohort (No Sections)
                      </div>
                    ) : (
                      <select
                        value={formData.sectionId}
                        onChange={(e) => {
                          const sid = Number(e.target.value);
                          setFormData({ ...formData, sectionId: sid });
                          if (!editingStudent) {
                            void computeNextRollNumber(formData.classId, sid, formData.academicYear);
                          }
                        }}
                        className="w-full min-h-[42px] px-3 py-2 border border-slate-300 rounded-lg bg-white"
                      >
                        {formClassObj?.sections.map((s) => (
                          <option key={s.id} value={s.id}>
                            Section {s.name}
                          </option>
                        ))}
                      </select>
                    )}
                  </div>
                  <div>
                    <label className="block font-semibold text-slate-700 mb-1">Stream / Track (Class 11–12)</label>
                    <select
                      value={formData.stream}
                      onChange={(e) => setFormData({ ...formData, stream: e.target.value as StudentStream })}
                      className="w-full min-h-[42px] px-3 py-2 border border-slate-300 rounded-lg bg-white"
                    >
                      <option value="">No Stream (General / Standard)</option>
                      <option value="Science">Science</option>
                      <option value="Humanities">Humanities</option>
                    </select>
                  </div>
                  <div>
                    <label className="block font-semibold text-slate-700 mb-1">Academic Year</label>
                    <input
                      type="text"
                      value={formData.academicYear}
                      onChange={(e) => {
                        const yr = e.target.value;
                        setFormData({ ...formData, academicYear: yr });
                        if (!editingStudent && yr.trim()) {
                          void computeNextRollNumber(formData.classId, formData.sectionId, yr.trim());
                        }
                      }}
                      className="w-full min-h-[42px] px-3 py-2 border border-slate-300 rounded-lg font-mono"
                    />
                  </div>
                  <div>
                    <label className="block font-semibold text-slate-700 mb-1">Gender</label>
                    <select
                      value={formData.gender}
                      onChange={(e) => setFormData({ ...formData, gender: e.target.value })}
                      className="w-full min-h-[42px] px-3 py-2 border border-slate-300 rounded-lg bg-white"
                    >
                      <option value="Male">Male</option>
                      <option value="Female">Female</option>
                      <option value="Other">Other</option>
                    </select>
                  </div>
                  <div>
                    <label className="block font-semibold text-slate-700 mb-1">Father&apos;s Name (Optional)</label>
                    <input
                      type="text"
                      value={formData.fatherName}
                      onChange={(e) => setFormData({ ...formData, fatherName: e.target.value })}
                      placeholder="Optional"
                      className="w-full min-h-[42px] px-3 py-2 border border-slate-300 rounded-lg"
                    />
                  </div>
                  <div>
                    <label className="block font-semibold text-slate-700 mb-1">Mother&apos;s Name (Optional)</label>
                    <input
                      type="text"
                      value={formData.motherName}
                      onChange={(e) => setFormData({ ...formData, motherName: e.target.value })}
                      placeholder="Optional"
                      className="w-full min-h-[42px] px-3 py-2 border border-slate-300 rounded-lg"
                    />
                  </div>
                  <div>
                    <label className="block font-semibold text-slate-700 mb-1">Contact No. (Optional)</label>
                    <input
                      type="text"
                      value={formData.contactNo}
                      onChange={(e) => setFormData({ ...formData, contactNo: e.target.value })}
                      placeholder="Phone number"
                      className="w-full min-h-[42px] px-3 py-2 border border-slate-300 rounded-lg font-mono"
                    />
                  </div>
                  <div>
                    <label className="block font-semibold text-slate-700 mb-1">AAPAAR ID (Optional)</label>
                    <input
                      type="text"
                      value={formData.aapaarId}
                      onChange={(e) => setFormData({ ...formData, aapaarId: e.target.value })}
                      placeholder="12-digit AAPAAR ID"
                      className="w-full min-h-[42px] px-3 py-2 border border-slate-300 rounded-lg font-mono"
                    />
                  </div>
                  <div className="sm:col-span-2">
                    <label className="block font-semibold text-slate-700 mb-1">Residential Address (Optional)</label>
                    <input
                      type="text"
                      value={formData.residentialAddress}
                      onChange={(e) => setFormData({ ...formData, residentialAddress: e.target.value })}
                      placeholder="Village / Town / District"
                      className="w-full min-h-[42px] px-3 py-2 border border-slate-300 rounded-lg"
                    />
                  </div>
                  <div>
                    <label className="block font-semibold text-slate-700 mb-1">Guardian Name</label>
                    <input
                      type="text"
                      value={formData.guardianName}
                      onChange={(e) => setFormData({ ...formData, guardianName: e.target.value })}
                      className="w-full min-h-[42px] px-3 py-2 border border-slate-300 rounded-lg"
                    />
                  </div>
                  <div>
                    <label className="block font-semibold text-slate-700 mb-1">Guardian Phone</label>
                    <input
                      type="text"
                      value={formData.guardianPhone}
                      onChange={(e) => setFormData({ ...formData, guardianPhone: e.target.value })}
                      className="w-full min-h-[42px] px-3 py-2 border border-slate-300 rounded-lg"
                    />
                  </div>
                  {editingStudent && (
                    <div className="sm:col-span-2">
                      <label className="block font-semibold text-slate-700 mb-1">Enrollment Status</label>
                      <select
                        value={formData.status}
                        onChange={(e) => setFormData({ ...formData, status: e.target.value })}
                        className="w-full min-h-[42px] px-3 py-2 border border-slate-300 rounded-lg bg-white"
                      >
                        <option value="active">Active</option>
                        <option value="inactive">Inactive</option>
                        <option value="transferred">Transferred</option>
                        <option value="promoted">Promoted</option>
                        <option value="graduated">Graduated</option>
                      </select>
                    </div>
                  )}
                  {formElectiveSubjects.map((es) => (
                    <div key={es.id} className="sm:col-span-2">
                      <label className="block font-semibold text-slate-700 mb-1">
                        {es.name} Elective / Optional Language
                      </label>
                      <select
                        value={
                          electiveSelections[es.id] !== undefined
                            ? electiveSelections[es.id]
                            : es.components[0]?.id || ''
                        }
                        onChange={(e) =>
                          setElectiveSelections((prev) => ({
                            ...prev,
                            [es.id]: Number(e.target.value),
                          }))
                        }
                        className="w-full min-h-[42px] px-3 py-2 border border-slate-300 rounded-lg bg-white"
                      >
                        <option value={-1}>None / Opt Out (Not Taking This Subject)</option>
                        {es.components.map((c) => (
                          <option key={c.id} value={c.id}>
                            {c.name} ({c.code})
                          </option>
                        ))}
                      </select>
                    </div>
                  ))}
                  {formApplicableSubjects.length > 0 && (
                    <div className="sm:col-span-2 p-3 bg-slate-50 border border-slate-200 rounded-lg space-y-2">
                      <div className="flex flex-wrap items-center justify-between gap-2">
                        <div>
                          <div className="font-semibold text-slate-800">
                            Subject Combination ({enrolledSubjectIds.length === 0 ? 'All Applicable Class Subjects' : `${enrolledSubjectIds.length} Custom Selected`})
                          </div>
                          <div className="text-[11px] text-slate-500">
                            Leave unchecked for default class subjects, or tick specific Science/Humanities/IT/combined subjects.
                          </div>
                        </div>
                        <div className="flex flex-wrap gap-1.5">
                          {(formData.stream === 'Science' || formData.stream === 'Humanities') && (
                            <button
                              type="button"
                              onClick={() => {
                                const picked = formApplicableSubjects
                                  .filter(
                                    (s) =>
                                      electiveSelections[s.id] !== -1 &&
                                      (s.streamCategory === 'Common' ||
                                        s.streamCategory === formData.stream ||
                                        !s.streamCategory)
                                  )
                                  .map((s) => s.id);
                                setEnrolledSubjectIds(picked);
                              }}
                              className="px-2 py-1 text-[11px] font-medium bg-indigo-50 text-indigo-800 border border-indigo-200 rounded hover:bg-indigo-100 cursor-pointer"
                            >
                              Auto-Pick {formData.stream}
                            </button>
                          )}
                          {enrolledSubjectIds.length > 0 && (
                            <button
                              type="button"
                              onClick={() => setEnrolledSubjectIds([])}
                              className="px-2 py-1 text-[11px] font-medium bg-white text-slate-700 border border-slate-300 rounded hover:bg-slate-100 cursor-pointer"
                            >
                              Reset to All
                            </button>
                          )}
                        </div>
                      </div>
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-1.5 max-h-40 overflow-y-auto pt-1">
                        {formApplicableSubjects.map((sub) => {
                          const isOptedOutElective = electiveSelections[sub.id] === -1;
                          const checked = enrolledSubjectIds.includes(sub.id);
                          return (
                            <label
                              key={sub.id}
                              className={`flex items-center justify-between gap-2 px-2.5 py-1.5 rounded border text-[11px] cursor-pointer ${
                                isOptedOutElective
                                  ? 'bg-slate-100 border-slate-200 text-slate-400 cursor-not-allowed'
                                  : checked
                                    ? 'bg-indigo-50/70 border-indigo-300 text-indigo-950 font-medium'
                                    : 'bg-white border-slate-200 text-slate-700'
                              }`}
                            >
                              <span className="flex items-center gap-1.5 truncate">
                                <input
                                  type="checkbox"
                                  disabled={isOptedOutElective}
                                  checked={checked}
                                  onChange={(e) => {
                                    setEnrolledSubjectIds((prev) =>
                                      e.target.checked
                                        ? [...prev, sub.id]
                                        : prev.filter((id) => id !== sub.id)
                                    );
                                  }}
                                />
                                <span className="truncate">{sub.name}</span>
                              </span>
                              <span className="flex items-center gap-1 shrink-0 text-[10px]">
                                {sub.streamCategory && (
                                  <span className="px-1 py-0.5 rounded bg-slate-100 text-slate-600">
                                    {sub.streamCategory}
                                  </span>
                                )}
                                {sub.hasPractical && (
                                  <span className="px-1 py-0.5 rounded bg-sky-50 text-sky-700">Pr</span>
                                )}
                              </span>
                            </label>
                          );
                        })}
                      </div>
                    </div>
                  )}
                </div>
                <div className="flex flex-col-reverse sm:flex-row sm:justify-end gap-2 pt-2">
                  <button
                    type="button"
                    disabled={saving}
                    onClick={() => setFormOpen(false)}
                    className="min-h-[42px] px-3.5 py-2 text-xs font-medium border border-slate-300 rounded-lg cursor-pointer"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    disabled={saving}
                    className="min-h-[42px] px-4 py-2 text-xs font-semibold text-white bg-[#1E3A5F] rounded-lg hover:bg-[#162D4A] disabled:opacity-50 cursor-pointer"
                  >
                    {saving ? 'Saving...' : editingStudent ? 'Save Changes' : 'Create Student'}
                  </button>
                </div>
              </form>
            </div>
          )}

          {/* Transfer Modal */}
          {transferStudent && (
            <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/50 p-4">
              <form
                onSubmit={handleTransfer}
                className="bg-white border border-slate-200 rounded-xl w-full max-w-md max-h-[90vh] overflow-y-auto p-6 space-y-4 shadow-xl"
              >
                <h3 className="text-base font-bold text-slate-900">Transfer Student</h3>
                <p className="text-xs text-slate-600">
                  Transfer <span className="font-semibold text-slate-900">{transferStudent.full_name}</span> (
                  {transferStudent.student_code}) from{' '}
                  {formatClassSectionLabel(
                    transferStudent.class_name,
                    transferStudent.section_name,
                    transferStudent.hasSections
                  )}
                  .
                </p>
                {modalError && (
                  <div className="p-2.5 rounded-lg bg-red-50 border border-red-200 text-xs font-medium text-red-900">
                    {modalError}
                  </div>
                )}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                  <div>
                    <label className="block font-semibold text-slate-700 mb-1">Target Class</label>
                    <select
                      value={transferData.targetClassId}
                      onChange={(e) => {
                        const cid = Number(e.target.value);
                        const cls = schoolInfo.classes.find((c) => c.id === cid);
                        setTransferData({
                          ...transferData,
                          targetClassId: cid,
                          targetSectionId: cls?.sections[0]?.id || 1,
                        });
                      }}
                      className="w-full min-h-[42px] px-3 py-2 border border-slate-300 rounded-lg bg-white"
                    >
                      {schoolInfo.classes.map((c) => (
                        <option key={c.id} value={c.id}>
                          {c.name}
                        </option>
                      ))}
                    </select>
                  </div>
                  <div>
                    <label className="block font-semibold text-slate-700 mb-1">Target Section</label>
                    {transferClassObj?.hasSections === false ? (
                      <div className="w-full min-h-[42px] px-3 py-2 border border-slate-200 rounded-lg bg-slate-50 text-slate-600 flex items-center">
                        Single Cohort (No Sections)
                      </div>
                    ) : (
                      <select
                        value={transferData.targetSectionId}
                        onChange={(e) => setTransferData({ ...transferData, targetSectionId: Number(e.target.value) })}
                        className="w-full min-h-[42px] px-3 py-2 border border-slate-300 rounded-lg bg-white"
                      >
                        {transferClassObj?.sections.map((s) => (
                          <option key={s.id} value={s.id}>
                            Section {s.name}
                          </option>
                        ))}
                      </select>
                    )}
                  </div>
                  <div className="sm:col-span-2">
                    <label className="block font-semibold text-slate-700 mb-1">
                      New Roll Number (Leave blank to auto-assign next available)
                    </label>
                    <input
                      type="number"
                      min={1}
                      value={transferData.newRollNumber}
                      onChange={(e) => setTransferData({ ...transferData, newRollNumber: e.target.value })}
                      placeholder="Auto-assign"
                      className="w-full min-h-[42px] px-3 py-2 border border-slate-300 rounded-lg font-mono"
                    />
                  </div>
                </div>
                <div className="flex flex-col-reverse sm:flex-row sm:justify-end gap-2 pt-2">
                  <button
                    type="button"
                    disabled={saving}
                    onClick={() => setTransferStudent(null)}
                    className="min-h-[42px] px-3.5 py-2 text-xs font-medium border border-slate-300 rounded-lg cursor-pointer"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    disabled={saving}
                    className="min-h-[42px] px-4 py-2 text-xs font-semibold text-white bg-[#1E3A5F] rounded-lg hover:bg-[#162D4A] disabled:opacity-50 cursor-pointer"
                  >
                    {saving ? 'Transferring...' : 'Confirm Transfer'}
                  </button>
                </div>
              </form>
            </div>
          )}
        </>
      )}
    </div>
  );
}
