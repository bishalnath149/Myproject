import React, { useState } from 'react';

export interface ChartSlice {
  label: string;
  value: number;
  color?: string;
  sublabel?: string;
  id?: number | string;
}

export interface BarItem {
  label: string;
  value: number;
  maxValue?: number;
  unit?: string;
  sublabel?: string;
  color?: string;
  id?: number | string;
  secondaryValue?: number;
  secondaryLabel?: string;
}

export const CHART_PALETTE = [
  '#2563EB', // Royal Blue
  '#10B981', // Emerald
  '#F59E0B', // Amber
  '#8B5CF6', // Violet
  '#EC4899', // Pink
  '#06B6D4', // Cyan
  '#F97316', // Orange
  '#14B8A6', // Teal
  '#6366F1', // Indigo
  '#84CC16', // Lime
];

function polarToCartesian(cx: number, cy: number, r: number, angleDeg: number) {
  const rad = ((angleDeg - 90) * Math.PI) / 180;
  return {
    x: cx + r * Math.cos(rad),
    y: cy + r * Math.sin(rad),
  };
}

function describeArc(cx: number, cy: number, rOuter: number, rInner: number, startAngle: number, endAngle: number) {
  const sweep = Math.min(359.99, Math.max(0.01, endAngle - startAngle));
  const adjustedEnd = startAngle + sweep;
  const startOuter = polarToCartesian(cx, cy, rOuter, adjustedEnd);
  const endOuter = polarToCartesian(cx, cy, rOuter, startAngle);
  const startInner = polarToCartesian(cx, cy, rInner, adjustedEnd);
  const endInner = polarToCartesian(cx, cy, rInner, startAngle);
  const largeArc = sweep <= 180 ? '0' : '1';

  if (rInner <= 0) {
    return [
      `M ${cx} ${cy}`,
      `L ${endOuter.x} ${endOuter.y}`,
      `A ${rOuter} ${rOuter} 0 ${largeArc} 1 ${startOuter.x} ${startOuter.y}`,
      'Z',
    ].join(' ');
  }

  return [
    `M ${startOuter.x} ${startOuter.y}`,
    `A ${rOuter} ${rOuter} 0 ${largeArc} 0 ${endOuter.x} ${endOuter.y}`,
    `L ${endInner.x} ${endInner.y}`,
    `A ${rInner} ${rInner} 0 ${largeArc} 1 ${startInner.x} ${startInner.y}`,
    'Z',
  ].join(' ');
}

export function InteractiveDonutChart({
  title,
  subtitle,
  data,
  variant = 'donut',
  valueUnit = '',
  centerLabel,
  onSelectSlice,
}: {
  title: string;
  subtitle?: string;
  data: ChartSlice[];
  variant?: 'pie' | 'donut';
  valueUnit?: string;
  centerLabel?: string;
  onSelectSlice?: (slice: ChartSlice) => void;
}) {
  const [hoveredIdx, setHoveredIdx] = useState<number | null>(null);
  const [selectedIdx, setSelectedIdx] = useState<number | null>(null);

  const nonZero = data.filter((d) => d.value > 0);
  const total = nonZero.reduce((sum, d) => sum + d.value, 0);
  const activeIdx = hoveredIdx ?? selectedIdx;
  const activeSlice = activeIdx !== null ? nonZero[activeIdx] : null;

  let currentAngle = 0;
  const segments = nonZero.map((d, i) => {
    const pct = total > 0 ? (d.value / total) * 100 : 0;
    const sweep = total > 0 ? (d.value / total) * 360 : 0;
    const start = currentAngle;
    const end = currentAngle + sweep;
    currentAngle = end;
    return {
      ...d,
      color: d.color || CHART_PALETTE[i % CHART_PALETTE.length],
      pct,
      start,
      end,
    };
  });

  return (
    <div className="bg-white border border-slate-200 rounded-2xl p-4 sm:p-5 flex flex-col justify-between shadow-xs hover:shadow-md transition-shadow">
      <div className="flex items-start justify-between gap-2 mb-3">
        <div>
          <h3 className="text-sm font-bold text-slate-900">{title}</h3>
          {subtitle && <p className="text-[11px] text-slate-500 mt-0.5">{subtitle}</p>}
        </div>
        {activeSlice && (
          <div className="text-right bg-slate-900 text-white px-2.5 py-1 rounded-lg text-[11px] shrink-0">
            <div className="font-semibold truncate max-w-[130px]">{activeSlice.label}</div>
            <div className="font-mono tabular-nums text-sky-300">
              {activeSlice.value}
              {valueUnit} ({total > 0 ? ((activeSlice.value / total) * 100).toFixed(1) : 0}%)
            </div>
          </div>
        )}
      </div>

      {total === 0 ? (
        <div className="h-44 flex items-center justify-center text-xs text-slate-400 bg-slate-50 rounded-xl border border-dashed border-slate-200">
          No recorded data for selected filter
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-12 gap-3 items-center">
          <div className="sm:col-span-5 flex items-center justify-center">
            <svg viewBox="0 0 180 180" className="w-40 h-40 overflow-visible">
              {segments.map((seg, idx) => {
                const isActive = activeIdx === idx;
                const rOuter = isActive ? 78 : 72;
                const rInner = variant === 'donut' ? 44 : 0;
                return (
                  <path
                    key={`${seg.label}-${idx}`}
                    d={describeArc(90, 90, rOuter, rInner, seg.start, seg.end)}
                    fill={seg.color}
                    stroke="#ffffff"
                    strokeWidth={1.5}
                    className="transition-all duration-150 cursor-pointer"
                    style={{ opacity: activeIdx !== null && !isActive ? 0.65 : 1 }}
                    onMouseEnter={() => setHoveredIdx(idx)}
                    onMouseLeave={() => setHoveredIdx(null)}
                    onClick={() => {
                      setSelectedIdx(selectedIdx === idx ? null : idx);
                      onSelectSlice?.(seg);
                    }}
                  />
                );
              })}
              {variant === 'donut' && (
                <g className="pointer-events-none">
                  <text
                    x="90"
                    y="86"
                    textAnchor="middle"
                    className="fill-slate-900 font-bold text-lg font-mono"
                  >
                    {activeSlice ? `${activeSlice.value}${valueUnit}` : `${total}${valueUnit}`}
                  </text>
                  <text
                    x="90"
                    y="104"
                    textAnchor="middle"
                    className="fill-slate-500 text-[10px] font-medium"
                  >
                    {activeSlice
                      ? `${((activeSlice.value / total) * 100).toFixed(1)}%`
                      : centerLabel || 'Total'}
                  </text>
                </g>
              )}
            </svg>
          </div>

          <div className="sm:col-span-7 space-y-1.5 max-h-44 overflow-y-auto pr-1">
            {segments.map((seg, idx) => {
              const isActive = activeIdx === idx;
              return (
                <button
                  key={`${seg.label}-${idx}`}
                  type="button"
                  onMouseEnter={() => setHoveredIdx(idx)}
                  onMouseLeave={() => setHoveredIdx(null)}
                  onClick={() => {
                    setSelectedIdx(selectedIdx === idx ? null : idx);
                    onSelectSlice?.(seg);
                  }}
                  className={`w-full flex items-center justify-between gap-2 px-2 py-1 rounded-lg text-left text-xs transition-colors cursor-pointer ${
                    isActive ? 'bg-slate-100 ring-1 ring-slate-300' : 'hover:bg-slate-50'
                  }`}
                >
                  <span className="flex items-center gap-2 min-w-0">
                    <span
                      className="w-2.5 h-2.5 rounded-full shrink-0"
                      style={{ backgroundColor: seg.color }}
                    />
                    <span className="truncate font-medium text-slate-700">{seg.label}</span>
                  </span>
                  <span className="font-mono tabular-nums text-[11px] font-semibold text-slate-900 shrink-0">
                    {seg.value}
                    {valueUnit}{' '}
                    <span className="text-slate-500 font-normal">({seg.pct.toFixed(1)}%)</span>
                  </span>
                </button>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
}

export function InteractiveBarChart({
  title,
  subtitle,
  items,
  maxScale = 100,
  unit = '%',
  onSelectBar,
}: {
  title: string;
  subtitle?: string;
  items: BarItem[];
  maxScale?: number;
  unit?: string;
  onSelectBar?: (item: BarItem) => void;
}) {
  const [hoveredIdx, setHoveredIdx] = useState<number | null>(null);
  const activeItem = hoveredIdx !== null ? items[hoveredIdx] : null;
  const computedMax = maxScale > 0 ? maxScale : Math.max(1, ...items.map((i) => i.maxValue || i.value));

  return (
    <div className="bg-white border border-slate-200 rounded-2xl p-4 sm:p-5 flex flex-col justify-between shadow-xs hover:shadow-md transition-shadow">
      <div className="flex items-start justify-between gap-2 mb-3">
        <div>
          <h3 className="text-sm font-bold text-slate-900">{title}</h3>
          {subtitle && <p className="text-[11px] text-slate-500 mt-0.5">{subtitle}</p>}
        </div>
        {activeItem && (
          <div className="text-right bg-slate-900 text-white px-2.5 py-1 rounded-lg text-[11px] shrink-0">
            <div className="font-semibold truncate max-w-[160px]">{activeItem.label}</div>
            <div className="font-mono tabular-nums text-emerald-300">
              {activeItem.value}
              {activeItem.unit ?? unit}
              {activeItem.sublabel ? ` · ${activeItem.sublabel}` : ''}
            </div>
          </div>
        )}
      </div>

      {items.length === 0 ? (
        <div className="h-44 flex items-center justify-center text-xs text-slate-400 bg-slate-50 rounded-xl border border-dashed border-slate-200">
          No evaluated records yet for selected filter
        </div>
      ) : (
        <div className="space-y-2.5 max-h-60 overflow-y-auto pr-1">
          {items.map((item, idx) => {
            const denom = item.maxValue || computedMax;
            const widthPct = Math.min(100, Math.max(0, (item.value / denom) * 100));
            const color = item.color || CHART_PALETTE[idx % CHART_PALETTE.length];
            const isActive = hoveredIdx === idx;

            return (
              <button
                key={`${item.label}-${idx}`}
                type="button"
                onMouseEnter={() => setHoveredIdx(idx)}
                onMouseLeave={() => setHoveredIdx(null)}
                onClick={() => onSelectBar?.(item)}
                className={`w-full text-left p-1.5 rounded-lg transition-colors cursor-pointer ${
                  isActive ? 'bg-slate-50' : 'hover:bg-slate-50/70'
                }`}
              >
                <div className="flex items-center justify-between gap-2 text-xs mb-1">
                  <span className="font-medium text-slate-800 truncate">{item.label}</span>
                  <span className="font-mono tabular-nums text-[11px] font-semibold text-slate-900 shrink-0">
                    {item.value}
                    {item.unit ?? unit}
                    {item.sublabel && (
                      <span className="text-slate-500 font-normal ml-1.5">({item.sublabel})</span>
                    )}
                  </span>
                </div>
                <div className="h-3 w-full bg-slate-100 rounded-full overflow-hidden">
                  <div
                    className="h-full rounded-full transition-all duration-300"
                    style={{
                      width: `${widthPct}%`,
                      backgroundColor: color,
                      opacity: hoveredIdx !== null && !isActive ? 0.7 : 1,
                    }}
                  />
                </div>
              </button>
            );
          })}
        </div>
      )}
    </div>
  );
}
