import React, { useEffect, useMemo, useRef, useState } from 'react';
import {
  FileDown,
  FileSpreadsheet,
  Search,
  Layers,
  BarChart3,
  Users,
  GitCompare,
  Award,
  AlertTriangle,
  RefreshCw,
  CheckCircle2,
  GraduationCap,
  UserRound,
} from 'lucide-react';
import type {
  AdminSubjectExcelPayload,
  CombinedTermClassReport,
  ConsolidatedClassReport,
  ConsolidatedStudentResult,
  ExaminationRecord,
  SchoolInfo,
} from '../types';
import { apiFetch, extractErrorMessage, isAbortError } from '../lib/api';
import { calculateSubjectGrade, formatClassSectionLabel, getGradeBadgeClass } from '../lib/grading';
import {
  exportAdminSubjectReportExcel,
  exportClassAllFinalMarksheetsPDF,
  exportClassConsolidatedPDF,
  exportCombinedReportCardPDF,
  exportConsolidatedExcel,
  exportIndividualReportCardPDF,
  exportSubjectWiseExcel,
  exportSubjectWisePDF,
  type BatchFinalMarksheetEntry,
} from '../lib/exports';
import { ResultStatusLabel } from './StatusIndicator';
import { StudentReportCardModal } from './StudentReportCardModal';
import { ClassWisePromotionPanel } from './ClassWisePromotionPanel';
import { CoScholasticGradesPanel } from './CoScholasticGradesPanel';
import { ClassTeacherStudentDetailsPanel } from './ClassTeacherStudentDetailsPanel';

interface SectionOption {
  classId: number;
  className: string;
  hasSections?: boolean;
  sectionId: number;
  sectionName: string;
}

interface ExamComparisonItem {
  examinationId: number;
  examinationName: string;
  status: string;
  completedCount: number;
  totalStudents: number;
  classAveragePercentage: number | null;
  passCount: number;
  failCount: number;
  subjectPerformance: ConsolidatedClassReport['subjectPerformance'];
}

export function ClassTeacherWorkspace({
  title = 'Class Teacher — Consolidated Results & Performance',
  allowedSections,
  classTeacherAssignments,
  examinations,
  schoolInfo,
  selectedAcademicYear,
  activeTab,
  onTabChange,
  onPromotionChanged,
  isAdminView = false,
}: {
  title?: string;
  allowedSections: SectionOption[];
  classTeacherAssignments?: Array<{
    class_id: number;
    class_name: string;
    has_sections?: number | boolean;
    section_id: number;
    section_name: string;
    academic_year: string;
  }>;
  examinations: ExaminationRecord[];
  schoolInfo: SchoolInfo;
  selectedAcademicYear?: string;
  activeTab:
    | 'consolidated'
    | 'students'
    | 'student-details'
    | 'co-scholastic'
    | 'analysis'
    | 'comparison'
    | 'promotion';
  onTabChange: (
    tab:
      | 'consolidated'
      | 'students'
      | 'student-details'
      | 'co-scholastic'
      | 'analysis'
      | 'comparison'
      | 'promotion'
  ) => void;
  onPromotionChanged?: () => Promise<void> | void;
  isAdminView?: boolean;
}) {
  const [yearFilter, setYearFilter] = useState<string>(
    selectedAcademicYear || schoolInfo.currentAcademicYear
  );
  const [selectedSectionKey, setSelectedSectionKey] = useState<string>(() => {
    const first = allowedSections[0];
    return first ? `${first.classId}:${first.sectionId}` : '';
  });

  const availableYears = useMemo(() => {
    const set = new Set<string>();
    for (const ay of schoolInfo.academicYears || []) set.add(ay.name);
    for (const ex of examinations) set.add(ex.academic_year);
    if (schoolInfo.currentAcademicYear) set.add(schoolInfo.currentAcademicYear);
    return Array.from(set).sort((a, b) => b.localeCompare(a));
  }, [schoolInfo.academicYears, schoolInfo.currentAcademicYear, examinations]);

  const filteredExaminations = useMemo(() => {
    if (yearFilter === 'ALL') return examinations;
    return examinations.filter((e) => e.academic_year === yearFilter);
  }, [examinations, yearFilter]);

  const [selectedExamId, setSelectedExamId] = useState<number>(() => {
    const initialPool =
      yearFilter === 'ALL'
        ? examinations
        : examinations.filter((e) => e.academic_year === yearFilter);
    const preferred =
      initialPool.find((e) => e.name.toLowerCase().includes('half-yearly')) ||
      initialPool.find((e) => e.status === 'Published') ||
      initialPool[0];
    return preferred?.id || 0;
  });

  const [report, setReport] = useState<ConsolidatedClassReport | null>(null);
  const [combinedReport, setCombinedReport] = useState<CombinedTermClassReport | null>(null);
  const [comparison, setComparison] = useState<ExamComparisonItem[]>([]);
  const [comparisonError, setComparisonError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [showComponents, setShowComponents] = useState(false);
  const [statusFilter, setStatusFilter] = useState<'all' | 'Pass' | 'Fail' | 'Incomplete'>('all');
  const [selectedStudent, setSelectedStudent] = useState<ConsolidatedStudentResult | null>(null);
  const [modalInitialMode, setModalInitialMode] = useState<'term1' | 'combined'>('term1');
  const [exportingExcel, setExportingExcel] = useState(false);
  const [exportingAllMarksheets, setExportingAllMarksheets] = useState(false);
  const [exportNotice, setExportNotice] = useState<{ type: 'success' | 'error'; text: string } | null>(null);
  const [adminSubjectId, setAdminSubjectId] = useState<string>('');

  const reportSeqRef = useRef(0);
  const reportAbortRef = useRef<AbortController | null>(null);
  const combinedSeqRef = useRef(0);
  const combinedAbortRef = useRef<AbortController | null>(null);
  const compSeqRef = useRef(0);
  const compAbortRef = useRef<AbortController | null>(null);

  useEffect(() => {
    return () => {
      reportAbortRef.current?.abort();
      combinedAbortRef.current?.abort();
      compAbortRef.current?.abort();
    };
  }, []);

  useEffect(() => {
    if (selectedAcademicYear) {
      setYearFilter(selectedAcademicYear);
    }
  }, [selectedAcademicYear]);

  useEffect(() => {
    if (allowedSections.length === 0) {
      if (selectedSectionKey !== '') setSelectedSectionKey('');
      return;
    }
    const stillValid = allowedSections.some(
      (s) => `${s.classId}:${s.sectionId}` === selectedSectionKey
    );
    if (!stillValid) {
      setSelectedSectionKey(`${allowedSections[0].classId}:${allowedSections[0].sectionId}`);
    }
  }, [allowedSections, selectedSectionKey]);

  useEffect(() => {
    if (filteredExaminations.length === 0) {
      setSelectedExamId(0);
      setReport(null);
      return;
    }
    if (!filteredExaminations.some((e) => e.id === selectedExamId)) {
      const preferred =
        filteredExaminations.find((e) => e.status === 'Published') ||
        filteredExaminations.find((e) => e.name.toLowerCase().includes('half-yearly')) ||
        filteredExaminations[0];
      setSelectedExamId(preferred.id);
    }
  }, [filteredExaminations, selectedExamId]);

  const parsedSection = useMemo(() => {
    if (!selectedSectionKey) return null;
    const [cid, sid] = selectedSectionKey.split(':').map(Number);
    return allowedSections.find((s) => s.classId === cid && s.sectionId === sid) || null;
  }, [selectedSectionKey, allowedSections]);

  const currentClassSections = useMemo(() => {
    if (!parsedSection) return [];
    return allowedSections.filter((s) => s.classId === parsedSection.classId);
  }, [allowedSections, parsedSection]);

  const loadReport = async () => {
    reportAbortRef.current?.abort();
    if (!parsedSection || !selectedExamId) {
      setReport(null);
      return;
    }
    const controller = new AbortController();
    reportAbortRef.current = controller;
    const seq = ++reportSeqRef.current;

    setLoading(true);
    setError(null);
    try {
      const data = await apiFetch<ConsolidatedClassReport>(
        `/api/results/consolidated?examinationId=${selectedExamId}&classId=${parsedSection.classId}&sectionId=${parsedSection.sectionId}`,
        { signal: controller.signal }
      );
      if (seq !== reportSeqRef.current) return;
      setReport(data);
    } catch (err: unknown) {
      if (isAbortError(err) || seq !== reportSeqRef.current) return;
      setReport(null);
      setError(extractErrorMessage(err, 'Could not load consolidated results.'));
    } finally {
      if (seq === reportSeqRef.current) {
        setLoading(false);
      }
    }
  };

  const loadCombinedReport = async () => {
    combinedAbortRef.current?.abort();
    if (!parsedSection) {
      setCombinedReport(null);
      return;
    }
    const controller = new AbortController();
    combinedAbortRef.current = controller;
    const seq = ++combinedSeqRef.current;

    const qs = new URLSearchParams({
      classId: String(parsedSection.classId),
      sectionId: String(parsedSection.sectionId),
    });
    if (yearFilter && yearFilter !== 'ALL') {
      qs.set('academicYear', yearFilter);
    } else if (selectedExamId) {
      qs.set('examinationId', String(selectedExamId));
    }

    try {
      const data = await apiFetch<CombinedTermClassReport>(`/api/results/combined?${qs.toString()}`, {
        signal: controller.signal,
      });
      if (seq !== combinedSeqRef.current) return;
      setCombinedReport(data);
    } catch (err: unknown) {
      if (isAbortError(err) || seq !== combinedSeqRef.current) return;
      setCombinedReport(null);
    }
  };

  useEffect(() => {
    loadReport();
    loadCombinedReport();
  }, [parsedSection?.classId, parsedSection?.sectionId, selectedExamId, yearFilter]);

  const loadComparison = async () => {
    compAbortRef.current?.abort();
    if (!parsedSection) return;
    const controller = new AbortController();
    compAbortRef.current = controller;
    const seq = ++compSeqRef.current;

    setComparisonError(null);
    const qs = new URLSearchParams({
      classId: String(parsedSection.classId),
      sectionId: String(parsedSection.sectionId),
    });
    if (yearFilter !== 'ALL') {
      qs.set('academicYear', yearFilter);
    }
    try {
      const data = await apiFetch<ExamComparisonItem[]>(`/api/results/exam-comparison?${qs.toString()}`, {
        signal: controller.signal,
      });
      if (seq !== compSeqRef.current) return;
      setComparison(data);
    } catch (err: unknown) {
      if (isAbortError(err) || seq !== compSeqRef.current) return;
      setComparison([]);
      setComparisonError(extractErrorMessage(err, 'Could not load examination comparison.'));
    }
  };

  useEffect(() => {
    if (activeTab === 'comparison' && parsedSection) {
      loadComparison();
    }
  }, [activeTab, parsedSection?.classId, parsedSection?.sectionId, yearFilter]);

  const filteredStudents = useMemo(() => {
    if (!report) return [];
    const q = searchQuery.trim().toLowerCase();
    return report.students.filter((st) => {
      if (statusFilter !== 'all' && st.resultStatus !== statusFilter) return false;
      if (!q) return true;
      return (
        st.studentName.toLowerCase().includes(q) ||
        st.studentCode.toLowerCase().includes(q) ||
        String(st.rollNumber).includes(q)
      );
    });
  }, [report, searchQuery, statusFilter]);

  const examSubjectOptions = useMemo(() => {
    const ex = examinations.find((e) => e.id === selectedExamId);
    if (ex?.subjects?.length) {
      return ex.subjects.map((s) => ({ id: s.subject_id, name: s.subject_name }));
    }
    if (report?.subjects?.length) {
      return report.subjects.map((s) => ({ id: s.subjectId, name: s.subjectName }));
    }
    return [];
  }, [examinations, selectedExamId, report]);

  if (allowedSections.length === 0) {
    return (
      <div className="bg-white border border-slate-200 rounded-xl p-10 text-center text-sm text-slate-500">
        No class teacher section is assigned to this account.
      </div>
    );
  }

  const handleDownloadClassExcel = async () => {
    if (!report) return;
    setExportingExcel(true);
    setExportNotice(null);
    try {
      const filename = await exportConsolidatedExcel(report, schoolInfo);
      setExportNotice({ type: 'success', text: `Downloaded class result Excel: ${filename}` });
    } catch (err: unknown) {
      setExportNotice({ type: 'error', text: extractErrorMessage(err, 'Failed to export class Excel.') });
    } finally {
      setExportingExcel(false);
    }
  };

  const handleDownloadSubjectExcel = async (subjectId: number) => {
    if (!report) return;
    setExportingExcel(true);
    setExportNotice(null);
    try {
      const filename = await exportSubjectWiseExcel(report, subjectId, schoolInfo);
      if (filename) {
        setExportNotice({ type: 'success', text: `Downloaded subject Excel: ${filename}` });
      }
    } catch (err: unknown) {
      setExportNotice({ type: 'error', text: extractErrorMessage(err, 'Failed to export subject Excel.') });
    } finally {
      setExportingExcel(false);
    }
  };

  const handleDownloadAdminSubjectExcel = async () => {
    if (!selectedExamId) return;
    setExportingExcel(true);
    setExportNotice(null);
    try {
      const qs = new URLSearchParams({ examinationId: String(selectedExamId) });
      if (adminSubjectId) qs.set('subjectId', adminSubjectId);
      const payload = await apiFetch<AdminSubjectExcelPayload>(`/api/admin/results/subject-excel?${qs.toString()}`);
      if (!payload.sections || payload.sections.length === 0) {
        setExportNotice({ type: 'error', text: 'No matching subject records found for export.' });
        return;
      }
      const filename = await exportAdminSubjectReportExcel(payload, schoolInfo);
      setExportNotice({ type: 'success', text: `Downloaded subject report: ${filename}` });
    } catch (err: unknown) {
      setExportNotice({ type: 'error', text: extractErrorMessage(err, 'Failed to export subject report.') });
    } finally {
      setExportingExcel(false);
    }
  };

  const handleDownloadSectionFinalMarksheets = async () => {
    if (!parsedSection) return;
    setExportingAllMarksheets(true);
    setExportNotice(null);
    try {
      const entries: BatchFinalMarksheetEntry[] = [];
      if (combinedReport && combinedReport.students.length > 0 && (combinedReport.term1Exam || combinedReport.term2Exam)) {
        for (const student of combinedReport.students) {
          entries.push({ mode: 'combined', student, report: combinedReport });
        }
      } else if (report && report.students.length > 0) {
        for (const student of report.students) {
          entries.push({ mode: 'single', student, report });
        }
      }

      if (entries.length === 0) {
        setExportNotice({ type: 'error', text: 'No student marksheet records found for this class/section.' });
        return;
      }

      const sectionLabel = formatClassSectionLabel(
        parsedSection.className,
        parsedSection.sectionName,
        parsedSection.hasSections ?? true
      );
      const yearLabel =
        combinedReport?.academicYear ||
        report?.examination.academicYear ||
        (yearFilter !== 'ALL' ? yearFilter : schoolInfo.currentAcademicYear);
      const filename = await exportClassAllFinalMarksheetsPDF(
        entries,
        schoolInfo,
        `${sectionLabel}_Final_Marksheets_${yearLabel}`
      );
      setExportNotice({
        type: 'success',
        text: `Downloaded ${entries.length} complete final marksheets in 1 PDF: ${filename}`,
      });
    } catch (err: unknown) {
      setExportNotice({
        type: 'error',
        text: extractErrorMessage(err, 'Failed to export class final marksheets PDF.'),
      });
    } finally {
      setExportingAllMarksheets(false);
    }
  };

  const handleDownloadWholeClassFinalMarksheets = async () => {
    if (!parsedSection || currentClassSections.length === 0) return;
    setExportingAllMarksheets(true);
    setExportNotice(null);
    try {
      const entries: BatchFinalMarksheetEntry[] = [];
      for (const sec of currentClassSections) {
        const qs = new URLSearchParams({
          classId: String(sec.classId),
          sectionId: String(sec.sectionId),
        });
        if (yearFilter && yearFilter !== 'ALL') {
          qs.set('academicYear', yearFilter);
        } else if (selectedExamId) {
          qs.set('examinationId', String(selectedExamId));
        }

        let addedFromCombined = false;
        try {
          const comb = await apiFetch<CombinedTermClassReport>(`/api/results/combined?${qs.toString()}`);
          if (comb.students.length > 0 && (comb.term1Exam || comb.term2Exam)) {
            for (const student of comb.students) {
              entries.push({ mode: 'combined', student, report: comb });
            }
            addedFromCombined = true;
          }
        } catch {
          // fallback to single consolidated below
        }

        if (!addedFromCombined && selectedExamId > 0) {
          const single = await apiFetch<ConsolidatedClassReport>(
            `/api/results/consolidated?examinationId=${selectedExamId}&classId=${sec.classId}&sectionId=${sec.sectionId}`
          );
          for (const student of single.students) {
            entries.push({ mode: 'single', student, report: single });
          }
        }
      }

      if (entries.length === 0) {
        setExportNotice({ type: 'error', text: `No student marksheets found across ${parsedSection.className}.` });
        return;
      }

      const yearLabel =
        (yearFilter !== 'ALL' ? yearFilter : report?.examination.academicYear) || schoolInfo.currentAcademicYear;
      const filename = await exportClassAllFinalMarksheetsPDF(
        entries,
        schoolInfo,
        `${parsedSection.className}_Whole_Class_All_Sections_Final_Marksheets_${yearLabel}`
      );
      setExportNotice({
        type: 'success',
        text: `Downloaded ${entries.length} complete final marksheets across ${currentClassSections.length} sections of ${parsedSection.className}: ${filename}`,
      });
    } catch (err: unknown) {
      setExportNotice({
        type: 'error',
        text: extractErrorMessage(err, 'Failed to export whole-class final marksheets PDF.'),
      });
    } finally {
      setExportingAllMarksheets(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Header & Exports */}
      <div className="flex flex-wrap items-center justify-between gap-4 border-b border-slate-200 pb-4">
        <div>
          <h1 className="text-xl font-bold text-slate-900 tracking-tight">
            {activeTab === 'promotion' ? 'Class Teacher — Student Promotion & Undo' : title}
          </h1>
        </div>

        {activeTab !== 'promotion' && (
          <div className="flex flex-wrap items-center gap-2 w-full sm:w-auto">
            <button
              type="button"
              onClick={() => {
                loadReport();
                loadCombinedReport();
              }}
              disabled={loading || !parsedSection || !selectedExamId}
              className="inline-flex items-center justify-center gap-1.5 px-3 py-2 min-h-[38px] text-xs font-medium text-slate-700 bg-white border border-slate-300 rounded-lg hover:bg-slate-50 disabled:opacity-50 transition-colors whitespace-nowrap cursor-pointer"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} />
              Refresh
            </button>
            {((combinedReport?.students.length || 0) > 0 || (report?.students.length || 0) > 0) && (
              <button
                type="button"
                onClick={handleDownloadSectionFinalMarksheets}
                disabled={exportingAllMarksheets}
                className="inline-flex items-center justify-center gap-1.5 px-3.5 py-2 min-h-[38px] flex-1 sm:flex-initial text-xs font-semibold text-white bg-[#1E3A5F] hover:bg-[#162D4A] rounded-lg disabled:opacity-50 transition-colors whitespace-nowrap cursor-pointer shadow-xs"
                title="Download all students' complete final marksheets (with co-scholastic, attendance, remarks, photo & result date) in 1 PDF"
              >
                <FileDown className="w-3.5 h-3.5" />
                {exportingAllMarksheets ? 'Generating PDFs...' : 'All Final Marksheets (PDF)'}
              </button>
            )}
            {isAdminView && currentClassSections.length > 1 && selectedExamId > 0 && (
              <button
                type="button"
                onClick={handleDownloadWholeClassFinalMarksheets}
                disabled={exportingAllMarksheets}
                className="inline-flex items-center justify-center gap-1.5 px-3.5 py-2 min-h-[38px] flex-1 sm:flex-initial text-xs font-semibold text-white bg-[#164E63] hover:bg-[#134254] rounded-lg disabled:opacity-50 transition-colors whitespace-nowrap cursor-pointer shadow-xs"
                title="Download complete final marksheets for ALL sections of this class in 1 PDF"
              >
                <Layers className="w-3.5 h-3.5" />
                {exportingAllMarksheets ? 'Generating...' : 'Whole Class PDF (All Sections)'}
              </button>
            )}
            {report && (
              <>
                <button
                  type="button"
                  onClick={() => exportClassConsolidatedPDF(report, schoolInfo)}
                  className="inline-flex items-center justify-center gap-1.5 px-3 py-2 min-h-[38px] flex-1 sm:flex-initial text-xs font-medium text-slate-700 bg-white border border-slate-300 rounded-lg hover:bg-slate-50 transition-colors whitespace-nowrap cursor-pointer"
                >
                  <FileDown className="w-3.5 h-3.5 text-[#1E3A5F]" />
                  Download Class PDF
                </button>
                <button
                  type="button"
                  onClick={handleDownloadClassExcel}
                  disabled={exportingExcel}
                  className="inline-flex items-center justify-center gap-1.5 px-3.5 py-2 min-h-[38px] flex-1 sm:flex-initial text-xs font-semibold text-white bg-emerald-700 hover:bg-emerald-800 rounded-lg disabled:opacity-50 transition-colors whitespace-nowrap cursor-pointer shadow-xs"
                >
                  <FileSpreadsheet className="w-3.5 h-3.5" />
                  {exportingExcel ? 'Preparing Excel...' : 'Download Class Result'}
                </button>
              </>
            )}
          </div>
        )}
      </div>

      {/* Filters & Navigation Tabs */}
      <div className="bg-white border border-slate-200 rounded-xl p-4 space-y-4">
        {activeTab !== 'promotion' && (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1.5">Academic Year</label>
              <select
                value={yearFilter}
                onChange={(e) => setYearFilter(e.target.value)}
                className="w-full min-h-[40px] px-3 py-2 text-sm font-mono bg-white border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#1E3A5F]/20 focus:border-[#1E3A5F]"
              >
                {availableYears.map((yr) => (
                  <option key={yr} value={yr}>
                    {yr} {yr === schoolInfo.currentAcademicYear ? '(Current)' : '(Archived)'}
                  </option>
                ))}
                <option value="ALL">All Academic Years</option>
              </select>
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1.5">Class &amp; Section</label>
              <select
                value={selectedSectionKey}
                onChange={(e) => setSelectedSectionKey(e.target.value)}
                disabled={allowedSections.length === 1}
                className="w-full min-h-[40px] px-3 py-2 text-sm bg-white border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#1E3A5F]/20 focus:border-[#1E3A5F] disabled:bg-slate-50"
              >
                {allowedSections.map((sec) => (
                  <option key={`${sec.classId}:${sec.sectionId}`} value={`${sec.classId}:${sec.sectionId}`}>
                    {formatClassSectionLabel(sec.className, sec.sectionName, sec.hasSections ?? true)}
                  </option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1.5">Examination</label>
              <select
                value={selectedExamId}
                onChange={(e) => setSelectedExamId(Number(e.target.value))}
                className="w-full min-h-[40px] px-3 py-2 text-sm bg-white border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#1E3A5F]/20 focus:border-[#1E3A5F]"
              >
                {filteredExaminations.length === 0 ? (
                  <option value={0}>No examinations in {yearFilter}</option>
                ) : (
                  filteredExaminations.map((ex) => (
                    <option key={ex.id} value={ex.id}>
                      {ex.name} ({ex.academic_year}) — {ex.status}
                    </option>
                  ))
                )}
              </select>
            </div>
          </div>
        )}

        <div className={`flex flex-wrap items-center justify-between gap-3 ${activeTab !== 'promotion' ? 'pt-2 border-t border-slate-100' : ''}`}>
          <div className="flex flex-wrap items-center gap-1 p-1 bg-slate-100 rounded-lg w-full lg:w-auto">
            <button
              type="button"
              onClick={() => onTabChange('consolidated')}
              className={`inline-flex items-center justify-center gap-1.5 px-3 py-2 min-h-[38px] text-xs font-medium rounded-md transition-colors whitespace-nowrap ${
                activeTab === 'consolidated'
                  ? 'bg-white text-slate-900 shadow-sm'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <Layers className="w-3.5 h-3.5" />
              Consolidated Marks
            </button>
            <button
              type="button"
              onClick={() => onTabChange('students')}
              className={`inline-flex items-center justify-center gap-1.5 px-3 py-2 min-h-[38px] text-xs font-medium rounded-md transition-colors whitespace-nowrap ${
                activeTab === 'students'
                  ? 'bg-white text-slate-900 shadow-sm'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <Users className="w-3.5 h-3.5" />
              Student List &amp; Mark Sheets
            </button>
            <button
              type="button"
              onClick={() => onTabChange('student-details')}
              className={`inline-flex items-center justify-center gap-1.5 px-3 py-2 min-h-[38px] text-xs font-medium rounded-md transition-colors whitespace-nowrap cursor-pointer ${
                activeTab === 'student-details'
                  ? 'bg-white text-slate-900 shadow-sm'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <UserRound className="w-3.5 h-3.5" />
              Student Details
            </button>
            <button
              type="button"
              onClick={() => onTabChange('co-scholastic')}
              className={`inline-flex items-center justify-center gap-1.5 px-3 py-2 min-h-[38px] text-xs font-medium rounded-md transition-colors whitespace-nowrap cursor-pointer ${
                activeTab === 'co-scholastic'
                  ? 'bg-white text-slate-900 shadow-sm'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <Award className="w-3.5 h-3.5" />
              Co-Scholastic, Attendance &amp; Remarks
            </button>
            <button
              type="button"
              onClick={() => onTabChange('analysis')}
              className={`inline-flex items-center justify-center gap-1.5 px-3 py-2 min-h-[38px] text-xs font-medium rounded-md transition-colors whitespace-nowrap ${
                activeTab === 'analysis'
                  ? 'bg-white text-slate-900 shadow-sm'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <BarChart3 className="w-3.5 h-3.5" />
              Subject &amp; Class Analysis
            </button>
            <button
              type="button"
              onClick={() => onTabChange('comparison')}
              className={`inline-flex items-center justify-center gap-1.5 px-3 py-2 min-h-[38px] text-xs font-medium rounded-md transition-colors whitespace-nowrap ${
                activeTab === 'comparison'
                  ? 'bg-white text-slate-900 shadow-sm'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <GitCompare className="w-3.5 h-3.5" />
              Exam Comparison
            </button>
            {!isAdminView && (
              <button
                type="button"
                onClick={() => onTabChange('promotion')}
                className={`inline-flex items-center justify-center gap-1.5 px-3 py-2 min-h-[38px] text-xs font-medium rounded-md transition-colors whitespace-nowrap cursor-pointer ${
                  activeTab === 'promotion'
                    ? 'bg-white text-slate-900 shadow-sm'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                <GraduationCap className="w-3.5 h-3.5" />
                Promote Students
              </button>
            )}
          </div>

          {report && (
            <div className="text-xs text-slate-500">
              Class Teacher:{' '}
              <span className="font-semibold text-slate-800">
                {report.classInfo.classTeacherName || 'Unassigned'}
              </span>
            </div>
          )}
        </div>

        {isAdminView && selectedExamId > 0 && (
          <div className="flex flex-wrap items-center justify-between gap-3 pt-3 border-t border-slate-100">
            <div className="text-xs text-slate-600">
              <span className="font-semibold text-slate-800">School-Wide Subject Report (.xlsx):</span>{' '}
              Download real marks across all classes and sections for the selected examination.
            </div>
            <div className="flex flex-wrap items-center gap-2 w-full sm:w-auto">
              <select
                value={adminSubjectId}
                onChange={(e) => setAdminSubjectId(e.target.value)}
                className="min-h-[36px] px-2.5 py-1.5 text-xs bg-slate-50 border border-slate-300 rounded-lg text-slate-800 flex-1 sm:flex-initial"
              >
                <option value="">All Subjects (All Classes)</option>
                {examSubjectOptions.map((sub) => (
                  <option key={sub.id} value={sub.id}>
                    {sub.name}
                  </option>
                ))}
              </select>
              <button
                type="button"
                onClick={handleDownloadAdminSubjectExcel}
                disabled={exportingExcel}
                className="inline-flex items-center justify-center gap-1.5 px-3 py-1.5 min-h-[36px] text-xs font-semibold text-white bg-[#1E3A5F] hover:bg-[#162D4A] rounded-lg disabled:opacity-50 transition-colors whitespace-nowrap cursor-pointer"
              >
                <FileSpreadsheet className="w-3.5 h-3.5" />
                Download Subject Excel
              </button>
            </div>
          </div>
        )}
      </div>

      {exportNotice && (
        <div
          className={`flex items-center gap-2 p-3 rounded-xl border text-xs font-medium ${
            exportNotice.type === 'success'
              ? 'bg-emerald-50 border-emerald-200 text-emerald-900'
              : 'bg-red-50 border-red-200 text-red-900'
          }`}
        >
          {exportNotice.type === 'success' ? (
            <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
          ) : (
            <AlertTriangle className="w-4 h-4 text-red-600 shrink-0" />
          )}
          <span>{exportNotice.text}</span>
        </div>
      )}

      {error && (
        <div className="p-4 rounded-xl bg-red-50 border border-red-200 flex flex-wrap items-center justify-between gap-2 text-sm text-red-800">
          <span>{error}</span>
          <button
            type="button"
            onClick={() => loadReport()}
            className="min-h-[34px] inline-flex items-center gap-1 px-3 py-1 bg-white border border-red-200 rounded-lg text-xs font-semibold text-red-800 hover:bg-red-100 cursor-pointer"
          >
            <RefreshCw className="w-3.5 h-3.5" />
            Retry
          </button>
        </div>
      )}

      {activeTab === 'promotion' && !isAdminView ? (
        <ClassWisePromotionPanel
          schoolInfo={schoolInfo}
          selectedAcademicYear={
            yearFilter === 'ALL' ? schoolInfo.currentAcademicYear : yearFilter
          }
          isClassTeacherView
          allowedClassSections={
            classTeacherAssignments && classTeacherAssignments.length > 0
              ? classTeacherAssignments.map((ct) => ({
                  classId: ct.class_id,
                  className: ct.class_name,
                  hasSections: ct.has_sections !== 0 && ct.has_sections !== false,
                  sectionId: ct.section_id,
                  sectionName: ct.section_name,
                  academicYear: ct.academic_year,
                }))
              : allowedSections
          }
          onPromoted={async () => {
            await Promise.all([loadReport(), loadCombinedReport()]);
            if (onPromotionChanged) {
              await onPromotionChanged();
            }
          }}
        />
      ) : activeTab === 'student-details' && parsedSection ? (
        <ClassTeacherStudentDetailsPanel
          academicYear={yearFilter === 'ALL' ? schoolInfo.currentAcademicYear : yearFilter}
          classId={parsedSection.classId}
          sectionId={parsedSection.sectionId}
          onSaved={async () => {
            await Promise.all([loadReport(), loadCombinedReport()]);
          }}
        />
      ) : activeTab === 'co-scholastic' && parsedSection && selectedExamId > 0 ? (
        <CoScholasticGradesPanel
          examinationId={selectedExamId}
          classId={parsedSection.classId}
          sectionId={parsedSection.sectionId}
          onSaved={async () => {
            await Promise.all([loadReport(), loadCombinedReport()]);
          }}
        />
      ) : loading ? (
        <div className="bg-white border border-slate-200 rounded-xl p-10 text-center text-sm text-slate-500">
          Consolidating marks across subject components...
        </div>
      ) : !selectedExamId ? (
        <div className="bg-white border border-slate-200 rounded-xl p-10 text-center text-sm text-slate-500">
          No examinations exist yet for Academic Year <span className="font-mono font-semibold">{yearFilter}</span>.
        </div>
      ) : (
        report && (
          <>
            {/* Summary KPI Row */}
            <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
              <div className="bg-white border border-slate-200 rounded-xl p-4">
                <div className="text-xs text-slate-500">Total Students</div>
                <div className="text-xl font-bold font-mono tabular-nums text-slate-900 mt-1">
                  {report.summary.totalStudents}
                </div>
                <div className="text-[11px] text-slate-500 mt-0.5">
                  {report.summary.completedCount} complete · {report.summary.incompleteCount} incomplete
                </div>
              </div>
              <div className="bg-white border border-slate-200 rounded-xl p-4">
                <div className="text-xs text-slate-500">Class Average</div>
                <div className="text-xl font-bold font-mono tabular-nums text-[#1E3A5F] mt-1">
                  {report.summary.classAveragePercentage !== null
                    ? `${report.summary.classAveragePercentage}%`
                    : 'Incomplete'}
                </div>
                <div className="text-[11px] text-slate-500 mt-0.5 font-mono tabular-nums">
                  {report.summary.classAverageTotal !== null
                    ? `${report.summary.classAverageTotal} / ${report.summary.totalMaxMarks}`
                    : 'Awaiting marks'}
                </div>
              </div>
              <div className="bg-white border border-slate-200 rounded-xl p-4">
                <div className="text-xs text-slate-500">Highest Total</div>
                <div className="text-xl font-bold font-mono tabular-nums text-emerald-700 mt-1">
                  {report.summary.highestTotal !== null
                    ? `${report.summary.highestTotal}/${report.summary.totalMaxMarks}`
                    : '—'}
                </div>
                <div className="text-[11px] text-slate-500 mt-0.5">Among completed results</div>
              </div>
              <div className="bg-white border border-slate-200 rounded-xl p-4">
                <div className="text-xs text-slate-500">Lowest Total</div>
                <div className="text-xl font-bold font-mono tabular-nums text-slate-900 mt-1">
                  {report.summary.lowestTotal !== null
                    ? `${report.summary.lowestTotal}/${report.summary.totalMaxMarks}`
                    : '—'}
                </div>
                <div className="text-[11px] text-slate-500 mt-0.5">Among completed results</div>
              </div>
              <div className="bg-white border border-slate-200 rounded-xl p-4">
                <div className="text-xs text-slate-500">Pass / Fail</div>
                <div className="text-xl font-bold font-mono tabular-nums text-slate-900 mt-1">
                  {report.summary.passCount} / {report.summary.failCount}
                </div>
                <div className="text-[11px] text-slate-500 mt-0.5">
                  Pass criteria: {report.examination.passingPercentage}%
                </div>
              </div>
            </div>

            {report.summary.incompleteCount > 0 && (
              <div className="flex items-center gap-2.5 px-3.5 py-2.5 bg-amber-50 border border-amber-200 rounded-xl text-xs text-amber-900">
                <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0" />
                <span>
                  <span className="font-semibold">{report.summary.incompleteCount} incomplete result(s)</span> — awaiting remaining subject marks.
                </span>
              </div>
            )}

            {/* TAB: CONSOLIDATED MARKS */}
            {activeTab === 'consolidated' && (
              <div className="bg-white border border-slate-200 rounded-xl overflow-hidden">
                <div className="px-5 py-3.5 border-b border-slate-200 flex flex-wrap items-center justify-between gap-3">
                  <div className="flex flex-wrap items-center gap-3">
                    <div className="relative">
                      <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                      <input
                        type="text"
                        value={searchQuery}
                        onChange={(e) => setSearchQuery(e.target.value)}
                        placeholder="Search student or roll..."
                        className="pl-8 pr-3 py-1.5 text-xs bg-white border border-slate-300 rounded-lg focus:outline-none focus:border-[#1E3A5F]"
                      />
                    </div>
                    <select
                      value={statusFilter}
                      onChange={(e) => setStatusFilter(e.target.value as any)}
                      className="px-2.5 py-1.5 text-xs bg-white border border-slate-300 rounded-lg"
                    >
                      <option value="all">All Statuses</option>
                      <option value="Pass">Pass Only</option>
                      <option value="Fail">Fail Only</option>
                      <option value="Incomplete">Incomplete Only</option>
                    </select>
                  </div>

                  <label className="inline-flex items-center gap-2 text-xs font-medium text-slate-700 cursor-pointer select-none">
                    <input
                      type="checkbox"
                      checked={showComponents}
                      onChange={(e) => setShowComponents(e.target.checked)}
                      className="rounded border-slate-300 text-[#1E3A5F] focus:ring-[#1E3A5F]"
                    />
                    Expand Components &amp; Internal Assessment
                  </label>
                </div>

                <div className="overflow-auto max-h-[65vh] relative">
                  <table className="w-full text-xs">
                    <thead className="bg-slate-50 border-b border-slate-200 text-slate-600 sticky top-0 z-20">
                      <tr>
                        <th className="text-left font-semibold px-3 py-2.5 sticky left-0 z-30 bg-slate-50">Roll</th>
                        <th className="text-left font-semibold px-3 py-2.5">Student Name</th>
                        {report.subjects.map((sub) => (
                          <React.Fragment key={sub.subjectId}>
                            {showComponents &&
                              (sub.hasComponents && sub.componentMode !== 'elective' ? (
                                sub.components.map((c) => (
                                  <th
                                    key={c.examComponentId}
                                    className="text-right font-medium px-2.5 py-2.5 text-slate-500 bg-slate-100/70 whitespace-nowrap"
                                  >
                                    {c.componentName.slice(0, 4)}
                                    <div className="font-mono text-[10px]">/{c.maxMarks}</div>
                                  </th>
                                ))
                              ) : sub.hasInternalAssessment || sub.componentMode === 'elective' ? (
                                <th className="text-right font-medium px-2.5 py-2.5 text-slate-500 bg-slate-100/70 whitespace-nowrap">
                                  {sub.componentMode === 'elective' ? 'Opt / Exam' : 'Exam'}
                                  <div className="font-mono text-[10px]">/{sub.writtenMaxMarks}</div>
                                </th>
                              ) : null)}
                            {showComponents && sub.hasInternalAssessment && (
                              <th className="text-right font-medium px-2.5 py-2.5 text-sky-700 bg-sky-50/70 whitespace-nowrap">
                                IA
                                <div className="font-mono text-[10px]">/{sub.iaMaxMarks}</div>
                              </th>
                            )}
                            <th className="text-right font-semibold px-3 py-2.5 whitespace-nowrap">
                              {sub.subjectName}
                              <div className="font-mono text-[10px] font-normal text-slate-500">
                                /{sub.maxMarks}
                              </div>
                            </th>
                          </React.Fragment>
                        ))}
                        <th className="text-right font-semibold px-3 py-2.5 whitespace-nowrap">
                          Grand Total
                          <div className="font-mono text-[10px] font-normal text-slate-500">
                            /{report.summary.totalMaxMarks}
                          </div>
                        </th>
                        <th className="text-right font-semibold px-3 py-2.5">%</th>
                        <th className="text-center font-semibold px-3 py-2.5">Grade</th>
                        <th className="text-center font-semibold px-3 py-2.5">Rank</th>
                        <th className="text-center font-semibold px-3 py-2.5">Result</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-200">
                      {filteredStudents.map((st) => (
                        <tr key={st.studentId} className="hover:bg-slate-50/80">
                          <td className="px-3 py-2 font-mono font-semibold text-slate-700 tabular-nums sticky left-0 bg-white">
                            {String(st.rollNumber).padStart(2, '0')}
                          </td>
                          <td className="px-3 py-2 whitespace-nowrap">
                            <button
                              type="button"
                              onClick={() => {
                                setModalInitialMode('term1');
                                setSelectedStudent(st);
                              }}
                              className="font-semibold text-[#1E3A5F] hover:underline text-left cursor-pointer"
                            >
                              {st.studentName}
                            </button>
                            <div className="flex items-center gap-1.5 text-[10px] font-mono text-slate-400">
                              <span>{st.studentCode}</span>
                              {st.stream && (
                                <span className="font-sans px-1.5 py-0 rounded bg-sky-50 text-sky-800 border border-sky-200 font-medium">
                                  {st.stream}
                                </span>
                              )}
                            </div>
                          </td>
                          {st.subjects.map((sub) => {
                            const isNotApplicable =
                              sub.isEnrolled === false || sub.gradeStatus === 'not_applicable';
                            if (isNotApplicable) {
                              return (
                                <React.Fragment key={sub.subjectId}>
                                  {showComponents &&
                                    (sub.hasComponents && sub.componentMode !== 'elective' ? (
                                      sub.components.map((c) => (
                                        <td
                                          key={c.examComponentId}
                                          className="px-2.5 py-2 text-right font-mono tabular-nums bg-slate-50/50 text-slate-300"
                                          title="Subject not taken by student"
                                        >
                                          —
                                        </td>
                                      ))
                                    ) : sub.hasInternalAssessment || sub.componentMode === 'elective' ? (
                                      <td
                                        className="px-2.5 py-2 text-right font-mono tabular-nums bg-slate-50/50 text-slate-300"
                                        title="Subject not taken by student"
                                      >
                                        —
                                      </td>
                                    ) : null)}
                                  {showComponents && sub.hasInternalAssessment && (
                                    <td
                                      className="px-2.5 py-2 text-right font-mono tabular-nums bg-sky-50/40 text-slate-300"
                                      title="Subject not taken by student"
                                    >
                                      —
                                    </td>
                                  )}
                                  <td
                                    className="px-3 py-2 text-right font-mono tabular-nums text-slate-300 whitespace-nowrap"
                                    title="Subject not taken by student"
                                  >
                                    —
                                  </td>
                                </React.Fragment>
                              );
                            }
                            return (
                              <React.Fragment key={sub.subjectId}>
                                {showComponents &&
                                  (sub.hasComponents && sub.componentMode !== 'elective' ? (
                                    sub.components.map((c) => (
                                      <td
                                        key={c.examComponentId}
                                        className={`px-2.5 py-2 text-right font-mono tabular-nums bg-slate-50/50 ${
                                          c.attendanceStatus === 'absent'
                                            ? 'text-rose-700 font-bold'
                                            : c.status === 'submitted'
                                              ? 'text-slate-700'
                                              : c.status === 'draft'
                                                ? 'text-amber-700'
                                                : 'text-red-500'
                                        }`}
                                        title={`Status: ${c.attendanceStatus === 'absent' ? 'Absent' : c.status}`}
                                      >
                                        {c.attendanceStatus === 'absent'
                                          ? 'AB'
                                          : c.obtainedMarks !== null
                                            ? c.obtainedMarks
                                            : '—'}
                                        {c.status === 'draft' ? '*' : ''}
                                      </td>
                                    ))
                                  ) : sub.hasInternalAssessment || sub.componentMode === 'elective' ? (
                                    <td
                                      className={`px-2.5 py-2 text-right font-mono tabular-nums bg-slate-50/50 whitespace-nowrap ${
                                        sub.components[0]?.attendanceStatus === 'absent'
                                          ? 'text-rose-700 font-bold'
                                          : sub.components[0]?.status === 'submitted'
                                            ? 'text-slate-700'
                                            : sub.components[0]?.status === 'draft'
                                              ? 'text-amber-700'
                                              : 'text-red-500'
                                      }`}
                                      title={sub.selectedComponentName ? `Option: ${sub.selectedComponentName}` : undefined}
                                    >
                                      {sub.componentMode === 'elective' && sub.selectedComponentName && (
                                        <span className="font-sans text-[10px] text-slate-500 mr-1">
                                          {sub.selectedComponentName.slice(0, 3)}
                                        </span>
                                      )}
                                      {sub.components[0]?.attendanceStatus === 'absent'
                                        ? 'AB'
                                        : sub.components[0]?.obtainedMarks !== null &&
                                            sub.components[0]?.obtainedMarks !== undefined
                                          ? sub.components[0].obtainedMarks
                                          : '—'}
                                      {sub.components[0]?.status === 'draft' ? '*' : ''}
                                    </td>
                                  ) : null)}
                                {showComponents && sub.hasInternalAssessment && (
                                  <td
                                    className={`px-2.5 py-2 text-right font-mono tabular-nums bg-sky-50/40 ${
                                      sub.iaStatus === 'submitted'
                                        ? 'text-sky-900'
                                        : sub.iaStatus === 'draft'
                                          ? 'text-amber-700'
                                          : 'text-red-500'
                                    }`}
                                    title={`NB: ${sub.iaNotebookMarks ?? '—'}/${sub.iaNotebookMax}, UT: ${sub.iaUnitTestMarks ?? '—'}/${sub.iaUnitTestMax}, Pr: ${sub.iaPracticalMarks ?? '—'}/${sub.iaPracticalMax}, OP: ${sub.iaParticipationMarks ?? '—'}/${sub.iaParticipationMax}`}
                                  >
                                    {sub.iaTotalMarks !== null ? sub.iaTotalMarks : '—'}
                                    {sub.iaStatus === 'draft' ? '*' : ''}
                                  </td>
                                )}
                                <td
                                  className="px-3 py-2 text-right font-mono tabular-nums font-semibold whitespace-nowrap"
                                  title={sub.selectedComponentName ? `${sub.subjectName} (${sub.selectedComponentName})` : undefined}
                                >
                                  {sub.components.some((c) => c.attendanceStatus === 'absent') ? (
                                    <span className="text-rose-700 font-bold">AB</span>
                                  ) : sub.isComplete && sub.obtainedMarks !== null ? (
                                    <span className="inline-flex items-center justify-end gap-1.5">
                                      <span className={sub.isPassed ? 'text-slate-900' : 'text-red-700'}>
                                        {sub.obtainedMarks}
                                      </span>
                                      {sub.grade && (
                                        <span
                                          className={`inline-flex items-center px-1.5 py-0.5 text-[10px] font-mono font-semibold rounded border ${getGradeBadgeClass(
                                            sub.grade
                                          )}`}
                                        >
                                          {sub.grade}
                                        </span>
                                      )}
                                    </span>
                                  ) : (
                                    <span className="text-amber-700 text-[11px] font-sans font-medium">
                                      {sub.gradeStatus === 'not_submitted' ? 'Not Submitted' : 'Pending'}
                                    </span>
                                  )}
                                </td>
                              </React.Fragment>
                            );
                          })}
                          <td className="px-3 py-2 text-right font-mono tabular-nums font-bold text-slate-900">
                            {st.grandTotal !== null ? st.grandTotal : '—'}
                          </td>
                          <td className="px-3 py-2 text-right font-mono tabular-nums text-slate-800">
                            {st.percentage !== null ? `${st.percentage.toFixed(1)}%` : '—'}
                          </td>
                          <td className="px-3 py-2 text-center font-mono font-semibold text-slate-800">
                            {st.grade ?? '—'}
                          </td>
                          <td className="px-3 py-2 text-center font-mono tabular-nums text-slate-700">
                            {st.classRank ? `#${st.classRank}` : '—'}
                          </td>
                          <td className="px-3 py-2 text-center">
                            <ResultStatusLabel status={st.resultStatus} />
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            )}

            {/* TAB: STUDENT LIST & INDIVIDUAL MARK SHEETS */}
            {activeTab === 'students' && (
              <div className="bg-white border border-slate-200 rounded-xl overflow-hidden">
                <div className="px-4 sm:px-5 py-3.5 border-b border-slate-200 flex flex-wrap items-center justify-between gap-3">
                  <div className="text-sm font-semibold text-slate-900">
                    Class Roster ({report.students.length} Students)
                  </div>
                  <div className="relative w-full sm:w-auto">
                    <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                    <input
                      type="text"
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      placeholder="Filter students..."
                      className="w-full sm:w-56 min-h-[38px] pl-8 pr-3 py-1.5 text-xs border border-slate-300 rounded-lg focus:outline-none focus:border-[#1E3A5F]"
                    />
                  </div>
                </div>

                {/* Mobile Cards */}
                <div className="md:hidden divide-y divide-slate-200">
                  {filteredStudents.map((st) => {
                    const t1Match =
                      combinedReport?.term1Report?.students.find((s) => s.studentId === st.studentId) || st;
                    const t1Report = combinedReport?.term1Report || report;
                    const combMatch =
                      combinedReport?.students.find((s) => s.studentId === st.studentId) || null;
                    return (
                      <div key={st.studentId} className="p-4 space-y-2.5">
                        <div className="flex items-start justify-between gap-2">
                          <div>
                            <div className="flex items-center gap-1.5 flex-wrap">
                              <span className="font-semibold text-sm text-slate-900">{st.studentName}</span>
                              {st.stream && (
                                <span className="px-1.5 py-0.5 text-[10px] font-medium rounded bg-sky-50 text-sky-800 border border-sky-200">
                                  {st.stream}
                                </span>
                              )}
                            </div>
                            <div className="text-xs font-mono text-slate-500 mt-0.5">
                              Roll {String(st.rollNumber).padStart(2, '0')} · {st.studentCode}
                            </div>
                          </div>
                          <ResultStatusLabel status={st.resultStatus} />
                        </div>
                        <div className="grid grid-cols-3 gap-2 text-xs font-mono tabular-nums text-slate-700">
                          <div>
                            Total:{' '}
                            <strong className="text-slate-900">
                              {st.grandTotal !== null ? `${st.grandTotal}/${st.totalMaxMarks}` : 'Inc.'}
                            </strong>
                          </div>
                          <div>
                            %: <strong className="text-slate-900">{st.percentage !== null ? `${st.percentage.toFixed(1)}%` : '—'}</strong>
                          </div>
                          <div>
                            Rank: <strong className="text-slate-900">{st.grade ? `${st.grade} #${st.classRank}` : '—'}</strong>
                          </div>
                        </div>
                        <div className="grid grid-cols-2 gap-2">
                          <button
                            type="button"
                            onClick={() => {
                              setModalInitialMode('term1');
                              setSelectedStudent(st);
                            }}
                            className="min-h-[38px] inline-flex items-center justify-center gap-1.5 px-2.5 py-2 text-xs font-medium text-white bg-[#1E3A5F] rounded-lg hover:bg-[#162D4A] cursor-pointer"
                          >
                            <Award className="w-3.5 h-3.5" />
                            1st Term Sheet
                          </button>
                          <button
                            type="button"
                            onClick={() => void exportIndividualReportCardPDF(t1Match, t1Report, schoolInfo)}
                            className="min-h-[38px] inline-flex items-center justify-center gap-1.5 px-2.5 py-2 text-xs font-medium text-slate-700 bg-white border border-slate-300 rounded-lg hover:bg-slate-50 cursor-pointer"
                          >
                            <FileDown className="w-3.5 h-3.5" />
                            1st Term PDF
                          </button>
                          {combinedReport && combMatch && (
                            <>
                              <button
                                type="button"
                                onClick={() => {
                                  setModalInitialMode('combined');
                                  setSelectedStudent(st);
                                }}
                                className="min-h-[38px] inline-flex items-center justify-center gap-1.5 px-2.5 py-2 text-xs font-medium text-white bg-[#164E63] rounded-lg hover:bg-[#134254] cursor-pointer"
                              >
                                <Layers className="w-3.5 h-3.5" />
                                Final Sheet
                              </button>
                              <button
                                type="button"
                                onClick={() => void exportCombinedReportCardPDF(combMatch, combinedReport, schoolInfo)}
                                className="min-h-[38px] inline-flex items-center justify-center gap-1.5 px-2.5 py-2 text-xs font-medium text-[#164E63] bg-cyan-50/50 border border-cyan-300 rounded-lg hover:bg-cyan-50 cursor-pointer"
                              >
                                <FileDown className="w-3.5 h-3.5" />
                                Final PDF
                              </button>
                            </>
                          )}
                        </div>
                      </div>
                    );
                  })}
                </div>

                {/* Desktop Table */}
                <div className="hidden md:block overflow-x-auto">
                  <table className="w-full text-sm">
                    <thead className="bg-slate-50 border-b border-slate-200 text-xs text-slate-600">
                      <tr>
                        <th className="text-left font-semibold px-4 py-2.5">Roll No.</th>
                        <th className="text-left font-semibold px-4 py-2.5">Student ID</th>
                        <th className="text-left font-semibold px-4 py-2.5">Student Name</th>
                        <th className="text-right font-semibold px-4 py-2.5">Grand Total</th>
                        <th className="text-right font-semibold px-4 py-2.5">Percentage</th>
                        <th className="text-center font-semibold px-4 py-2.5">Grade &amp; Rank</th>
                        <th className="text-center font-semibold px-4 py-2.5">Status</th>
                        <th className="text-right font-semibold px-4 py-2.5">Mark Sheets (View / PDF)</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-200">
                      {filteredStudents.map((st) => {
                        const t1Match =
                          combinedReport?.term1Report?.students.find((s) => s.studentId === st.studentId) || st;
                        const t1Report = combinedReport?.term1Report || report;
                        const combMatch =
                          combinedReport?.students.find((s) => s.studentId === st.studentId) || null;
                        return (
                          <tr key={st.studentId} className="hover:bg-slate-50/70">
                            <td className="px-4 py-2.5 font-mono text-xs font-semibold tabular-nums">
                              {String(st.rollNumber).padStart(2, '0')}
                            </td>
                            <td className="px-4 py-2.5 font-mono text-xs text-slate-500">{st.studentCode}</td>
                            <td className="px-4 py-2.5 font-medium text-slate-900">
                              <span>{st.studentName}</span>
                              {st.stream && (
                                <span className="ml-2 px-1.5 py-0.5 text-[10px] font-medium rounded bg-sky-50 text-sky-800 border border-sky-200">
                                  {st.stream}
                                </span>
                              )}
                            </td>
                            <td className="px-4 py-2.5 text-right font-mono tabular-nums">
                              {st.grandTotal !== null ? `${st.grandTotal}/${st.totalMaxMarks}` : 'Incomplete'}
                            </td>
                            <td className="px-4 py-2.5 text-right font-mono tabular-nums">
                              {st.percentage !== null ? `${st.percentage.toFixed(2)}%` : '—'}
                            </td>
                            <td className="px-4 py-2.5 text-center font-mono text-xs">
                              {st.grade ? `${st.grade} · #${st.classRank}` : '—'}
                            </td>
                            <td className="px-4 py-2.5 text-center">
                              <ResultStatusLabel status={st.resultStatus} />
                            </td>
                            <td className="px-4 py-2.5 text-right whitespace-nowrap">
                              <div className="inline-flex items-center gap-1.5 flex-wrap justify-end">
                                <button
                                  type="button"
                                  onClick={() => {
                                    setModalInitialMode('term1');
                                    setSelectedStudent(st);
                                  }}
                                  className="inline-flex items-center gap-1 px-2.5 py-1.5 text-xs font-medium text-white bg-[#1E3A5F] rounded-lg hover:bg-[#162D4A] cursor-pointer"
                                  title="View 1st Term Only Mark Sheet"
                                >
                                  <Award className="w-3.5 h-3.5" />
                                  1st Term
                                </button>
                                <button
                                  type="button"
                                  onClick={() => void exportIndividualReportCardPDF(t1Match, t1Report, schoolInfo)}
                                  title="Download 1st Term Only Marksheet PDF"
                                  className="inline-flex items-center gap-1 px-2 py-1.5 text-xs font-medium text-slate-700 bg-white border border-slate-300 rounded-lg hover:bg-slate-50 cursor-pointer"
                                >
                                  <FileDown className="w-3.5 h-3.5 text-[#1E3A5F]" />
                                  PDF
                                </button>
                                {combinedReport && combMatch && (
                                  <>
                                    <button
                                      type="button"
                                      onClick={() => {
                                        setModalInitialMode('combined');
                                        setSelectedStudent(st);
                                      }}
                                      className="inline-flex items-center gap-1 px-2.5 py-1.5 text-xs font-medium text-white bg-[#164E63] rounded-lg hover:bg-[#134254] cursor-pointer"
                                      title="View Final Combined (1st Term + Annual) Mark Sheet"
                                    >
                                      <Layers className="w-3.5 h-3.5" />
                                      Final Combined
                                    </button>
                                    <button
                                      type="button"
                                      onClick={() =>
                                        void exportCombinedReportCardPDF(combMatch, combinedReport, schoolInfo)
                                      }
                                      title="Download Final Combined (1st Term + Annual) Marksheet PDF"
                                      className="inline-flex items-center gap-1 px-2 py-1.5 text-xs font-medium text-[#164E63] bg-cyan-50/50 border border-cyan-300 rounded-lg hover:bg-cyan-50 cursor-pointer"
                                    >
                                      <FileDown className="w-3.5 h-3.5" />
                                      Final PDF
                                    </button>
                                  </>
                                )}
                              </div>
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              </div>
            )}

            {/* TAB: SUBJECT & CLASS PERFORMANCE ANALYSIS */}
            {activeTab === 'analysis' && (
              <div className="space-y-6">
                {/* Visual SVG Bar Chart */}
                <div className="bg-white border border-slate-200 rounded-xl p-5">
                  <h2 className="text-sm font-semibold text-slate-900">Subject-Wise Average Performance (%)</h2>
                  <p className="text-xs text-slate-500 mt-0.5">
                    Computed from submitted marks in{' '}
                    {formatClassSectionLabel(
                      report.classInfo.className,
                      report.classInfo.sectionName,
                      report.classInfo.hasSections ?? true
                    )}
                  </p>
                  <div className="mt-5 space-y-3">
                    {report.subjectPerformance.map((sp) => {
                      const pct = sp.averagePercentage ?? 0;
                      return (
                        <div key={sp.subjectId} className="grid grid-cols-12 items-center gap-3 text-xs">
                          <div className="col-span-3 sm:col-span-2 font-medium text-slate-800 truncate">
                            {sp.subjectName}
                          </div>
                          <div className="col-span-7 sm:col-span-8 bg-slate-100 h-6 rounded overflow-hidden relative">
                            <div
                              className="h-full bg-[#1E3A5F] transition-all duration-300"
                              style={{ width: `${Math.min(100, pct)}%` }}
                            />
                          </div>
                          <div className="col-span-2 text-right font-mono tabular-nums font-semibold text-slate-800">
                            {sp.averagePercentage !== null ? `${sp.averagePercentage}%` : 'Pending'}
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>

                {/* Subject-wise Detailed Metrics & PDF Export */}
                <div className="bg-white border border-slate-200 rounded-xl overflow-hidden">
                  <div className="px-5 py-3.5 border-b border-slate-200">
                    <h2 className="text-sm font-semibold text-slate-900">Subject-Wise Statistical Breakdown</h2>
                  </div>
                  <div className="overflow-x-auto">
                    <table className="w-full text-sm">
                      <thead className="bg-slate-50 border-b border-slate-200 text-xs text-slate-600">
                        <tr>
                          <th className="text-left font-semibold px-4 py-2.5">Subject</th>
                          <th className="text-right font-semibold px-4 py-2.5">Max</th>
                          <th className="text-right font-semibold px-4 py-2.5">Submitted</th>
                          <th className="text-right font-semibold px-4 py-2.5">Class Avg</th>
                          <th className="text-center font-semibold px-4 py-2.5">Avg Grade</th>
                          <th className="text-right font-semibold px-4 py-2.5">Highest</th>
                          <th className="text-right font-semibold px-4 py-2.5">Lowest</th>
                          <th className="text-right font-semibold px-4 py-2.5">Pass Rate</th>
                          <th className="text-right font-semibold px-4 py-2.5">Reports</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-200">
                        {report.subjectPerformance.map((sp) => {
                          const avgGradeInfo = calculateSubjectGrade(sp.averageMarks, sp.maxMarks, {
                            isPending: sp.averageMarks === null,
                            isNotSubmitted: sp.completedStudents === 0,
                          });
                          return (
                            <tr key={sp.subjectId} className="hover:bg-slate-50/70">
                              <td className="px-4 py-2.5 font-medium text-slate-900">{sp.subjectName}</td>
                              <td className="px-4 py-2.5 text-right font-mono tabular-nums">{sp.maxMarks}</td>
                              <td className="px-4 py-2.5 text-right font-mono tabular-nums">
                                {sp.completedStudents}/{report.summary.totalStudents}
                              </td>
                              <td className="px-4 py-2.5 text-right font-mono tabular-nums">
                                {sp.averageMarks !== null ? `${sp.averageMarks} (${sp.averagePercentage}%)` : 'Pending'}
                              </td>
                              <td className="px-4 py-2.5 text-center">
                                <span
                                  className={`inline-flex items-center px-2 py-0.5 text-[11px] font-mono font-semibold rounded border ${getGradeBadgeClass(
                                    avgGradeInfo.grade || avgGradeInfo.display
                                  )}`}
                                >
                                  {avgGradeInfo.display}
                                </span>
                              </td>
                              <td className="px-4 py-2.5 text-right font-mono tabular-nums text-emerald-700">
                                {sp.highestMarks ?? '—'}
                              </td>
                              <td className="px-4 py-2.5 text-right font-mono tabular-nums text-slate-700">
                                {sp.lowestMarks ?? '—'}
                              </td>
                              <td className="px-4 py-2.5 text-right font-mono tabular-nums">
                                {sp.passRate !== null ? `${sp.passRate}%` : '—'}
                              </td>
                              <td className="px-4 py-2.5 text-right">
                                <div className="inline-flex items-center gap-1.5">
                                  <button
                                    type="button"
                                    onClick={() => handleDownloadSubjectExcel(sp.subjectId)}
                                    disabled={exportingExcel}
                                    className="inline-flex items-center gap-1 px-2.5 py-1 text-xs font-semibold text-emerald-800 bg-emerald-50 border border-emerald-300 rounded hover:bg-emerald-100 disabled:opacity-50 cursor-pointer"
                                  >
                                    <FileSpreadsheet className="w-3 h-3" />
                                    Excel
                                  </button>
                                  <button
                                    type="button"
                                    onClick={() => exportSubjectWisePDF(report, sp.subjectId, schoolInfo)}
                                    className="inline-flex items-center gap-1 px-2.5 py-1 text-xs font-medium text-slate-700 border border-slate-300 rounded hover:bg-slate-50 cursor-pointer"
                                  >
                                    <FileDown className="w-3 h-3" />
                                    PDF
                                  </button>
                                </div>
                              </td>
                            </tr>
                          );
                        })}
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            )}

            {/* TAB: EXAM-WISE COMPARISON */}
            {activeTab === 'comparison' && (
              <div className="bg-white border border-slate-200 rounded-xl overflow-hidden">
                <div className="px-4 sm:px-5 py-4 border-b border-slate-200 flex flex-wrap items-center justify-between gap-2">
                  <div>
                    <h2 className="text-sm font-semibold text-slate-900">
                      Examination-Wise Class Comparison ·{' '}
                      {formatClassSectionLabel(
                        report.classInfo.className,
                        report.classInfo.sectionName,
                        report.classInfo.hasSections ?? true
                      )}
                    </h2>
                    <p className="text-xs text-slate-500 mt-0.5">
                      Progress of overall average and pass rate across examinations
                    </p>
                  </div>
                  {comparisonError && (
                    <button
                      type="button"
                      onClick={loadComparison}
                      className="px-3 py-1.5 text-xs font-medium text-slate-700 bg-white border border-slate-300 rounded-lg hover:bg-slate-50"
                    >
                      Retry
                    </button>
                  )}
                </div>

                {comparisonError ? (
                  <div className="p-6 text-center text-sm text-red-700 bg-red-50/50">{comparisonError}</div>
                ) : (
                  <>
                    {/* Mobile Cards */}
                    <div className="md:hidden divide-y divide-slate-200">
                      {comparison.map((ex) => (
                        <div key={ex.examinationId} className="p-4 space-y-2">
                          <div className="flex items-start justify-between gap-2">
                            <div>
                              <div className="font-semibold text-sm text-slate-900">{ex.examinationName}</div>
                              <div className="text-xs text-slate-500 mt-0.5">Status: {ex.status}</div>
                            </div>
                            <span className="font-mono text-sm font-bold text-[#1E3A5F] tabular-nums">
                              {ex.classAveragePercentage !== null ? `${ex.classAveragePercentage}%` : 'Incomplete'}
                            </span>
                          </div>
                          <div className="grid grid-cols-3 gap-2 text-xs font-mono tabular-nums text-slate-600">
                            <div>Done: <strong className="text-slate-900">{ex.completedCount}/{ex.totalStudents}</strong></div>
                            <div>Pass: <strong className="text-emerald-700">{ex.passCount}</strong></div>
                            <div>Fail: <strong className="text-red-700">{ex.failCount}</strong></div>
                          </div>
                        </div>
                      ))}
                    </div>

                    {/* Desktop Table */}
                    <div className="hidden md:block overflow-x-auto">
                      <table className="w-full text-sm">
                        <thead className="bg-slate-50 border-b border-slate-200 text-xs text-slate-600">
                          <tr>
                            <th className="text-left font-semibold px-4 py-2.5">Examination</th>
                            <th className="text-left font-semibold px-4 py-2.5">Status</th>
                            <th className="text-right font-semibold px-4 py-2.5">Complete Results</th>
                            <th className="text-right font-semibold px-4 py-2.5">Passed</th>
                            <th className="text-right font-semibold px-4 py-2.5">Failed</th>
                            <th className="text-right font-semibold px-4 py-2.5">Class Avg (%)</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-slate-200">
                          {comparison.map((ex) => (
                            <tr key={ex.examinationId} className="hover:bg-slate-50/70">
                              <td className="px-4 py-2.5 font-medium text-slate-900">{ex.examinationName}</td>
                              <td className="px-4 py-2.5 text-xs text-slate-600">{ex.status}</td>
                              <td className="px-4 py-2.5 text-right font-mono tabular-nums">
                                {ex.completedCount}/{ex.totalStudents}
                              </td>
                              <td className="px-4 py-2.5 text-right font-mono tabular-nums text-emerald-700">
                                {ex.passCount}
                              </td>
                              <td className="px-4 py-2.5 text-right font-mono tabular-nums text-red-700">
                                {ex.failCount}
                              </td>
                              <td className="px-4 py-2.5 text-right font-mono tabular-nums font-semibold">
                                {ex.classAveragePercentage !== null ? `${ex.classAveragePercentage}%` : 'Incomplete'}
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </>
                )}
              </div>
            )}
          </>
        )
      )}

      {selectedStudent && report && (
        <StudentReportCardModal
          student={selectedStudent}
          report={report}
          combinedReport={combinedReport}
          initialMode={modalInitialMode}
          schoolInfo={schoolInfo}
          onClose={() => setSelectedStudent(null)}
        />
      )}
    </div>
  );
}
