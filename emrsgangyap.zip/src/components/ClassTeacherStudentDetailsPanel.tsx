import React, { useEffect, useMemo, useRef, useState } from 'react';
import {
  AlertTriangle,
  CheckCircle2,
  RefreshCw,
  RotateCcw,
  Save,
  Search,
  UserRound,
} from 'lucide-react';
import type {
  ClassTeacherStudentProfile,
  ClassTeacherStudentProfilesResponse,
} from '../types';
import { apiFetch, extractErrorMessage, isAbortError } from '../lib/api';
import { formatClassSectionLabel } from '../lib/grading';
import { StudentPhotoField } from './StudentPhotoField';

interface Props {
  academicYear: string;
  classId: number;
  sectionId: number;
  onSaved?: () => Promise<void> | void;
}

interface DraftFields {
  fatherName: string;
  motherName: string;
  contactNo: string;
  aapaarId: string;
  residentialAddress: string;
  photoUrl: string;
}

export function ClassTeacherStudentDetailsPanel({
  academicYear,
  classId,
  sectionId,
  onSaved,
}: Props) {
  const [data, setData] = useState<ClassTeacherStudentProfilesResponse | null>(null);
  const [drafts, setDrafts] = useState<Record<number, DraftFields>>({});
  const [dirtyIds, setDirtyIds] = useState<Set<number>>(new Set());
  const [loading, setLoading] = useState(false);
  const [saving, setSaving] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [feedback, setFeedback] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  const reqSeqRef = useRef(0);
  const abortRef = useRef<AbortController | null>(null);

  useEffect(() => {
    return () => {
      abortRef.current?.abort();
    };
  }, []);

  const syncDraftsFromStudents = (students: ClassTeacherStudentProfile[]) => {
    const next: Record<number, DraftFields> = {};
    for (const st of students) {
      next[st.studentId] = {
        fatherName: st.fatherName || '',
        motherName: st.motherName || '',
        contactNo: st.contactNo || '',
        aapaarId: st.aapaarId || '',
        residentialAddress: st.residentialAddress || '',
        photoUrl: st.photoUrl || '',
      };
    }
    setDrafts(next);
    setDirtyIds(new Set());
  };

  const loadProfiles = async () => {
    abortRef.current?.abort();
    if (!classId || !sectionId) {
      setData(null);
      return;
    }
    const controller = new AbortController();
    abortRef.current = controller;
    const seq = ++reqSeqRef.current;

    setLoading(true);
    setError(null);
    setFeedback(null);
    try {
      const qs = new URLSearchParams({
        classId: String(classId),
        sectionId: String(sectionId),
      });
      if (academicYear && academicYear !== 'ALL') {
        qs.set('academicYear', academicYear);
      }
      const res = await apiFetch<ClassTeacherStudentProfilesResponse>(
        `/api/class-teacher/student-profiles?${qs.toString()}`,
        { signal: controller.signal }
      );
      if (seq !== reqSeqRef.current) return;
      setData(res);
      syncDraftsFromStudents(res.students);
    } catch (err: unknown) {
      if (isAbortError(err) || seq !== reqSeqRef.current) return;
      setData(null);
      setError(extractErrorMessage(err, 'Could not load class student details.'));
    } finally {
      if (seq === reqSeqRef.current) {
        setLoading(false);
      }
    }
  };

  useEffect(() => {
    loadProfiles();
  }, [academicYear, classId, sectionId]);

  const filteredStudents = useMemo(() => {
    if (!data) return [];
    const q = searchQuery.trim().toLowerCase();
    if (!q) return data.students;
    return data.students.filter((st) => {
      const d = drafts[st.studentId];
      return (
        st.fullName.toLowerCase().includes(q) ||
        st.studentCode.toLowerCase().includes(q) ||
        String(st.rollNumber).includes(q) ||
        (d?.fatherName || '').toLowerCase().includes(q) ||
        (d?.motherName || '').toLowerCase().includes(q) ||
        (d?.aapaarId || '').toLowerCase().includes(q)
      );
    });
  }, [data, drafts, searchQuery]);

  const handleFieldChange = (studentId: number, field: keyof DraftFields, value: string) => {
    setDrafts((prev) => {
      const base = prev[studentId] || {
        fatherName: '',
        motherName: '',
        contactNo: '',
        aapaarId: '',
        residentialAddress: '',
        photoUrl: '',
      };
      return {
        ...prev,
        [studentId]: {
          ...base,
          [field]: value,
        },
      };
    });
    setDirtyIds((prev) => {
      const next = new Set(prev);
      next.add(studentId);
      return next;
    });
    setFeedback(null);
  };

  const handleResetChanges = () => {
    if (!data) return;
    syncDraftsFromStudents(data.students);
    setFeedback(null);
  };

  const handleSaveRecords = async (onlyStudentId?: number) => {
    if (!data) return;
    const targetIds =
      onlyStudentId !== undefined
        ? [onlyStudentId]
        : dirtyIds.size > 0
          ? Array.from(dirtyIds)
          : data.students.map((s) => s.studentId);

    if (targetIds.length === 0) return;

    const records = targetIds.map((studentId) => {
      const d = drafts[studentId] || {
        fatherName: '',
        motherName: '',
        contactNo: '',
        aapaarId: '',
        residentialAddress: '',
        photoUrl: '',
      };
      return {
        studentId,
        fatherName: d.fatherName,
        motherName: d.motherName,
        contactNo: d.contactNo,
        aapaarId: d.aapaarId,
        residentialAddress: d.residentialAddress,
        photoUrl: d.photoUrl,
      };
    });

    setSaving(true);
    setFeedback(null);
    try {
      const res = await apiFetch<{
        success: boolean;
        academicYear: string;
        updatedCount: number;
        students: ClassTeacherStudentProfile[];
      }>('/api/class-teacher/student-profiles/save', {
        method: 'POST',
        body: JSON.stringify({
          classId,
          sectionId,
          academicYear: data.academicYear,
          records,
        }),
      });

      setData((prev) => (prev ? { ...prev, students: res.students } : prev));
      if (onlyStudentId !== undefined) {
        setDirtyIds((prev) => {
          const next = new Set(prev);
          next.delete(onlyStudentId);
          return next;
        });
      } else {
        setDirtyIds(new Set());
      }

      if (onSaved) {
        await onSaved();
      }

      setFeedback({
        type: 'success',
        text:
          onlyStudentId !== undefined
            ? 'Saved student details & photo. Final combined mark sheets and Admin Student Directory are updated.'
            : `Saved details for ${res.updatedCount} student(s). Final combined mark sheets and Admin Student Directory are updated.`,
      });
    } catch (err: unknown) {
      setFeedback({
        type: 'error',
        text: extractErrorMessage(err, 'Failed to save student details.'),
      });
    } finally {
      setSaving(false);
    }
  };

  if (loading && !data) {
    return (
      <div className="bg-white border border-slate-200 rounded-xl p-10 text-center text-sm text-slate-500">
        Loading Class Student Details...
      </div>
    );
  }

  if (error) {
    return (
      <div className="p-4 rounded-xl bg-red-50 border border-red-200 flex flex-wrap items-center justify-between gap-2 text-sm text-red-800">
        <span>{error}</span>
        <button
          type="button"
          onClick={loadProfiles}
          className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-white border border-red-200 rounded-lg text-xs font-semibold text-red-800 hover:bg-red-100 cursor-pointer"
        >
          <RefreshCw className="w-3.5 h-3.5" />
          Retry
        </button>
      </div>
    );
  }

  if (!data) {
    return (
      <div className="bg-white border border-slate-200 rounded-xl p-10 text-center text-sm text-slate-500">
        Select a class and section to view or update student details.
      </div>
    );
  }

  const classLabel = formatClassSectionLabel(
    data.classInfo.className,
    data.classInfo.sectionName,
    data.classInfo.hasSections ?? true
  );

  const photoCount = data.students.filter((st) => Boolean(drafts[st.studentId]?.photoUrl)).length;

  return (
    <div className="space-y-4">
      {/* Header & Controls */}
      <div className="bg-white border border-slate-200 rounded-xl p-4 space-y-3">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div>
            <div className="flex items-center gap-2 flex-wrap">
              <UserRound className="w-4 h-4 text-[#1E3A5F]" />
              <h2 className="text-sm font-bold text-slate-900">
                Student Details &amp; Photo — {classLabel}
              </h2>
              <span className="px-2 py-0.5 text-[11px] font-mono font-semibold rounded bg-slate-100 text-slate-700 border border-slate-200">
                AY {data.academicYear}
              </span>
            </div>
            <p className="text-xs text-slate-500 mt-1">
              All fields and student photos are optional. Parent, contact, AAPAAR, address, and compressed (&lt; 100 KB) student photos sync between Admin Student Directory and student marksheets.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <button
              type="button"
              onClick={loadProfiles}
              disabled={loading || saving}
              className="inline-flex items-center gap-1.5 px-3 py-2 min-h-[38px] text-xs font-medium text-slate-700 bg-white border border-slate-300 rounded-lg hover:bg-slate-50 disabled:opacity-50 cursor-pointer"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} />
              Refresh
            </button>
            {dirtyIds.size > 0 && (
              <button
                type="button"
                onClick={handleResetChanges}
                disabled={saving}
                className="inline-flex items-center gap-1.5 px-3 py-2 min-h-[38px] text-xs font-medium text-slate-700 bg-white border border-slate-300 rounded-lg hover:bg-slate-50 disabled:opacity-50 cursor-pointer"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                Discard ({dirtyIds.size})
              </button>
            )}
            <button
              type="button"
              onClick={() => handleSaveRecords()}
              disabled={saving || data.students.length === 0 || dirtyIds.size === 0}
              className="inline-flex items-center gap-1.5 px-4 py-2 min-h-[38px] text-xs font-semibold text-white bg-[#1E3A5F] rounded-lg hover:bg-[#162D4A] disabled:opacity-45 cursor-pointer shadow-xs"
            >
              <Save className="w-3.5 h-3.5" />
              {saving
                ? 'Saving...'
                : dirtyIds.size > 0
                  ? `Save Changes (${dirtyIds.size})`
                  : 'All Saved'}
            </button>
          </div>
        </div>

        <div className="flex flex-wrap items-center justify-between gap-3 pt-2 border-t border-slate-100">
          <div className="relative w-full sm:w-72">
            <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search student, roll, parent, AAPAAR..."
              className="w-full min-h-[36px] pl-8 pr-3 py-1.5 text-xs bg-white border border-slate-300 rounded-lg focus:outline-none focus:border-[#1E3A5F]"
            />
          </div>
          <div className="text-xs text-slate-500 flex items-center gap-3 flex-wrap">
            <span>
              Photos: <strong className="text-slate-800">{photoCount}</strong>/{data.students.length}
            </span>
            <span>·</span>
            <span>
              Showing <strong className="text-slate-800">{filteredStudents.length}</strong> of{' '}
              <strong className="text-slate-800">{data.students.length}</strong> active student(s)
            </span>
          </div>
        </div>
      </div>

      {feedback && (
        <div
          className={`flex items-center gap-2 p-3 rounded-xl border text-xs font-medium ${
            feedback.type === 'success'
              ? 'bg-emerald-50 border-emerald-200 text-emerald-900'
              : 'bg-red-50 border-red-200 text-red-900'
          }`}
        >
          {feedback.type === 'success' ? (
            <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
          ) : (
            <AlertTriangle className="w-4 h-4 text-red-600 shrink-0" />
          )}
          <span>{feedback.text}</span>
        </div>
      )}

      {data.students.length === 0 ? (
        <div className="bg-white border border-slate-200 rounded-xl p-10 text-center text-sm text-slate-500">
          No active students found in {classLabel} for AY {data.academicYear}.
        </div>
      ) : (
        <>
          {/* Mobile Cards */}
          <div className="lg:hidden space-y-3">
            {filteredStudents.map((st) => {
              const d = drafts[st.studentId] || {
                fatherName: '',
                motherName: '',
                contactNo: '',
                aapaarId: '',
                residentialAddress: '',
                photoUrl: '',
              };
              const isDirty = dirtyIds.has(st.studentId);
              return (
                <div
                  key={st.studentId}
                  className={`bg-white border rounded-xl p-4 space-y-3 text-xs ${
                    isDirty ? 'border-amber-400 ring-1 ring-amber-200' : 'border-slate-200'
                  }`}
                >
                  <div className="flex items-start justify-between gap-2 border-b border-slate-100 pb-3">
                    <div>
                      <div className="font-bold text-sm text-slate-900">{st.fullName}</div>
                      <div className="font-mono text-[11px] text-slate-500">
                        Roll {String(st.rollNumber).padStart(2, '0')} · {st.studentCode}
                        {st.stream ? ` · ${st.stream}` : ''}
                      </div>
                    </div>
                    {isDirty && (
                      <button
                        type="button"
                        disabled={saving}
                        onClick={() => handleSaveRecords(st.studentId)}
                        className="inline-flex items-center gap-1 px-2.5 py-1.5 text-[11px] font-semibold text-white bg-[#1E3A5F] rounded-lg cursor-pointer shrink-0"
                      >
                        <Save className="w-3 h-3" />
                        Save
                      </button>
                    )}
                  </div>

                  <div className="pt-0.5">
                    <StudentPhotoField
                      value={d.photoUrl}
                      studentName={st.fullName}
                      onChange={(nextUrl) => handleFieldChange(st.studentId, 'photoUrl', nextUrl)}
                      onError={(msg) => setFeedback({ type: 'error', text: msg })}
                      compact
                    />
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                    <div>
                      <label className="block font-medium text-slate-600 mb-1">Father&apos;s Name</label>
                      <input
                        type="text"
                        value={d.fatherName}
                        onChange={(e) => handleFieldChange(st.studentId, 'fatherName', e.target.value)}
                        placeholder="Optional"
                        className="w-full min-h-[36px] px-2.5 py-1.5 border border-slate-300 rounded-lg focus:outline-none focus:border-[#1E3A5F]"
                      />
                    </div>
                    <div>
                      <label className="block font-medium text-slate-600 mb-1">Mother&apos;s Name</label>
                      <input
                        type="text"
                        value={d.motherName}
                        onChange={(e) => handleFieldChange(st.studentId, 'motherName', e.target.value)}
                        placeholder="Optional"
                        className="w-full min-h-[36px] px-2.5 py-1.5 border border-slate-300 rounded-lg focus:outline-none focus:border-[#1E3A5F]"
                      />
                    </div>
                    <div>
                      <label className="block font-medium text-slate-600 mb-1">Contact No.</label>
                      <input
                        type="text"
                        value={d.contactNo}
                        onChange={(e) => handleFieldChange(st.studentId, 'contactNo', e.target.value)}
                        placeholder="Optional"
                        className="w-full min-h-[36px] px-2.5 py-1.5 border border-slate-300 rounded-lg font-mono focus:outline-none focus:border-[#1E3A5F]"
                      />
                    </div>
                    <div>
                      <label className="block font-medium text-slate-600 mb-1">AAPAAR ID</label>
                      <input
                        type="text"
                        value={d.aapaarId}
                        onChange={(e) => handleFieldChange(st.studentId, 'aapaarId', e.target.value)}
                        placeholder="Optional"
                        className="w-full min-h-[36px] px-2.5 py-1.5 border border-slate-300 rounded-lg font-mono focus:outline-none focus:border-[#1E3A5F]"
                      />
                    </div>
                    <div className="sm:col-span-2">
                      <label className="block font-medium text-slate-600 mb-1">Residential Address</label>
                      <input
                        type="text"
                        value={d.residentialAddress}
                        onChange={(e) => handleFieldChange(st.studentId, 'residentialAddress', e.target.value)}
                        placeholder="Optional"
                        className="w-full min-h-[36px] px-2.5 py-1.5 border border-slate-300 rounded-lg focus:outline-none focus:border-[#1E3A5F]"
                      />
                    </div>
                  </div>
                </div>
              );
            })}
          </div>

          {/* Desktop Editable Spreadsheet Table */}
          <div className="hidden lg:block bg-white border border-slate-200 rounded-xl overflow-hidden">
            <div className="overflow-x-auto max-h-[68vh]">
              <table className="w-full text-xs">
                <thead className="bg-slate-50 border-b border-slate-200 text-slate-700 sticky top-0 z-10">
                  <tr>
                    <th className="text-left font-semibold px-3 py-2.5 w-14">Roll</th>
                    <th className="text-left font-semibold px-2.5 py-2.5 min-w-[230px]">Student Photo (File / Camera)</th>
                    <th className="text-left font-semibold px-3 py-2.5 min-w-[160px]">Student</th>
                    <th className="text-left font-semibold px-2.5 py-2.5 min-w-[155px]">Father&apos;s Name</th>
                    <th className="text-left font-semibold px-2.5 py-2.5 min-w-[155px]">Mother&apos;s Name</th>
                    <th className="text-left font-semibold px-2.5 py-2.5 min-w-[125px]">Contact No.</th>
                    <th className="text-left font-semibold px-2.5 py-2.5 min-w-[135px]">AAPAAR ID</th>
                    <th className="text-left font-semibold px-2.5 py-2.5 min-w-[200px]">Residential Address</th>
                    <th className="text-right font-semibold px-3 py-2.5 w-24">Action</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200">
                  {filteredStudents.map((st) => {
                    const d = drafts[st.studentId] || {
                      fatherName: '',
                      motherName: '',
                      contactNo: '',
                      aapaarId: '',
                      residentialAddress: '',
                      photoUrl: '',
                    };
                    const isDirty = dirtyIds.has(st.studentId);
                    return (
                      <tr
                        key={st.studentId}
                        className={isDirty ? 'bg-amber-50/40' : 'hover:bg-slate-50/70'}
                      >
                        <td className="px-3 py-2 font-mono font-semibold text-slate-700 tabular-nums">
                          {String(st.rollNumber).padStart(2, '0')}
                        </td>
                        <td className="px-2.5 py-2">
                          <StudentPhotoField
                            value={d.photoUrl}
                            studentName={st.fullName}
                            onChange={(nextUrl) => handleFieldChange(st.studentId, 'photoUrl', nextUrl)}
                            onError={(msg) => setFeedback({ type: 'error', text: msg })}
                            compact
                          />
                        </td>
                        <td className="px-3 py-2">
                          <div className="font-semibold text-slate-900">{st.fullName}</div>
                          <div className="font-mono text-[10px] text-slate-400">
                            {st.studentCode}
                            {st.stream ? ` · ${st.stream}` : ''}
                          </div>
                        </td>
                        <td className="px-2 py-1.5">
                          <input
                            type="text"
                            value={d.fatherName}
                            onChange={(e) => handleFieldChange(st.studentId, 'fatherName', e.target.value)}
                            placeholder="Optional"
                            className="w-full min-h-[34px] px-2.5 py-1 border border-slate-300 rounded-md bg-white focus:outline-none focus:border-[#1E3A5F]"
                          />
                        </td>
                        <td className="px-2 py-1.5">
                          <input
                            type="text"
                            value={d.motherName}
                            onChange={(e) => handleFieldChange(st.studentId, 'motherName', e.target.value)}
                            placeholder="Optional"
                            className="w-full min-h-[34px] px-2.5 py-1 border border-slate-300 rounded-md bg-white focus:outline-none focus:border-[#1E3A5F]"
                          />
                        </td>
                        <td className="px-2 py-1.5">
                          <input
                            type="text"
                            value={d.contactNo}
                            onChange={(e) => handleFieldChange(st.studentId, 'contactNo', e.target.value)}
                            placeholder="Optional"
                            className="w-full min-h-[34px] px-2.5 py-1 border border-slate-300 rounded-md bg-white font-mono focus:outline-none focus:border-[#1E3A5F]"
                          />
                        </td>
                        <td className="px-2 py-1.5">
                          <input
                            type="text"
                            value={d.aapaarId}
                            onChange={(e) => handleFieldChange(st.studentId, 'aapaarId', e.target.value)}
                            placeholder="Optional"
                            className="w-full min-h-[34px] px-2.5 py-1 border border-slate-300 rounded-md bg-white font-mono focus:outline-none focus:border-[#1E3A5F]"
                          />
                        </td>
                        <td className="px-2 py-1.5">
                          <input
                            type="text"
                            value={d.residentialAddress}
                            onChange={(e) =>
                              handleFieldChange(st.studentId, 'residentialAddress', e.target.value)
                            }
                            placeholder="Optional"
                            className="w-full min-h-[34px] px-2.5 py-1 border border-slate-300 rounded-md bg-white focus:outline-none focus:border-[#1E3A5F]"
                          />
                        </td>
                        <td className="px-3 py-1.5 text-right whitespace-nowrap">
                          {isDirty ? (
                            <button
                              type="button"
                              disabled={saving}
                              onClick={() => handleSaveRecords(st.studentId)}
                              className="inline-flex items-center gap-1 px-2.5 py-1.5 text-[11px] font-semibold text-white bg-[#1E3A5F] hover:bg-[#162D4A] rounded-md cursor-pointer"
                            >
                              <Save className="w-3 h-3" />
                              Save
                            </button>
                          ) : (
                            <span className="text-[11px] text-slate-400">Saved</span>
                          )}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        </>
      )}
    </div>
  );
}
