import React, { useEffect, useState } from 'react';

export const DEFAULT_SCHOOL_LOGO_PATH = '/assets/aistudio/logo_emrs_1d5c0342.jpg';

const LEGACY_DEFAULT_PATHS = new Set([
  '/assets/aistudio/logo_emrs_1d5c0342.jpg',
  'assets/aistudio/logo_emrs_1d5c0342.jpg',
  '/school-emblem.jpg',
  'school-emblem.jpg',
  '/src/assets/images/school_emblem_logo_1794585477262.jpg',
  'src/assets/images/school_emblem_logo_1794585477262.jpg',
]);

export function resolveLogoSource(logo?: string | null, allowDefaultWhenEmpty = true): string | null {
  const trimmed = (logo || '').trim();
  if (!trimmed) {
    return allowDefaultWhenEmpty ? DEFAULT_SCHOOL_LOGO_PATH : null;
  }
  if (LEGACY_DEFAULT_PATHS.has(trimmed)) {
    return DEFAULT_SCHOOL_LOGO_PATH;
  }
  return trimmed;
}

export function SchoolLogo({
  src,
  alt,
  className = 'w-10 h-10 object-contain rounded-lg border border-slate-200 p-0.5 shrink-0 bg-white',
  allowDefaultWhenEmpty = true,
}: {
  src?: string | null;
  alt: string;
  className?: string;
  allowDefaultWhenEmpty?: boolean;
}) {
  const primarySrc = resolveLogoSource(src, allowDefaultWhenEmpty);
  const [activeSrc, setActiveSrc] = useState<string | null>(primarySrc);

  useEffect(() => {
    setActiveSrc(resolveLogoSource(src, allowDefaultWhenEmpty));
  }, [src, allowDefaultWhenEmpty]);

  if (!activeSrc) return null;

  return (
    <img
      src={activeSrc}
      alt={alt}
      referrerPolicy="no-referrer"
      decoding="async"
      onError={() => {
        if (activeSrc !== DEFAULT_SCHOOL_LOGO_PATH) {
          setActiveSrc(DEFAULT_SCHOOL_LOGO_PATH);
        }
      }}
      className={className}
    />
  );
}
