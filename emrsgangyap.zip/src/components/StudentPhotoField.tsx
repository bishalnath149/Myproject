import React, { useEffect, useRef, useState } from 'react';
import { Camera, RefreshCw, SwitchCamera, Trash2, Upload, UserRound, X } from 'lucide-react';
import {
  captureVideoFrameToUnder100KB,
  compressPhotoFileToUnder100KB,
  formatPhotoByteSize,
  getDataUrlByteSize,
} from '../lib/photoUpload';

interface Props {
  value: string;
  studentName?: string;
  onChange: (nextUrl: string) => void;
  onError?: (message: string) => void;
  compact?: boolean;
}

export function StudentPhotoField({
  value,
  studentName,
  onChange,
  onError,
  compact = false,
}: Props) {
  const [processing, setProcessing] = useState(false);
  const [cameraOpen, setCameraOpen] = useState(false);
  const [facingMode, setFacingMode] = useState<'user' | 'environment'>('user');
  const [cameraStarting, setCameraStarting] = useState(false);
  const [cameraError, setCameraError] = useState<string | null>(null);

  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const deviceCameraInputRef = useRef<HTMLInputElement | null>(null);
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const streamRef = useRef<MediaStream | null>(null);

  const stopCameraStream = () => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach((t) => {
        try {
          t.stop();
        } catch {
          // ignore
        }
      });
      streamRef.current = null;
    }
    if (videoRef.current) {
      videoRef.current.srcObject = null;
    }
  };

  useEffect(() => {
    if (!cameraOpen) {
      stopCameraStream();
      return;
    }

    let cancelled = false;
    const startCamera = async () => {
      stopCameraStream();
      setCameraStarting(true);
      setCameraError(null);
      if (typeof navigator === 'undefined' || !navigator.mediaDevices?.getUserMedia) {
        setCameraError(
          'Live webcam access is unavailable in this browser/frame. Use "Device Camera App" or upload a file instead.'
        );
        setCameraStarting(false);
        return;
      }

      try {
        const stream = await navigator.mediaDevices.getUserMedia({
          video: {
            facingMode: { ideal: facingMode },
            width: { ideal: 720 },
            height: { ideal: 960 },
          },
          audio: false,
        });
        if (cancelled) {
          stream.getTracks().forEach((t) => t.stop());
          return;
        }
        streamRef.current = stream;
        if (videoRef.current) {
          videoRef.current.srcObject = stream;
          await videoRef.current.play().catch(() => {});
        }
      } catch (err: unknown) {
        if (cancelled) return;
        const msg =
          err instanceof Error && err.message
            ? err.message
            : 'Camera permission was denied or no camera device was found.';
        setCameraError(`${msg} You can also use "Device Camera App" below.`);
      } finally {
        if (!cancelled) {
          setCameraStarting(false);
        }
      }
    };

    void startCamera();
    return () => {
      cancelled = true;
      stopCameraStream();
    };
  }, [cameraOpen, facingMode]);

  const handleFileChange = async (file: File | null) => {
    if (!file) return;
    setProcessing(true);
    try {
      const { dataUrl } = await compressPhotoFileToUnder100KB(file);
      onChange(dataUrl);
      if (cameraOpen) setCameraOpen(false);
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Failed to process photo.';
      onError?.(msg);
    } finally {
      setProcessing(false);
    }
  };

  const handleCaptureFrame = () => {
    if (!videoRef.current) return;
    setProcessing(true);
    setCameraError(null);
    try {
      const { dataUrl } = captureVideoFrameToUnder100KB(videoRef.current);
      onChange(dataUrl);
      setCameraOpen(false);
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Failed to capture photo from camera.';
      setCameraError(msg);
      onError?.(msg);
    } finally {
      setProcessing(false);
    }
  };

  const photoBytes = value.startsWith('data:image/') ? getDataUrlByteSize(value) : 0;

  return (
    <div className="flex flex-wrap items-center gap-3">
      <div
        className={`${
          compact ? 'w-14 h-16' : 'w-16 h-20'
        } rounded-lg border border-slate-300 bg-slate-50 overflow-hidden flex items-center justify-center shrink-0`}
      >
        {value ? (
          <img
            src={value}
            alt={studentName || 'Student Photo'}
            className="w-full h-full object-cover"
          />
        ) : (
          <UserRound className="w-6 h-6 text-slate-300" />
        )}
      </div>

      <div className="flex flex-col gap-1.5 min-w-0">
        <div className="flex flex-wrap items-center gap-1.5">
          <input
            ref={fileInputRef}
            type="file"
            accept="image/jpeg,image/png,image/webp,image/*"
            className="hidden"
            onChange={(e) => {
              const f = e.target.files?.[0] || null;
              void handleFileChange(f);
              e.currentTarget.value = '';
            }}
          />
          <button
            type="button"
            disabled={processing}
            onClick={() => fileInputRef.current?.click()}
            className="inline-flex items-center justify-center gap-1.5 min-h-[38px] sm:min-h-[32px] px-2.5 py-1.5 text-xs font-medium text-slate-700 bg-white border border-slate-300 rounded-lg hover:bg-slate-50 disabled:opacity-50 cursor-pointer"
          >
            <Upload className="w-3.5 h-3.5 text-[#1E3A5F]" />
            {processing ? 'Processing...' : value ? 'Upload File' : 'Upload Photo'}
          </button>

          <button
            type="button"
            disabled={processing}
            onClick={() => {
              setCameraError(null);
              setCameraOpen(true);
            }}
            className="inline-flex items-center justify-center gap-1.5 min-h-[38px] sm:min-h-[32px] px-2.5 py-1.5 text-xs font-medium text-[#1E3A5F] bg-sky-50 border border-sky-200 rounded-lg hover:bg-sky-100 disabled:opacity-50 cursor-pointer"
          >
            <Camera className="w-3.5 h-3.5" />
            Camera
          </button>

          {value && (
            <button
              type="button"
              disabled={processing}
              onClick={() => onChange('')}
              className="inline-flex items-center justify-center gap-1 min-h-[38px] sm:min-h-[32px] px-2.5 py-1.5 text-xs font-medium text-rose-700 bg-rose-50 border border-rose-200 rounded-lg hover:bg-rose-100 cursor-pointer"
            >
              <Trash2 className="w-3.5 h-3.5" />
              Remove
            </button>
          )}
        </div>

        <div className="text-[11px] text-slate-500 font-mono">
          {value
            ? photoBytes > 0
              ? `Ready · ${formatPhotoByteSize(photoBytes)} (under 100 KB)`
              : 'Photo attached'
            : 'Auto-compressed under 100 KB JPEG'}
        </div>
      </div>

      {/* Live Camera Capture Modal */}
      {cameraOpen && (
        <div className="fixed inset-0 z-[70] flex items-center justify-center bg-slate-900/70 p-3 sm:p-4">
          <div className="bg-white border border-slate-200 rounded-xl w-full max-w-md overflow-hidden shadow-2xl">
            <div className="flex items-center justify-between px-4 py-3 border-b border-slate-200 bg-slate-50">
              <div>
                <h4 className="text-sm font-bold text-slate-900">Capture Student Photo</h4>
                <p className="text-[11px] text-slate-500">
                  {studentName ? `${studentName} · ` : ''}Automatically compressed to under 100 KB
                </p>
              </div>
              <button
                type="button"
                onClick={() => setCameraOpen(false)}
                className="p-2 text-slate-500 hover:text-slate-900 rounded-lg hover:bg-slate-200 cursor-pointer"
                aria-label="Close camera"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="p-4 space-y-3">
              <div className="relative w-full aspect-[5/6] max-h-[360px] mx-auto bg-slate-950 rounded-xl overflow-hidden flex items-center justify-center border border-slate-300">
                <video
                  ref={videoRef}
                  autoPlay
                  playsInline
                  muted
                  className={`w-full h-full object-cover ${facingMode === 'user' ? 'scale-x-[-1]' : ''}`}
                />
                {!cameraError && (
                  <div className="pointer-events-none absolute inset-4 border-2 border-dashed border-white/50 rounded-lg" />
                )}
                {cameraStarting && (
                  <div className="absolute inset-0 flex flex-col items-center justify-center gap-2 bg-slate-900/70 text-white text-xs">
                    <RefreshCw className="w-5 h-5 animate-spin" />
                    <span>Starting camera...</span>
                  </div>
                )}
              </div>

              {cameraError && (
                <div className="p-2.5 rounded-lg bg-amber-50 border border-amber-200 text-xs text-amber-900">
                  {cameraError}
                </div>
              )}

              <input
                ref={deviceCameraInputRef}
                type="file"
                accept="image/*"
                capture={facingMode}
                className="hidden"
                onChange={(e) => {
                  const f = e.target.files?.[0] || null;
                  void handleFileChange(f);
                  e.currentTarget.value = '';
                }}
              />

              <div className="flex flex-wrap items-center justify-between gap-2">
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => setFacingMode((prev) => (prev === 'user' ? 'environment' : 'user'))}
                    className="inline-flex items-center gap-1.5 min-h-[42px] px-3 py-2 text-xs font-medium text-slate-700 bg-white border border-slate-300 rounded-lg hover:bg-slate-50 cursor-pointer"
                  >
                    <SwitchCamera className="w-3.5 h-3.5" />
                    Flip
                  </button>
                  <button
                    type="button"
                    onClick={() => deviceCameraInputRef.current?.click()}
                    className="inline-flex items-center gap-1.5 min-h-[42px] px-3 py-2 text-xs font-medium text-slate-700 bg-slate-100 border border-slate-300 rounded-lg hover:bg-slate-200 cursor-pointer"
                  >
                    <Camera className="w-3.5 h-3.5" />
                    Device Camera App
                  </button>
                </div>

                <div className="flex items-center gap-2 ml-auto">
                  <button
                    type="button"
                    onClick={() => setCameraOpen(false)}
                    className="min-h-[42px] px-3 py-2 text-xs font-medium text-slate-700 border border-slate-300 rounded-lg hover:bg-slate-50 cursor-pointer"
                  >
                    Cancel
                  </button>
                  <button
                    type="button"
                    disabled={processing || cameraStarting || Boolean(cameraError)}
                    onClick={handleCaptureFrame}
                    className="inline-flex items-center gap-1.5 min-h-[42px] px-4 py-2 text-xs font-semibold text-white bg-[#1E3A5F] rounded-lg hover:bg-[#162D4A] disabled:opacity-50 cursor-pointer"
                  >
                    <Camera className="w-3.5 h-3.5" />
                    {processing ? 'Compressing...' : 'Capture Photo'}
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
