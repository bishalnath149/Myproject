import React from 'react';
import { CheckCircle2, Clock, AlertCircle, Lock } from 'lucide-react';

export function SubmissionStatusLabel({
  status,
}: {
  status: 'Submitted' | 'Draft' | 'Pending' | 'submitted' | 'draft' | 'pending';
}) {
  const norm = status.toLowerCase();
  if (norm === 'submitted') {
    return (
      <span className="inline-flex items-center gap-1.5 px-2 py-0.5 text-xs font-medium rounded bg-emerald-50 text-emerald-800 border border-emerald-200 whitespace-nowrap">
        <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
        Submitted
      </span>
    );
  }
  if (norm === 'draft') {
    return (
      <span className="inline-flex items-center gap-1.5 px-2 py-0.5 text-xs font-medium rounded bg-amber-50 text-amber-800 border border-amber-200 whitespace-nowrap">
        <Clock className="w-3.5 h-3.5 text-amber-600 shrink-0" />
        Draft
      </span>
    );
  }
  return (
    <span className="inline-flex items-center gap-1.5 px-2 py-0.5 text-xs font-medium rounded bg-red-50 text-red-800 border border-red-200 whitespace-nowrap">
      <AlertCircle className="w-3.5 h-3.5 text-red-600 shrink-0" />
      Pending
    </span>
  );
}

export function ResultStatusLabel({ status }: { status: 'Pass' | 'Fail' | 'Incomplete' }) {
  if (status === 'Pass') {
    return (
      <span className="inline-flex items-center px-2 py-0.5 text-xs font-medium rounded bg-emerald-50 text-emerald-800 border border-emerald-200 whitespace-nowrap">
        Pass
      </span>
    );
  }
  if (status === 'Fail') {
    return (
      <span className="inline-flex items-center px-2 py-0.5 text-xs font-medium rounded bg-red-50 text-red-800 border border-red-200 whitespace-nowrap">
        Fail
      </span>
    );
  }
  return (
    <span className="inline-flex items-center px-2 py-0.5 text-xs font-medium rounded bg-amber-50 text-amber-800 border border-amber-200 whitespace-nowrap">
      Incomplete
    </span>
  );
}

export function ExamStatusLabel({ status, marksEntryOpen }: { status: string; marksEntryOpen?: boolean }) {
  const styles: Record<string, string> = {
    Active: 'bg-emerald-50 text-emerald-800 border-emerald-200',
    Published: 'bg-sky-50 text-sky-800 border-sky-200',
    Completed: 'bg-slate-100 text-slate-700 border-slate-200',
    Upcoming: 'bg-amber-50 text-amber-800 border-amber-200',
  };
  return (
    <span className="inline-flex items-center gap-2 whitespace-nowrap">
      <span
        className={`inline-flex items-center px-2 py-0.5 text-xs font-medium rounded border ${
          styles[status] || styles.Upcoming
        }`}
      >
        {status}
      </span>
      {marksEntryOpen === false && (
        <span className="inline-flex items-center gap-1 text-xs text-slate-500">
          <Lock className="w-3 h-3" /> Entry Closed
        </span>
      )}
    </span>
  );
}

export function AttendanceBadge({ status }: { status: 'present' | 'absent' | 'pending' }) {
  if (status === 'present') {
    return (
      <span className="inline-flex items-center px-2 py-0.5 text-[11px] font-semibold rounded bg-emerald-50 text-emerald-700 border border-emerald-200 whitespace-nowrap">
        Present
      </span>
    );
  }
  if (status === 'absent') {
    return (
      <span className="inline-flex items-center px-2 py-0.5 text-[11px] font-semibold rounded bg-rose-50 text-rose-700 border border-rose-200 whitespace-nowrap">
        Absent (AB)
      </span>
    );
  }
  return (
    <span className="inline-flex items-center px-2 py-0.5 text-[11px] font-semibold rounded bg-slate-100 text-slate-600 border border-slate-200 whitespace-nowrap">
      Pending
    </span>
  );
}
