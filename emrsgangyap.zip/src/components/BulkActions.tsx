import React, { useMemo, useState } from 'react';
import {
  AlertTriangle,
  Archive,
  CheckCircle2,
  ChevronLeft,
  ChevronRight,
  Download,
  Edit3,
  Power,
  RotateCcw,
  Trash2,
  X,
} from 'lucide-react';

export interface BulkActionOption {
  id: string;
  label: string;
  variant?: 'danger' | 'warning' | 'primary' | 'default' | 'success';
  icon?: 'delete' | 'archive' | 'restore' | 'edit' | 'activate' | 'deactivate' | 'export';
  onClick: () => void;
}

interface BulkActionToolbarProps {
  selectedCount: number;
  entityLabel: string;
  onClearSelection: () => void;
  actions: BulkActionOption[];
  disabled?: boolean;
}

export function BulkActionToolbar({
  selectedCount,
  entityLabel,
  onClearSelection,
  actions,
  disabled = false,
}: BulkActionToolbarProps) {
  if (selectedCount <= 0) return null;

  const iconFor = (icon?: BulkActionOption['icon']) => {
    switch (icon) {
      case 'delete':
        return <Trash2 className="w-3.5 h-3.5" />;
      case 'archive':
        return <Archive className="w-3.5 h-3.5" />;
      case 'restore':
        return <RotateCcw className="w-3.5 h-3.5" />;
      case 'edit':
        return <Edit3 className="w-3.5 h-3.5" />;
      case 'activate':
      case 'deactivate':
        return <Power className="w-3.5 h-3.5" />;
      case 'export':
        return <Download className="w-3.5 h-3.5" />;
      default:
        return null;
    }
  };

  const variantClasses = (variant?: BulkActionOption['variant']) => {
    switch (variant) {
      case 'danger':
        return 'bg-red-700 hover:bg-red-800 text-white border-red-700';
      case 'warning':
        return 'bg-amber-600 hover:bg-amber-700 text-white border-amber-600';
      case 'success':
        return 'bg-emerald-700 hover:bg-emerald-800 text-white border-emerald-700';
      case 'primary':
        return 'bg-[#1E3A5F] hover:bg-[#152a45] text-white border-[#1E3A5F]';
      default:
        return 'bg-white hover:bg-slate-100 text-slate-800 border-slate-300';
    }
  };

  return (
    <div
      role="region"
      aria-label="Bulk selection actions"
      className="bg-slate-900 text-white rounded-xl p-3 sm:px-4 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2.5 shadow-sm"
    >
      <div className="flex items-center justify-between sm:justify-start gap-3">
        <span className="text-xs font-semibold font-mono tabular-nums">
          {selectedCount} {entityLabel}
          {selectedCount === 1 ? '' : 's'} selected
        </span>
        <button
          type="button"
          onClick={onClearSelection}
          disabled={disabled}
          className="inline-flex items-center gap-1 px-2.5 py-1.5 text-[11px] font-medium text-slate-200 hover:text-white bg-slate-800 hover:bg-slate-700 rounded-lg cursor-pointer"
        >
          <X className="w-3 h-3" />
          Clear
        </button>
      </div>
      <div className="flex flex-wrap items-center gap-2">
        {actions.map((act) => (
          <button
            key={act.id}
            type="button"
            disabled={disabled}
            onClick={act.onClick}
            className={`min-h-[38px] sm:min-h-[34px] inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold border rounded-lg transition-colors disabled:opacity-50 cursor-pointer ${variantClasses(
              act.variant
            )}`}
          >
            {iconFor(act.icon)}
            <span>{act.label}</span>
          </button>
        ))}
      </div>
    </div>
  );
}

export interface BulkConfirmItem {
  id: string | number;
  label: string;
  sublabel?: string;
}

interface BulkConfirmModalProps {
  open: boolean;
  title: string;
  confirmLabel: string;
  description: string;
  safetyNote?: string;
  safetyNoteTone?: 'success' | 'danger' | 'warning';
  items: BulkConfirmItem[];
  variant?: 'danger' | 'warning' | 'primary';
  busy?: boolean;
  onCancel: () => void;
  onConfirm: () => void;
}

export function BulkConfirmModal({
  open,
  title,
  confirmLabel,
  description,
  safetyNote,
  safetyNoteTone = 'success',
  items,
  variant = 'danger',
  busy = false,
  onCancel,
  onConfirm,
}: BulkConfirmModalProps) {
  if (!open) return null;

  const previewItems = items.slice(0, 12);
  const remaining = items.length - previewItems.length;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 p-4">
      <div
        role="dialog"
        aria-modal="true"
        className="bg-white border border-slate-200 rounded-xl w-full max-w-lg max-h-[90vh] flex flex-col shadow-xl text-xs"
      >
        <div className="px-5 py-4 border-b border-slate-200 flex items-start gap-3">
          <div
            className={`p-2 rounded-lg shrink-0 ${
              variant === 'danger'
                ? 'bg-red-50 text-red-700'
                : variant === 'warning'
                  ? 'bg-amber-50 text-amber-700'
                  : 'bg-sky-50 text-sky-700'
            }`}
          >
            <AlertTriangle className="w-5 h-5" />
          </div>
          <div className="min-w-0 flex-1">
            <h3 className="text-sm font-bold text-slate-900">{title}</h3>
            <p className="text-xs text-slate-600 mt-1 leading-relaxed">{description}</p>
          </div>
          <button
            type="button"
            onClick={onCancel}
            disabled={busy}
            className="p-1.5 text-slate-400 hover:text-slate-700 rounded-lg cursor-pointer"
            aria-label="Close confirmation dialog"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="p-5 space-y-3 overflow-y-auto">
          <div className="text-[11px] font-semibold uppercase tracking-wide text-slate-500 font-mono">
            Affected Records ({items.length})
          </div>
          <div className="max-h-48 overflow-y-auto border border-slate-200 rounded-lg divide-y divide-slate-100 bg-slate-50/70">
            {previewItems.map((it) => (
              <div key={String(it.id)} className="px-3 py-2 flex items-center justify-between gap-2">
                <span className="font-medium text-slate-900 truncate">{it.label}</span>
                {it.sublabel && (
                  <span className="text-[11px] font-mono text-slate-500 shrink-0">{it.sublabel}</span>
                )}
              </div>
            ))}
            {remaining > 0 && (
              <div className="px-3 py-2 text-[11px] text-slate-500 font-medium">
                ...and {remaining} more record{remaining === 1 ? '' : 's'}
              </div>
            )}
          </div>

          {safetyNote && (
            <div
              className={`p-3 border rounded-lg text-[11px] leading-relaxed ${
                safetyNoteTone === 'danger'
                  ? 'bg-red-50 border-red-200 text-red-900 font-medium'
                  : safetyNoteTone === 'warning'
                    ? 'bg-amber-50 border-amber-200 text-amber-900'
                    : 'bg-emerald-50 border-emerald-200 text-emerald-900'
              }`}
            >
              {safetyNote}
            </div>
          )}
        </div>

        <div className="px-5 py-3.5 border-t border-slate-200 bg-slate-50 flex flex-col-reverse sm:flex-row sm:justify-end gap-2">
          <button
            type="button"
            onClick={onCancel}
            disabled={busy}
            className="min-h-[42px] sm:min-h-[36px] px-4 py-2 text-xs font-medium text-slate-700 bg-white border border-slate-300 rounded-lg hover:bg-slate-100 cursor-pointer"
          >
            Cancel
          </button>
          <button
            type="button"
            onClick={onConfirm}
            disabled={busy}
            className={`min-h-[42px] sm:min-h-[36px] px-4 py-2 text-xs font-semibold text-white rounded-lg disabled:opacity-50 cursor-pointer ${
              variant === 'danger'
                ? 'bg-red-700 hover:bg-red-800'
                : variant === 'warning'
                  ? 'bg-amber-600 hover:bg-amber-700'
                  : 'bg-[#1E3A5F] hover:bg-[#152a45]'
            }`}
          >
            {busy ? 'Processing...' : confirmLabel}
          </button>
        </div>
      </div>
    </div>
  );
}

interface UndoBannerProps {
  message: string;
  onUndo: () => void;
  onDismiss: () => void;
  busy?: boolean;
}

export function UndoBanner({ message, onUndo, onDismiss, busy = false }: UndoBannerProps) {
  return (
    <div className="p-3.5 bg-emerald-50 border border-emerald-200 rounded-xl flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2.5 text-xs text-emerald-950">
      <div className="flex items-center gap-2 min-w-0">
        <CheckCircle2 className="w-4 h-4 text-emerald-700 shrink-0" />
        <span className="font-medium truncate">{message}</span>
      </div>
      <div className="flex items-center gap-2 shrink-0">
        <button
          type="button"
          onClick={onUndo}
          disabled={busy}
          className="min-h-[36px] inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold bg-emerald-800 text-white rounded-lg hover:bg-emerald-900 disabled:opacity-50 cursor-pointer"
        >
          <RotateCcw className="w-3.5 h-3.5" />
          {busy ? 'Restoring...' : 'Undo / Restore'}
        </button>
        <button
          type="button"
          onClick={onDismiss}
          className="min-h-[36px] px-2.5 py-1.5 text-xs font-medium text-emerald-800 hover:bg-emerald-100 rounded-lg cursor-pointer"
        >
          Dismiss
        </button>
      </div>
    </div>
  );
}

interface PaginationBarProps {
  totalItems: number;
  page: number;
  pageSize: number;
  onPageChange: (nextPage: number) => void;
  onPageSizeChange: (nextSize: number) => void;
}

export function PaginationBar({
  totalItems,
  page,
  pageSize,
  onPageChange,
  onPageSizeChange,
}: PaginationBarProps) {
  const totalPages = Math.max(1, Math.ceil(totalItems / pageSize));
  const safePage = Math.min(Math.max(1, page), totalPages);
  const startIdx = totalItems === 0 ? 0 : (safePage - 1) * pageSize + 1;
  const endIdx = Math.min(totalItems, safePage * pageSize);

  return (
    <div className="px-4 py-3 border-t border-slate-200 bg-slate-50/70 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2 text-xs text-slate-600">
      <div className="flex items-center justify-between sm:justify-start gap-3">
        <span className="font-mono tabular-nums">
          Showing {startIdx}–{endIdx} of {totalItems}
        </span>
        <label className="inline-flex items-center gap-1.5">
          <span>Rows:</span>
          <select
            value={pageSize}
            onChange={(e) => onPageSizeChange(Number(e.target.value))}
            className="px-2 py-1 text-xs bg-white border border-slate-300 rounded-lg font-mono"
          >
            {[10, 25, 50, 100].map((sz) => (
              <option key={sz} value={sz}>
                {sz}
              </option>
            ))}
          </select>
        </label>
      </div>
      <div className="flex items-center justify-between sm:justify-end gap-1.5">
        <button
          type="button"
          disabled={safePage <= 1}
          onClick={() => onPageChange(safePage - 1)}
          className="min-h-[36px] inline-flex items-center gap-1 px-3 py-1.5 text-xs font-medium bg-white border border-slate-300 rounded-lg hover:bg-slate-100 disabled:opacity-40 cursor-pointer"
        >
          <ChevronLeft className="w-3.5 h-3.5" />
          Prev
        </button>
        <span className="px-2.5 font-mono tabular-nums">
          Page {safePage} / {totalPages}
        </span>
        <button
          type="button"
          disabled={safePage >= totalPages}
          onClick={() => onPageChange(safePage + 1)}
          className="min-h-[36px] inline-flex items-center gap-1 px-3 py-1.5 text-xs font-medium bg-white border border-slate-300 rounded-lg hover:bg-slate-100 disabled:opacity-40 cursor-pointer"
        >
          Next
          <ChevronRight className="w-3.5 h-3.5" />
        </button>
      </div>
    </div>
  );
}

export function usePagination<T>(items: T[], initialPageSize = 25) {
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(initialPageSize);

  const totalPages = Math.max(1, Math.ceil(items.length / pageSize));
  const currentPage = Math.min(Math.max(1, page), totalPages);

  const pagedItems = useMemo(() => {
    const start = (currentPage - 1) * pageSize;
    return items.slice(start, start + pageSize);
  }, [items, currentPage, pageSize]);

  const handlePageSizeChange = (nextSize: number) => {
    setPageSize(nextSize);
    setPage(1);
  };

  return {
    page: currentPage,
    setPage,
    pageSize,
    setPageSize: handlePageSizeChange,
    totalPages,
    pagedItems,
  };
}
