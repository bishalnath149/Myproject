import crypto from 'node:crypto';
import type { Request, Response, NextFunction } from 'express';
import { db } from './database.ts';

export function hashPassword(password: string): string {
  const salt = crypto.randomBytes(16).toString('hex');
  const derived = crypto.scryptSync(password, salt, 64).toString('hex');
  return `${salt}:${derived}`;
}

export function verifyPassword(password: string, storedHash: string): boolean {
  const parts = storedHash.split(':');
  if (parts.length !== 2) return false;
  const [salt, hash] = parts;
  const derived = crypto.scryptSync(password, salt, 64);
  const storedBuf = Buffer.from(hash, 'hex');
  if (derived.length !== storedBuf.length) return false;
  return crypto.timingSafeEqual(derived, storedBuf);
}

export interface AuthUser {
  id: number;
  username: string;
  fullName: string;
  email: string;
  employeeCode: string;
  roles: string[];
  mustChangePassword: boolean;
  isClassTeacher: boolean;
  isSubjectTeacher: boolean;
}

export interface AuthenticatedRequest extends Request {
  user?: AuthUser;
  sessionToken?: string;
}

export function getUserWithRoles(userId: number): AuthUser | null {
  const userRow = db
    .prepare(
      `SELECT id, username, full_name, email, employee_code, is_active, COALESCE(is_deleted, 0) as is_deleted, must_change_password
       FROM users WHERE id = ?`
    )
    .get(userId) as
    | {
        id: number;
        username: string;
        full_name: string;
        email: string;
        employee_code: string;
        is_active: number;
        is_deleted: number;
        must_change_password: number;
      }
    | undefined;

  if (!userRow || !userRow.is_active || userRow.is_deleted) return null;

  const roleRows = db
    .prepare(
      `SELECT r.name FROM roles r
       JOIN user_roles ur ON ur.role_id = r.id
       WHERE ur.user_id = ?`
    )
    .all(userId) as { name: string }[];

  const roles = roleRows.map((r) => r.name);

  const subjectCount = (
    db
      .prepare(`SELECT COUNT(*) as cnt FROM teacher_assignments WHERE teacher_id = ?`)
      .get(userId) as { cnt: number }
  ).cnt;

  const classTeacherCount = (
    db
      .prepare(`SELECT COUNT(*) as cnt FROM class_teacher_assignments WHERE teacher_id = ?`)
      .get(userId) as { cnt: number }
  ).cnt;

  return {
    id: userRow.id,
    username: userRow.username,
    fullName: userRow.full_name,
    email: userRow.email || '',
    employeeCode: userRow.employee_code || '',
    roles,
    mustChangePassword: Boolean(userRow.must_change_password),
    isSubjectTeacher: subjectCount > 0 || roles.includes('teacher'),
    isClassTeacher: classTeacherCount > 0,
  };
}

const SESSION_SIGNING_SECRET =
  process.env.SESSION_SECRET || 'emrs-gangyap-portal-session-signing-key-v1';

function signSessionPayload(jti: string, payloadB64: string): string {
  return crypto
    .createHmac('sha256', SESSION_SIGNING_SECRET)
    .update(`${jti}.${payloadB64}`)
    .digest('hex');
}

function verifySignedToken(token: string): { userId: number; expiresAtMs: number } | null {
  const parts = token.split('.');
  if (parts.length !== 3) return null;
  const [jti, payloadB64, sigHex] = parts;
  if (!jti || !payloadB64 || !sigHex) return null;
  const expected = signSessionPayload(jti, payloadB64);
  const a = Buffer.from(sigHex, 'hex');
  const b = Buffer.from(expected, 'hex');
  if (a.length === 0 || a.length !== b.length || !crypto.timingSafeEqual(a, b)) {
    return null;
  }
  try {
    const parsed = JSON.parse(Buffer.from(payloadB64, 'base64url').toString('utf8')) as {
      uid?: number;
      exp?: number;
    };
    if (!parsed.uid || !parsed.exp || parsed.exp < Date.now()) return null;
    return { userId: Number(parsed.uid), expiresAtMs: Number(parsed.exp) };
  } catch {
    return null;
  }
}

export function createSession(userId: number): string {
  const jti = crypto.randomBytes(16).toString('hex');
  const expiresAtMs = Date.now() + 7 * 24 * 60 * 60 * 1000;
  const expiresAt = new Date(expiresAtMs).toISOString();
  const payloadB64 = Buffer.from(JSON.stringify({ uid: userId, exp: expiresAtMs }), 'utf8').toString(
    'base64url'
  );
  const sig = signSessionPayload(jti, payloadB64);
  const token = `${jti}.${payloadB64}.${sig}`;
  db.prepare(`INSERT INTO sessions (token, user_id, expires_at) VALUES (?, ?, ?)`).run(
    token,
    userId,
    expiresAt
  );
  return token;
}

export function deleteSession(token: string): void {
  db.prepare(`DELETE FROM sessions WHERE token = ?`).run(token);
}

export function parseCookies(cookieHeader: string | undefined): Record<string, string> {
  const out: Record<string, string> = {};
  if (!cookieHeader) return out;
  for (const part of cookieHeader.split(';')) {
    const idx = part.indexOf('=');
    if (idx > 0) {
      const k = part.slice(0, idx).trim();
      const rawVal = part.slice(idx + 1).trim();
      try {
        out[k] = decodeURIComponent(rawVal);
      } catch {
        out[k] = rawVal;
      }
    }
  }
  return out;
}

export function requireAuth(req: AuthenticatedRequest, res: Response, next: NextFunction) {
  try {
    const authHeader = req.headers.authorization;
    const cookies = parseCookies(req.headers.cookie);
    let token = '';

    if (authHeader && authHeader.startsWith('Bearer ')) {
      token = authHeader.slice(7).trim();
    } else if (cookies.school_session) {
      token = cookies.school_session;
    }

    if (!token) {
      return res.status(401).json({ error: 'Authentication required. Please sign in.' });
    }

    let session = db
      .prepare(`SELECT token, user_id, expires_at FROM sessions WHERE token = ?`)
      .get(token) as { token: string; user_id: number; expires_at: string } | undefined;

    // On serverless deployments (e.g. Vercel /tmp), restore valid signed session if cold-started
    if (!session && process.env.VERCEL) {
      const verified = verifySignedToken(token);
      if (verified) {
        const expIso = new Date(verified.expiresAtMs).toISOString();
        db.prepare(`INSERT OR IGNORE INTO sessions (token, user_id, expires_at) VALUES (?, ?, ?)`).run(
          token,
          verified.userId,
          expIso
        );
        session = { token, user_id: verified.userId, expires_at: expIso };
      }
    }

    if (!session) {
      return res.status(401).json({ error: 'Session expired or invalid. Please sign in again.' });
    }

    if (new Date(session.expires_at).getTime() < Date.now()) {
      deleteSession(token);
      return res.status(401).json({ error: 'Session expired. Please sign in again.' });
    }

    const user = getUserWithRoles(session.user_id);
    if (!user) {
      deleteSession(token);
      return res.status(401).json({ error: 'Account is inactive or unavailable.' });
    }

    req.user = user;
    req.sessionToken = token;
    next();
  } catch (err) {
    console.error('Authentication check failed:', err);
    return res.status(500).json({ error: 'Server authentication error. Please try again.' });
  }
}

export function requireAdmin(req: AuthenticatedRequest, res: Response, next: NextFunction) {
  if (!req.user || !req.user.roles.includes('admin')) {
    return res.status(403).json({ error: 'Administrator privileges required.' });
  }
  next();
}

export function logAudit(
  user: AuthUser | { id: number | null; username: string; roles: string[] },
  action: string,
  entityType: string,
  entityId: string | number | null,
  details: Record<string, unknown> | string
) {
  try {
    const roleStr = user.roles.join(',');
    const detailsStr = typeof details === 'string' ? details : JSON.stringify(details);
    db.prepare(
      `INSERT INTO audit_logs (user_id, username, user_role, action, entity_type, entity_id, details)
       VALUES (?, ?, ?, ?, ?, ?, ?)`
    ).run(user.id, user.username, roleStr, action, entityType, entityId ? String(entityId) : null, detailsStr);
  } catch (err) {
    console.error('Audit log write skipped:', err);
  }
}
