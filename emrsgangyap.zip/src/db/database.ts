import Database from 'better-sqlite3';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import crypto from 'node:crypto';
import { fileURLToPath } from 'node:url';

function isDirWritable(dir: string): boolean {
  try {
    fs.accessSync(dir, fs.constants.W_OK);
    return true;
  } catch {
    return false;
  }
}

function resolveDatabasePath(): string {
  if (process.env.DB_PATH) {
    const customPath = path.resolve(process.env.DB_PATH);
    fs.mkdirSync(path.dirname(customPath), { recursive: true });
    return customPath;
  }

  const cwdDbPath = path.resolve(process.cwd(), 'school.db');
  const runningOnVercel = Boolean(process.env.VERCEL);

  if (!runningOnVercel && isDirWritable(process.cwd())) {
    return cwdDbPath;
  }

  // On Vercel or read-only filesystems, copy the bundled school.db into writable /tmp
  const tmpDbPath = path.join(os.tmpdir(), 'school.db');
  if (!fs.existsSync(tmpDbPath)) {
    const moduleDir = path.dirname(fileURLToPath(import.meta.url));
    const candidates = [
      cwdDbPath,
      path.resolve(moduleDir, '../../school.db'),
      path.resolve(moduleDir, '../school.db'),
    ];
    for (const srcPath of candidates) {
      if (fs.existsSync(srcPath)) {
        fs.copyFileSync(srcPath, tmpDbPath);
        break;
      }
    }
  }
  return tmpDbPath;
}

const dbPath = resolveDatabasePath();

function configureDbPragmas(database: Database.Database) {
  try {
    database.pragma('journal_mode = WAL');
    database.pragma('synchronous = NORMAL');
    database.pragma('wal_autocheckpoint = 100');
  } catch {
    // fallback cleanly on filesystems that disallow WAL
  }
  database.pragma('busy_timeout = 5000');
  database.pragma('foreign_keys = ON');
}

export let db = new Database(dbPath);
configureDbPragmas(db);

export function getDatabasePath(): string {
  return dbPath;
}

export function checkpointWal(mode: 'PASSIVE' | 'FULL' | 'RESTART' | 'TRUNCATE' = 'PASSIVE') {
  try {
    db.pragma(`wal_checkpoint(${mode})`);
  } catch {
    // Non-fatal on filesystems or states without WAL
  }
}

export function closeDatabase() {
  try {
    checkpointWal('TRUNCATE');
  } catch {
    // ignore
  }
  try {
    db.close();
  } catch {
    // ignore
  }
}

export function reopenDatabase() {
  try {
    db.close();
  } catch {
    // ignore
  }
  db = new Database(dbPath);
  configureDbPragmas(db);
  return db;
}

let shutdownHookRegistered = false;
if (!shutdownHookRegistered) {
  shutdownHookRegistered = true;
  const flushOnExit = () => {
    checkpointWal('TRUNCATE');
  };
  process.once('beforeExit', flushOnExit);
  process.once('SIGINT', () => {
    flushOnExit();
    process.exit(0);
  });
  process.once('SIGTERM', () => {
    flushOnExit();
    process.exit(0);
  });
}

function hashSeedPassword(password: string): string {
  const salt = crypto.randomBytes(16).toString('hex');
  const derived = crypto.scryptSync(password, salt, 64).toString('hex');
  return `${salt}:${derived}`;
}

export function initializeDatabase() {
  db.exec(`
    CREATE TABLE IF NOT EXISTS roles (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL UNIQUE,
      description TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS users (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      username TEXT NOT NULL UNIQUE,
      password_hash TEXT NOT NULL,
      full_name TEXT NOT NULL,
      email TEXT,
      employee_code TEXT,
      is_active INTEGER NOT NULL DEFAULT 1,
      must_change_password INTEGER NOT NULL DEFAULT 0,
      created_at TEXT NOT NULL DEFAULT (datetime('now')),
      updated_at TEXT NOT NULL DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS user_roles (
      user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      role_id INTEGER NOT NULL REFERENCES roles(id) ON DELETE CASCADE,
      PRIMARY KEY (user_id, role_id)
    );

    CREATE TABLE IF NOT EXISTS sessions (
      token TEXT PRIMARY KEY,
      user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      expires_at TEXT NOT NULL,
      created_at TEXT NOT NULL DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS classes (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL UNIQUE,
      numeric_order INTEGER NOT NULL,
      is_active INTEGER NOT NULL DEFAULT 1
    );

    CREATE TABLE IF NOT EXISTS sections (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      class_id INTEGER NOT NULL REFERENCES classes(id) ON DELETE CASCADE,
      name TEXT NOT NULL,
      capacity INTEGER NOT NULL DEFAULT 30,
      UNIQUE(class_id, name)
    );

    CREATE TABLE IF NOT EXISTS students (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      student_code TEXT NOT NULL UNIQUE,
      full_name TEXT NOT NULL,
      roll_number INTEGER NOT NULL,
      class_id INTEGER NOT NULL REFERENCES classes(id) ON DELETE RESTRICT,
      section_id INTEGER NOT NULL REFERENCES sections(id) ON DELETE RESTRICT,
      academic_year TEXT NOT NULL DEFAULT '2025-26',
      gender TEXT DEFAULT 'Not Specified',
      guardian_name TEXT DEFAULT '',
      guardian_phone TEXT DEFAULT '',
      status TEXT NOT NULL DEFAULT 'active',
      created_at TEXT NOT NULL DEFAULT (datetime('now')),
      updated_at TEXT NOT NULL DEFAULT (datetime('now'))
    );

    CREATE INDEX IF NOT EXISTS idx_students_class_section
      ON students(class_id, section_id, roll_number);

    CREATE TABLE IF NOT EXISTS subjects (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      code TEXT NOT NULL UNIQUE,
      name TEXT NOT NULL UNIQUE,
      default_max_marks REAL NOT NULL DEFAULT 100,
      has_components INTEGER NOT NULL DEFAULT 0,
      component_mode TEXT NOT NULL DEFAULT 'single',
      has_internal_assessment INTEGER NOT NULL DEFAULT 1,
      ia_notebook_max REAL NOT NULL DEFAULT 5,
      ia_unit_test_max REAL NOT NULL DEFAULT 5,
      ia_practical_max REAL NOT NULL DEFAULT 5,
      ia_participation_max REAL NOT NULL DEFAULT 5,
      display_order INTEGER NOT NULL DEFAULT 0,
      is_active INTEGER NOT NULL DEFAULT 1
    );

    CREATE TABLE IF NOT EXISTS subject_components (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      subject_id INTEGER NOT NULL REFERENCES subjects(id) ON DELETE CASCADE,
      name TEXT NOT NULL,
      code TEXT NOT NULL,
      default_max_marks REAL NOT NULL DEFAULT 100,
      display_order INTEGER NOT NULL DEFAULT 0,
      UNIQUE(subject_id, name)
    );

    CREATE TABLE IF NOT EXISTS teacher_assignments (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      teacher_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      subject_id INTEGER NOT NULL REFERENCES subjects(id) ON DELETE CASCADE,
      component_id INTEGER NOT NULL REFERENCES subject_components(id) ON DELETE CASCADE,
      class_id INTEGER NOT NULL REFERENCES classes(id) ON DELETE CASCADE,
      section_id INTEGER NOT NULL REFERENCES sections(id) ON DELETE CASCADE,
      academic_year TEXT NOT NULL DEFAULT '2025-26',
      UNIQUE(subject_id, component_id, class_id, section_id, academic_year)
    );

    CREATE TABLE IF NOT EXISTS class_teacher_assignments (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      teacher_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      class_id INTEGER NOT NULL REFERENCES classes(id) ON DELETE CASCADE,
      section_id INTEGER NOT NULL REFERENCES sections(id) ON DELETE CASCADE,
      academic_year TEXT NOT NULL DEFAULT '2025-26',
      UNIQUE(class_id, section_id, academic_year)
    );

    CREATE TABLE IF NOT EXISTS examinations (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      academic_year TEXT NOT NULL DEFAULT '2025-26',
      start_date TEXT NOT NULL,
      end_date TEXT NOT NULL,
      status TEXT NOT NULL DEFAULT 'Upcoming',
      marks_entry_open INTEGER NOT NULL DEFAULT 0,
      passing_percentage REAL NOT NULL DEFAULT 33,
      created_at TEXT NOT NULL DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS examination_subjects (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      examination_id INTEGER NOT NULL REFERENCES examinations(id) ON DELETE CASCADE,
      subject_id INTEGER NOT NULL REFERENCES subjects(id) ON DELETE CASCADE,
      max_marks REAL NOT NULL,
      passing_marks REAL NOT NULL,
      has_internal_assessment INTEGER NOT NULL DEFAULT 1,
      ia_notebook_max REAL NOT NULL DEFAULT 5,
      ia_unit_test_max REAL NOT NULL DEFAULT 5,
      ia_practical_max REAL NOT NULL DEFAULT 5,
      ia_participation_max REAL NOT NULL DEFAULT 5,
      is_required INTEGER NOT NULL DEFAULT 1,
      display_order INTEGER NOT NULL DEFAULT 0,
      UNIQUE(examination_id, subject_id)
    );

    CREATE TABLE IF NOT EXISTS examination_components (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      examination_id INTEGER NOT NULL REFERENCES examinations(id) ON DELETE CASCADE,
      examination_subject_id INTEGER NOT NULL REFERENCES examination_subjects(id) ON DELETE CASCADE,
      subject_id INTEGER NOT NULL REFERENCES subjects(id) ON DELETE CASCADE,
      component_id INTEGER NOT NULL REFERENCES subject_components(id) ON DELETE CASCADE,
      component_name TEXT NOT NULL,
      max_marks REAL NOT NULL,
      passing_marks REAL NOT NULL,
      display_order INTEGER NOT NULL DEFAULT 0,
      UNIQUE(examination_id, component_id)
    );

    CREATE TABLE IF NOT EXISTS marks (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      student_id INTEGER NOT NULL REFERENCES students(id) ON DELETE CASCADE,
      examination_id INTEGER NOT NULL REFERENCES examinations(id) ON DELETE CASCADE,
      examination_component_id INTEGER NOT NULL REFERENCES examination_components(id) ON DELETE CASCADE,
      obtained_marks REAL,
      status TEXT NOT NULL DEFAULT 'draft',
      entered_by INTEGER REFERENCES users(id) ON DELETE SET NULL,
      submitted_by INTEGER REFERENCES users(id) ON DELETE SET NULL,
      submitted_at TEXT,
      updated_at TEXT NOT NULL DEFAULT (datetime('now')),
      UNIQUE(student_id, examination_id, examination_component_id)
    );

    CREATE INDEX IF NOT EXISTS idx_marks_lookup
      ON marks(examination_id, examination_component_id, student_id);

    CREATE TABLE IF NOT EXISTS internal_assessment_marks (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      student_id INTEGER NOT NULL REFERENCES students(id) ON DELETE CASCADE,
      examination_id INTEGER NOT NULL REFERENCES examinations(id) ON DELETE CASCADE,
      subject_id INTEGER NOT NULL REFERENCES subjects(id) ON DELETE CASCADE,
      notebook_marks REAL,
      unit_test_marks REAL,
      practical_marks REAL,
      participation_marks REAL,
      status TEXT NOT NULL DEFAULT 'draft',
      entered_by INTEGER REFERENCES users(id) ON DELETE SET NULL,
      entered_via_component_id INTEGER REFERENCES examination_components(id) ON DELETE SET NULL,
      submitted_by INTEGER REFERENCES users(id) ON DELETE SET NULL,
      submitted_at TEXT,
      updated_at TEXT NOT NULL DEFAULT (datetime('now')),
      UNIQUE(student_id, examination_id, subject_id)
    );

    CREATE INDEX IF NOT EXISTS idx_ia_marks_lookup
      ON internal_assessment_marks(examination_id, subject_id, student_id);

    CREATE TABLE IF NOT EXISTS mark_correction_requests (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      examination_id INTEGER NOT NULL REFERENCES examinations(id) ON DELETE CASCADE,
      examination_component_id INTEGER NOT NULL REFERENCES examination_components(id) ON DELETE CASCADE,
      class_id INTEGER NOT NULL REFERENCES classes(id) ON DELETE CASCADE,
      section_id INTEGER NOT NULL REFERENCES sections(id) ON DELETE CASCADE,
      requested_by INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      reason TEXT NOT NULL,
      status TEXT NOT NULL DEFAULT 'pending',
      reviewed_by INTEGER REFERENCES users(id) ON DELETE SET NULL,
      reviewed_at TEXT,
      created_at TEXT NOT NULL DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS audit_logs (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER REFERENCES users(id) ON DELETE SET NULL,
      username TEXT NOT NULL,
      user_role TEXT NOT NULL,
      action TEXT NOT NULL,
      entity_type TEXT NOT NULL,
      entity_id TEXT,
      details TEXT,
      created_at TEXT NOT NULL DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS student_electives (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      student_id INTEGER NOT NULL REFERENCES students(id) ON DELETE CASCADE,
      subject_id INTEGER NOT NULL REFERENCES subjects(id) ON DELETE CASCADE,
      component_id INTEGER NOT NULL REFERENCES subject_components(id) ON DELETE CASCADE,
      UNIQUE(student_id, subject_id)
    );

    CREATE INDEX IF NOT EXISTS idx_student_electives_sub_comp
      ON student_electives(subject_id, component_id);

    CREATE TABLE IF NOT EXISTS academic_years (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL UNIQUE,
      is_current INTEGER NOT NULL DEFAULT 0,
      created_at TEXT NOT NULL DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS student_enrollments (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      student_id INTEGER NOT NULL REFERENCES students(id) ON DELETE CASCADE,
      academic_year TEXT NOT NULL,
      class_id INTEGER NOT NULL REFERENCES classes(id) ON DELETE RESTRICT,
      section_id INTEGER NOT NULL REFERENCES sections(id) ON DELETE RESTRICT,
      roll_number INTEGER NOT NULL,
      status TEXT NOT NULL DEFAULT 'active',
      created_at TEXT NOT NULL DEFAULT (datetime('now')),
      UNIQUE(student_id, academic_year)
    );

    CREATE INDEX IF NOT EXISTS idx_student_enrollments_year_class
      ON student_enrollments(academic_year, class_id, section_id, roll_number);

    CREATE TABLE IF NOT EXISTS student_year_electives (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      student_id INTEGER NOT NULL REFERENCES students(id) ON DELETE CASCADE,
      academic_year TEXT NOT NULL,
      subject_id INTEGER NOT NULL REFERENCES subjects(id) ON DELETE CASCADE,
      component_id INTEGER NOT NULL REFERENCES subject_components(id) ON DELETE CASCADE,
      UNIQUE(student_id, academic_year, subject_id)
    );

    CREATE INDEX IF NOT EXISTS idx_student_year_electives_lookup
      ON student_year_electives(academic_year, subject_id, component_id);

    CREATE TABLE IF NOT EXISTS ia_teacher_assignments (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      teacher_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      subject_id INTEGER NOT NULL REFERENCES subjects(id) ON DELETE CASCADE,
      class_id INTEGER NOT NULL REFERENCES classes(id) ON DELETE CASCADE,
      section_id INTEGER NOT NULL REFERENCES sections(id) ON DELETE CASCADE,
      ia_component TEXT NOT NULL,
      academic_year TEXT NOT NULL DEFAULT '2025-26',
      UNIQUE(subject_id, class_id, section_id, ia_component, academic_year)
    );

    CREATE TABLE IF NOT EXISTS system_settings (
      key TEXT PRIMARY KEY,
      value TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS student_subjects (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      student_id INTEGER NOT NULL REFERENCES students(id) ON DELETE CASCADE,
      subject_id INTEGER NOT NULL REFERENCES subjects(id) ON DELETE CASCADE,
      UNIQUE(student_id, subject_id)
    );

    CREATE TABLE IF NOT EXISTS student_year_subjects (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      student_id INTEGER NOT NULL REFERENCES students(id) ON DELETE CASCADE,
      academic_year TEXT NOT NULL,
      subject_id INTEGER NOT NULL REFERENCES subjects(id) ON DELETE CASCADE,
      UNIQUE(student_id, academic_year, subject_id)
    );

    CREATE INDEX IF NOT EXISTS idx_student_year_subjects_lookup
      ON student_year_subjects(academic_year, subject_id, student_id);

    CREATE TABLE IF NOT EXISTS student_elective_opt_outs (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      student_id INTEGER NOT NULL REFERENCES students(id) ON DELETE CASCADE,
      academic_year TEXT NOT NULL,
      subject_id INTEGER NOT NULL REFERENCES subjects(id) ON DELETE CASCADE,
      UNIQUE(student_id, academic_year, subject_id)
    );

    CREATE INDEX IF NOT EXISTS idx_student_elective_opt_outs_lookup
      ON student_elective_opt_outs(academic_year, subject_id, student_id);

    CREATE TABLE IF NOT EXISTS student_co_scholastic_grades (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      student_id INTEGER NOT NULL REFERENCES students(id) ON DELETE CASCADE,
      academic_year TEXT NOT NULL,
      term INTEGER NOT NULL CHECK(term IN (1, 2)),
      examination_id INTEGER REFERENCES examinations(id) ON DELETE SET NULL,
      item_key TEXT NOT NULL,
      grade TEXT NOT NULL CHECK(grade IN ('A', 'B', 'C')),
      points INTEGER NOT NULL CHECK(points IN (5, 4, 2)),
      entered_by INTEGER REFERENCES users(id) ON DELETE SET NULL,
      updated_at TEXT NOT NULL DEFAULT (datetime('now')),
      UNIQUE(student_id, academic_year, term, item_key)
    );

    CREATE INDEX IF NOT EXISTS idx_co_scholastic_lookup
      ON student_co_scholastic_grades(academic_year, student_id, term);

    CREATE TABLE IF NOT EXISTS student_term_records (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      student_id INTEGER NOT NULL REFERENCES students(id) ON DELETE CASCADE,
      academic_year TEXT NOT NULL,
      term INTEGER NOT NULL CHECK(term IN (1, 2)),
      examination_id INTEGER REFERENCES examinations(id) ON DELETE SET NULL,
      days_attended INTEGER,
      total_days INTEGER,
      remarks TEXT NOT NULL DEFAULT '',
      entered_by INTEGER REFERENCES users(id) ON DELETE SET NULL,
      updated_at TEXT NOT NULL DEFAULT (datetime('now')),
      UNIQUE(student_id, academic_year, term)
    );

    CREATE INDEX IF NOT EXISTS idx_student_term_records_lookup
      ON student_term_records(academic_year, student_id, term);

    CREATE TABLE IF NOT EXISTS class_result_dates (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      class_id INTEGER NOT NULL REFERENCES classes(id) ON DELETE CASCADE,
      section_id INTEGER NOT NULL REFERENCES sections(id) ON DELETE CASCADE,
      academic_year TEXT NOT NULL,
      result_date TEXT NOT NULL DEFAULT '',
      updated_by INTEGER REFERENCES users(id) ON DELETE SET NULL,
      updated_at TEXT NOT NULL DEFAULT (datetime('now')),
      UNIQUE(class_id, section_id, academic_year)
    );
  `);

  // Idempotent schema migrations for pre-existing databases
  const ensureColumn = (table: string, col: string, ddl: string) => {
    const cols = db.prepare(`PRAGMA table_info(${table})`).all() as Array<{ name: string }>;
    if (!cols.some((c) => c.name === col)) {
      db.exec(`ALTER TABLE ${table} ADD COLUMN ${ddl}`);
      return true;
    }
    return false;
  };

  const addedSubIa = ensureColumn('subjects', 'has_internal_assessment', 'has_internal_assessment INTEGER NOT NULL DEFAULT 1');
  ensureColumn('subjects', 'ia_notebook_max', 'ia_notebook_max REAL NOT NULL DEFAULT 5');
  ensureColumn('subjects', 'ia_unit_test_max', 'ia_unit_test_max REAL NOT NULL DEFAULT 5');
  ensureColumn('subjects', 'ia_practical_max', 'ia_practical_max REAL NOT NULL DEFAULT 5');
  ensureColumn('subjects', 'ia_participation_max', 'ia_participation_max REAL NOT NULL DEFAULT 0');
  const addedCompMode = ensureColumn('subjects', 'component_mode', "component_mode TEXT NOT NULL DEFAULT 'single'");

  // Phase 3: Classes without sections, student streams, subject class scoping & practical flag
  ensureColumn('classes', 'has_sections', 'has_sections INTEGER NOT NULL DEFAULT 1');
  ensureColumn('students', 'stream', "stream TEXT NOT NULL DEFAULT ''");
  ensureColumn('students', 'father_name', "father_name TEXT NOT NULL DEFAULT ''");
  ensureColumn('students', 'mother_name', "mother_name TEXT NOT NULL DEFAULT ''");
  ensureColumn('students', 'residential_address', "residential_address TEXT NOT NULL DEFAULT ''");
  ensureColumn('students', 'contact_no', "contact_no TEXT NOT NULL DEFAULT ''");
  ensureColumn('students', 'aapaar_id', "aapaar_id TEXT NOT NULL DEFAULT ''");
  ensureColumn('students', 'photo_url', "photo_url TEXT NOT NULL DEFAULT ''");
  ensureColumn('student_enrollments', 'stream', "stream TEXT NOT NULL DEFAULT ''");
  ensureColumn('subjects', 'applicable_class_ids', "applicable_class_ids TEXT NOT NULL DEFAULT ''");
  ensureColumn('subjects', 'stream_category', "stream_category TEXT NOT NULL DEFAULT ''");
  ensureColumn('subjects', 'has_practical', 'has_practical INTEGER NOT NULL DEFAULT 0');
  ensureColumn('examination_subjects', 'target_class_ids', "target_class_ids TEXT NOT NULL DEFAULT ''");

  ensureColumn('examination_subjects', 'has_internal_assessment', 'has_internal_assessment INTEGER NOT NULL DEFAULT 1');
  ensureColumn('examination_subjects', 'ia_notebook_max', 'ia_notebook_max REAL NOT NULL DEFAULT 5');
  ensureColumn('examination_subjects', 'ia_unit_test_max', 'ia_unit_test_max REAL NOT NULL DEFAULT 5');
  ensureColumn('examination_subjects', 'ia_practical_max', 'ia_practical_max REAL NOT NULL DEFAULT 5');
  ensureColumn('examination_subjects', 'ia_participation_max', 'ia_participation_max REAL NOT NULL DEFAULT 0');

  ensureColumn('internal_assessment_marks', 'participation_marks', 'participation_marks REAL');
  ensureColumn('internal_assessment_marks', 'nb_status', "nb_status TEXT NOT NULL DEFAULT 'pending'");
  ensureColumn('internal_assessment_marks', 'nb_by', 'nb_by INTEGER');
  ensureColumn('internal_assessment_marks', 'ut_status', "ut_status TEXT NOT NULL DEFAULT 'pending'");
  ensureColumn('internal_assessment_marks', 'ut_by', 'ut_by INTEGER');
  ensureColumn('internal_assessment_marks', 'pr_status', "pr_status TEXT NOT NULL DEFAULT 'pending'");
  ensureColumn('internal_assessment_marks', 'pr_by', 'pr_by INTEGER');
  ensureColumn('internal_assessment_marks', 'op_status', "op_status TEXT NOT NULL DEFAULT 'pending'");
  ensureColumn('internal_assessment_marks', 'op_by', 'op_by INTEGER');

  ensureColumn('marks', 'attendance_status', "attendance_status TEXT NOT NULL DEFAULT 'pending'");
  ensureColumn('examinations', 'exam_type', "exam_type TEXT NOT NULL DEFAULT 'Regular'");

  // Soft-delete & archive support across core administrative entities
  ensureColumn('students', 'is_deleted', 'is_deleted INTEGER NOT NULL DEFAULT 0');
  ensureColumn('students', 'deleted_at', 'deleted_at TEXT');
  ensureColumn('students', 'deleted_by', 'deleted_by INTEGER');

  ensureColumn('users', 'is_deleted', 'is_deleted INTEGER NOT NULL DEFAULT 0');
  ensureColumn('users', 'deleted_at', 'deleted_at TEXT');
  ensureColumn('users', 'deleted_by', 'deleted_by INTEGER');
  ensureColumn('users', 'archived_assignments_json', 'archived_assignments_json TEXT');

  ensureColumn('classes', 'is_deleted', 'is_deleted INTEGER NOT NULL DEFAULT 0');
  ensureColumn('classes', 'deleted_at', 'deleted_at TEXT');
  ensureColumn('classes', 'deleted_by', 'deleted_by INTEGER');

  ensureColumn('sections', 'is_deleted', 'is_deleted INTEGER NOT NULL DEFAULT 0');
  ensureColumn('sections', 'deleted_at', 'deleted_at TEXT');
  ensureColumn('sections', 'deleted_by', 'deleted_by INTEGER');

  ensureColumn('subjects', 'is_deleted', 'is_deleted INTEGER NOT NULL DEFAULT 0');
  ensureColumn('subjects', 'deleted_at', 'deleted_at TEXT');
  ensureColumn('subjects', 'deleted_by', 'deleted_by INTEGER');

  ensureColumn('examinations', 'is_deleted', 'is_deleted INTEGER NOT NULL DEFAULT 0');
  ensureColumn('examinations', 'deleted_at', 'deleted_at TEXT');
  ensureColumn('examinations', 'deleted_by', 'deleted_by INTEGER');

  ensureColumn('academic_years', 'is_deleted', 'is_deleted INTEGER NOT NULL DEFAULT 0');
  ensureColumn('academic_years', 'deleted_at', 'deleted_at TEXT');

  if (addedCompMode) {
    db.exec(`UPDATE subjects SET component_mode = 'combined' WHERE has_components = 1 AND component_mode = 'single'`);
  }

  const schemaInitialized = (
    db.prepare(`SELECT value FROM system_settings WHERE key = 'schema_initialized'`).get() as
      | { value: string }
      | undefined
  )?.value === '1';

  const roleCount = (db.prepare(`SELECT COUNT(*) as cnt FROM roles`).get() as { cnt: number }).cnt;
  if (roleCount === 0 && !schemaInitialized) {
    if (process.env.DISABLE_DEMO_SEED === '1') {
      seedMinimalAdminOnly();
    } else {
      seedInitialData();
    }
    db.prepare(`INSERT OR REPLACE INTO system_settings (key, value) VALUES ('schema_initialized', '1')`).run();
  } else {
    if (!schemaInitialized) {
      db.prepare(`INSERT OR REPLACE INTO system_settings (key, value) VALUES ('schema_initialized', '1')`).run();
    }
    const iaCount = (db.prepare(`SELECT COUNT(*) as cnt FROM internal_assessment_marks`).get() as { cnt: number }).cnt;
    const legacyEng = db
      .prepare(`SELECT id FROM subject_components WHERE code = 'ENG' AND default_max_marks = 100`)
      .get();
    if (addedSubIa || (iaCount === 0 && legacyEng)) {
      migrateExistingDataToInternalAssessment();
    }
  }

  ensureLanguageSubjectAndElectives();
  ensureHindiLanguageOption();
  ensureAcademicYearsAndHistory();
  ensureIaParticipationMigration();
  ensureAttendanceAndIaSubStatuses();
  ensureBrandingAndPortalDefaults();
}

function seedMinimalAdminOnly() {
  db.transaction(() => {
    const defaultGrades = [
      { grade: 'A1', minPct: 91, maxPct: 100, remark: 'Outstanding' },
      { grade: 'A2', minPct: 81, maxPct: 90.99, remark: 'Excellent' },
      { grade: 'B1', minPct: 71, maxPct: 80.99, remark: 'Very Good' },
      { grade: 'B2', minPct: 61, maxPct: 70.99, remark: 'Good' },
      { grade: 'C1', minPct: 51, maxPct: 60.99, remark: 'Satisfactory' },
      { grade: 'C2', minPct: 41, maxPct: 50.99, remark: 'Acceptable' },
      { grade: 'D', minPct: 33, maxPct: 40.99, remark: 'Pass' },
      { grade: 'E', minPct: 0, maxPct: 32.99, remark: 'Needs Improvement' },
    ];
    const currentYear = `${new Date().getFullYear()}-${String((new Date().getFullYear() + 1) % 100).padStart(2, '0')}`;
    const insertSetting = db.prepare(`INSERT OR IGNORE INTO system_settings (key, value) VALUES (?, ?)`);
    insertSetting.run('school_name', 'EMRS Gangyap');
    insertSetting.run('school_address', 'Gangyap, Gyalshing District, Sikkim');
    insertSetting.run('school_motto', 'Discipline, Inquiry & Academic Excellence');
    insertSetting.run('current_academic_year', currentYear);
    insertSetting.run('default_pass_percentage', '33');
    insertSetting.run('grading_scale', JSON.stringify(defaultGrades));
    insertSetting.run('language_elective_seeded', '1');
    insertSetting.run('historical_ay_2024_25_seeded', '1');

    db.prepare(`INSERT OR IGNORE INTO academic_years (name, is_current) VALUES (?, 1)`).run(currentYear);
    const insertRole = db.prepare(`INSERT INTO roles (name, description) VALUES (?, ?)`);
    const adminRoleId = Number(insertRole.run('admin', 'Full school system administration').lastInsertRowid);
    insertRole.run('teacher', 'Subject teacher and/or class teacher');

    const adminPass = hashSeedPassword('123456');
    const adminId = Number(
      db
        .prepare(
          `INSERT INTO users (username, password_hash, full_name, email, employee_code, is_active, must_change_password)
           VALUES ('admin', ?, 'Administrator', 'admin@emrsgangyap.edu', 'ADM-001', 1, 0)`
        )
        .run(adminPass).lastInsertRowid
    );
    db.prepare(`INSERT INTO user_roles (user_id, role_id) VALUES (?, ?)`).run(adminId, adminRoleId);
  })();
}

function seedInitialData() {
  const insertAll = db.transaction(() => {
    // 1. System Settings
    const defaultGrades = [
      { grade: 'A1', minPct: 91, maxPct: 100, remark: 'Outstanding' },
      { grade: 'A2', minPct: 81, maxPct: 90.99, remark: 'Excellent' },
      { grade: 'B1', minPct: 71, maxPct: 80.99, remark: 'Very Good' },
      { grade: 'B2', minPct: 61, maxPct: 70.99, remark: 'Good' },
      { grade: 'C1', minPct: 51, maxPct: 60.99, remark: 'Satisfactory' },
      { grade: 'C2', minPct: 41, maxPct: 50.99, remark: 'Acceptable' },
      { grade: 'D', minPct: 33, maxPct: 40.99, remark: 'Pass' },
      { grade: 'E', minPct: 0, maxPct: 32.99, remark: 'Needs Improvement' },
    ];

    const insertSetting = db.prepare(`INSERT INTO system_settings (key, value) VALUES (?, ?)`);
    insertSetting.run('school_name', 'EMRS Gangyap');
    insertSetting.run('school_address', 'Gangyap, Gyalshing District, Sikkim');
    insertSetting.run('school_motto', 'Discipline, Inquiry & Academic Excellence');
    insertSetting.run('current_academic_year', '2025-26');
    insertSetting.run('default_pass_percentage', '33');
    insertSetting.run('grading_scale', JSON.stringify(defaultGrades));

    // 2. Roles
    const insertRole = db.prepare(`INSERT INTO roles (name, description) VALUES (?, ?)`);
    const adminRoleId = Number(insertRole.run('admin', 'Full school system administration').lastInsertRowid);
    const teacherRoleId = Number(insertRole.run('teacher', 'Subject teacher and/or class teacher').lastInsertRowid);

    // 3. Users (1 Admin + 10 Teachers)
    const adminPass = hashSeedPassword('admin123');
    const teacherPass = hashSeedPassword('teacher123');

    const insertUser = db.prepare(
      `INSERT INTO users (username, password_hash, full_name, email, employee_code, is_active, must_change_password)
       VALUES (?, ?, ?, ?, ?, 1, 0)`
    );
    const insertUserRole = db.prepare(`INSERT INTO user_roles (user_id, role_id) VALUES (?, ?)`);

    const adminId = Number(
      insertUser.run('admin', adminPass, 'Dr. Meenakshi Kulkarni', 'principal@stxaviers.edu', 'ADM-001').lastInsertRowid
    );
    insertUserRole.run(adminId, adminRoleId);

    const teacherDefs = [
      { username: 'sharma', name: 'Mr. Rajesh Sharma', email: 'r.sharma@stxaviers.edu', code: 'TCH-101' },
      { username: 'das', name: 'Mrs. Ananya Das', email: 'a.das@stxaviers.edu', code: 'TCH-102' },
      { username: 'roy', name: 'Mr. Subhash Roy', email: 's.roy@stxaviers.edu', code: 'TCH-103' },
      { username: 'sen', name: 'Mrs. Meera Sen', email: 'm.sen@stxaviers.edu', code: 'TCH-104' },
      { username: 'kumar', name: 'Mr. Vivek Kumar', email: 'v.kumar@stxaviers.edu', code: 'TCH-105' },
      { username: 'gupta', name: 'Mr. Arvind Gupta', email: 'a.gupta@stxaviers.edu', code: 'TCH-106' },
      { username: 'nair', name: 'Mrs. Priya Nair', email: 'p.nair@stxaviers.edu', code: 'TCH-107' },
      { username: 'verma', name: 'Mr. Sanjay Verma', email: 's.verma@stxaviers.edu', code: 'TCH-108' },
      { username: 'iyer', name: 'Mrs. Kavita Iyer', email: 'k.iyer@stxaviers.edu', code: 'TCH-109' },
      { username: 'kapoor', name: 'Mr. Rohan Kapoor', email: 'r.kapoor@stxaviers.edu', code: 'TCH-110' },
    ];

    const teachers: Record<string, number> = {};
    for (const t of teacherDefs) {
      const uid = Number(insertUser.run(t.username, teacherPass, t.name, t.email, t.code).lastInsertRowid);
      insertUserRole.run(uid, teacherRoleId);
      teachers[t.username] = uid;
    }

    // 4. Classes & Sections (Class 6..9, Section A & B)
    const insertClass = db.prepare(`INSERT INTO classes (name, numeric_order) VALUES (?, ?)`);
    const insertSection = db.prepare(`INSERT INTO sections (class_id, name, capacity) VALUES (?, ?, 30)`);

    const classMap: Record<number, { id: number; sections: Record<string, number> }> = {};
    for (const num of [6, 7, 8, 9]) {
      const cid = Number(insertClass.run(`Class ${num}`, num).lastInsertRowid);
      const secA = Number(insertSection.run(cid, 'A').lastInsertRowid);
      const secB = Number(insertSection.run(cid, 'B').lastInsertRowid);
      classMap[num] = { id: cid, sections: { A: secA, B: secB } };
    }

    // 5. 240 Students (30 per section x 8 sections)
    const firstNames = [
      'Rahul', 'Priya', 'Amit', 'Rohan', 'Sneha', 'Ananya', 'Vikram', 'Neha', 'Arjun', 'Kavya',
      'Aditya', 'Ishita', 'Karan', 'Pooja', 'Siddharth', 'Meera', 'Dev', 'Riya', 'Nikhil', 'Tanvi',
      'Varun', 'Shruti', 'Manish', 'Divya', 'Pranav', 'Nandini', 'Harsh', 'Sanya', 'Aakash', 'Aarti',
    ];
    const lastNames = [
      'Verma', 'Nair', 'Patel', 'Sharma', 'Gupta', 'Das', 'Mehta', 'Kapoor', 'Rao', 'Joshi',
      'Mishra', 'Banerjee', 'Kulkarni', 'Choudhary', 'Sinha', 'Reddy', 'Malhotra', 'Agarwal', 'Tiwari', 'Bose',
    ];
    const guardianPrefixes = ['Mr. Ramesh', 'Mrs. Sunita', 'Mr. Suresh', 'Mrs. Rekha', 'Mr. Deepak', 'Mrs. Anita'];

    const insertStudent = db.prepare(
      `INSERT INTO students (student_code, full_name, roll_number, class_id, section_id, academic_year, gender, guardian_name, guardian_phone, status)
       VALUES (?, ?, ?, ?, ?, '2025-26', ?, ?, ?, 'active')`
    );

    const studentsBySec: Record<string, number[]> = {};
    let globalIdx = 1;
    for (const num of [6, 7, 8, 9]) {
      for (const secName of ['A', 'B']) {
        const key = `${num}${secName}`;
        studentsBySec[key] = [];
        const cid = classMap[num].id;
        const sid = classMap[num].sections[secName];
        for (let r = 1; r <= 30; r++) {
          const code = `ST${String(globalIdx).padStart(3, '0')}`;
          const fName = firstNames[(r - 1) % firstNames.length];
          const lName =
            num === 6 && secName === 'A' && r <= 4
              ? ['Verma', 'Nair', 'Patel', 'Sharma'][r - 1]
              : lastNames[(globalIdx * 3 + r) % lastNames.length];
          const fullName = `${fName} ${lName}`;
          const gender = r % 2 === 1 ? 'Male' : 'Female';
          const guardian = `${guardianPrefixes[globalIdx % guardianPrefixes.length]} ${lName}`;
          const phone = `+91 98${String(10000000 + globalIdx * 317).slice(0, 8)}`;
          const stId = Number(insertStudent.run(code, fullName, r, cid, sid, gender, guardian, phone).lastInsertRowid);
          studentsBySec[key].push(stId);
          globalIdx++;
        }
      }
    }

    // 6. Subjects & Subject Components (80 Exam + 20 IA [5 Notebook + 5 Unit Test + 5 Practical/Assignment/Project + 5 Overall Participation] = 100)
    const insertSubject = db.prepare(
      `INSERT INTO subjects (code, name, default_max_marks, has_components, component_mode, has_internal_assessment, ia_notebook_max, ia_unit_test_max, ia_practical_max, ia_participation_max, display_order)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
    );
    const insertComp = db.prepare(
      `INSERT INTO subject_components (subject_id, name, code, default_max_marks, display_order) VALUES (?, ?, ?, ?, ?)`
    );

    const subjectsData = [
      {
        code: 'SCI',
        name: 'Science',
        max: 100,
        hasComp: 1,
        hasIa: 1,
        nb: 5,
        ut: 5,
        pr: 5,
        op: 5,
        order: 1,
        comps: [
          { name: 'Physics', code: 'PHY', max: 25, order: 1 },
          { name: 'Chemistry', code: 'CHEM', max: 25, order: 2 },
          { name: 'Biology', code: 'BIO', max: 30, order: 3 },
        ],
      },
      {
        code: 'SST',
        name: 'Social Science',
        max: 100,
        hasComp: 1,
        hasIa: 1,
        nb: 5,
        ut: 5,
        pr: 5,
        op: 5,
        order: 2,
        comps: [
          { name: 'History', code: 'HIST', max: 20, order: 1 },
          { name: 'Geography', code: 'GEO', max: 20, order: 2 },
          { name: 'Civics', code: 'CIV', max: 20, order: 3 },
          { name: 'Economics', code: 'ECO', max: 20, order: 4 },
        ],
      },
      {
        code: 'ENG',
        name: 'English',
        max: 100,
        hasComp: 0,
        hasIa: 1,
        nb: 5,
        ut: 5,
        pr: 5,
        op: 5,
        order: 3,
        comps: [{ name: 'English', code: 'ENG', max: 80, order: 1 }],
      },
      {
        code: 'MATH',
        name: 'Mathematics',
        max: 100,
        hasComp: 0,
        hasIa: 1,
        nb: 5,
        ut: 5,
        pr: 5,
        op: 5,
        order: 4,
        comps: [{ name: 'Mathematics', code: 'MATH', max: 80, order: 1 }],
      },
      {
        code: 'HIN',
        name: 'Hindi',
        max: 100,
        hasComp: 0,
        hasIa: 1,
        nb: 5,
        ut: 5,
        pr: 5,
        op: 5,
        order: 5,
        comps: [{ name: 'Hindi', code: 'HIN', max: 80, order: 1 }],
      },
      {
        code: 'CS',
        name: 'Computer Science',
        max: 50,
        hasComp: 0,
        hasIa: 1,
        nb: 5,
        ut: 5,
        pr: 5,
        op: 0,
        order: 6,
        comps: [{ name: 'Computer Science', code: 'CS', max: 35, order: 1 }],
      },
    ];

    const subIds: Record<string, number> = {};
    const compIds: Record<string, number> = {};
    for (const s of subjectsData) {
      const sid = Number(
        insertSubject.run(
          s.code,
          s.name,
          s.max,
          s.hasComp,
          s.hasComp ? 'combined' : 'single',
          s.hasIa,
          s.nb,
          s.ut,
          s.pr,
          s.op,
          s.order
        ).lastInsertRowid
      );
      subIds[s.code] = sid;
      for (const c of s.comps) {
        const cid = Number(insertComp.run(sid, c.name, c.code, c.max, c.order).lastInsertRowid);
        compIds[c.code] = cid;
      }
    }

    // 7. Class Teacher Assignments
    const insertClassTeacher = db.prepare(
      `INSERT INTO class_teacher_assignments (teacher_id, class_id, section_id, academic_year) VALUES (?, ?, ?, '2025-26')`
    );
    const ctMap: Array<[string, number, string]> = [
      ['sharma', 6, 'A'],
      ['das', 6, 'B'],
      ['roy', 7, 'A'],
      ['sen', 7, 'B'],
      ['nair', 8, 'A'],
      ['verma', 8, 'B'],
      ['iyer', 9, 'A'],
      ['kapoor', 9, 'B'],
    ];
    for (const [uname, cls, sec] of ctMap) {
      insertClassTeacher.run(teachers[uname], classMap[cls].id, classMap[cls].sections[sec]);
    }

    // 8. Teacher Subject-Component Assignments
    const insertAssign = db.prepare(
      `INSERT INTO teacher_assignments (teacher_id, subject_id, component_id, class_id, section_id, academic_year)
       VALUES (?, ?, ?, ?, ?, '2025-26')`
    );

    const assign = (uname: string, subCode: string, compCode: string, cls: number, sec: string) => {
      insertAssign.run(
        teachers[uname],
        subIds[subCode],
        compIds[compCode],
        classMap[cls].id,
        classMap[cls].sections[sec]
      );
    };

    // Exact prompt examples + complete school coverage
    // Physics
    assign('sharma', 'SCI', 'PHY', 6, 'A');
    assign('sharma', 'SCI', 'PHY', 6, 'B');
    assign('sharma', 'SCI', 'PHY', 7, 'A');
    assign('kumar', 'SCI', 'PHY', 7, 'B');
    assign('kumar', 'SCI', 'PHY', 8, 'A');
    assign('kumar', 'SCI', 'PHY', 8, 'B');
    assign('kapoor', 'SCI', 'PHY', 9, 'A');
    assign('kapoor', 'SCI', 'PHY', 9, 'B');

    // Chemistry
    assign('das', 'SCI', 'CHEM', 6, 'A');
    assign('das', 'SCI', 'CHEM', 6, 'B');
    assign('kapoor', 'SCI', 'CHEM', 7, 'A');
    assign('kapoor', 'SCI', 'CHEM', 7, 'B');
    assign('kapoor', 'SCI', 'CHEM', 8, 'A');
    assign('kapoor', 'SCI', 'CHEM', 8, 'B');
    assign('kapoor', 'SCI', 'CHEM', 9, 'A');
    assign('kapoor', 'SCI', 'CHEM', 9, 'B');

    // Biology
    assign('roy', 'SCI', 'BIO', 6, 'A');
    assign('roy', 'SCI', 'BIO', 6, 'B');
    assign('das', 'SCI', 'BIO', 7, 'A');
    assign('roy', 'SCI', 'BIO', 7, 'B');
    assign('roy', 'SCI', 'BIO', 8, 'A');
    assign('roy', 'SCI', 'BIO', 8, 'B');
    assign('roy', 'SCI', 'BIO', 9, 'A');
    assign('roy', 'SCI', 'BIO', 9, 'B');

    // Social Science
    for (const [cls, sec] of [
      [6, 'A'], [6, 'B'], [7, 'A'], [7, 'B'], [8, 'A'], [8, 'B'], [9, 'A'], [9, 'B'],
    ] as Array<[number, string]>) {
      assign('sen', 'SST', 'HIST', cls, sec);
      assign('kumar', 'SST', 'GEO', cls, sec);
      assign(cls === 6 && sec === 'A' ? 'das' : 'iyer', 'SST', 'CIV', cls, sec);
      assign(cls === 6 && sec === 'B' ? 'roy' : 'iyer', 'SST', 'ECO', cls, sec);
      assign('gupta', 'ENG', 'ENG', cls, sec);
      assign(cls === 8 && sec === 'B' ? 'sharma' : 'nair', 'MATH', 'MATH', cls, sec);
      assign('verma', 'HIN', 'HIN', cls, sec);
      assign(cls >= 8 ? 'kapoor' : 'verma', 'CS', 'CS', cls, sec);
    }

    // 9. Examinations
    const insertExam = db.prepare(
      `INSERT INTO examinations (name, academic_year, start_date, end_date, status, marks_entry_open, passing_percentage)
       VALUES (?, '2025-26', ?, ?, ?, ?, 33)`
    );
    const insertExamSub = db.prepare(
      `INSERT INTO examination_subjects (examination_id, subject_id, max_marks, passing_marks, has_internal_assessment, ia_notebook_max, ia_unit_test_max, ia_practical_max, ia_participation_max, is_required, display_order)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 1, ?)`
    );
    const insertExamComp = db.prepare(
      `INSERT INTO examination_components (examination_id, examination_subject_id, subject_id, component_id, component_name, max_marks, passing_marks, display_order)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?)`
    );

    const exam1Id = Number(
      insertExam.run('Unit Test 1', '2025-07-14', '2025-07-21', 'Published', 0).lastInsertRowid
    );
    const exam2Id = Number(
      insertExam.run('Half-Yearly Examination', '2025-09-22', '2025-10-04', 'Active', 1).lastInsertRowid
    );
    const exam3Id = Number(
      insertExam.run('Annual Examination', '2026-02-18', '2026-03-03', 'Active', 1).lastInsertRowid
    );

    // Helper to configure exam subjects & components
    const setupExamConfig = (
      examId: number,
      config: Array<{
        subCode: string;
        max: number;
        pass: number;
        hasIa: number;
        nb: number;
        ut: number;
        pr: number;
        op: number;
        order: number;
        comps: Array<{ code: string; name: string; max: number; pass: number; order: number }>;
      }>
    ) => {
      const exCompMap: Record<string, number> = {};
      for (const s of config) {
        const esId = Number(
          insertExamSub.run(examId, subIds[s.subCode], s.max, s.pass, s.hasIa, s.nb, s.ut, s.pr, s.op, s.order).lastInsertRowid
        );
        for (const c of s.comps) {
          const ecId = Number(
            insertExamComp.run(examId, esId, subIds[s.subCode], compIds[c.code], c.name, c.max, c.pass, c.order)
              .lastInsertRowid
          );
          exCompMap[c.code] = ecId;
        }
      }
      return exCompMap;
    };

    const ut1Comps = setupExamConfig(exam1Id, [
      {
        subCode: 'SCI',
        max: 40,
        pass: 13,
        hasIa: 0,
        nb: 0,
        ut: 0,
        pr: 0,
        op: 0,
        order: 1,
        comps: [
          { code: 'PHY', name: 'Physics', max: 13, pass: 4, order: 1 },
          { code: 'CHEM', name: 'Chemistry', max: 13, pass: 4, order: 2 },
          { code: 'BIO', name: 'Biology', max: 14, pass: 5, order: 3 },
        ],
      },
      {
        subCode: 'SST',
        max: 40,
        pass: 13,
        hasIa: 0,
        nb: 0,
        ut: 0,
        pr: 0,
        op: 0,
        order: 2,
        comps: [
          { code: 'HIST', name: 'History', max: 10, pass: 3, order: 1 },
          { code: 'GEO', name: 'Geography', max: 10, pass: 3, order: 2 },
          { code: 'CIV', name: 'Civics', max: 10, pass: 3, order: 3 },
          { code: 'ECO', name: 'Economics', max: 10, pass: 3, order: 4 },
        ],
      },
      {
        subCode: 'ENG',
        max: 50,
        pass: 17,
        hasIa: 0,
        nb: 0,
        ut: 0,
        pr: 0,
        op: 0,
        order: 3,
        comps: [{ code: 'ENG', name: 'English', max: 50, pass: 17, order: 1 }],
      },
      {
        subCode: 'MATH',
        max: 50,
        pass: 17,
        hasIa: 0,
        nb: 0,
        ut: 0,
        pr: 0,
        op: 0,
        order: 4,
        comps: [{ code: 'MATH', name: 'Mathematics', max: 50, pass: 17, order: 1 }],
      },
    ]);

    const hyComps = setupExamConfig(exam2Id, [
      {
        subCode: 'SCI',
        max: 100,
        pass: 33,
        hasIa: 1,
        nb: 5,
        ut: 5,
        pr: 5,
        op: 5,
        order: 1,
        comps: [
          { code: 'PHY', name: 'Physics', max: 25, pass: 8, order: 1 },
          { code: 'CHEM', name: 'Chemistry', max: 25, pass: 8, order: 2 },
          { code: 'BIO', name: 'Biology', max: 30, pass: 10, order: 3 },
        ],
      },
      {
        subCode: 'SST',
        max: 100,
        pass: 33,
        hasIa: 1,
        nb: 5,
        ut: 5,
        pr: 5,
        op: 5,
        order: 2,
        comps: [
          { code: 'HIST', name: 'History', max: 20, pass: 7, order: 1 },
          { code: 'GEO', name: 'Geography', max: 20, pass: 7, order: 2 },
          { code: 'CIV', name: 'Civics', max: 20, pass: 7, order: 3 },
          { code: 'ECO', name: 'Economics', max: 20, pass: 7, order: 4 },
        ],
      },
      {
        subCode: 'ENG',
        max: 100,
        pass: 33,
        hasIa: 1,
        nb: 5,
        ut: 5,
        pr: 5,
        op: 5,
        order: 3,
        comps: [{ code: 'ENG', name: 'English', max: 80, pass: 26, order: 1 }],
      },
      {
        subCode: 'MATH',
        max: 100,
        pass: 33,
        hasIa: 1,
        nb: 5,
        ut: 5,
        pr: 5,
        op: 5,
        order: 4,
        comps: [{ code: 'MATH', name: 'Mathematics', max: 80, pass: 26, order: 1 }],
      },
      {
        subCode: 'HIN',
        max: 100,
        pass: 33,
        hasIa: 1,
        nb: 5,
        ut: 5,
        pr: 5,
        op: 5,
        order: 5,
        comps: [{ code: 'HIN', name: 'Hindi', max: 80, pass: 26, order: 1 }],
      },
      {
        subCode: 'CS',
        max: 50,
        pass: 17,
        hasIa: 1,
        nb: 5,
        ut: 5,
        pr: 5,
        op: 0,
        order: 6,
        comps: [{ code: 'CS', name: 'Computer Science', max: 35, pass: 12, order: 1 }],
      },
    ]);

    setupExamConfig(exam3Id, [
      {
        subCode: 'SCI',
        max: 100,
        pass: 33,
        hasIa: 1,
        nb: 5,
        ut: 5,
        pr: 5,
        op: 5,
        order: 1,
        comps: [
          { code: 'PHY', name: 'Physics', max: 25, pass: 8, order: 1 },
          { code: 'CHEM', name: 'Chemistry', max: 25, pass: 8, order: 2 },
          { code: 'BIO', name: 'Biology', max: 30, pass: 10, order: 3 },
        ],
      },
      {
        subCode: 'SST',
        max: 100,
        pass: 33,
        hasIa: 1,
        nb: 5,
        ut: 5,
        pr: 5,
        op: 5,
        order: 2,
        comps: [
          { code: 'HIST', name: 'History', max: 20, pass: 7, order: 1 },
          { code: 'GEO', name: 'Geography', max: 20, pass: 7, order: 2 },
          { code: 'CIV', name: 'Civics', max: 20, pass: 7, order: 3 },
          { code: 'ECO', name: 'Economics', max: 20, pass: 7, order: 4 },
        ],
      },
      {
        subCode: 'ENG',
        max: 100,
        pass: 33,
        hasIa: 1,
        nb: 5,
        ut: 5,
        pr: 5,
        op: 5,
        order: 3,
        comps: [{ code: 'ENG', name: 'English', max: 80, pass: 26, order: 1 }],
      },
      {
        subCode: 'MATH',
        max: 100,
        pass: 33,
        hasIa: 1,
        nb: 5,
        ut: 5,
        pr: 5,
        op: 5,
        order: 4,
        comps: [{ code: 'MATH', name: 'Mathematics', max: 80, pass: 26, order: 1 }],
      },
    ]);

    // 10. Seed deterministic marks for Unit Test 1 (6A, 6B, 7A complete) & Half-Yearly (6B complete + IA, 6A mixed)
    const insertMark = db.prepare(
      `INSERT INTO marks (student_id, examination_id, examination_component_id, obtained_marks, status, entered_by, submitted_by, submitted_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?)`
    );
    const insertIa = db.prepare(
      `INSERT INTO internal_assessment_marks (student_id, examination_id, subject_id, notebook_marks, unit_test_marks, practical_marks, participation_marks, status, entered_by, entered_via_component_id, submitted_by, submitted_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
    );

    const scoreFor = (studentIdx: number, max: number, salt: number) => {
      const raw = ((studentIdx * 17 + salt * 13) % 40) / 100;
      const pct = studentIdx % 19 === 14 ? 0.28 + raw * 0.2 : 0.56 + raw;
      return Math.min(max, Math.max(0, Math.round(max * pct)));
    };

    const submittedTimestamp = '2025-10-06 14:30:00';

    // Unit Test 1: complete for 6A, 6B, 7A
    for (const secKey of ['6A', '6B', '7A']) {
      const stList = studentsBySec[secKey];
      stList.forEach((stId, idx) => {
        const entries: Array<[string, number, string]> = [
          ['PHY', 13, 'sharma'],
          ['CHEM', 13, secKey === '7A' ? 'kapoor' : 'das'],
          ['BIO', 14, secKey === '7A' ? 'das' : 'roy'],
          ['HIST', 10, 'sen'],
          ['GEO', 10, 'kumar'],
          ['CIV', 10, secKey === '6A' ? 'das' : 'iyer'],
          ['ECO', 10, secKey === '6B' ? 'roy' : 'iyer'],
          ['ENG', 50, 'gupta'],
          ['MATH', 50, 'nair'],
        ];
        entries.forEach(([cCode, max, tName], cIdx) => {
          insertMark.run(
            stId,
            exam1Id,
            ut1Comps[cCode],
            scoreFor(idx + 1, max, cIdx + 3),
            'submitted',
            teachers[tName],
            teachers[tName],
            '2025-07-24 11:15:00'
          );
        });
      });
    }

    // Half-Yearly Examination: 6B complete (all written + all IA submitted)
    studentsBySec['6B'].forEach((stId, idx) => {
      const entries: Array<[string, number, string]> = [
        ['PHY', 25, 'sharma'],
        ['CHEM', 25, 'das'],
        ['BIO', 30, 'roy'],
        ['HIST', 20, 'sen'],
        ['GEO', 20, 'kumar'],
        ['CIV', 20, 'iyer'],
        ['ECO', 20, 'roy'],
        ['ENG', 80, 'gupta'],
        ['MATH', 80, 'nair'],
        ['HIN', 80, 'verma'],
        ['CS', 35, 'verma'],
      ];
      entries.forEach(([cCode, max, tName], cIdx) => {
        insertMark.run(
          stId,
          exam2Id,
          hyComps[cCode],
          scoreFor(idx + 2, max, cIdx + 7),
          'submitted',
          teachers[tName],
          teachers[tName],
          submittedTimestamp
        );
      });

      const iaSeeds: Array<[string, number, number, string, string]> = [
        ['SCI', 5, 5, 'roy', 'BIO'],
        ['SST', 5, 5, 'roy', 'ECO'],
        ['ENG', 5, 5, 'gupta', 'ENG'],
        ['MATH', 5, 5, 'nair', 'MATH'],
        ['HIN', 5, 5, 'verma', 'HIN'],
        ['CS', 5, 0, 'verma', 'CS'],
      ];
      iaSeeds.forEach(([sCode, prMax, opMax, tName, viaComp], sIdx) => {
        insertIa.run(
          stId,
          exam2Id,
          subIds[sCode],
          scoreFor(idx + 2, 5, sIdx + 1),
          scoreFor(idx + 3, 5, sIdx + 4),
          scoreFor(idx + 4, prMax, sIdx + 7),
          opMax > 0 ? scoreFor(idx + 5, opMax, sIdx + 11) : 0,
          'submitted',
          teachers[tName],
          hyComps[viaComp],
          teachers[tName],
          submittedTimestamp
        );
      });
    });

    // Half-Yearly Examination: 6A mixed
    // Submitted: PHY, CHEM, HIST, CIV, ECO, ENG (+IA), HIN (+IA), CS (+IA)
    // Draft: BIO (first 24) -> roy is the LAST teacher for 6A Science!
    // Pending: GEO -> kumar is the LAST teacher for 6A Social Science! MATH -> nair
    studentsBySec['6A'].forEach((stId, idx) => {
      const submittedEntries: Array<[string, number, string]> = [
        ['PHY', 25, 'sharma'],
        ['CHEM', 25, 'das'],
        ['HIST', 20, 'sen'],
        ['CIV', 20, 'das'],
        ['ECO', 20, 'iyer'],
        ['ENG', 80, 'gupta'],
        ['HIN', 80, 'verma'],
        ['CS', 35, 'verma'],
      ];
      submittedEntries.forEach(([cCode, max, tName], cIdx) => {
        insertMark.run(
          stId,
          exam2Id,
          hyComps[cCode],
          scoreFor(idx + 1, max, cIdx + 11),
          'submitted',
          teachers[tName],
          teachers[tName],
          submittedTimestamp
        );
      });

      const iaSeeds6A: Array<[string, number, number, string, string]> = [
        ['ENG', 5, 5, 'gupta', 'ENG'],
        ['HIN', 5, 5, 'verma', 'HIN'],
        ['CS', 5, 0, 'verma', 'CS'],
      ];
      iaSeeds6A.forEach(([sCode, prMax, opMax, tName, viaComp], sIdx) => {
        insertIa.run(
          stId,
          exam2Id,
          subIds[sCode],
          scoreFor(idx + 1, 5, sIdx + 2),
          scoreFor(idx + 2, 5, sIdx + 5),
          scoreFor(idx + 3, prMax, sIdx + 9),
          opMax > 0 ? scoreFor(idx + 4, opMax, sIdx + 13) : 0,
          'submitted',
          teachers[tName],
          hyComps[viaComp],
          teachers[tName],
          submittedTimestamp
        );
      });

      // Biology Draft for first 24 students (leaving 6 blank/missing!)
      if (idx < 24) {
        insertMark.run(
          stId,
          exam2Id,
          hyComps['BIO'],
          scoreFor(idx + 1, 30, 19),
          'draft',
          teachers['roy'],
          null,
          null
        );
      }
    });

    // Audit Log seed
    const insertAudit = db.prepare(
      `INSERT INTO audit_logs (user_id, username, user_role, action, entity_type, entity_id, details)
       VALUES (?, ?, ?, ?, ?, ?, ?)`
    );
    insertAudit.run(
      adminId,
      'admin',
      'admin',
      'SYSTEM_INITIALIZED',
      'system',
      '1',
      JSON.stringify({ classes: 4, sections: 8, students: 240, examinations: 3 })
    );
    insertAudit.run(
      teachers['sharma'],
      'sharma',
      'teacher',
      'SUBMIT_MARKS',
      'marks',
      String(exam2Id),
      JSON.stringify({ examination: 'Half-Yearly Examination', class: 'Class 6', section: 'A', component: 'Physics', count: 30 })
    );
  });

  insertAll();
}

function migrateExistingDataToInternalAssessment() {
  db.transaction(() => {
    // Disable IA on Unit Test 1 if present
    const ut1 = db.prepare(`SELECT id FROM examinations WHERE name = 'Unit Test 1'`).get() as { id: number } | undefined;
    if (ut1) {
      db.prepare(
        `UPDATE examination_subjects SET has_internal_assessment = 0, ia_notebook_max = 0, ia_unit_test_max = 0, ia_practical_max = 0, ia_participation_max = 0 WHERE examination_id = ?`
      ).run(ut1.id);
    }

    // Update default subject templates to 80 Exam + 20 IA = 100 (and CS: 35 + 15 = 50)
    for (const code of ['ENG', 'MATH', 'HIN']) {
      const sub = db.prepare(`SELECT id FROM subjects WHERE code = ?`).get(code) as { id: number } | undefined;
      if (sub) {
        db.prepare(
          `UPDATE subjects SET default_max_marks = 100, has_internal_assessment = 1, ia_notebook_max = 5, ia_unit_test_max = 5, ia_practical_max = 5, ia_participation_max = 5 WHERE id = ?`
        ).run(sub.id);
        db.prepare(`UPDATE subject_components SET default_max_marks = 80 WHERE subject_id = ? AND code = ?`).run(sub.id, code);
      }
    }
    for (const code of ['SCI', 'SST']) {
      db.prepare(
        `UPDATE subjects SET default_max_marks = 100, has_internal_assessment = 1, ia_notebook_max = 5, ia_unit_test_max = 5, ia_practical_max = 5, ia_participation_max = 5 WHERE code = ?`
      ).run(code);
    }
    const csSub = db.prepare(`SELECT id FROM subjects WHERE code = 'CS'`).get() as { id: number } | undefined;
    if (csSub) {
      db.prepare(
        `UPDATE subjects SET default_max_marks = 50, has_internal_assessment = 1, ia_notebook_max = 5, ia_unit_test_max = 5, ia_practical_max = 5, ia_participation_max = 0 WHERE id = ?`
      ).run(csSub.id);
      db.prepare(`UPDATE subject_components SET default_max_marks = 35 WHERE subject_id = ? AND code = 'CS'`).run(csSub.id);
    }

    // Update Half-Yearly and Annual examinations
    const iaExams = db
      .prepare(`SELECT id FROM examinations WHERE name IN ('Half-Yearly Examination', 'Annual Examination')`)
      .all() as Array<{ id: number }>;

    for (const ex of iaExams) {
      const exSubs = db
        .prepare(
          `SELECT es.id, es.subject_id, s.code FROM examination_subjects es JOIN subjects s ON s.id = es.subject_id WHERE es.examination_id = ?`
        )
        .all(ex.id) as Array<{ id: number; subject_id: number; code: string }>;

      for (const es of exSubs) {
        if (['SCI', 'SST'].includes(es.code)) {
          db.prepare(
            `UPDATE examination_subjects SET max_marks = 100, passing_marks = 33, has_internal_assessment = 1, ia_notebook_max = 5, ia_unit_test_max = 5, ia_practical_max = 5, ia_participation_max = 5 WHERE id = ?`
          ).run(es.id);
        } else if (['ENG', 'MATH', 'HIN'].includes(es.code)) {
          db.prepare(
            `UPDATE examination_subjects SET max_marks = 100, passing_marks = 33, has_internal_assessment = 1, ia_notebook_max = 5, ia_unit_test_max = 5, ia_practical_max = 5, ia_participation_max = 5 WHERE id = ?`
          ).run(es.id);
          const ec = db
            .prepare(`SELECT id, max_marks FROM examination_components WHERE examination_subject_id = ?`)
            .get(es.id) as { id: number; max_marks: number } | undefined;
          if (ec && ec.max_marks === 100) {
            db.prepare(`UPDATE examination_components SET max_marks = 80, passing_marks = 26 WHERE id = ?`).run(ec.id);
            db.prepare(
              `UPDATE marks SET obtained_marks = MIN(80, ROUND(obtained_marks * 0.8)) WHERE examination_id = ? AND examination_component_id = ? AND obtained_marks IS NOT NULL`
            ).run(ex.id, ec.id);
          }
        } else if (es.code === 'CS') {
          db.prepare(
            `UPDATE examination_subjects SET max_marks = 50, passing_marks = 17, has_internal_assessment = 1, ia_notebook_max = 5, ia_unit_test_max = 5, ia_practical_max = 5, ia_participation_max = 0 WHERE id = ?`
          ).run(es.id);
          const ec = db
            .prepare(`SELECT id, max_marks FROM examination_components WHERE examination_subject_id = ?`)
            .get(es.id) as { id: number; max_marks: number } | undefined;
          if (ec && ec.max_marks === 50) {
            db.prepare(`UPDATE examination_components SET max_marks = 35, passing_marks = 12 WHERE id = ?`).run(ec.id);
            db.prepare(
              `UPDATE marks SET obtained_marks = MIN(35, ROUND(obtained_marks * 0.7)) WHERE examination_id = ? AND examination_component_id = ? AND obtained_marks IS NOT NULL`
            ).run(ex.id, ec.id);
          }
        }
      }
    }

    // Seed internal_assessment_marks for already-submitted sections in Half-Yearly
    const hy = db.prepare(`SELECT id FROM examinations WHERE name = 'Half-Yearly Examination'`).get() as { id: number } | undefined;
    const iaCount = (db.prepare(`SELECT COUNT(*) as cnt FROM internal_assessment_marks`).get() as { cnt: number }).cnt;
    if (hy && iaCount === 0) {
      const insertIa = db.prepare(
        `INSERT OR IGNORE INTO internal_assessment_marks (student_id, examination_id, subject_id, notebook_marks, unit_test_marks, practical_marks, participation_marks, status, entered_by, entered_via_component_id, submitted_by, submitted_at)
         VALUES (?, ?, ?, ?, ?, ?, ?, 'submitted', ?, ?, ?, '2025-10-06 14:30:00')`
      );
      const hySubs = db
        .prepare(
          `SELECT es.subject_id, s.code, es.ia_notebook_max, es.ia_unit_test_max, es.ia_practical_max, es.ia_participation_max
           FROM examination_subjects es JOIN subjects s ON s.id = es.subject_id
           WHERE es.examination_id = ? AND es.has_internal_assessment = 1`
        )
        .all(hy.id) as Array<{
        subject_id: number;
        code: string;
        ia_notebook_max: number;
        ia_unit_test_max: number;
        ia_practical_max: number;
        ia_participation_max: number;
      }>;

      const sec6A = db
        .prepare(
          `SELECT s.id as section_id, c.id as class_id FROM sections s JOIN classes c ON c.id = s.class_id WHERE c.name = 'Class 6' AND s.name = 'A'`
        )
        .get() as { section_id: number; class_id: number } | undefined;
      const sec6B = db
        .prepare(
          `SELECT s.id as section_id, c.id as class_id FROM sections s JOIN classes c ON c.id = s.class_id WHERE c.name = 'Class 6' AND s.name = 'B'`
        )
        .get() as { section_id: number; class_id: number } | undefined;

      const findExamCompAndTeacher = (subId: number, clsId: number, secId: number) => {
        return db
          .prepare(
            `SELECT ec.id as ec_id, ta.teacher_id
             FROM examination_components ec
             LEFT JOIN teacher_assignments ta ON ta.component_id = ec.component_id AND ta.class_id = ? AND ta.section_id = ?
             WHERE ec.examination_id = ? AND ec.subject_id = ?
             ORDER BY ec.display_order DESC LIMIT 1`
          )
          .get(clsId, secId, hy.id, subId) as { ec_id: number; teacher_id: number | null } | undefined;
      };

      const seedSec = (clsId: number, secId: number, codes: string[]) => {
        const sts = db
          .prepare(`SELECT id FROM students WHERE class_id = ? AND section_id = ? AND status = 'active' ORDER BY roll_number ASC`)
          .all(clsId, secId) as Array<{ id: number }>;
        hySubs
          .filter((s) => codes.includes(s.code))
          .forEach((s, sIdx) => {
            const meta = findExamCompAndTeacher(s.subject_id, clsId, secId);
            sts.forEach((st, idx) => {
              const nb = Math.min(s.ia_notebook_max, Math.max(2, Math.round(s.ia_notebook_max * (0.65 + ((idx + sIdx) % 4) * 0.1))));
              const ut = Math.min(s.ia_unit_test_max, Math.max(2, Math.round(s.ia_unit_test_max * (0.6 + ((idx * 2 + sIdx) % 4) * 0.1))));
              const pr = Math.min(s.ia_practical_max, Math.max(2, Math.round(s.ia_practical_max * (0.65 + ((idx + sIdx * 2) % 4) * 0.1))));
              const op =
                s.ia_participation_max > 0
                  ? Math.min(s.ia_participation_max, Math.max(2, Math.round(s.ia_participation_max * (0.6 + ((idx + sIdx * 3) % 4) * 0.1))))
                  : 0;
              insertIa.run(st.id, hy.id, s.subject_id, nb, ut, pr, op, meta?.teacher_id ?? null, meta?.ec_id ?? null, meta?.teacher_id ?? null);
            });
          });
      };

      if (sec6B) {
        seedSec(sec6B.class_id, sec6B.section_id, ['SCI', 'SST', 'ENG', 'MATH', 'HIN', 'CS']);
      }
      if (sec6A) {
        seedSec(sec6A.class_id, sec6A.section_id, ['ENG', 'HIN', 'CS']);
      }
    }
  })();
}

function ensureLanguageSubjectAndElectives() {
  const alreadySeeded = db
    .prepare(`SELECT value FROM system_settings WHERE key = 'language_elective_seeded'`)
    .get() as { value: string } | undefined;
  if (alreadySeeded?.value === '1') return;

  db.transaction(() => {
    db.exec(`UPDATE subjects SET component_mode = 'combined' WHERE has_components = 1 AND component_mode = 'single'`);

    const teacherRole = db.prepare(`SELECT id FROM roles WHERE name = 'teacher'`).get() as { id: number } | undefined;
    if (!teacherRole) return;

    const teacherPass = hashSeedPassword('teacher123');
    const langTeachers = [
      { username: 'thapa', name: 'Mr. Bikash Thapa', email: 'b.thapa@stxaviers.edu', code: 'TCH-111', compCode: 'NEP' },
      { username: 'lepcha', name: 'Mr. Tenzing Lepcha', email: 't.lepcha@stxaviers.edu', code: 'TCH-112', compCode: 'LEP' },
      { username: 'subba', name: 'Mrs. Kamala Subba', email: 'k.subba@stxaviers.edu', code: 'TCH-113', compCode: 'LIM' },
      { username: 'bhutia', name: 'Mr. Karma Bhutia', email: 'k.bhutia@stxaviers.edu', code: 'TCH-114', compCode: 'BHU' },
    ];

    const teacherIdByCompCode: Record<string, number> = {};
    for (const lt of langTeachers) {
      let row = db.prepare(`SELECT id FROM users WHERE lower(username) = lower(?)`).get(lt.username) as
        | { id: number }
        | undefined;
      if (!row) {
        const info = db
          .prepare(
            `INSERT INTO users (username, password_hash, full_name, email, employee_code, is_active, must_change_password)
             VALUES (?, ?, ?, ?, ?, 1, 0)`
          )
          .run(lt.username, teacherPass, lt.name, lt.email, lt.code);
        const uid = Number(info.lastInsertRowid);
        db.prepare(`INSERT OR IGNORE INTO user_roles (user_id, role_id) VALUES (?, ?)`).run(uid, teacherRole.id);
        row = { id: uid };
      }
      teacherIdByCompCode[lt.compCode] = row.id;
    }

    let langSub = db.prepare(`SELECT id FROM subjects WHERE code = 'LANG' OR lower(name) = 'language'`).get() as
      | { id: number }
      | undefined;
    if (!langSub) {
      const ordRow = db.prepare(`SELECT COALESCE(MAX(display_order), 0) + 1 as ord FROM subjects`).get() as {
        ord: number;
      };
      const info = db
        .prepare(
          `INSERT INTO subjects (code, name, default_max_marks, has_components, component_mode, has_internal_assessment, ia_notebook_max, ia_unit_test_max, ia_practical_max, ia_participation_max, display_order)
           VALUES ('LANG', 'Language', 100, 1, 'elective', 1, 5, 5, 5, 5, ?)`
        )
        .run(ordRow.ord);
      langSub = { id: Number(info.lastInsertRowid) };
    } else {
      db.prepare(
        `UPDATE subjects SET default_max_marks = 100, has_components = 1, component_mode = 'elective', has_internal_assessment = 1, ia_notebook_max = 5, ia_unit_test_max = 5, ia_practical_max = 5, ia_participation_max = 5 WHERE id = ?`
      ).run(langSub.id);
    }

    const subOptions = [
      { name: 'Nepali', code: 'NEP', max: 80, order: 1 },
      { name: 'Lepcha', code: 'LEP', max: 80, order: 2 },
      { name: 'Limboo', code: 'LIM', max: 80, order: 3 },
      { name: 'Bhutia', code: 'BHU', max: 80, order: 4 },
      { name: 'Hindi(Lang)', code: 'HINL', max: 80, order: 5 },
    ];

    const compIdByCode: Record<string, number> = {};
    for (const opt of subOptions) {
      let compRow = db
        .prepare(`SELECT id FROM subject_components WHERE subject_id = ? AND (code = ? OR lower(name) = lower(?))`)
        .get(langSub.id, opt.code, opt.name) as { id: number } | undefined;
      if (!compRow) {
        const info = db
          .prepare(
            `INSERT INTO subject_components (subject_id, name, code, default_max_marks, display_order)
             VALUES (?, ?, ?, ?, ?)`
          )
          .run(langSub.id, opt.name, opt.code, opt.max, opt.order);
        compRow = { id: Number(info.lastInsertRowid) };
      }
      compIdByCode[opt.code] = compRow.id;
    }

    // Assign the 4 distinct Language teachers across all classes & sections
    const yearRow = db.prepare(`SELECT value FROM system_settings WHERE key = 'current_academic_year'`).get() as
      | { value: string }
      | undefined;
    const academicYear = yearRow?.value || '2025-26';
    const classSections = db
      .prepare(`SELECT c.id as class_id, s.id as section_id FROM classes c JOIN sections s ON s.class_id = c.id`)
      .all() as Array<{ class_id: number; section_id: number }>;

    const insertAssign = db.prepare(
      `INSERT OR IGNORE INTO teacher_assignments (teacher_id, subject_id, component_id, class_id, section_id, academic_year)
       VALUES (?, ?, ?, ?, ?, ?)`
    );
    for (const cs of classSections) {
      for (const opt of subOptions) {
        const tid = teacherIdByCompCode[opt.code];
        if (!tid) continue;
        insertAssign.run(
          tid,
          langSub.id,
          compIdByCode[opt.code],
          cs.class_id,
          cs.section_id,
          academicYear
        );
      }
    }

    // Distribute all active students across Nepali, Lepcha, Limboo, Bhutia
    const activeStudents = db
      .prepare(`SELECT id, roll_number, class_id, section_id FROM students WHERE status = 'active' ORDER BY id ASC`)
      .all() as Array<{ id: number; roll_number: number; class_id: number; section_id: number }>;
    const insertElective = db.prepare(
      `INSERT OR IGNORE INTO student_electives (student_id, subject_id, component_id) VALUES (?, ?, ?)`
    );
    const optCodes = ['NEP', 'LEP', 'LIM', 'BHU'];
    for (const st of activeStudents) {
      const code = optCodes[(st.roll_number - 1 + st.section_id) % optCodes.length];
      insertElective.run(st.id, langSub.id, compIdByCode[code]);
    }

    // Add Language (80 + 20 IA = 100) to Half-Yearly Examination and Annual Examination
    const targetExams = db
      .prepare(`SELECT id FROM examinations WHERE name IN ('Half-Yearly Examination', 'Annual Examination')`)
      .all() as Array<{ id: number }>;

    for (const ex of targetExams) {
      let exSub = db
        .prepare(`SELECT id FROM examination_subjects WHERE examination_id = ? AND subject_id = ?`)
        .get(ex.id, langSub.id) as { id: number } | undefined;

      if (!exSub) {
        const maxOrd = (
          db
            .prepare(`SELECT COALESCE(MAX(display_order), 0) + 1 as ord FROM examination_subjects WHERE examination_id = ?`)
            .get(ex.id) as { ord: number }
        ).ord;
        const esInfo = db
          .prepare(
            `INSERT INTO examination_subjects (examination_id, subject_id, max_marks, passing_marks, has_internal_assessment, ia_notebook_max, ia_unit_test_max, ia_practical_max, ia_participation_max, is_required, display_order)
             VALUES (?, ?, 100, 33, 1, 5, 5, 5, 5, 1, ?)`
          )
          .run(ex.id, langSub.id, maxOrd);
        exSub = { id: Number(esInfo.lastInsertRowid) };
      }

      for (const opt of subOptions) {
        db.prepare(
          `INSERT OR IGNORE INTO examination_components (examination_id, examination_subject_id, subject_id, component_id, component_name, max_marks, passing_marks, display_order)
           VALUES (?, ?, ?, ?, ?, 80, 26, ?)`
        ).run(ex.id, exSub.id, langSub.id, compIdByCode[opt.code], opt.name, opt.order);
      }
    }

    // Seed Class 6B Half-Yearly Language written + IA marks so 6B remains 100% complete
    const hy = db.prepare(`SELECT id FROM examinations WHERE name = 'Half-Yearly Examination'`).get() as
      | { id: number }
      | undefined;
    const sec6B = db
      .prepare(
        `SELECT s.id as section_id, c.id as class_id FROM sections s JOIN classes c ON c.id = s.class_id WHERE c.name = 'Class 6' AND s.name = 'B'`
      )
      .get() as { section_id: number; class_id: number } | undefined;

    if (hy && sec6B) {
      const hyLangComps = db
        .prepare(
          `SELECT ec.id as ec_id, ec.component_id, sc.code as comp_code
           FROM examination_components ec
           JOIN subject_components sc ON sc.id = ec.component_id
           WHERE ec.examination_id = ? AND ec.subject_id = ?`
        )
        .all(hy.id, langSub.id) as Array<{ ec_id: number; component_id: number; comp_code: string }>;
      const ecByCompId = new Map(hyLangComps.map((r) => [r.component_id, r]));

      const students6B = db
        .prepare(
          `SELECT st.id, st.roll_number, se.component_id
           FROM students st
           JOIN student_electives se ON se.student_id = st.id AND se.subject_id = ?
           WHERE st.class_id = ? AND st.section_id = ? AND st.status = 'active'`
        )
        .all(langSub.id, sec6B.class_id, sec6B.section_id) as Array<{
        id: number;
        roll_number: number;
        component_id: number;
      }>;

      const insertMark = db.prepare(
        `INSERT OR IGNORE INTO marks (student_id, examination_id, examination_component_id, obtained_marks, status, entered_by, submitted_by, submitted_at)
         VALUES (?, ?, ?, ?, 'submitted', ?, ?, '2025-10-06 14:30:00')`
      );
      const insertIa = db.prepare(
        `INSERT OR IGNORE INTO internal_assessment_marks (student_id, examination_id, subject_id, notebook_marks, unit_test_marks, practical_marks, participation_marks, status, entered_by, entered_via_component_id, submitted_by, submitted_at)
         VALUES (?, ?, ?, ?, ?, ?, ?, 'submitted', ?, ?, ?, '2025-10-06 14:30:00')`
      );

      students6B.forEach((st, idx) => {
        const meta = ecByCompId.get(st.component_id);
        if (!meta) return;
        const tid = teacherIdByCompCode[meta.comp_code] ?? null;
        const rawPct = 0.6 + ((idx * 17 + 29) % 34) / 100;
        const writtenScore = Math.min(80, Math.max(32, Math.round(80 * rawPct)));
        const nb = Math.min(5, 3 + (idx % 3));
        const ut = Math.min(5, 3 + ((idx + 1) % 3));
        const pr = Math.min(5, 3 + ((idx + 2) % 3));
        const op = Math.min(5, 3 + ((idx + 3) % 3));
        insertMark.run(st.id, hy.id, meta.ec_id, writtenScore, tid, tid);
        insertIa.run(st.id, hy.id, langSub.id, nb, ut, pr, op, tid, meta.ec_id, tid);
      });
    }

    db.prepare(`INSERT OR REPLACE INTO system_settings (key, value) VALUES ('language_elective_seeded', '1')`).run();
  })();
}

function ensureHindiLanguageOption() {
  const alreadySeeded = db
    .prepare(`SELECT value FROM system_settings WHERE key = 'hindi_lang_option_seeded_v1'`)
    .get() as { value: string } | undefined;
  if (alreadySeeded?.value === '1') return;

  db.transaction(() => {
    const langSub = db
      .prepare(
        `SELECT id, component_mode, has_components
         FROM subjects
         WHERE (upper(code) = 'LANG' OR lower(trim(name)) = 'language')
           AND COALESCE(is_deleted, 0) = 0
         ORDER BY id ASC
         LIMIT 1`
      )
      .get() as { id: number; component_mode: string; has_components: number } | undefined;

    if (!langSub) return;

    let compRow = db
      .prepare(
        `SELECT id, name, code, default_max_marks
         FROM subject_components
         WHERE subject_id = ?
           AND (upper(trim(code)) = 'HINL' OR lower(replace(trim(name), ' ', '')) = 'hindi(lang)')
         LIMIT 1`
      )
      .get(langSub.id) as
      | { id: number; name: string; code: string; default_max_marks: number }
      | undefined;

    if (!compRow) {
      const sibling = db
        .prepare(
          `SELECT default_max_marks FROM subject_components WHERE subject_id = ? ORDER BY display_order ASC, id ASC LIMIT 1`
        )
        .get(langSub.id) as { default_max_marks: number } | undefined;
      const ordRow = db
        .prepare(`SELECT COALESCE(MAX(display_order), 0) + 1 as ord FROM subject_components WHERE subject_id = ?`)
        .get(langSub.id) as { ord: number };
      const defaultMax = Number(sibling?.default_max_marks ?? 80);

      const info = db
        .prepare(
          `INSERT INTO subject_components (subject_id, name, code, default_max_marks, display_order)
           VALUES (?, 'Hindi(Lang)', 'HINL', ?, ?)`
        )
        .run(langSub.id, defaultMax, ordRow.ord);

      compRow = {
        id: Number(info.lastInsertRowid),
        name: 'Hindi(Lang)',
        code: 'HINL',
        default_max_marks: defaultMax,
      };
    }

    if (langSub.component_mode !== 'elective' || !langSub.has_components) {
      db.prepare(`UPDATE subjects SET has_components = 1, component_mode = 'elective' WHERE id = ?`).run(langSub.id);
    }

    const examSubs = db
      .prepare(`SELECT id as es_id, examination_id FROM examination_subjects WHERE subject_id = ?`)
      .all(langSub.id) as Array<{ es_id: number; examination_id: number }>;

    const findSiblingExamComp = db.prepare(
      `SELECT max_marks, passing_marks
       FROM examination_components
       WHERE examination_subject_id = ?
       ORDER BY display_order ASC, id ASC
       LIMIT 1`
    );
    const findMaxOrder = db.prepare(
      `SELECT COALESCE(MAX(display_order), 0) + 1 as ord
       FROM examination_components
       WHERE examination_subject_id = ?`
    );
    const insertExamComp = db.prepare(
      `INSERT OR IGNORE INTO examination_components
       (examination_id, examination_subject_id, subject_id, component_id, component_name, max_marks, passing_marks, display_order)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?)`
    );

    for (const es of examSubs) {
      const sib = findSiblingExamComp.get(es.es_id) as { max_marks: number; passing_marks: number } | undefined;
      const ord = (findMaxOrder.get(es.es_id) as { ord: number }).ord;
      const maxMarks = Number(sib?.max_marks ?? compRow.default_max_marks);
      const passingMarks = Number(sib?.passing_marks ?? Math.round(maxMarks * 0.33));
      insertExamComp.run(es.examination_id, es.es_id, langSub.id, compRow.id, compRow.name, maxMarks, passingMarks, ord);
    }

    db.prepare(`INSERT OR REPLACE INTO system_settings (key, value) VALUES ('hindi_lang_option_seeded_v1', '1')`).run();
  })();
}

function ensureAcademicYearsAndHistory() {
  const currentYearRow = db
    .prepare(`SELECT value FROM system_settings WHERE key = 'current_academic_year'`)
    .get() as { value: string } | undefined;
  const currentYear = currentYearRow?.value || '2025-26';

  db.transaction(() => {
    // 1. Register current year and any years already present in tables
    db.prepare(`INSERT OR IGNORE INTO academic_years (name, is_current) VALUES (?, 1)`).run(currentYear);
    db.prepare(`UPDATE academic_years SET is_current = CASE WHEN name = ? THEN 1 ELSE 0 END`).run(currentYear);

    const knownYears = db
      .prepare(
        `SELECT DISTINCT academic_year as yr FROM students WHERE academic_year IS NOT NULL AND academic_year != ''
         UNION
         SELECT DISTINCT academic_year as yr FROM examinations WHERE academic_year IS NOT NULL AND academic_year != ''
         UNION
         SELECT DISTINCT academic_year as yr FROM teacher_assignments WHERE academic_year IS NOT NULL AND academic_year != ''
         UNION
         SELECT DISTINCT academic_year as yr FROM class_teacher_assignments WHERE academic_year IS NOT NULL AND academic_year != ''`
      )
      .all() as Array<{ yr: string }>;

    for (const y of knownYears) {
      db.prepare(`INSERT OR IGNORE INTO academic_years (name, is_current) VALUES (?, ?)`).run(
        y.yr,
        y.yr === currentYear ? 1 : 0
      );
    }

    // 2. One-time backfill of student_enrollments & student_year_electives from legacy students table
    const enrMigrated = db
      .prepare(`SELECT value FROM system_settings WHERE key = 'enrollments_backfilled_v1'`)
      .get() as { value: string } | undefined;
    if (enrMigrated?.value !== '1') {
      db.exec(`
        INSERT OR IGNORE INTO student_enrollments (student_id, academic_year, class_id, section_id, roll_number, status)
        SELECT id, academic_year, class_id, section_id, roll_number, status FROM students;

        INSERT OR IGNORE INTO student_year_electives (student_id, academic_year, subject_id, component_id)
        SELECT se.student_id, st.academic_year, se.subject_id, se.component_id
        FROM student_electives se
        JOIN students st ON st.id = se.student_id;
      `);
      db.prepare(`INSERT OR REPLACE INTO system_settings (key, value) VALUES ('enrollments_backfilled_v1', '1')`).run();
    }
  })();

  // 3. Seed archived 2024-25 historical academic year once so administrators can browse prior year results immediately
  const histSeeded = db
    .prepare(`SELECT value FROM system_settings WHERE key = 'historical_ay_2024_25_seeded'`)
    .get() as { value: string } | undefined;
  if (histSeeded?.value === '1') return;

  db.transaction(() => {
    const histYear = '2024-25';
    db.prepare(`INSERT OR IGNORE INTO academic_years (name, is_current) VALUES (?, 0)`).run(histYear);

    const classes = db
      .prepare(`SELECT id, name, numeric_order FROM classes ORDER BY numeric_order ASC`)
      .all() as Array<{ id: number; name: string; numeric_order: number }>;
    const classByOrder = new Map<number, number>();
    for (const c of classes) classByOrder.set(c.numeric_order, c.id);

    const sections = db
      .prepare(`SELECT id, class_id, name FROM sections`)
      .all() as Array<{ id: number; class_id: number; name: string }>;
    const secIdLookup = new Map<string, number>();
    const secNameById = new Map<number, string>();
    for (const s of sections) {
      secIdLookup.set(`${s.class_id}:${s.name}`, s.id);
      secNameById.set(s.id, s.name);
    }

    // Map current 2025-26 Class 7, 8, 9 students back to their previous year (2024-25) Class 6, 7, 8 enrollments
    const currentEnrollments = db
      .prepare(
        `SELECT se.student_id, se.class_id, se.section_id, se.roll_number, se.status, c.numeric_order
         FROM student_enrollments se
         JOIN classes c ON c.id = se.class_id
         WHERE se.academic_year = ? AND se.status = 'active'`
      )
      .all(currentYear) as Array<{
      student_id: number;
      class_id: number;
      section_id: number;
      roll_number: number;
      status: string;
      numeric_order: number;
    }>;

    const insertEnrollment = db.prepare(
      `INSERT OR IGNORE INTO student_enrollments (student_id, academic_year, class_id, section_id, roll_number, status)
       VALUES (?, ?, ?, ?, ?, 'active')`
    );

    for (const row of currentEnrollments) {
      const prevOrder = row.numeric_order - 1;
      const prevClassId = classByOrder.get(prevOrder);
      if (!prevClassId) continue;
      const secName = secNameById.get(row.section_id) || 'A';
      const prevSectionId = secIdLookup.get(`${prevClassId}:${secName}`) ?? row.section_id;
      insertEnrollment.run(row.student_id, histYear, prevClassId, prevSectionId, row.roll_number);
    }

    // Copy electives for 2024-25 enrolled students
    db.prepare(
      `INSERT OR IGNORE INTO student_year_electives (student_id, academic_year, subject_id, component_id)
       SELECT se.student_id, ?, sye.subject_id, sye.component_id
       FROM student_enrollments se
       JOIN student_year_electives sye ON sye.student_id = se.student_id AND sye.academic_year = ?
       WHERE se.academic_year = ?`
    ).run(histYear, currentYear, histYear);

    // Preserve teacher & class-teacher assignments for 2024-25
    db.prepare(
      `INSERT OR IGNORE INTO teacher_assignments (teacher_id, subject_id, component_id, class_id, section_id, academic_year)
       SELECT teacher_id, subject_id, component_id, class_id, section_id, ?
       FROM teacher_assignments
       WHERE academic_year = ?`
    ).run(histYear, currentYear);

    db.prepare(
      `INSERT OR IGNORE INTO class_teacher_assignments (teacher_id, class_id, section_id, academic_year)
       SELECT teacher_id, class_id, section_id, ?
       FROM class_teacher_assignments
       WHERE academic_year = ?`
    ).run(histYear, currentYear);

    // Create a Published historical examination for 2024-25 if none exists
    const existingHistExam = db
      .prepare(`SELECT id FROM examinations WHERE academic_year = ? LIMIT 1`)
      .get(histYear) as { id: number } | undefined;

    if (!existingHistExam) {
      const examInfo = db
        .prepare(
          `INSERT INTO examinations (name, academic_year, start_date, end_date, status, marks_entry_open, passing_percentage)
           VALUES ('Annual Examination', ?, '2025-03-03', '2025-03-14', 'Published', 0, 33)`
        )
        .run(histYear);
      const histExamId = Number(examInfo.lastInsertRowid);

      const activeSubjects = db
        .prepare(`SELECT * FROM subjects WHERE is_active = 1 ORDER BY display_order ASC, id ASC`)
        .all() as Array<any>;

      for (let sIdx = 0; sIdx < activeSubjects.length; sIdx++) {
        const sub = activeSubjects[sIdx];
        const comps = db
          .prepare(`SELECT * FROM subject_components WHERE subject_id = ? ORDER BY display_order ASC, id ASC`)
          .all(sub.id) as Array<any>;
        const hasIa = Boolean(sub.has_internal_assessment) ? 1 : 0;
        const nbMax = hasIa ? Number(sub.ia_notebook_max ?? 5) : 0;
        const utMax = hasIa ? Number(sub.ia_unit_test_max ?? 5) : 0;
        const prMax = hasIa ? Number(sub.ia_practical_max ?? 5) : 0;
        const opMax = hasIa ? Number(sub.ia_participation_max ?? 5) : 0;
        const writtenMax =
          sub.component_mode === 'elective'
            ? Number(comps[0]?.default_max_marks ?? 80)
            : comps.reduce((sum, c) => sum + Number(c.default_max_marks || 0), 0);
        const totalMax = writtenMax + nbMax + utMax + prMax + opMax;
        const passMarks = Math.round(totalMax * 0.33);

        const esInfo = db
          .prepare(
            `INSERT INTO examination_subjects (examination_id, subject_id, max_marks, passing_marks, has_internal_assessment, ia_notebook_max, ia_unit_test_max, ia_practical_max, ia_participation_max, is_required, display_order)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 1, ?)`
          )
          .run(histExamId, sub.id, totalMax, passMarks, hasIa, nbMax, utMax, prMax, opMax, sIdx + 1);
        const esId = Number(esInfo.lastInsertRowid);

        comps.forEach((c, cIdx) => {
          db.prepare(
            `INSERT INTO examination_components (examination_id, examination_subject_id, subject_id, component_id, component_name, max_marks, passing_marks, display_order)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?)`
          ).run(
            histExamId,
            esId,
            sub.id,
            c.id,
            c.name,
            Number(c.default_max_marks),
            Math.round(Number(c.default_max_marks) * 0.33),
            cIdx + 1
          );
        });
      }

      // Seed complete published marks for 2024-25 Class 6 Section A and Class 6 Section B
      const class6Id = classByOrder.get(6);
      if (class6Id) {
        const examSubs = db
          .prepare(
            `SELECT es.id as es_id, es.subject_id, es.has_internal_assessment, es.ia_notebook_max, es.ia_unit_test_max, es.ia_practical_max, es.ia_participation_max, s.component_mode
             FROM examination_subjects es
             JOIN subjects s ON s.id = es.subject_id
             WHERE es.examination_id = ?`
          )
          .all(histExamId) as Array<any>;
        const examComps = db
          .prepare(
            `SELECT id as ec_id, examination_subject_id, subject_id, component_id, max_marks
             FROM examination_components WHERE examination_id = ? ORDER BY display_order ASC`
          )
          .all(histExamId) as Array<any>;

        const insertMark = db.prepare(
          `INSERT OR IGNORE INTO marks (student_id, examination_id, examination_component_id, obtained_marks, status, entered_by, submitted_by, submitted_at)
           VALUES (?, ?, ?, ?, 'submitted', ?, ?, '2025-03-18 15:00:00')`
        );
        const insertIa = db.prepare(
          `INSERT OR IGNORE INTO internal_assessment_marks (student_id, examination_id, subject_id, notebook_marks, unit_test_marks, practical_marks, participation_marks, status, entered_by, entered_via_component_id, submitted_by, submitted_at)
           VALUES (?, ?, ?, ?, ?, ?, ?, 'submitted', ?, ?, ?, '2025-03-18 15:00:00')`
        );
        const getTeacher = db.prepare(
          `SELECT teacher_id FROM teacher_assignments WHERE component_id = ? AND class_id = ? AND section_id = ? AND academic_year = ? LIMIT 1`
        );
        const getElective = db.prepare(
          `SELECT component_id FROM student_year_electives WHERE student_id = ? AND academic_year = ? AND subject_id = ?`
        );

        for (const secName of ['A', 'B']) {
          const secId = secIdLookup.get(`${class6Id}:${secName}`);
          if (!secId) continue;

          const cohort = db
            .prepare(
              `SELECT student_id, roll_number FROM student_enrollments
               WHERE academic_year = ? AND class_id = ? AND section_id = ? AND status = 'active'
               ORDER BY roll_number ASC`
            )
            .all(histYear, class6Id, secId) as Array<{ student_id: number; roll_number: number }>;

          cohort.forEach((st, idx) => {
            examSubs.forEach((es, sIdx) => {
              const comps = examComps.filter((c) => c.examination_subject_id === es.es_id);
              let lastTeacherId: number | null = null;
              let lastEcId: number | null = null;

              if (es.component_mode === 'elective') {
                const elRow = getElective.get(st.student_id, histYear, es.subject_id) as { component_id: number } | undefined;
                const chosenComp = (elRow && comps.find((c) => c.component_id === elRow.component_id)) || comps[0];
                if (chosenComp) {
                  const tRow = getTeacher.get(chosenComp.component_id, class6Id, secId, histYear) as { teacher_id: number } | undefined;
                  const pct = 0.56 + ((idx * 13 + sIdx * 7 + (secName === 'A' ? 5 : 11)) % 39) / 100;
                  const score = Math.min(chosenComp.max_marks, Math.max(10, Math.round(chosenComp.max_marks * pct)));
                  insertMark.run(st.student_id, histExamId, chosenComp.ec_id, score, tRow?.teacher_id ?? null, tRow?.teacher_id ?? null);
                  lastTeacherId = tRow?.teacher_id ?? null;
                  lastEcId = chosenComp.ec_id;
                }
              } else {
                comps.forEach((c, cIdx) => {
                  const tRow = getTeacher.get(c.component_id, class6Id, secId, histYear) as { teacher_id: number } | undefined;
                  const pct = 0.54 + ((idx * 11 + sIdx * 7 + cIdx * 5 + (secName === 'B' ? 4 : 0)) % 41) / 100;
                  const score = Math.min(c.max_marks, Math.max(8, Math.round(c.max_marks * pct)));
                  insertMark.run(st.student_id, histExamId, c.ec_id, score, tRow?.teacher_id ?? null, tRow?.teacher_id ?? null);
                  lastTeacherId = tRow?.teacher_id ?? null;
                  lastEcId = c.ec_id;
                });
              }

              if (es.has_internal_assessment && lastEcId) {
                const nb = Math.min(es.ia_notebook_max, Math.max(2, Math.round(es.ia_notebook_max * (0.65 + ((idx + sIdx) % 4) * 0.1))));
                const ut = Math.min(es.ia_unit_test_max, Math.max(2, Math.round(es.ia_unit_test_max * (0.6 + ((idx * 2 + sIdx) % 4) * 0.1))));
                const pr = Math.min(es.ia_practical_max, Math.max(2, Math.round(es.ia_practical_max * (0.65 + ((idx + sIdx * 2) % 4) * 0.1))));
                const op =
                  es.ia_participation_max > 0
                    ? Math.min(es.ia_participation_max, Math.max(2, Math.round(es.ia_participation_max * (0.6 + ((idx + sIdx * 3) % 4) * 0.1))))
                    : 0;
                insertIa.run(st.student_id, histExamId, es.subject_id, nb, ut, pr, op, lastTeacherId, lastEcId, lastTeacherId);
              }
            });
          });
        }
      }
    }

    db.prepare(`INSERT OR REPLACE INTO system_settings (key, value) VALUES ('historical_ay_2024_25_seeded', '1')`).run();
  })();
}

function ensureIaParticipationMigration() {
  const migrated = db
    .prepare(`SELECT value FROM system_settings WHERE key = 'ia_participation_migrated'`)
    .get() as { value: string } | undefined;
  if (migrated?.value === '1') return;

  db.transaction(() => {
    // 1. Convert subjects with 5/5/10 IA breakdown to 5/5/5/5 (Notebook 5, Unit Test 5, Practical/Proj 5, Overall Participation 5)
    db.exec(`
      UPDATE subjects
      SET ia_practical_max = 5, ia_participation_max = 5
      WHERE has_internal_assessment = 1 AND ia_practical_max = 10 AND ia_participation_max = 0;

      UPDATE examination_subjects
      SET ia_practical_max = 5, ia_participation_max = 5
      WHERE has_internal_assessment = 1 AND ia_practical_max = 10 AND ia_participation_max = 0;
    `);

    // 2. Migrate existing internal_assessment_marks rows without participation_marks
    const iaRows = db
      .prepare(
        `SELECT ia.id, ia.practical_marks, ia.participation_marks, es.ia_practical_max, es.ia_participation_max
         FROM internal_assessment_marks ia
         JOIN examination_subjects es ON es.examination_id = ia.examination_id AND es.subject_id = ia.subject_id
         WHERE ia.participation_marks IS NULL`
      )
      .all() as Array<{
      id: number;
      practical_marks: number | null;
      participation_marks: number | null;
      ia_practical_max: number;
      ia_participation_max: number;
    }>;

    const updateIaRow = db.prepare(
      `UPDATE internal_assessment_marks SET practical_marks = ?, participation_marks = ? WHERE id = ?`
    );

    for (const r of iaRows) {
      if (r.practical_marks === null) continue;
      if (r.ia_participation_max > 0) {
        const oldPr = Number(r.practical_marks);
        const newPr = Math.min(Number(r.ia_practical_max || 5), Math.ceil(oldPr / 2));
        const newOp = Math.min(
          Number(r.ia_participation_max || 5),
          Math.max(0, Number((oldPr - newPr).toFixed(2)))
        );
        updateIaRow.run(newPr, newOp, r.id);
      } else {
        updateIaRow.run(r.practical_marks, 0, r.id);
      }
    }

    db.prepare(`INSERT OR REPLACE INTO system_settings (key, value) VALUES ('ia_participation_migrated', '1')`).run();
  })();
}

function ensureAttendanceAndIaSubStatuses() {
  const attMigrated = db
    .prepare(`SELECT value FROM system_settings WHERE key = 'attendance_status_migrated'`)
    .get() as { value: string } | undefined;
  if (attMigrated?.value !== '1') {
    db.transaction(() => {
      db.exec(`
        UPDATE marks
        SET attendance_status = 'present'
        WHERE obtained_marks IS NOT NULL AND attendance_status = 'pending';
      `);
      db.prepare(`INSERT OR REPLACE INTO system_settings (key, value) VALUES ('attendance_status_migrated', '1')`).run();
    })();
  }

  const iaSubMigrated = db
    .prepare(`SELECT value FROM system_settings WHERE key = 'ia_subcomponent_status_migrated'`)
    .get() as { value: string } | undefined;
  if (iaSubMigrated?.value !== '1') {
    db.transaction(() => {
      db.exec(`
        UPDATE internal_assessment_marks
        SET
          nb_status = CASE WHEN notebook_marks IS NOT NULL THEN status ELSE 'pending' END,
          nb_by = CASE WHEN notebook_marks IS NOT NULL THEN COALESCE(submitted_by, entered_by) ELSE NULL END,
          ut_status = CASE WHEN unit_test_marks IS NOT NULL THEN status ELSE 'pending' END,
          ut_by = CASE WHEN unit_test_marks IS NOT NULL THEN COALESCE(submitted_by, entered_by) ELSE NULL END,
          pr_status = CASE WHEN practical_marks IS NOT NULL THEN status ELSE 'pending' END,
          pr_by = CASE WHEN practical_marks IS NOT NULL THEN COALESCE(submitted_by, entered_by) ELSE NULL END,
          op_status = CASE WHEN participation_marks IS NOT NULL THEN status ELSE 'pending' END,
          op_by = CASE WHEN participation_marks IS NOT NULL THEN COALESCE(submitted_by, entered_by) ELSE NULL END;
      `);
      db.prepare(`INSERT OR REPLACE INTO system_settings (key, value) VALUES ('ia_subcomponent_status_migrated', '1')`).run();
    })();
  }
}

export const DEFAULT_PORTAL_SECTIONS = [
  { id: 'overview', label: 'Dashboard Analytics', description: 'Live institutional overview and visual analytics', enabled: true, order: 1 },
  { id: 'students', label: 'Manage Students', description: 'Student directory, enrollments, electives, and transfers', enabled: true, order: 2 },
  { id: 'users', label: 'Teachers & Users', description: 'Teacher and administrator accounts', enabled: true, order: 3 },
  { id: 'classes-subjects', label: 'Classes & Subjects', description: 'Classes, sections, subjects, and components', enabled: true, order: 4 },
  { id: 'teacher-assignments', label: 'Teacher Assignments', description: 'Subject, IA component, and class teacher mappings', enabled: true, order: 5 },
  { id: 'examinations', label: 'Examinations', description: 'Exam cycles, types, passing criteria, and entry windows', enabled: true, order: 6 },
  { id: 'monitoring', label: 'Submission Monitor', description: 'Real-time marks completion and correction approvals', enabled: true, order: 7 },
  { id: 'results', label: 'Results & Reports', description: 'Consolidated class sheets and student report cards', enabled: true, order: 8 },
  { id: 'audit-logs', label: 'Audit Logs', description: 'Administrative and marks entry activity records', enabled: true, order: 9 },
  { id: 'settings', label: 'Website & System Settings', description: 'Branding, logo, theme colors, sections, and backup', enabled: true, order: 10 },
];

export const DEFAULT_THEME_CONFIG = {
  primaryColor: '#1E3A5F',
  accentColor: '#0284C7',
  secondaryColor: '#10B981',
  headerBg: '#FFFFFF',
};

export const DEFAULT_SITE_CONTENT = {
  portalTitle: 'Examination & Marks Portal',
  portalSubtitle: 'EMRS Gangyap',
  loginHeading: 'Portal Sign In',
  loginButtonLabel: 'Sign In',
  reportCardTitle: 'Statement of Marks',
  reportCardFooterLeft: 'Class Teacher',
  reportCardFooterCenter: 'Controller of Examinations',
  reportCardFooterRight: 'Principal',
};

export const DEFAULT_EXAM_TYPES = ['Unit Test', 'Periodic Test', 'Half-Yearly', 'Pre-Board', 'Annual'];

function ensureBrandingAndPortalDefaults() {
  db.transaction(() => {
    const emrsMigrated = db
      .prepare(`SELECT value FROM system_settings WHERE key = 'emrs_gangyap_migrated'`)
      .get() as { value: string } | undefined;

    if (emrsMigrated?.value !== '1') {
      const nameRow = db.prepare(`SELECT value FROM system_settings WHERE key = 'school_name'`).get() as { value: string } | undefined;
      if (!nameRow || nameRow.value === "St. Xavier's Academy" || !nameRow.value.trim()) {
        db.prepare(`INSERT INTO system_settings (key, value) VALUES ('school_name', 'EMRS Gangyap') ON CONFLICT(key) DO UPDATE SET value = 'EMRS Gangyap'`).run();
      }
      db.prepare(`INSERT OR REPLACE INTO system_settings (key, value) VALUES ('emrs_gangyap_migrated', '1')`).run();
    }

    const insertDefault = db.prepare(`INSERT OR IGNORE INTO system_settings (key, value) VALUES (?, ?)`);
    insertDefault.run('school_logo', '/assets/aistudio/logo_emrs_1d5c0342.jpg');
    insertDefault.run('theme_config', JSON.stringify(DEFAULT_THEME_CONFIG));
    insertDefault.run('site_content', JSON.stringify(DEFAULT_SITE_CONTENT));
    insertDefault.run('portal_sections', JSON.stringify(DEFAULT_PORTAL_SECTIONS));
    insertDefault.run('examination_types', JSON.stringify(DEFAULT_EXAM_TYPES));

    // One-time migration to set the official uploaded EMRS logo everywhere
    const officialLogoMigrated = db
      .prepare(`SELECT value FROM system_settings WHERE key = 'emrs_official_logo_migrated'`)
      .get() as { value: string } | undefined;
    if (officialLogoMigrated?.value !== '1') {
      db.prepare(
        `INSERT INTO system_settings (key, value) VALUES ('school_logo', '/assets/aistudio/logo_emrs_1d5c0342.jpg')
         ON CONFLICT(key) DO UPDATE SET value = '/assets/aistudio/logo_emrs_1d5c0342.jpg'`
      ).run();
      db.prepare(`INSERT OR REPLACE INTO system_settings (key, value) VALUES ('emrs_official_logo_migrated', '1')`).run();
    }

    // Migrate fragile legacy logo paths if encountered
    const currentLogo = db
      .prepare(`SELECT value FROM system_settings WHERE key = 'school_logo'`)
      .get() as { value: string } | undefined;
    if (
      currentLogo &&
      (currentLogo.value === '/school-emblem.jpg' ||
        currentLogo.value === 'school-emblem.jpg' ||
        currentLogo.value === '/src/assets/images/school_emblem_logo_1794585477262.jpg' ||
        currentLogo.value === 'src/assets/images/school_emblem_logo_1794585477262.jpg')
    ) {
      db.prepare(`UPDATE system_settings SET value = '/assets/aistudio/logo_emrs_1d5c0342.jpg' WHERE key = 'school_logo'`).run();
    }

    // One-time migration from legacy A+..F default grading scale to standardized A1..E scale
    const gradeMigrated = db
      .prepare(`SELECT value FROM system_settings WHERE key = 'grading_scale_a1_e_migrated'`)
      .get() as { value: string } | undefined;
    if (gradeMigrated?.value !== '1') {
      const standardScale = [
        { grade: 'A1', minPct: 91, maxPct: 100, remark: 'Outstanding' },
        { grade: 'A2', minPct: 81, maxPct: 90.99, remark: 'Excellent' },
        { grade: 'B1', minPct: 71, maxPct: 80.99, remark: 'Very Good' },
        { grade: 'B2', minPct: 61, maxPct: 70.99, remark: 'Good' },
        { grade: 'C1', minPct: 51, maxPct: 60.99, remark: 'Satisfactory' },
        { grade: 'C2', minPct: 41, maxPct: 50.99, remark: 'Acceptable' },
        { grade: 'D', minPct: 33, maxPct: 40.99, remark: 'Pass' },
        { grade: 'E', minPct: 0, maxPct: 32.99, remark: 'Needs Improvement' },
      ];
      db.prepare(
        `INSERT INTO system_settings (key, value) VALUES ('grading_scale', ?)
         ON CONFLICT(key) DO UPDATE SET value = excluded.value`
      ).run(JSON.stringify(standardScale));
      db.prepare(`INSERT OR REPLACE INTO system_settings (key, value) VALUES ('grading_scale_a1_e_migrated', '1')`).run();
    }
  })();
}
