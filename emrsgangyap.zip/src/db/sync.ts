import crypto from 'node:crypto';
import fs from 'node:fs';
import zlib from 'node:zlib';
import {
  checkpointWal,
  closeDatabase,
  getDatabasePath,
  initializeDatabase,
  reopenDatabase,
} from './database.ts';

export type StorageMode = 'local' | 'kv-synced' | 'ephemeral-serverless';

function getKvConfig(): { url: string; token: string } | null {
  const url = (
    process.env.KV_REST_API_URL ||
    process.env.UPSTASH_REDIS_REST_URL ||
    ''
  )
    .trim()
    .replace(/\/+$/, '');
  const token = (
    process.env.KV_REST_API_TOKEN ||
    process.env.UPSTASH_REDIS_REST_TOKEN ||
    ''
  ).trim();
  if (!url || !token) return null;
  return { url, token };
}

export function getStorageMode(): StorageMode {
  if (getKvConfig()) return 'kv-synced';
  if (process.env.VERCEL) return 'ephemeral-serverless';
  return 'local';
}

const PREFIX = (process.env.KV_DB_PREFIX || 'emrs_gangyap_portal').trim();
const VERSION_KEY = `${PREFIX}:db_version`;
const SNAPSHOT_KEY = `${PREFIX}:db_snapshot`;
const LOCK_KEY = `${PREFIX}:db_lock`;

let localSyncedVersion = 0;
let activeLockToken: string | null = null;
let initializedRemoteSchema = false;

// Serialize local file swaps/checkpoints within the current Node process
let processMutex: Promise<void> = Promise.resolve();
function withProcessLock<T>(fn: () => Promise<T>): Promise<T> {
  const prev = processMutex;
  let release!: () => void;
  processMutex = new Promise<void>((resolve) => {
    release = resolve;
  });
  return prev.then(fn).finally(release);
}

async function kvPipeline(commands: Array<Array<string | number>>): Promise<Array<{ result?: any; error?: string }>> {
  const cfg = getKvConfig();
  if (!cfg) return [];
  const res = await fetch(`${cfg.url}/pipeline`, {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${cfg.token}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify(commands),
  });
  if (!res.ok) {
    const text = await res.text().catch(() => '');
    throw new Error(`KV REST error (${res.status}): ${text || res.statusText}`);
  }
  const data = (await res.json()) as Array<{ result?: any; error?: string }>;
  return Array.isArray(data) ? data : [];
}

async function acquireDistributedLock(timeoutMs = 3000): Promise<void> {
  const cfg = getKvConfig();
  if (!cfg) return;
  const token = crypto.randomUUID();
  const deadline = Date.now() + timeoutMs;
  while (Date.now() < deadline) {
    const res = await kvPipeline([['SET', LOCK_KEY, token, 'NX', 'PX', 8000]]);
    if (res[0]?.result === 'OK') {
      activeLockToken = token;
      return;
    }
    await new Promise((r) => setTimeout(r, 60));
  }
}

export async function releaseMutationLock(): Promise<void> {
  if (!activeLockToken) return;
  const token = activeLockToken;
  activeLockToken = null;
  try {
    const cur = await kvPipeline([['GET', LOCK_KEY]]);
    if (cur[0]?.result === token) {
      await kvPipeline([['DEL', LOCK_KEY]]);
    }
  } catch {
    // TTL guarantees cleanup even if release fails
  }
}

export async function syncDbBeforeRequest(isMutation: boolean): Promise<void> {
  if (getStorageMode() !== 'kv-synced') return;

  await withProcessLock(async () => {
    if (isMutation) {
      await acquireDistributedLock();
    }

    const verRes = await kvPipeline([['GET', VERSION_KEY]]);
    const remoteVersion = Number(verRes[0]?.result || 0);

    if (remoteVersion > localSyncedVersion) {
      const snapRes = await kvPipeline([['GET', SNAPSHOT_KEY]]);
      const b64 = snapRes[0]?.result;
      if (typeof b64 === 'string' && b64.length > 0) {
        const compressed = Buffer.from(b64, 'base64');
        const rawDb = zlib.gunzipSync(compressed);
        const dbPath = getDatabasePath();
        const tmpPath = `${dbPath}.incoming.${process.pid}`;

        closeDatabase();
        try {
          fs.writeFileSync(tmpPath, rawDb);
          for (const suffix of ['-wal', '-shm']) {
            const sidecar = `${dbPath}${suffix}`;
            if (fs.existsSync(sidecar)) {
              try {
                fs.unlinkSync(sidecar);
              } catch {
                // ignore
              }
            }
          }
          fs.renameSync(tmpPath, dbPath);
        } finally {
          reopenDatabase();
        }
        if (!initializedRemoteSchema) {
          initializeDatabase();
          initializedRemoteSchema = true;
        }
        localSyncedVersion = remoteVersion;
      }
    }
  });
}

export async function pushDbAfterMutation(): Promise<void> {
  if (getStorageMode() !== 'kv-synced') return;

  await withProcessLock(async () => {
    checkpointWal('TRUNCATE');
    const dbPath = getDatabasePath();
    if (!fs.existsSync(dbPath)) return;
    const raw = fs.readFileSync(dbPath);
    const compressed = zlib.gzipSync(raw, { level: 6 });
    const b64 = compressed.toString('base64');
    const res = await kvPipeline([
      ['SET', SNAPSHOT_KEY, b64],
      ['INCR', VERSION_KEY],
    ]);
    const nextVer = Number(res[1]?.result || localSyncedVersion + 1);
    if (Number.isFinite(nextVer) && nextVer > 0) {
      localSyncedVersion = nextVer;
    } else {
      localSyncedVersion += 1;
    }
  });
}
