export interface AuthUser {
  id: number;
  username: string;
  fullName: string;
  email: string;
  employeeCode: string;
  roles: string[];
  mustChangePassword: boolean;
  isSubjectTeacher: boolean;
  isClassTeacher: boolean;
}

export interface GradeRule {
  grade: string;
  minPct: number;
  maxPct: number;
  remark: string;
}

export interface SectionInfo {
  id: number;
  class_id: number;
  name: string;
  capacity: number;
  student_count?: number;
  isDeleted?: boolean;
  deleted_at?: string | null;
}

export interface ClassInfo {
  id: number;
  name: string;
  numeric_order: number;
  hasSections: boolean;
  is_active: number;
  isDeleted?: boolean;
  deleted_at?: string | null;
  sections: SectionInfo[];
}

export interface AcademicYearSummary {
  name: string;
  isCurrent: boolean;
  isDeleted?: boolean;
  deletedAt?: string | null;
  studentCount: number;
  graduatedCount?: number;
  examCount: number;
  assignmentCount: number;
  classTeacherCount?: number;
}

export type AttendanceStatus = 'present' | 'absent' | 'pending';
export type IaComponentKey = 'notebook' | 'unit_test' | 'practical' | 'participation';
export type StudentStream = '' | 'Science' | 'Humanities';
export type SubjectStreamCategory = '' | 'Common' | 'Science' | 'Humanities' | 'Language';

export interface ThemeConfig {
  primaryColor: string;
  accentColor: string;
  secondaryColor: string;
  headerBg: string;
}

export interface SiteContent {
  portalTitle: string;
  portalSubtitle: string;
  loginHeading: string;
  loginButtonLabel: string;
  reportCardTitle: string;
  reportCardFooterLeft: string;
  reportCardFooterCenter: string;
  reportCardFooterRight: string;
}

export interface PortalSectionConfig {
  id: string;
  label: string;
  description: string;
  enabled: boolean;
  order: number;
  custom?: boolean;
  customHeading?: string;
  customBody?: string;
}

export interface SchoolInfo {
  schoolName: string;
  schoolAddress: string;
  schoolMotto: string;
  schoolLogo: string;
  currentAcademicYear: string;
  defaultPassPercentage: number;
  gradingScale: GradeRule[];
  themeConfig: ThemeConfig;
  siteContent: SiteContent;
  portalSections: PortalSectionConfig[];
  examinationTypes: string[];
  classes: ClassInfo[];
  academicYears: AcademicYearSummary[];
  storageMode?: 'local' | 'kv-synced' | 'ephemeral-serverless';
}

export type ComponentMode = 'single' | 'combined' | 'elective';

export interface StudentElective {
  subjectId: number;
  subjectName: string;
  componentId: number;
  componentName: string;
}

export interface StudentRecord {
  id: number;
  student_code: string;
  full_name: string;
  roll_number: number;
  class_id: number;
  class_name: string;
  hasSections?: boolean;
  section_id: number;
  section_name: string;
  academic_year: string;
  stream?: StudentStream;
  gender: string;
  guardian_name: string;
  guardian_phone: string;
  father_name?: string;
  mother_name?: string;
  residential_address?: string;
  contact_no?: string;
  aapaar_id?: string;
  photo_url?: string;
  status: 'active' | 'transferred' | 'inactive' | 'promoted' | 'graduated' | 'archived';
  isDeleted?: boolean;
  deleted_at?: string | null;
  marksCount?: number;
  electives?: StudentElective[];
  enrolledSubjectIds?: number[];
  electiveOptOutSubjectIds?: number[];
}

export interface SubjectComponent {
  id: number;
  subject_id: number;
  name: string;
  code: string;
  default_max_marks: number;
  display_order: number;
}

export interface SubjectRecord {
  id: number;
  code: string;
  name: string;
  default_max_marks: number;
  hasComponents: boolean;
  componentMode: ComponentMode;
  hasInternalAssessment: boolean;
  hasPractical?: boolean;
  streamCategory?: SubjectStreamCategory;
  applicableClassIds?: number[];
  iaNotebookMax: number;
  iaUnitTestMax: number;
  iaPracticalMax: number;
  iaParticipationMax: number;
  display_order: number;
  is_active: number;
  isDeleted?: boolean;
  deleted_at?: string | null;
  components: SubjectComponent[];
}

export interface ExaminationComponent {
  id: number;
  examination_id: number;
  examination_subject_id: number;
  subject_id: number;
  component_id: number;
  component_name: string;
  max_marks: number;
  passing_marks: number;
  display_order: number;
}

export interface ExaminationSubject {
  id: number;
  examination_id: number;
  subject_id: number;
  subject_name: string;
  subject_code: string;
  has_components: number;
  componentMode: ComponentMode;
  hasInternalAssessment: boolean;
  hasPractical?: boolean;
  streamCategory?: SubjectStreamCategory;
  targetClassIds?: number[];
  iaNotebookMax: number;
  iaUnitTestMax: number;
  iaPracticalMax: number;
  iaParticipationMax: number;
  writtenMaxMarks: number;
  iaMaxMarks: number;
  max_marks: number;
  passing_marks: number;
  is_required: number;
  display_order: number;
  components: ExaminationComponent[];
}

export interface ExaminationRecord {
  id: number;
  name: string;
  exam_type?: string;
  academic_year: string;
  start_date: string;
  end_date: string;
  status: 'Upcoming' | 'Active' | 'Completed' | 'Published';
  marksEntryOpen: boolean;
  isDeleted?: boolean;
  deleted_at?: string | null;
  passing_percentage: number;
  subjects: ExaminationSubject[];
}

export interface TeacherAssignment {
  id: number;
  teacher_id: number;
  teacher_name: string;
  username: string;
  subject_id: number;
  subject_name: string;
  subject_code?: string;
  has_components: number;
  component_id: number;
  component_name: string;
  class_id: number;
  class_name: string;
  hasSections?: boolean;
  section_id: number;
  section_name: string;
  academic_year: string;
}

export interface ClassTeacherAssignment {
  id: number;
  teacher_id: number;
  teacher_name: string;
  username: string;
  class_id: number;
  class_name: string;
  hasSections?: boolean;
  section_id: number;
  section_name: string;
  academic_year: string;
}

export interface TeacherAssignmentSummary {
  id: number;
  teacher_id: number;
  subject_id: number;
  subject_name: string;
  subject_code: string;
  component_id: number;
  component_name: string;
  class_id: number;
  class_name: string;
  hasSections?: boolean;
  numeric_order: number;
  section_id: number;
  section_name: string;
  academic_year: string;
}

export interface ClassTeacherAssignmentSummary {
  id: number;
  teacher_id: number;
  class_id: number;
  class_name: string;
  hasSections?: boolean;
  section_id: number;
  section_name: string;
  academic_year: string;
}

export interface UserRecord {
  id: number;
  username: string;
  full_name: string;
  email: string;
  employee_code: string;
  is_active: number;
  isActive: boolean;
  isDeleted: boolean;
  deleted_at?: string | null;
  mustChangePassword: boolean;
  created_at: string;
  roles: string[];
  subjectAssignmentCount: number;
  assignments: TeacherAssignmentSummary[];
  assignedSubjects: string[];
  assignedClasses: string[];
  assignedSections: string[];
  classTeacherAssignments: ClassTeacherAssignmentSummary[];
  classTeacherSections: string[];
  submittedMarksCount: number;
}

export interface TeacherProfileResponse {
  id: number;
  username: string;
  full_name: string;
  email: string;
  employee_code: string;
  isActive: boolean;
  isDeleted: boolean;
  deleted_at: string | null;
  mustChangePassword: boolean;
  created_at: string;
  updated_at: string;
  roles: string[];
  assignments: TeacherAssignmentSummary[];
  classTeacherAssignments: ClassTeacherAssignmentSummary[];
  marksStats: {
    total_rows: number;
    submitted_rows: number;
    last_activity_at: string | null;
  };
  recentLogs: Array<{
    id: number;
    action: string;
    entity_type: string;
    entity_id: string;
    details_json: string;
    created_at: string;
  }>;
}

export interface BulkActionResponse {
  success: boolean;
  action: string;
  affectedCount: number;
  records?: Array<{ id: number; [key: string]: any }>;
}

export interface MonitoringRow {
  examinationId: number;
  examinationName: string;
  classId: number;
  className: string;
  hasSections?: boolean;
  sectionId: number;
  sectionName: string;
  subjectId: number;
  subjectName: string;
  examComponentId: number;
  componentId: number;
  componentName: string;
  maxMarks: number;
  teacherId: number | null;
  teacherName: string | null;
  totalStudents: number;
  enteredCount: number;
  presentCount?: number;
  absentCount?: number;
  submittedCount: number;
  draftCount: number;
  missingCount: number;
  submissionStatus: 'Submitted' | 'Draft' | 'Pending';
  hasInternalAssessment: boolean;
  iaStatus: 'Submitted' | 'Draft' | 'Pending' | 'N/A';
  lastUpdatedAt: string | null;
}

export interface ConsolidatedComponentResult {
  examComponentId: number;
  componentId: number;
  componentName: string;
  maxMarks: number;
  passingMarks: number;
  obtainedMarks: number | null;
  attendanceStatus: AttendanceStatus;
  status: 'submitted' | 'draft' | 'pending';
}

export interface ConsolidatedSubjectResult {
  examSubjectId: number;
  subjectId: number;
  subjectCode: string;
  subjectName: string;
  hasComponents: boolean;
  componentMode: ComponentMode;
  selectedComponentName?: string | null;
  hasInternalAssessment: boolean;
  hasPractical?: boolean;
  streamCategory?: SubjectStreamCategory;
  isEnrolled?: boolean;
  writtenMaxMarks: number;
  writtenObtainedMarks: number | null;
  iaNotebookMax: number;
  iaUnitTestMax: number;
  iaPracticalMax: number;
  iaParticipationMax: number;
  iaMaxMarks: number;
  iaNotebookMarks: number | null;
  iaUnitTestMarks: number | null;
  iaPracticalMarks: number | null;
  iaParticipationMarks: number | null;
  iaTotalMarks: number | null;
  iaStatus: 'submitted' | 'draft' | 'pending' | 'na';
  maxMarks: number;
  passingMarks: number;
  isRequired: boolean;
  obtainedMarks: number | null;
  submittedSubtotal: number;
  isComplete: boolean;
  isPassed: boolean | null;
  grade: string | null;
  gradeRemark?: string | null;
  gradeStatus?: 'graded' | 'absent' | 'pending' | 'not_submitted' | 'not_applicable';
  components: ConsolidatedComponentResult[];
}

export type CoScholasticGradeValue = 'A' | 'B' | 'C';

export interface StudentCoScholasticData {
  term1: Record<string, CoScholasticGradeValue>;
  term2: Record<string, CoScholasticGradeValue>;
  term1TotalPoints: number | null;
  term2TotalPoints: number | null;
}

export interface CoScholasticTermMeta {
  examinationId: number;
  examinationName: string;
  academicYear: string;
  eligible: boolean;
  term: 1 | 2 | null;
  termLabel: 'Grade Term I' | 'Grade Term II' | null;
  reason: string;
  eligibleExams: Array<{
    id: number;
    name: string;
    term: 1 | 2;
    termLabel: 'Grade Term I' | 'Grade Term II';
  }>;
}

export interface TermAttendanceRemark {
  daysAttended: number | null;
  totalDays: number | null;
  remarks: string;
}

export interface StudentTermData {
  term1: TermAttendanceRemark;
  term2: TermAttendanceRemark;
  totalDaysAttended: number | null;
  totalWorkingDays: number | null;
}

export interface CoScholasticSheetStudent {
  studentId: number;
  studentCode: string;
  studentName: string;
  rollNumber: number;
  stream?: StudentStream;
  fatherName?: string;
  motherName?: string;
  residentialAddress?: string;
  contactNo?: string;
  aapaarId?: string;
  termRecords?: StudentTermData;
  term1: Record<string, CoScholasticGradeValue>;
  term2: Record<string, CoScholasticGradeValue>;
  term1TotalPoints: number | null;
  term2TotalPoints: number | null;
}

export interface CoScholasticSheetResponse {
  termMeta: CoScholasticTermMeta;
  classInfo: {
    classId: number;
    className: string;
    hasSections?: boolean;
    sectionId: number;
    sectionName: string;
    resultDate?: string | null;
  };
  students: CoScholasticSheetStudent[];
}

export interface ClassTeacherStudentProfile {
  studentId: number;
  studentCode: string;
  fullName: string;
  rollNumber: number;
  stream?: StudentStream;
  fatherName: string;
  motherName: string;
  residentialAddress: string;
  contactNo: string;
  aapaarId: string;
  photoUrl: string;
}

export interface ClassTeacherStudentProfilesResponse {
  academicYear: string;
  classInfo: {
    classId: number;
    className: string;
    hasSections?: boolean;
    sectionId: number;
    sectionName: string;
  };
  students: ClassTeacherStudentProfile[];
}

export interface ConsolidatedStudentResult {
  studentId: number;
  studentCode: string;
  studentName: string;
  rollNumber: number;
  classId: number;
  className: string;
  hasSections?: boolean;
  sectionId: number;
  sectionName: string;
  stream?: StudentStream;
  fatherName?: string;
  motherName?: string;
  residentialAddress?: string;
  contactNo?: string;
  aapaarId?: string;
  photoUrl?: string;
  subjects: ConsolidatedSubjectResult[];
  grandTotal: number | null;
  totalMaxMarks: number;
  percentage: number | null;
  grade: string | null;
  gradeRemark: string | null;
  resultStatus: 'Pass' | 'Fail' | 'Incomplete';
  classRank: number | null;
  missingComponents: string[];
  coScholastic?: StudentCoScholasticData;
  termRecords?: StudentTermData;
}

export interface CombinedTermSubjectRow {
  subjectId: number;
  subjectCode: string;
  subjectName: string;
  componentMode: ComponentMode;
  term1: ConsolidatedSubjectResult | null;
  term2: ConsolidatedSubjectResult | null;
  averageMarks: number | null;
  combinedObtainedMarks: number | null;
  combinedMaxMarks: number;
  combinedGrade: string | null;
  combinedPassed: boolean | null;
}

export interface CombinedTermSummary {
  examinationId: number;
  examinationName: string;
  grandTotal: number | null;
  totalMaxMarks: number;
  percentage: number | null;
  grade: string | null;
  gradeRemark: string | null;
  resultStatus: 'Pass' | 'Fail' | 'Incomplete';
  classRank: number | null;
  missingComponents: string[];
}

export interface CombinedTermStudentResult {
  studentId: number;
  studentCode: string;
  studentName: string;
  rollNumber: number;
  classId: number;
  className: string;
  hasSections?: boolean;
  sectionId: number;
  sectionName: string;
  stream?: StudentStream;
  fatherName?: string;
  motherName?: string;
  residentialAddress?: string;
  contactNo?: string;
  aapaarId?: string;
  photoUrl?: string;
  subjects: CombinedTermSubjectRow[];
  term1Summary: CombinedTermSummary | null;
  term2Summary: CombinedTermSummary | null;
  overall: {
    combinedTotal: number | null;
    combinedMaxMarks: number;
    averageObtained: number | null;
    averageMaxMarks: number | null;
    finalPercentage: number | null;
    finalGrade: string | null;
    finalGradeRemark: string | null;
    resultStatus: 'Pass' | 'Fail' | 'Incomplete';
  };
  termRecords: StudentTermData;
  coScholastic: StudentCoScholasticData;
}

export interface CombinedTermClassReport {
  academicYear: string;
  classInfo: ConsolidatedClassReport['classInfo'];
  gradingScale: GradeRule[];
  term1Exam: ConsolidatedClassReport['examination'] | null;
  term2Exam: ConsolidatedClassReport['examination'] | null;
  term1Report: ConsolidatedClassReport | null;
  term2Report: ConsolidatedClassReport | null;
  students: CombinedTermStudentResult[];
}

export interface ConsolidatedClassReport {
  examination: {
    id: number;
    name: string;
    academicYear: string;
    startDate: string;
    endDate: string;
    status: string;
    marksEntryOpen: boolean;
    passingPercentage: number;
  };
  classInfo: {
    classId: number;
    className: string;
    hasSections?: boolean;
    sectionId: number;
    sectionName: string;
    classTeacherName: string | null;
    resultDate?: string | null;
  };
  gradingScale: GradeRule[];
  subjects: Array<{
    examSubjectId: number;
    subjectId: number;
    subjectCode: string;
    subjectName: string;
    hasComponents: boolean;
    componentMode: ComponentMode;
    hasInternalAssessment: boolean;
    writtenMaxMarks: number;
    iaNotebookMax: number;
    iaUnitTestMax: number;
    iaPracticalMax: number;
    iaParticipationMax: number;
    iaMaxMarks: number;
    maxMarks: number;
    passingMarks: number;
    isRequired: boolean;
    components: Array<{
      examComponentId: number;
      componentId: number;
      componentName: string;
      maxMarks: number;
      passingMarks: number;
    }>;
  }>;
  students: ConsolidatedStudentResult[];
  summary: {
    totalStudents: number;
    completedCount: number;
    incompleteCount: number;
    passCount: number;
    failCount: number;
    highestTotal: number | null;
    lowestTotal: number | null;
    classAverageTotal: number | null;
    classAveragePercentage: number | null;
    totalMaxMarks: number;
  };
  subjectPerformance: Array<{
    subjectId: number;
    subjectName: string;
    subjectCode: string;
    maxMarks: number;
    averageMarks: number | null;
    averagePercentage: number | null;
    highestMarks: number | null;
    lowestMarks: number | null;
    completedStudents: number;
    passedStudents: number;
    passRate: number | null;
  }>;
  coScholasticMeta?: CoScholasticTermMeta & {
    hasAnyGradesForYear: boolean;
  };
}

export interface PromotionCandidate {
  studentId: number;
  studentCode: string;
  fullName: string;
  rollNumber: number;
  stream?: StudentStream;
  classId: number;
  className: string;
  hasSections?: boolean;
  sectionId: number;
  sectionName: string;
  targetClassId: number | null;
  targetClassName: string;
  targetHasSections?: boolean;
  targetSectionId: number | null;
  targetSectionName: string | null;
  targetStatus: 'active' | 'graduated';
  resultStatus: 'Pass' | 'Fail' | 'Incomplete' | 'No Exam';
  grandTotal: number | null;
  totalMaxMarks: number | null;
  percentage: number | null;
  grade: string | null;
  missingCount: number;
  alreadyInTargetYear: boolean;
  targetEnrollment: {
    className: string;
    hasSections?: boolean;
    sectionName: string;
    rollNumber: number;
    status: string;
  } | null;
}

export interface PromotionCandidatesResponse {
  sourceAcademicYear: string;
  targetAcademicYear: string;
  targetYearExists: boolean;
  sourceClass: {
    id: number;
    name: string;
    numericOrder: number;
    hasSections?: boolean;
  };
  nextClass: {
    id: number;
    name: string;
    numericOrder: number;
    hasSections?: boolean;
  } | null;
  selectedExaminationId: number | null;
  availableExaminations: Array<{
    id: number;
    name: string;
    status: string;
    passingPercentage: number;
    hasMarks: boolean;
  }>;
  summary: {
    totalStudents: number;
    passCount: number;
    failCount: number;
    incompleteCount: number;
    noExamCount: number;
    alreadyTransferredCount: number;
    eligiblePassCount: number;
  };
  candidates: PromotionCandidate[];
}

export interface PromoteStudentsResponse {
  success: boolean;
  sourceAcademicYear: string;
  targetAcademicYear: string;
  classId: number;
  sourceClassName: string;
  nextClassName: string;
  promotedCount: number;
  graduatedCount: number;
  skippedCount: number;
  copiedAssignments: number;
  copiedClassTeachers: number;
  setAsCurrentYear: boolean;
}

export interface UnpromoteStudentsResponse {
  success: boolean;
  sourceAcademicYear: string;
  targetAcademicYear: string;
  classId: number;
  sourceClassName: string;
  unpromotedCount: number;
  restoredPointerCount: number;
  skippedCount: number;
}

export interface IaTeacherAssignment {
  id: number;
  teacher_id: number;
  teacher_name: string;
  username: string;
  subject_id: number;
  subject_name: string;
  class_id: number;
  class_name: string;
  hasSections?: boolean;
  section_id: number;
  section_name: string;
  ia_component: IaComponentKey;
  academic_year: string;
}

export interface AnalyticsDistributionItem {
  id?: number | string;
  label: string;
  value: number;
  extra?: string;
}

export interface AdminAnalyticsResponse {
  academicYear: string;
  activeExaminationId: number | null;
  summary: {
    totalStudents: number;
    totalTeachers: number;
    totalClasses: number;
    totalSections: number;
    totalSubjects: number;
    totalExaminations: number;
    marksCompleted: number;
    marksPending: number;
    pendingCorrections: number;
  };
  charts: {
    classStudentDistribution: AnalyticsDistributionItem[];
    sectionStudentDistribution: Array<{ classId: number; className: string; sectionId: number; sectionName: string; label: string; value: number }>;
    subjectMarksStatus: Array<{ subjectId: number; subjectName: string; completed: number; pending: number; total: number }>;
    completedVsPending: AnalyticsDistributionItem[];
    examParticipation: Array<{ label: 'Present' | 'Absent' | 'Pending'; value: number }>;
    classExamPerformance: Array<{ classId: number; className: string; averagePct: number; evaluatedCount: number; passRate: number }>;
    subjectAverageMarks: Array<{ subjectId: number; subjectName: string; averagePct: number; averageMarks: number; maxMarks: number; evaluatedCount: number }>;
    sectionComparison: Array<{ classId: number; className: string; sectionId: number; sectionName: string; label: string; averagePct: number; passRate: number; evaluatedCount: number }>;
    examComparison: Array<{ examinationId: number; examinationName: string; status: string; averagePct: number; evaluatedCount: number; passRate: number }>;
  };
}

export interface TeacherExcelExportRow {
  rollNumber: number;
  studentCode: string;
  studentName: string;
  className: string;
  hasSections?: boolean;
  sectionName: string;
  subjectName: string;
  componentName: string;
  attendanceStatus: AttendanceStatus;
  writtenMarks: number | null;
  otherComponentsMarks: number | null;
  subjectExternalMarks: number | null;
  iaNotebookMarks: number | null;
  iaUnitTestMarks: number | null;
  iaPracticalMarks: number | null;
  iaParticipationMarks: number | null;
  iaTotalMarks: number | null;
  totalMarks: number | null;
  grade: string | null;
  gradeStatus: 'graded' | 'absent' | 'pending' | 'not_submitted';
  submissionStatus: 'Submitted' | 'Draft' | 'Not Submitted' | 'Absent';
}

export interface TeacherExcelExportSheet {
  examinationId: number;
  examinationName: string;
  academicYear: string;
  classId: number;
  className: string;
  hasSections?: boolean;
  sectionId: number;
  sectionName: string;
  subjectId: number;
  subjectName: string;
  subjectCode: string;
  componentId: number;
  componentName: string;
  hasComponents: boolean;
  componentMode: ComponentMode;
  writtenMaxMarks: number;
  subjectWrittenMaxMarks: number;
  iaEnabled: boolean;
  iaNotebookMax: number;
  iaUnitTestMax: number;
  iaPracticalMax: number;
  iaParticipationMax: number;
  iaMaxMarks: number;
  subjectTotalMaxMarks: number;
  rows: TeacherExcelExportRow[];
}

export interface TeacherExcelExportPayload {
  examinationId: number;
  examinationName: string;
  academicYear: string;
  teacherName: string;
  generatedAt: string;
  sheets: TeacherExcelExportSheet[];
}

export interface AdminSubjectExcelPayload {
  examinationId: number;
  examinationName: string;
  academicYear: string;
  subjectId: number | null;
  subjectName: string;
  generatedAt: string;
  sections: Array<{
    classId: number;
    className: string;
    hasSections?: boolean;
    sectionId: number;
    sectionName: string;
    subject: ConsolidatedClassReport['subjects'][number];
    students: Array<{
      rollNumber: number;
      studentCode: string;
      studentName: string;
      result: ConsolidatedSubjectResult;
    }>;
  }>;
}

