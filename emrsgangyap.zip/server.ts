import express from 'express';
import path from 'node:path';
import fs from 'node:fs';
import os from 'node:os';
import {
  DEFAULT_EXAM_TYPES,
  DEFAULT_PORTAL_SECTIONS,
  DEFAULT_SITE_CONTENT,
  DEFAULT_THEME_CONFIG,
  checkpointWal,
  db,
  initializeDatabase,
} from './src/db/database.ts';
import {
  AuthenticatedRequest,
  createSession,
  deleteSession,
  hashPassword,
  logAudit,
  requireAdmin,
  requireAuth,
  verifyPassword,
} from './src/db/auth.ts';
import {
  type AttendanceStatus,
  createEmptyTermData,
  getClassResultDate,
  getCombinedTermResults,
  getConsolidatedResults,
  getExamCoScholasticTerm,
  getGradingScale,
  getStudentExtendedProfilesMap,
  getStudentTermRecordsMap,
  getSubmissionMonitoring,
  resolveYearTermExams,
} from './src/services/consolidation.ts';
import {
  getStorageMode,
  pushDbAfterMutation,
  releaseMutationLock,
  syncDbBeforeRequest,
} from './src/db/sync.ts';
import {
  calculateSubjectGrade,
  doesSubjectApplyToClass,
  formatClassSectionLabel,
  parseTargetClassIds,
} from './src/lib/grading.ts';
import {
  type CoScholasticGrade,
  CO_SCHOLASTIC_ITEM_KEYS,
  getCoScholasticPoints,
  isValidCoScholasticGrade,
  summarizeCoScholasticGrades,
} from './src/lib/coScholastic.ts';

initializeDatabase();

const app = express();
app.set('trust proxy', 1);
app.set('etag', false);
const PORT = Number(process.env.PORT) || 3000;

app.use(express.json({ limit: '10mb' }));
app.use('/api', async (req, res, next) => {
  res.setHeader('Cache-Control', 'no-store, no-cache, must-revalidate, proxy-revalidate');
  res.setHeader('Pragma', 'no-cache');
  res.setHeader('Expires', '0');

  const isMutation =
    req.method === 'POST' ||
    req.method === 'PUT' ||
    req.method === 'PATCH' ||
    req.method === 'DELETE';
  const storageMode = getStorageMode();

  if (storageMode === 'kv-synced') {
    try {
      await syncDbBeforeRequest(isMutation);
    } catch (err) {
      console.error('KV pre-request sync failed:', err);
    }
  }

  if (!isMutation) {
    return next();
  }

  let finalized = false;
  const origJson = res.json.bind(res);
  const origSend = res.send.bind(res);

  const finalizeSyncLocal = (statusCode: number) => {
    if (finalized) return;
    finalized = true;
    if (statusCode < 400) {
      checkpointWal(process.env.VERCEL ? 'TRUNCATE' : 'PASSIVE');
    }
  };

  const finalizeAsyncKv = async (statusCode: number) => {
    if (finalized) return;
    finalized = true;
    try {
      if (statusCode < 400) {
        checkpointWal('TRUNCATE');
        await pushDbAfterMutation();
      }
    } catch (err) {
      console.error('KV post-mutation sync failed:', err);
    } finally {
      await releaseMutationLock().catch(() => {});
    }
  };

  (res as any).json = (body?: any) => {
    if (finalized) return origJson(body);
    if (storageMode !== 'kv-synced') {
      finalizeSyncLocal(res.statusCode);
      return origJson(body);
    }
    void finalizeAsyncKv(res.statusCode).then(() => {
      if (!res.headersSent) origJson(body);
    });
    return res;
  };

  (res as any).send = (body?: any) => {
    if (finalized) return origSend(body);
    if (storageMode !== 'kv-synced') {
      finalizeSyncLocal(res.statusCode);
      return origSend(body);
    }
    void finalizeAsyncKv(res.statusCode).then(() => {
      if (!res.headersSent) origSend(body);
    });
    return res;
  };

  if (storageMode === 'kv-synced') {
    res.on('close', () => {
      if (!finalized) {
        void releaseMutationLock().catch(() => {});
      }
    });
  }

  return next();
});

// Health check
app.get('/api/health', (_req, res) => {
  res.json({
    status: 'ok',
    storageMode: getStorageMode(),
    timestamp: new Date().toISOString(),
  });
});

// ==========================================
// 1. AUTHENTICATION & SESSION ROUTES
// ==========================================

app.post('/api/auth/login', (req, res) => {
  const { username, password } = req.body as { username?: string; password?: string };
  if (!username || !password) {
    return res.status(400).json({ error: 'Username and password are required.' });
  }

  const userRow = db
    .prepare(
      `SELECT id, username, password_hash, full_name, email, employee_code, is_active, COALESCE(is_deleted, 0) as is_deleted, must_change_password
       FROM users WHERE lower(username) = lower(?)`
    )
    .get(username.trim()) as
    | {
        id: number;
        username: string;
        password_hash: string;
        full_name: string;
        email: string;
        employee_code: string;
        is_active: number;
        is_deleted: number;
        must_change_password: number;
      }
    | undefined;

  if (!userRow || !verifyPassword(password, userRow.password_hash)) {
    return res.status(401).json({ error: 'Invalid username or password.' });
  }

  if (userRow.is_deleted) {
    return res.status(403).json({ error: 'This account has been archived or removed. Contact the administrator.' });
  }

  if (!userRow.is_active) {
    return res.status(403).json({ error: 'This account has been deactivated. Contact the administrator.' });
  }

  const roleRows = db
    .prepare(
      `SELECT r.name FROM roles r
       JOIN user_roles ur ON ur.role_id = r.id
       WHERE ur.user_id = ?`
    )
    .all(userRow.id) as { name: string }[];
  const roles = roleRows.map((r) => r.name);

  const token = createSession(userRow.id);
  const isHttps = req.secure || req.headers['x-forwarded-proto'] === 'https';
  res.cookie('school_session', token, {
    httpOnly: true,
    sameSite: isHttps ? 'none' : 'lax',
    secure: isHttps,
    path: '/',
    maxAge: 7 * 24 * 60 * 60 * 1000,
  });

  logAudit(
    { id: userRow.id, username: userRow.username, roles },
    'LOGIN',
    'user',
    userRow.id,
    { username: userRow.username }
  );

  const subjectCount = (
    db.prepare(`SELECT COUNT(*) as cnt FROM teacher_assignments WHERE teacher_id = ?`).get(userRow.id) as {
      cnt: number;
    }
  ).cnt;
  const classTeacherCount = (
    db.prepare(`SELECT COUNT(*) as cnt FROM class_teacher_assignments WHERE teacher_id = ?`).get(userRow.id) as {
      cnt: number;
    }
  ).cnt;

  res.json({
    token,
    user: {
      id: userRow.id,
      username: userRow.username,
      fullName: userRow.full_name,
      email: userRow.email || '',
      employeeCode: userRow.employee_code || '',
      roles,
      mustChangePassword: Boolean(userRow.must_change_password),
      isSubjectTeacher: subjectCount > 0 || roles.includes('teacher'),
      isClassTeacher: classTeacherCount > 0,
    },
  });
});

app.post('/api/auth/logout', requireAuth, (req: AuthenticatedRequest, res) => {
  if (req.sessionToken) {
    deleteSession(req.sessionToken);
  }
  if (req.user) {
    logAudit(req.user, 'LOGOUT', 'user', req.user.id, { username: req.user.username });
  }
  const isHttps = req.secure || req.headers['x-forwarded-proto'] === 'https';
  res.clearCookie('school_session', {
    path: '/',
    sameSite: isHttps ? 'none' : 'lax',
    secure: isHttps,
  });
  res.json({ success: true });
});

app.get('/api/auth/me', requireAuth, (req: AuthenticatedRequest, res) => {
  res.json({ user: req.user });
});

app.post('/api/auth/change-password', requireAuth, (req: AuthenticatedRequest, res) => {
  const { currentPassword, newPassword } = req.body as {
    currentPassword?: string;
    newPassword?: string;
  };
  if (!currentPassword || !newPassword || newPassword.length < 6) {
    return res.status(400).json({ error: 'New password must be at least 6 characters.' });
  }

  const userRow = db
    .prepare(`SELECT id, password_hash FROM users WHERE id = ?`)
    .get(req.user!.id) as { id: number; password_hash: string };

  if (!verifyPassword(currentPassword, userRow.password_hash)) {
    return res.status(400).json({ error: 'Current password is incorrect.' });
  }

  const newHash = hashPassword(newPassword);
  db.prepare(
    `UPDATE users SET password_hash = ?, must_change_password = 0, updated_at = datetime('now') WHERE id = ?`
  ).run(newHash, req.user!.id);

  logAudit(req.user!, 'CHANGE_PASSWORD', 'user', req.user!.id, { selfService: true });
  res.json({ success: true });
});

// ==========================================
// 2. SCHOOL METADATA & SETTINGS
// ==========================================

function getCurrentAcademicYear(): string {
  const row = db
    .prepare(`SELECT value FROM system_settings WHERE key = 'current_academic_year'`)
    .get() as { value: string } | undefined;
  return row?.value || '2025-26';
}

function getAcademicYearsSummary(viewMode: 'active' | 'archived' | 'all' = 'active') {
  const whereClause =
    viewMode === 'active'
      ? `WHERE COALESCE(ay.is_deleted, 0) = 0`
      : viewMode === 'archived'
        ? `WHERE COALESCE(ay.is_deleted, 0) = 1`
        : '';
  return db
    .prepare(
      `SELECT ay.name,
              ay.is_current,
              COALESCE(ay.is_deleted, 0) as is_deleted,
              ay.deleted_at,
              (SELECT COUNT(*) FROM student_enrollments se JOIN students st ON st.id = se.student_id WHERE se.academic_year = ay.name AND se.status = 'active' AND COALESCE(st.is_deleted, 0) = 0) as studentCount,
              (SELECT COUNT(*) FROM student_enrollments se JOIN students st ON st.id = se.student_id WHERE se.academic_year = ay.name AND se.status = 'graduated' AND COALESCE(st.is_deleted, 0) = 0) as graduatedCount,
              (SELECT COUNT(*) FROM examinations ex WHERE ex.academic_year = ay.name AND COALESCE(ex.is_deleted, 0) = 0) as examCount,
              (SELECT COUNT(*) FROM teacher_assignments ta WHERE ta.academic_year = ay.name) as assignmentCount,
              (SELECT COUNT(*) FROM class_teacher_assignments cta WHERE cta.academic_year = ay.name) as classTeacherCount
       FROM academic_years ay
       ${whereClause}
       ORDER BY ay.name DESC`
    )
    .all()
    .map((r: any) => ({
      name: r.name,
      isCurrent: Boolean(r.is_current),
      isDeleted: Boolean(r.is_deleted),
      deletedAt: r.deleted_at || null,
      studentCount: Number(r.studentCount || 0),
      graduatedCount: Number(r.graduatedCount || 0),
      examCount: Number(r.examCount || 0),
      assignmentCount: Number(r.assignmentCount || 0),
      classTeacherCount: Number(r.classTeacherCount || 0),
    }));
}

function parseSettingJson<T>(raw: string | undefined, fallback: T): T {
  if (!raw) return fallback;
  try {
    return JSON.parse(raw) as T;
  } catch {
    return fallback;
  }
}

app.get('/api/school/info', (_req, res) => {
  try {
    const settingsRows = db.prepare(`SELECT key, value FROM system_settings`).all() as Array<{
      key: string;
      value: string;
    }>;
    const settings: Record<string, string> = {};
    for (const r of settingsRows) settings[r.key] = r.value;

    const currentYear = settings.current_academic_year || '2025-26';
    const classes = db
      .prepare(`SELECT id, name, numeric_order, COALESCE(has_sections, 1) as has_sections FROM classes WHERE is_active = 1 AND COALESCE(is_deleted, 0) = 0 ORDER BY numeric_order ASC`)
      .all() as Array<{ id: number; name: string; numeric_order: number; has_sections: number }>;

    const sections = db
      .prepare(`SELECT id, class_id, name, capacity FROM sections WHERE COALESCE(is_deleted, 0) = 0 ORDER BY name ASC`)
      .all() as Array<{ id: number; class_id: number; name: string; capacity: number }>;

    res.json({
      schoolName: settings.school_name || 'EMRS Gangyap',
      schoolAddress: settings.school_address || '',
      schoolMotto: settings.school_motto || '',
      schoolLogo: settings.school_logo ?? '',
      currentAcademicYear: currentYear,
      defaultPassPercentage: Number(settings.default_pass_percentage || '33'),
      gradingScale: getGradingScale(),
      themeConfig: {
        ...DEFAULT_THEME_CONFIG,
        ...parseSettingJson(settings.theme_config, DEFAULT_THEME_CONFIG),
      },
      siteContent: {
        ...DEFAULT_SITE_CONTENT,
        ...parseSettingJson(settings.site_content, DEFAULT_SITE_CONTENT),
      },
      portalSections: parseSettingJson(settings.portal_sections, DEFAULT_PORTAL_SECTIONS),
      examinationTypes: parseSettingJson(settings.examination_types, DEFAULT_EXAM_TYPES),
      academicYears: getAcademicYearsSummary(),
      storageMode: getStorageMode(),
      classes: classes.map((c) => ({
        ...c,
        hasSections: Boolean(c.has_sections ?? 1),
        sections: sections.filter((s) => s.class_id === c.id),
      })),
    });
  } catch (err: any) {
    console.error('Error loading /api/school/info:', err);
    res.status(500).json({ error: 'Database error while loading school configuration.' });
  }
});

app.get('/api/examinations', requireAuth, (req, res) => {
  try {
    const academicYear = req.query.academicYear as string | undefined;
    const view = req.query.view as string | undefined;
    const delClause = view === 'archived' ? 'COALESCE(is_deleted, 0) = 1' : view === 'all' ? '1=1' : 'COALESCE(is_deleted, 0) = 0';
    const exams = (
      academicYear && academicYear !== 'all'
        ? db
            .prepare(
              `SELECT id, name, exam_type, academic_year, start_date, end_date, status, marks_entry_open, passing_percentage, COALESCE(is_deleted, 0) as is_deleted, deleted_at
               FROM examinations WHERE academic_year = ? AND ${delClause} ORDER BY start_date DESC, id DESC`
            )
            .all(academicYear)
        : db
            .prepare(
              `SELECT id, name, exam_type, academic_year, start_date, end_date, status, marks_entry_open, passing_percentage, COALESCE(is_deleted, 0) as is_deleted, deleted_at
               FROM examinations WHERE ${delClause} ORDER BY academic_year DESC, start_date DESC, id DESC`
            )
            .all()
    ) as Array<{
      id: number;
      name: string;
      exam_type: string;
      academic_year: string;
      start_date: string;
      end_date: string;
      status: string;
      marks_entry_open: number;
      passing_percentage: number;
    }>;

    const examSubs = db
      .prepare(
        `SELECT es.id, es.examination_id, es.subject_id, s.name as subject_name, s.code as subject_code,
                s.has_components, s.component_mode, COALESCE(s.has_practical, 0) as has_practical,
                COALESCE(s.stream_category, '') as stream_category,
                COALESCE(s.applicable_class_ids, '') as subject_applicable_class_ids,
                COALESCE(es.target_class_ids, '') as target_class_ids,
                es.has_internal_assessment, es.ia_notebook_max, es.ia_unit_test_max, es.ia_practical_max, es.ia_participation_max,
                es.max_marks, es.passing_marks, es.is_required, es.display_order
         FROM examination_subjects es
         JOIN subjects s ON s.id = es.subject_id
         ORDER BY es.display_order ASC`
      )
      .all() as Array<{
      id: number;
      examination_id: number;
      subject_id: number;
      subject_name: string;
      subject_code: string;
      has_components: number;
      component_mode: string | null;
      has_practical: number;
      stream_category: string;
      subject_applicable_class_ids: string;
      target_class_ids: string;
      has_internal_assessment: number;
      ia_notebook_max: number;
      ia_unit_test_max: number;
      ia_practical_max: number;
      ia_participation_max: number;
      max_marks: number;
      passing_marks: number;
      is_required: number;
      display_order: number;
    }>;

    const examComps = db
      .prepare(
        `SELECT id, examination_id, examination_subject_id, subject_id, component_id, component_name, max_marks, passing_marks, display_order
         FROM examination_components ORDER BY display_order ASC, id ASC`
      )
      .all() as Array<{
      id: number;
      examination_id: number;
      examination_subject_id: number;
      subject_id: number;
      component_id: number;
      component_name: string;
      max_marks: number;
      passing_marks: number;
      display_order: number;
    }>;

    res.json(
      exams.map((e) => ({
        ...e,
        marksEntryOpen: Boolean(e.marks_entry_open),
        subjects: examSubs
          .filter((es) => es.examination_id === e.id)
          .map((es) => {
            const comps = examComps.filter((ec) => ec.examination_subject_id === es.id);
            const componentMode =
              es.component_mode === 'elective'
                ? 'elective'
                : es.component_mode === 'combined' || Boolean(es.has_components) || comps.length > 1
                  ? 'combined'
                  : 'single';
            const writtenMaxMarks =
              componentMode === 'elective'
                ? (comps[0]?.max_marks ?? es.max_marks)
                : comps.reduce((sum, c) => sum + c.max_marks, 0);
            const hasIa = Boolean(es.has_internal_assessment);
            const iaMaxMarks = hasIa
              ? Number(es.ia_notebook_max || 0) +
                Number(es.ia_unit_test_max || 0) +
                Number(es.ia_practical_max || 0) +
                Number(es.ia_participation_max || 0)
              : 0;
            return {
              ...es,
              componentMode,
              hasInternalAssessment: hasIa,
              hasPractical: Boolean(es.has_practical),
              streamCategory: es.stream_category || '',
              targetClassIds: parseTargetClassIds(es.target_class_ids || es.subject_applicable_class_ids),
              iaNotebookMax: hasIa ? Number(es.ia_notebook_max || 0) : 0,
              iaUnitTestMax: hasIa ? Number(es.ia_unit_test_max || 0) : 0,
              iaPracticalMax: hasIa ? Number(es.ia_practical_max || 0) : 0,
              iaParticipationMax: hasIa ? Number(es.ia_participation_max || 0) : 0,
              writtenMaxMarks,
              iaMaxMarks,
              components: comps,
            };
          }),
      }))
    );
  } catch (err: any) {
    console.error('Error loading /api/examinations:', err);
    res.status(500).json({ error: err?.message || 'Database error while loading examinations.' });
  }
});

// ==========================================
// 3. ADMIN ROUTES
// ==========================================

// Overview & Analytics
app.get('/api/admin/overview', requireAuth, requireAdmin, (req, res) => {
  const academicYear = (req.query.academicYear as string) || getCurrentAcademicYear();

  const totalStudents = (
    db
      .prepare(
        `SELECT COUNT(*) as cnt FROM student_enrollments se
         JOIN students st ON st.id = se.student_id
         WHERE se.academic_year = ? AND se.status = 'active' AND COALESCE(st.is_deleted, 0) = 0`
      )
      .get(academicYear) as { cnt: number }
  ).cnt;
  const totalTeachers = (
    db
      .prepare(
        `SELECT COUNT(DISTINCT u.id) as cnt FROM users u
         JOIN user_roles ur ON ur.user_id = u.id
         JOIN roles r ON r.id = ur.role_id
         WHERE r.name = 'teacher' AND u.is_active = 1 AND COALESCE(u.is_deleted, 0) = 0`
      )
      .get() as { cnt: number }
  ).cnt;
  const totalClasses = (
    db.prepare(`SELECT COUNT(*) as cnt FROM classes WHERE is_active = 1 AND COALESCE(is_deleted, 0) = 0`).get() as { cnt: number }
  ).cnt;
  const totalSections = (db.prepare(`SELECT COUNT(*) as cnt FROM sections WHERE COALESCE(is_deleted, 0) = 0`).get() as { cnt: number }).cnt;
  const totalSubjects = (
    db.prepare(`SELECT COUNT(*) as cnt FROM subjects WHERE is_active = 1 AND COALESCE(is_deleted, 0) = 0`).get() as { cnt: number }
  ).cnt;
  const activeExams = (
    db
      .prepare(`SELECT COUNT(*) as cnt FROM examinations WHERE academic_year = ? AND status = 'Active' AND COALESCE(is_deleted, 0) = 0`)
      .get(academicYear) as { cnt: number }
  ).cnt;
  const pendingCorrections = (
    db.prepare(`SELECT COUNT(*) as cnt FROM mark_correction_requests WHERE status = 'pending'`).get() as {
      cnt: number;
    }
  ).cnt;

  const classDistribution = db
    .prepare(
      `SELECT c.id as class_id, c.name as class_name, s.id as section_id, s.name as section_name,
              COUNT(CASE WHEN COALESCE(st.is_deleted, 0) = 0 THEN se.id END) as student_count,
              u.full_name as class_teacher_name
       FROM classes c
       JOIN sections s ON s.class_id = c.id
       LEFT JOIN student_enrollments se ON se.class_id = c.id AND se.section_id = s.id AND se.academic_year = ? AND se.status = 'active'
       LEFT JOIN students st ON st.id = se.student_id
       LEFT JOIN class_teacher_assignments cta ON cta.class_id = c.id AND cta.section_id = s.id AND cta.academic_year = ?
       LEFT JOIN users u ON u.id = cta.teacher_id AND COALESCE(u.is_deleted, 0) = 0
       WHERE COALESCE(c.is_deleted, 0) = 0 AND COALESCE(s.is_deleted, 0) = 0
       GROUP BY c.id, s.id
       ORDER BY c.numeric_order ASC, s.name ASC`
    )
    .all(academicYear, academicYear);

  const exams = db
    .prepare(
      `SELECT id, name, status, marks_entry_open, academic_year
       FROM examinations WHERE academic_year = ? AND COALESCE(is_deleted, 0) = 0 ORDER BY start_date DESC, id DESC`
    )
    .all(academicYear) as Array<{
    id: number;
    name: string;
    status: string;
    marks_entry_open: number;
    academic_year: string;
  }>;

  const examId =
    Number(req.query.examinationId) ||
    exams.find((e) => e.status === 'Active')?.id ||
    exams.find((e) => e.status === 'Published')?.id ||
    exams[0]?.id;
  const monitoring = examId ? getSubmissionMonitoring(examId) : [];

  const monitoringSummary = {
    totalSlots: monitoring.length,
    submitted: monitoring.filter((m) => m.submissionStatus === 'Submitted').length,
    draft: monitoring.filter((m) => m.submissionStatus === 'Draft').length,
    pending: monitoring.filter((m) => m.submissionStatus === 'Pending').length,
  };

  res.json({
    academicYear,
    counts: {
      totalStudents,
      totalTeachers,
      totalClasses,
      totalSections,
      totalSubjects,
      activeExams,
      pendingCorrections,
    },
    classDistribution,
    monitoringSummary,
    activeExaminationId: examId || null,
  });
});

// Interactive Admin Visual Analytics (real DB data, filterable by class, section, subject, examination)
app.get('/api/admin/analytics', requireAuth, requireAdmin, (req, res) => {
  const academicYear = (req.query.academicYear as string) || getCurrentAcademicYear();
  const classId = req.query.classId ? Number(req.query.classId) : undefined;
  const sectionId = req.query.sectionId ? Number(req.query.sectionId) : undefined;
  const subjectId = req.query.subjectId ? Number(req.query.subjectId) : undefined;
  const requestedExamId = req.query.examinationId ? Number(req.query.examinationId) : undefined;

  const exams = db
    .prepare(
      `SELECT id, name, status, marks_entry_open, academic_year
       FROM examinations WHERE academic_year = ? AND COALESCE(is_deleted, 0) = 0 ORDER BY start_date DESC, id DESC`
    )
    .all(academicYear) as Array<{
    id: number;
    name: string;
    status: string;
    marks_entry_open: number;
    academic_year: string;
  }>;

  const examHasMarks = (eid: number) =>
    ((db.prepare(`SELECT COUNT(*) as cnt FROM marks WHERE examination_id = ?`).get(eid) as { cnt: number })?.cnt || 0) > 0;

  const activeExamId =
    (requestedExamId && exams.some((e) => e.id === requestedExamId) ? requestedExamId : undefined) ||
    exams.find((e) => e.status === 'Active' && examHasMarks(e.id))?.id ||
    exams.find((e) => e.status === 'Published' && examHasMarks(e.id))?.id ||
    exams.find((e) => examHasMarks(e.id))?.id ||
    exams.find((e) => e.status === 'Active')?.id ||
    exams.find((e) => e.status === 'Published')?.id ||
    exams[0]?.id ||
    null;

  const totalTeachers = (
    db
      .prepare(
        `SELECT COUNT(DISTINCT u.id) as cnt FROM users u
         JOIN user_roles ur ON ur.user_id = u.id
         JOIN roles r ON r.id = ur.role_id
         WHERE r.name = 'teacher' AND u.is_active = 1 AND COALESCE(u.is_deleted, 0) = 0`
      )
      .get() as { cnt: number }
  ).cnt;

  const totalClasses = (
    db.prepare(`SELECT COUNT(*) as cnt FROM classes WHERE is_active = 1 AND COALESCE(is_deleted, 0) = 0`).get() as { cnt: number }
  ).cnt;
  const totalSections = (db.prepare(`SELECT COUNT(*) as cnt FROM sections WHERE COALESCE(is_deleted, 0) = 0`).get() as { cnt: number }).cnt;
  const totalSubjects = (
    db.prepare(`SELECT COUNT(*) as cnt FROM subjects WHERE is_active = 1 AND COALESCE(is_deleted, 0) = 0`).get() as { cnt: number }
  ).cnt;
  const totalExaminations = exams.length;
  const pendingCorrections = (
    db.prepare(`SELECT COUNT(*) as cnt FROM mark_correction_requests WHERE status = 'pending'`).get() as {
      cnt: number;
    }
  ).cnt;

  // Student counts & distribution (filtered by classId / sectionId if specified)
  const sectionStudentRows = db
    .prepare(
      `SELECT c.id as classId, c.name as className, s.id as sectionId, s.name as sectionName,
              COUNT(CASE WHEN COALESCE(st.is_deleted, 0) = 0 THEN se.id END) as studentCount
       FROM classes c
       JOIN sections s ON s.class_id = c.id
       LEFT JOIN student_enrollments se
         ON se.class_id = c.id AND se.section_id = s.id AND se.academic_year = ? AND se.status = 'active'
       LEFT JOIN students st ON st.id = se.student_id
       WHERE c.is_active = 1 AND COALESCE(c.is_deleted, 0) = 0 AND COALESCE(s.is_deleted, 0) = 0
       ${classId ? 'AND c.id = ?' : ''}
       ${sectionId ? 'AND s.id = ?' : ''}
       GROUP BY c.id, s.id
       ORDER BY c.numeric_order ASC, s.name ASC`
    )
    .all(
      ...[academicYear, ...(classId ? [classId] : []), ...(sectionId ? [sectionId] : [])]
    ) as Array<{
    classId: number;
    className: string;
    sectionId: number;
    sectionName: string;
    studentCount: number;
  }>;

  const totalStudents = sectionStudentRows.reduce((sum, r) => sum + Number(r.studentCount || 0), 0);

  const classMap = new Map<number, { id: number; label: string; value: number }>();
  for (const r of sectionStudentRows) {
    const existing = classMap.get(r.classId);
    if (existing) {
      existing.value += Number(r.studentCount || 0);
    } else {
      classMap.set(r.classId, { id: r.classId, label: r.className, value: Number(r.studentCount || 0) });
    }
  }
  const classStudentDistribution = Array.from(classMap.values());
  const sectionStudentDistribution = sectionStudentRows.map((r) => ({
    classId: r.classId,
    className: r.className,
    sectionId: r.sectionId,
    sectionName: r.sectionName,
    label: `${r.className} ${r.sectionName}`,
    value: Number(r.studentCount || 0),
  }));

  // Monitoring-based analytics for active/selected examination
  const rawMonitoring = activeExamId ? getSubmissionMonitoring(activeExamId, classId, sectionId) : [];
  const filteredMonitoring = subjectId ? rawMonitoring.filter((m) => m.subjectId === subjectId) : rawMonitoring;

  const marksCompleted = filteredMonitoring.reduce((sum, m) => sum + m.submittedCount, 0);
  const totalExpectedEntries = filteredMonitoring.reduce((sum, m) => sum + m.totalStudents, 0);
  const marksPending = Math.max(0, totalExpectedEntries - marksCompleted);

  const presentTotal = filteredMonitoring.reduce((sum, m) => sum + (m.presentCount ?? 0), 0);
  const absentTotal = filteredMonitoring.reduce((sum, m) => sum + (m.absentCount ?? 0), 0);
  const pendingParticipation = Math.max(0, totalExpectedEntries - (presentTotal + absentTotal));

  const subMarksMap = new Map<number, { subjectId: number; subjectName: string; completed: number; pending: number; total: number }>();
  for (const m of filteredMonitoring) {
    const cur = subMarksMap.get(m.subjectId) || {
      subjectId: m.subjectId,
      subjectName: m.subjectName,
      completed: 0,
      pending: 0,
      total: 0,
    };
    cur.completed += m.submittedCount;
    cur.total += m.totalStudents;
    cur.pending = Math.max(0, cur.total - cur.completed);
    subMarksMap.set(m.subjectId, cur);
  }
  const subjectMarksStatus = Array.from(subMarksMap.values());

  const completedVsPending = [
    { label: 'Completed', value: marksCompleted },
    { label: 'Pending', value: marksPending },
  ];

  const examParticipation: Array<{ label: 'Present' | 'Absent' | 'Pending'; value: number }> = [
    { label: 'Present', value: presentTotal },
    { label: 'Absent', value: absentTotal },
    { label: 'Pending', value: pendingParticipation },
  ];

  // Performance analytics computed cleanly via getConsolidatedResults (real scores, handles IA + absent + electives)
  const classPerfMap = new Map<number, { classId: number; className: string; pctSum: number; passCount: number; evalCount: number }>();
  const subPerfMap = new Map<
    number,
    { subjectId: number; subjectName: string; maxMarks: number; markSum: number; pctSum: number; evalCount: number }
  >();
  const sectionComparison: Array<{
    classId: number;
    className: string;
    sectionId: number;
    sectionName: string;
    label: string;
    averagePct: number;
    passRate: number;
    evaluatedCount: number;
  }> = [];

  if (activeExamId) {
    for (const sec of sectionStudentRows) {
      if (sec.studentCount === 0) continue;
      try {
        const report = getConsolidatedResults(activeExamId, sec.classId, sec.sectionId);
        // Subject-wise averages
        for (const st of report.students) {
          for (const sr of st.subjects) {
            if (subjectId && sr.subjectId !== subjectId) continue;
            if (!sr.isComplete || sr.obtainedMarks === null || sr.maxMarks <= 0) continue;
            const sp = subPerfMap.get(sr.subjectId) || {
              subjectId: sr.subjectId,
              subjectName: sr.subjectName,
              maxMarks: sr.maxMarks,
              markSum: 0,
              pctSum: 0,
              evalCount: 0,
            };
            sp.markSum += sr.obtainedMarks;
            sp.pctSum += (sr.obtainedMarks / sr.maxMarks) * 100;
            sp.evalCount += 1;
            subPerfMap.set(sr.subjectId, sp);
          }
        }

        // Section & Class performance (respecting subjectId filter if applied)
        let secPctSum = 0;
        let secEval = 0;
        let secPass = 0;

        for (const st of report.students) {
          if (subjectId) {
            const sr = st.subjects.find((x) => x.subjectId === subjectId);
            if (sr && sr.isComplete && sr.obtainedMarks !== null && sr.maxMarks > 0) {
              secPctSum += (sr.obtainedMarks / sr.maxMarks) * 100;
              secEval += 1;
              if (sr.isPassed) secPass += 1;
            }
          } else if (st.resultStatus !== 'Incomplete' && st.percentage !== null) {
            secPctSum += st.percentage;
            secEval += 1;
            if (st.resultStatus === 'Pass') secPass += 1;
          }
        }

        const avgPct = secEval > 0 ? Number((secPctSum / secEval).toFixed(1)) : 0;
        const passRate = secEval > 0 ? Number(((secPass / secEval) * 100).toFixed(1)) : 0;
        sectionComparison.push({
          classId: sec.classId,
          className: sec.className,
          sectionId: sec.sectionId,
          sectionName: sec.sectionName,
          label: `${sec.className} ${sec.sectionName}`,
          averagePct: avgPct,
          passRate,
          evaluatedCount: secEval,
        });

        const cp = classPerfMap.get(sec.classId) || {
          classId: sec.classId,
          className: sec.className,
          pctSum: 0,
          passCount: 0,
          evalCount: 0,
        };
        cp.pctSum += secPctSum;
        cp.passCount += secPass;
        cp.evalCount += secEval;
        classPerfMap.set(sec.classId, cp);
      } catch {
        // ignore sections not part of exam
      }
    }
  }

  const classExamPerformance = Array.from(classPerfMap.values()).map((c) => ({
    classId: c.classId,
    className: c.className,
    averagePct: c.evalCount > 0 ? Number((c.pctSum / c.evalCount).toFixed(1)) : 0,
    passRate: c.evalCount > 0 ? Number(((c.passCount / c.evalCount) * 100).toFixed(1)) : 0,
    evaluatedCount: c.evalCount,
  }));

  const subjectAverageMarks = Array.from(subPerfMap.values()).map((s) => ({
    subjectId: s.subjectId,
    subjectName: s.subjectName,
    maxMarks: s.maxMarks,
    averageMarks: s.evalCount > 0 ? Number((s.markSum / s.evalCount).toFixed(1)) : 0,
    averagePct: s.evalCount > 0 ? Number((s.pctSum / s.evalCount).toFixed(1)) : 0,
    evaluatedCount: s.evalCount,
  }));

  // Examination-wise performance comparison across academic year exams
  const examComparison = exams.map((ex) => {
    let pctSum = 0;
    let passCount = 0;
    let evalCount = 0;
    for (const sec of sectionStudentRows) {
      if (sec.studentCount === 0) continue;
      try {
        const rep = getConsolidatedResults(ex.id, sec.classId, sec.sectionId);
        for (const st of rep.students) {
          if (subjectId) {
            const sr = st.subjects.find((x) => x.subjectId === subjectId);
            if (sr && sr.isComplete && sr.obtainedMarks !== null && sr.maxMarks > 0) {
              pctSum += (sr.obtainedMarks / sr.maxMarks) * 100;
              evalCount += 1;
              if (sr.isPassed) passCount += 1;
            }
          } else if (st.resultStatus !== 'Incomplete' && st.percentage !== null) {
            pctSum += st.percentage;
            evalCount += 1;
            if (st.resultStatus === 'Pass') passCount += 1;
          }
        }
      } catch {
        // skip
      }
    }
    return {
      examinationId: ex.id,
      examinationName: ex.name,
      status: ex.status,
      averagePct: evalCount > 0 ? Number((pctSum / evalCount).toFixed(1)) : 0,
      passRate: evalCount > 0 ? Number(((passCount / evalCount) * 100).toFixed(1)) : 0,
      evaluatedCount: evalCount,
    };
  });

  res.json({
    academicYear,
    activeExaminationId: activeExamId,
    summary: {
      totalStudents,
      totalTeachers,
      totalClasses,
      totalSections,
      totalSubjects,
      totalExaminations,
      marksCompleted,
      marksPending,
      pendingCorrections,
    },
    charts: {
      classStudentDistribution,
      sectionStudentDistribution,
      subjectMarksStatus,
      completedVsPending,
      examParticipation,
      classExamPerformance,
      subjectAverageMarks,
      sectionComparison,
      examComparison,
    },
  });
});

// Students CRUD + Transfer (Multi-Year Enrollment Aware)
app.get('/api/admin/students', requireAuth, requireAdmin, (req, res) => {
  try {
    const { classId, sectionId, status, stream, search, academicYear, view, sortBy } = req.query as Record<string, string | undefined>;
    const targetYear = academicYear && academicYear !== 'all' ? academicYear : getCurrentAcademicYear();
    const useAll = academicYear === 'all';
    const viewMode = view === 'archived' ? 'archived' : view === 'all' ? 'all' : 'active';

    const where: string[] = [];
    const params: Array<string | number> = [];

    if (viewMode === 'active') {
      where.push(`COALESCE(st.is_deleted, 0) = 0`);
    } else if (viewMode === 'archived') {
      where.push(`COALESCE(st.is_deleted, 0) = 1`);
    }

    if (!useAll) {
      where.push(`se.academic_year = ?`);
      params.push(targetYear);
    }
    if (classId) {
      where.push(useAll ? `st.class_id = ?` : `se.class_id = ?`);
      params.push(Number(classId));
    }
    if (sectionId) {
      where.push(useAll ? `st.section_id = ?` : `se.section_id = ?`);
      params.push(Number(sectionId));
    }
    if (status && status !== 'all') {
      where.push(useAll ? `st.status = ?` : `se.status = ?`);
      params.push(status);
    }
    if (stream && stream !== 'all') {
      if (stream === 'none') {
        where.push(useAll ? `COALESCE(st.stream, '') = ''` : `COALESCE(NULLIF(se.stream, ''), st.stream, '') = ''`);
      } else {
        where.push(useAll ? `COALESCE(st.stream, '') = ?` : `COALESCE(NULLIF(se.stream, ''), st.stream, '') = ?`);
        params.push(stream);
      }
    }
    if (search && search.trim()) {
      const q = search.trim();
      if (useAll) {
        where.push(
          `(lower(st.full_name) LIKE lower(?) OR lower(st.student_code) LIKE lower(?) OR lower(COALESCE(st.guardian_name, '')) LIKE lower(?) OR lower(COALESCE(st.father_name, '')) LIKE lower(?) OR lower(COALESCE(st.mother_name, '')) LIKE lower(?) OR lower(COALESCE(st.aapaar_id, '')) LIKE lower(?) OR CAST(st.roll_number AS TEXT) = ?)`
        );
        params.push(`%${q}%`, `%${q}%`, `%${q}%`, `%${q}%`, `%${q}%`, `%${q}%`, q);
      } else {
        where.push(
          `(lower(st.full_name) LIKE lower(?) OR lower(st.student_code) LIKE lower(?) OR lower(COALESCE(st.guardian_name, '')) LIKE lower(?) OR lower(COALESCE(st.father_name, '')) LIKE lower(?) OR lower(COALESCE(st.mother_name, '')) LIKE lower(?) OR lower(COALESCE(st.aapaar_id, '')) LIKE lower(?) OR CAST(se.roll_number AS TEXT) = ? OR CAST(st.roll_number AS TEXT) = ?)`
        );
        params.push(`%${q}%`, `%${q}%`, `%${q}%`, `%${q}%`, `%${q}%`, `%${q}%`, q, q);
      }
    }

    const orderClause =
      sortBy === 'name_asc'
        ? `lower(st.full_name) ASC, c.numeric_order ASC, s.name ASC`
        : sortBy === 'name_desc'
          ? `lower(st.full_name) DESC, c.numeric_order ASC, s.name ASC`
          : sortBy === 'code_asc'
            ? `lower(st.student_code) ASC`
            : sortBy === 'code_desc'
              ? `lower(st.student_code) DESC`
              : useAll
                ? `c.numeric_order ASC, s.name ASC, st.roll_number ASC, st.student_code ASC`
                : `c.numeric_order ASC, s.name ASC, se.roll_number ASC, st.student_code ASC`;

    const sql = useAll
      ? `
        SELECT st.*, COALESCE(st.stream, '') as stream,
               COALESCE(st.father_name, '') as father_name,
               COALESCE(st.mother_name, '') as mother_name,
               COALESCE(st.residential_address, '') as residential_address,
               COALESCE(NULLIF(st.contact_no, ''), st.guardian_phone, '') as contact_no,
               COALESCE(st.aapaar_id, '') as aapaar_id,
               COALESCE(st.photo_url, '') as photo_url,
               c.name as class_name, COALESCE(c.has_sections, 1) as has_sections, s.name as section_name,
               (SELECT COUNT(*) FROM marks m WHERE m.student_id = st.id) as marks_count
        FROM students st
        JOIN classes c ON c.id = st.class_id
        JOIN sections s ON s.id = st.section_id
        ${where.length ? 'WHERE ' + where.join(' AND ') : ''}
        ORDER BY ${orderClause}
      `
      : `
        SELECT st.id, st.student_code, st.full_name, st.gender, st.guardian_name, st.guardian_phone,
               COALESCE(st.father_name, '') as father_name,
               COALESCE(st.mother_name, '') as mother_name,
               COALESCE(st.residential_address, '') as residential_address,
               COALESCE(NULLIF(st.contact_no, ''), st.guardian_phone, '') as contact_no,
               COALESCE(st.aapaar_id, '') as aapaar_id,
               COALESCE(st.photo_url, '') as photo_url,
               st.is_deleted, st.deleted_at,
               st.created_at, st.updated_at,
               se.roll_number, se.class_id, c.name as class_name, COALESCE(c.has_sections, 1) as has_sections,
               se.section_id, s.name as section_name,
               se.academic_year, se.status,
               COALESCE(NULLIF(se.stream, ''), st.stream, '') as stream,
               (SELECT COUNT(*) FROM marks m WHERE m.student_id = st.id) as marks_count
        FROM student_enrollments se
        JOIN students st ON st.id = se.student_id
        JOIN classes c ON c.id = se.class_id
        JOIN sections s ON s.id = se.section_id
        ${where.length ? 'WHERE ' + where.join(' AND ') : ''}
        ORDER BY ${orderClause}
      `;

    const rows = db.prepare(sql).all(...params) as Array<any>;
    const electiveRows = (
      useAll
        ? db
            .prepare(
              `SELECT se.student_id, se.subject_id as subjectId, sub.name as subjectName,
                      se.component_id as componentId, sc.name as componentName
               FROM student_electives se
               JOIN subjects sub ON sub.id = se.subject_id
               JOIN subject_components sc ON sc.id = se.component_id`
            )
            .all()
        : db
            .prepare(
              `SELECT sye.student_id, sye.subject_id as subjectId, sub.name as subjectName,
                      sye.component_id as componentId, sc.name as componentName
               FROM student_year_electives sye
               JOIN subjects sub ON sub.id = sye.subject_id
               JOIN subject_components sc ON sc.id = sye.component_id
               WHERE sye.academic_year = ?`
            )
            .all(targetYear)
    ) as Array<{
      student_id: number;
      subjectId: number;
      subjectName: string;
      componentId: number;
      componentName: string;
    }>;

    const electiveMap = new Map<
      number,
      Array<{ subjectId: number; subjectName: string; componentId: number; componentName: string }>
    >();
    for (const er of electiveRows) {
      const list = electiveMap.get(er.student_id) ?? [];
      list.push({
        subjectId: er.subjectId,
        subjectName: er.subjectName,
        componentId: er.componentId,
        componentName: er.componentName,
      });
      electiveMap.set(er.student_id, list);
    }

    const customSubMap = new Map<number, number[]>();
    const yearSubRows = db
      .prepare(`SELECT student_id, subject_id FROM student_year_subjects WHERE academic_year = ?`)
      .all(targetYear) as Array<{ student_id: number; subject_id: number }>;
    for (const r of yearSubRows) {
      const arr = customSubMap.get(r.student_id) ?? [];
      arr.push(r.subject_id);
      customSubMap.set(r.student_id, arr);
    }
    const baseSubRows = db
      .prepare(`SELECT student_id, subject_id FROM student_subjects`)
      .all() as Array<{ student_id: number; subject_id: number }>;
    for (const r of baseSubRows) {
      if (customSubMap.has(r.student_id)) continue;
      const arr = customSubMap.get(r.student_id) ?? [];
      arr.push(r.subject_id);
      customSubMap.set(r.student_id, arr);
    }

    const optOutMap = new Map<number, number[]>();
    const optOutRows = db
      .prepare(`SELECT student_id, subject_id FROM student_elective_opt_outs WHERE academic_year = ?`)
      .all(targetYear) as Array<{ student_id: number; subject_id: number }>;
    for (const r of optOutRows) {
      const arr = optOutMap.get(r.student_id) ?? [];
      arr.push(r.subject_id);
      optOutMap.set(r.student_id, arr);
    }

    res.json(
      rows.map((r) => ({
        ...r,
        hasSections: Boolean(r.has_sections ?? 1),
        stream: r.stream || '',
        isDeleted: Boolean(r.is_deleted),
        marksCount: Number(r.marks_count || 0),
        electives: electiveMap.get(r.id) ?? [],
        enrolledSubjectIds: customSubMap.get(r.id) ?? [],
        electiveOptOutSubjectIds: optOutMap.get(r.id) ?? [],
      }))
    );
  } catch (err: any) {
    console.error('Error loading /api/admin/students:', err);
    res.status(500).json({ error: err?.message || 'Database error while loading student directory.' });
  }
});

function getStudentRecordById(studentId: number, academicYear?: string) {
  const year = academicYear && academicYear !== 'all' ? academicYear : undefined;
  let row: any = null;
  if (year) {
    row = db
      .prepare(
        `SELECT st.id, st.student_code, st.full_name, st.gender, st.guardian_name, st.guardian_phone,
                COALESCE(st.father_name, '') as father_name,
                COALESCE(st.mother_name, '') as mother_name,
                COALESCE(st.residential_address, '') as residential_address,
                COALESCE(NULLIF(st.contact_no, ''), st.guardian_phone, '') as contact_no,
                COALESCE(st.aapaar_id, '') as aapaar_id,
                COALESCE(st.photo_url, '') as photo_url,
                st.is_deleted, st.deleted_at,
                st.created_at, st.updated_at,
                se.roll_number, se.class_id, c.name as class_name, COALESCE(c.has_sections, 1) as has_sections,
                se.section_id, s.name as section_name,
                se.academic_year, se.status,
                COALESCE(NULLIF(se.stream, ''), st.stream, '') as stream,
                (SELECT COUNT(*) FROM marks m WHERE m.student_id = st.id) as marks_count
         FROM student_enrollments se
         JOIN students st ON st.id = se.student_id
         JOIN classes c ON c.id = se.class_id
         JOIN sections s ON s.id = se.section_id
         WHERE st.id = ? AND se.academic_year = ?`
      )
      .get(studentId, year);
  }
  if (!row) {
    row = db
      .prepare(
        `SELECT st.*, COALESCE(st.stream, '') as stream,
                COALESCE(st.father_name, '') as father_name,
                COALESCE(st.mother_name, '') as mother_name,
                COALESCE(st.residential_address, '') as residential_address,
                COALESCE(NULLIF(st.contact_no, ''), st.guardian_phone, '') as contact_no,
                COALESCE(st.aapaar_id, '') as aapaar_id,
                COALESCE(st.photo_url, '') as photo_url,
                c.name as class_name, COALESCE(c.has_sections, 1) as has_sections, s.name as section_name,
                (SELECT COUNT(*) FROM marks m WHERE m.student_id = st.id) as marks_count
         FROM students st
         JOIN classes c ON c.id = st.class_id
         JOIN sections s ON s.id = st.section_id
         WHERE st.id = ?`
      )
      .get(studentId);
  }
  if (!row) return null;

  const effYear = year || row.academic_year || getCurrentAcademicYear();
  const electiveRows = (
    year
      ? db
          .prepare(
            `SELECT sye.subject_id as subjectId, sub.name as subjectName,
                    sye.component_id as componentId, sc.name as componentName
             FROM student_year_electives sye
             JOIN subjects sub ON sub.id = sye.subject_id
             JOIN subject_components sc ON sc.id = sye.component_id
             WHERE sye.student_id = ? AND sye.academic_year = ?`
          )
          .all(studentId, year)
      : db
          .prepare(
            `SELECT se.subject_id as subjectId, sub.name as subjectName,
                    se.component_id as componentId, sc.name as componentName
             FROM student_electives se
             JOIN subjects sub ON sub.id = se.subject_id
             JOIN subject_components sc ON sc.id = se.component_id
             WHERE se.student_id = ?`
          )
          .all(studentId)
  ) as Array<{
    subjectId: number;
    subjectName: string;
    componentId: number;
    componentName: string;
  }>;

  const yearCustomSubs = (
    db
      .prepare(`SELECT subject_id FROM student_year_subjects WHERE student_id = ? AND academic_year = ?`)
      .all(studentId, effYear) as Array<{ subject_id: number }>
  ).map((r) => r.subject_id);
  const enrolledSubjectIds =
    yearCustomSubs.length > 0
      ? yearCustomSubs
      : (
          db
            .prepare(`SELECT subject_id FROM student_subjects WHERE student_id = ?`)
            .all(studentId) as Array<{ subject_id: number }>
        ).map((r) => r.subject_id);

  const electiveOptOutSubjectIds = (
    db
      .prepare(`SELECT subject_id FROM student_elective_opt_outs WHERE student_id = ? AND academic_year = ?`)
      .all(studentId, effYear) as Array<{ subject_id: number }>
  ).map((r) => r.subject_id);

  return {
    ...row,
    hasSections: Boolean(row.has_sections ?? 1),
    stream: row.stream || '',
    isDeleted: Boolean(row.is_deleted),
    marksCount: Number(row.marks_count || 0),
    electives: electiveRows,
    enrolledSubjectIds,
    electiveOptOutSubjectIds,
  };
}

function resolveDefaultSectionForClass(classId: number): number | null {
  const row = db
    .prepare(
      `SELECT id FROM sections WHERE class_id = ? AND COALESCE(is_deleted, 0) = 0 ORDER BY id ASC LIMIT 1`
    )
    .get(classId) as { id: number } | undefined;
  return row?.id ?? null;
}

function normalizeStudentStream(stream: string | undefined | null): '' | 'Science' | 'Humanities' {
  const val = String(stream || '').trim();
  if (val === 'Science' || val === 'Humanities') return val;
  return '';
}

function validateStudentPhotoInput(raw: unknown): string | undefined {
  if (raw === undefined) return undefined;
  const trimmed = String(raw ?? '').trim();
  if (!trimmed) return '';
  const dataMatch = trimmed.match(/^data:image\/(jpeg|jpg|png|webp);base64,([A-Za-z0-9+/=]+)$/i);
  if (dataMatch) {
    const byteLen = Buffer.from(dataMatch[2], 'base64').byteLength;
    if (byteLen > 100 * 1024) {
      throw new Error('Student photo must be smaller than 100 KB after compression.');
    }
    return trimmed;
  }
  if (/^(\/assets\/|https?:\/\/)/i.test(trimmed)) {
    return trimmed;
  }
  throw new Error('Invalid student photo format. Please upload or capture a JPG, PNG, or WebP image.');
}

app.post('/api/admin/students', requireAuth, requireAdmin, (req: AuthenticatedRequest, res) => {
  const {
    studentCode,
    fullName,
    rollNumber,
    classId,
    sectionId,
    academicYear,
    stream,
    gender,
    guardianName,
    guardianPhone,
    fatherName,
    motherName,
    residentialAddress,
    contactNo,
    aapaarId,
    photoUrl,
    photo_url,
    electives,
    enrolledSubjectIds,
    electiveOptOutSubjectIds,
  } = req.body as {
    studentCode?: string;
    fullName?: string;
    rollNumber?: number;
    classId?: number;
    sectionId?: number;
    academicYear?: string;
    stream?: string;
    gender?: string;
    guardianName?: string;
    guardianPhone?: string;
    fatherName?: string;
    motherName?: string;
    residentialAddress?: string;
    contactNo?: string;
    aapaarId?: string;
    photoUrl?: string;
    photo_url?: string;
    electives?: Array<{ subjectId: number; componentId: number }>;
    enrolledSubjectIds?: number[];
    electiveOptOutSubjectIds?: number[];
  };

  let cleanPhotoUrl = '';
  try {
    cleanPhotoUrl = validateStudentPhotoInput(photoUrl !== undefined ? photoUrl : photo_url) ?? '';
  } catch (err: any) {
    return res.status(400).json({ error: err?.message || 'Invalid student photo.' });
  }

  const resolvedSectionId = sectionId ? Number(sectionId) : classId ? resolveDefaultSectionForClass(Number(classId)) : null;

  if (!fullName?.trim() || !classId || !resolvedSectionId || !rollNumber) {
    return res.status(400).json({ error: 'Student name, roll number, class, and section are required.' });
  }

  const normalizedStream = normalizeStudentStream(stream);
  const currentYear = getCurrentAcademicYear();
  const year = academicYear && academicYear !== 'all' && academicYear.trim() ? academicYear.trim() : currentYear;

  const duplicateRoll = db
    .prepare(
      `SELECT se.id FROM student_enrollments se
       JOIN students st ON st.id = se.student_id
       WHERE se.class_id = ? AND se.section_id = ? AND se.roll_number = ? AND se.academic_year = ?
         AND se.status = 'active' AND COALESCE(st.is_deleted, 0) = 0`
    )
    .get(Number(classId), resolvedSectionId, Number(rollNumber), year);
  if (duplicateRoll) {
    return res.status(409).json({ error: `Roll number ${rollNumber} is already assigned in this class/section for ${year}.` });
  }

  let code = studentCode?.trim();
  if (code) {
    const dupCode = db
      .prepare(`SELECT id FROM students WHERE lower(student_code) = lower(?)`)
      .get(code);
    if (dupCode) {
      return res.status(409).json({ error: `Student ID "${code}" is already registered.` });
    }
  } else {
    let nextNum = (db.prepare(`SELECT COALESCE(MAX(id), 0) as m FROM students`).get() as { m: number }).m + 1;
    code = `ST${String(nextNum).padStart(3, '0')}`;
    while (db.prepare(`SELECT 1 FROM students WHERE lower(student_code) = lower(?)`).get(code)) {
      nextNum += 1;
      code = `ST${String(nextNum).padStart(3, '0')}`;
    }
  }

  const cleanFatherName = (fatherName ?? '').trim();
  const cleanMotherName = (motherName ?? '').trim();
  const cleanAddress = (residentialAddress ?? '').trim();
  const cleanContactNo = (contactNo ?? '').trim() || (guardianPhone ?? '').trim();
  const cleanGuardianPhone = (guardianPhone ?? '').trim() || cleanContactNo;
  const cleanAapaarId = (aapaarId ?? '').trim();

  try {
    const studentId = db.transaction(() => {
      db.prepare(`INSERT OR IGNORE INTO academic_years (name, is_current, is_deleted) VALUES (?, ?, 0)`).run(
        year,
        year === currentYear ? 1 : 0
      );

      const result = db
        .prepare(
          `INSERT INTO students (
             student_code, full_name, roll_number, class_id, section_id, academic_year, stream, gender,
             guardian_name, guardian_phone, father_name, mother_name, residential_address, contact_no, aapaar_id, photo_url,
             status, is_deleted
           )
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'active', 0)`
        )
        .run(
          code!,
          fullName.trim(),
          Number(rollNumber),
          Number(classId),
          resolvedSectionId,
          year,
          normalizedStream,
          gender || 'Not Specified',
          guardianName || '',
          cleanGuardianPhone,
          cleanFatherName,
          cleanMotherName,
          cleanAddress,
          cleanContactNo,
          cleanAapaarId,
          cleanPhotoUrl
        );
      const stId = Number(result.lastInsertRowid);

      db.prepare(
        `INSERT INTO student_enrollments (student_id, academic_year, class_id, section_id, roll_number, stream, status)
         VALUES (?, ?, ?, ?, ?, ?, 'active')`
      ).run(stId, year, Number(classId), resolvedSectionId, Number(rollNumber), normalizedStream);

      const optOutSubIds = Array.isArray(electiveOptOutSubjectIds)
        ? Array.from(new Set(electiveOptOutSubjectIds.map(Number).filter((n) => n > 0)))
        : [];
      const optOutSet = new Set(optOutSubIds);
      if (optOutSubIds.length > 0) {
        const insOptOut = db.prepare(
          `INSERT OR IGNORE INTO student_elective_opt_outs (student_id, academic_year, subject_id) VALUES (?, ?, ?)`
        );
        for (const subId of optOutSubIds) {
          insOptOut.run(stId, year, subId);
        }
      }

      if (Array.isArray(electives)) {
        const upsertElective = db.prepare(
          `INSERT INTO student_electives (student_id, subject_id, component_id) VALUES (?, ?, ?)
           ON CONFLICT(student_id, subject_id) DO UPDATE SET component_id = excluded.component_id`
        );
        const upsertYearElective = db.prepare(
          `INSERT INTO student_year_electives (student_id, academic_year, subject_id, component_id) VALUES (?, ?, ?, ?)
           ON CONFLICT(student_id, academic_year, subject_id) DO UPDATE SET component_id = excluded.component_id`
        );
        for (const el of electives) {
          if (el.subjectId && el.componentId && !optOutSet.has(Number(el.subjectId))) {
            upsertElective.run(stId, Number(el.subjectId), Number(el.componentId));
            upsertYearElective.run(stId, year, Number(el.subjectId), Number(el.componentId));
          }
        }
      }

      if (Array.isArray(enrolledSubjectIds) && enrolledSubjectIds.length > 0) {
        const cleanSubIds = Array.from(new Set(enrolledSubjectIds.map(Number).filter((n) => n > 0)));
        const insSub = db.prepare(`INSERT OR IGNORE INTO student_subjects (student_id, subject_id) VALUES (?, ?)`);
        const insYearSub = db.prepare(
          `INSERT OR IGNORE INTO student_year_subjects (student_id, academic_year, subject_id) VALUES (?, ?, ?)`
        );
        for (const subId of cleanSubIds) {
          insSub.run(stId, subId);
          insYearSub.run(stId, year, subId);
        }
      }
      return stId;
    })();

    logAudit(req.user!, 'CREATE_STUDENT', 'student', studentId, {
      studentCode: code,
      fullName: fullName.trim(),
      classId,
      sectionId: resolvedSectionId,
      rollNumber,
      stream: normalizedStream,
      academicYear: year,
    });
    const student = getStudentRecordById(studentId, year);
    res.status(201).json({ id: studentId, studentCode: code, academicYear: year, student });
  } catch (err: any) {
    res.status(400).json({ error: err.message || 'Could not create student.' });
  }
});

app.put('/api/admin/students/:id', requireAuth, requireAdmin, (req: AuthenticatedRequest, res) => {
  const id = Number(req.params.id);
  const {
    studentCode,
    fullName,
    rollNumber,
    classId,
    sectionId,
    academicYear,
    stream,
    gender,
    guardianName,
    guardianPhone,
    fatherName,
    motherName,
    residentialAddress,
    contactNo,
    aapaarId,
    photoUrl,
    photo_url,
    status,
    electives,
    enrolledSubjectIds,
    electiveOptOutSubjectIds,
  } = req.body as {
    studentCode?: string;
    fullName?: string;
    rollNumber?: number;
    classId?: number;
    sectionId?: number;
    academicYear?: string;
    stream?: string;
    gender?: string;
    guardianName?: string;
    guardianPhone?: string;
    fatherName?: string;
    motherName?: string;
    residentialAddress?: string;
    contactNo?: string;
    aapaarId?: string;
    photoUrl?: string;
    photo_url?: string;
    status?: string;
    electives?: Array<{ subjectId: number; componentId: number }>;
    enrolledSubjectIds?: number[];
    electiveOptOutSubjectIds?: number[];
  };

  let incomingPhotoUrl: string | undefined;
  try {
    incomingPhotoUrl = validateStudentPhotoInput(photoUrl !== undefined ? photoUrl : photo_url);
  } catch (err: any) {
    return res.status(400).json({ error: err?.message || 'Invalid student photo.' });
  }

  const existing = db.prepare(`SELECT * FROM students WHERE id = ?`).get(id) as any;
  if (!existing) return res.status(404).json({ error: 'Student not found.' });

  const currentYear = getCurrentAcademicYear();
  const safeIncomingYear = academicYear && academicYear !== 'all' && academicYear.trim() ? academicYear.trim() : undefined;
  const targetYear = safeIncomingYear ?? existing.academic_year ?? currentYear;
  const existingEnrollment = db
    .prepare(`SELECT * FROM student_enrollments WHERE student_id = ? AND academic_year = ?`)
    .get(id, targetYear) as any;

  const targetCode = studentCode !== undefined && studentCode.trim() ? studentCode.trim() : existing.student_code;
  if (targetCode.toLowerCase() !== String(existing.student_code).toLowerCase()) {
    const dupCode = db
      .prepare(`SELECT id FROM students WHERE lower(student_code) = lower(?) AND id != ?`)
      .get(targetCode, id);
    if (dupCode) {
      return res.status(409).json({ error: `Student ID "${targetCode}" is already assigned to another student.` });
    }
  }

  const targetClass = Number(classId ?? existingEnrollment?.class_id ?? existing.class_id);
  let targetSection = Number(sectionId ?? existingEnrollment?.section_id ?? existing.section_id);
  if (classId && !sectionId) {
    targetSection = resolveDefaultSectionForClass(targetClass) ?? targetSection;
  }
  const targetRoll = Number(rollNumber ?? existingEnrollment?.roll_number ?? existing.roll_number);
  const targetStatus = status ?? existingEnrollment?.status ?? existing.status;
  const targetStream =
    stream !== undefined
      ? normalizeStudentStream(stream)
      : normalizeStudentStream(existingEnrollment?.stream || existing.stream);

  if (targetStatus === 'active' && !existing.is_deleted) {
    const conflict = db
      .prepare(
        `SELECT se.student_id FROM student_enrollments se
         JOIN students st ON st.id = se.student_id
         WHERE se.class_id = ? AND se.section_id = ? AND se.roll_number = ? AND se.academic_year = ?
           AND se.status = 'active' AND COALESCE(st.is_deleted, 0) = 0 AND se.student_id != ?`
      )
      .get(targetClass, targetSection, targetRoll, targetYear, id);
    if (conflict) {
      return res.status(409).json({ error: `Roll number ${targetRoll} is already taken in the selected section.` });
    }
  }

  try {
    db.transaction(() => {
      db.prepare(`INSERT OR IGNORE INTO academic_years (name, is_current, is_deleted) VALUES (?, ?, 0)`).run(
        targetYear,
        targetYear === currentYear ? 1 : 0
      );

      const nextFatherName = fatherName !== undefined ? fatherName.trim() : existing.father_name || '';
      const nextMotherName = motherName !== undefined ? motherName.trim() : existing.mother_name || '';
      const nextAddress =
        residentialAddress !== undefined ? residentialAddress.trim() : existing.residential_address || '';
      const nextContactNo =
        contactNo !== undefined
          ? contactNo.trim()
          : existing.contact_no || (guardianPhone !== undefined ? guardianPhone.trim() : existing.guardian_phone || '');
      const nextGuardianPhone =
        guardianPhone !== undefined ? guardianPhone.trim() : existing.guardian_phone || nextContactNo;
      const nextAapaarId = aapaarId !== undefined ? aapaarId.trim() : existing.aapaar_id || '';
      const nextPhotoUrl = incomingPhotoUrl !== undefined ? incomingPhotoUrl : existing.photo_url || '';

      const shouldUpdateMasterPlacement = targetYear === currentYear || targetYear === existing.academic_year;
      if (shouldUpdateMasterPlacement) {
        db.prepare(
          `UPDATE students
           SET student_code = ?, full_name = ?, roll_number = ?, class_id = ?, section_id = ?, academic_year = ?, stream = ?,
               gender = ?, guardian_name = ?, guardian_phone = ?,
               father_name = ?, mother_name = ?, residential_address = ?, contact_no = ?, aapaar_id = ?, photo_url = ?,
               status = ?, updated_at = datetime('now')
           WHERE id = ?`
        ).run(
          targetCode,
          fullName !== undefined ? fullName.trim() : existing.full_name,
          targetRoll,
          targetClass,
          targetSection,
          targetYear,
          targetStream,
          gender ?? existing.gender,
          guardianName ?? existing.guardian_name,
          nextGuardianPhone,
          nextFatherName,
          nextMotherName,
          nextAddress,
          nextContactNo,
          nextAapaarId,
          nextPhotoUrl,
          targetStatus,
          id
        );
      } else {
        db.prepare(
          `UPDATE students
           SET student_code = ?, full_name = ?, gender = ?, guardian_name = ?, guardian_phone = ?,
               father_name = ?, mother_name = ?, residential_address = ?, contact_no = ?, aapaar_id = ?, photo_url = ?,
               updated_at = datetime('now')
           WHERE id = ?`
        ).run(
          targetCode,
          fullName !== undefined ? fullName.trim() : existing.full_name,
          gender ?? existing.gender,
          guardianName ?? existing.guardian_name,
          nextGuardianPhone,
          nextFatherName,
          nextMotherName,
          nextAddress,
          nextContactNo,
          nextAapaarId,
          nextPhotoUrl,
          id
        );
      }

      db.prepare(
        `INSERT INTO student_enrollments (student_id, academic_year, class_id, section_id, roll_number, stream, status)
         VALUES (?, ?, ?, ?, ?, ?, ?)
         ON CONFLICT(student_id, academic_year) DO UPDATE SET
           class_id = excluded.class_id,
           section_id = excluded.section_id,
           roll_number = excluded.roll_number,
           stream = excluded.stream,
           status = excluded.status`
      ).run(id, targetYear, targetClass, targetSection, targetRoll, targetStream, targetStatus);

      let optOutSet = new Set<number>();
      if (Array.isArray(electiveOptOutSubjectIds)) {
        const cleanOptOutIds = Array.from(new Set(electiveOptOutSubjectIds.map(Number).filter((n) => n > 0)));
        optOutSet = new Set(cleanOptOutIds);
        db.prepare(`DELETE FROM student_elective_opt_outs WHERE student_id = ? AND academic_year = ?`).run(id, targetYear);
        const insOptOut = db.prepare(
          `INSERT OR IGNORE INTO student_elective_opt_outs (student_id, academic_year, subject_id) VALUES (?, ?, ?)`
        );
        for (const subId of cleanOptOutIds) {
          insOptOut.run(id, targetYear, subId);
          db.prepare(`DELETE FROM student_year_electives WHERE student_id = ? AND academic_year = ? AND subject_id = ?`).run(
            id,
            targetYear,
            subId
          );
          if (shouldUpdateMasterPlacement) {
            db.prepare(`DELETE FROM student_electives WHERE student_id = ? AND subject_id = ?`).run(id, subId);
          }
        }
      }

      if (Array.isArray(electives)) {
        const upsertElective = db.prepare(
          `INSERT INTO student_electives (student_id, subject_id, component_id) VALUES (?, ?, ?)
           ON CONFLICT(student_id, subject_id) DO UPDATE SET component_id = excluded.component_id`
        );
        const upsertYearElective = db.prepare(
          `INSERT INTO student_year_electives (student_id, academic_year, subject_id, component_id) VALUES (?, ?, ?, ?)
           ON CONFLICT(student_id, academic_year, subject_id) DO UPDATE SET component_id = excluded.component_id`
        );
        for (const el of electives) {
          if (el.subjectId && el.componentId && !optOutSet.has(Number(el.subjectId))) {
            if (shouldUpdateMasterPlacement) {
              upsertElective.run(id, Number(el.subjectId), Number(el.componentId));
            }
            upsertYearElective.run(id, targetYear, Number(el.subjectId), Number(el.componentId));
          }
        }
      }

      if (Array.isArray(enrolledSubjectIds)) {
        const cleanSubIds = Array.from(new Set(enrolledSubjectIds.map(Number).filter((n) => n > 0)));
        db.prepare(`DELETE FROM student_year_subjects WHERE student_id = ? AND academic_year = ?`).run(id, targetYear);
        const insYearSub = db.prepare(
          `INSERT OR IGNORE INTO student_year_subjects (student_id, academic_year, subject_id) VALUES (?, ?, ?)`
        );
        for (const subId of cleanSubIds) {
          insYearSub.run(id, targetYear, subId);
        }
        if (shouldUpdateMasterPlacement) {
          db.prepare(`DELETE FROM student_subjects WHERE student_id = ?`).run(id);
          const insSub = db.prepare(`INSERT OR IGNORE INTO student_subjects (student_id, subject_id) VALUES (?, ?)`);
          for (const subId of cleanSubIds) {
            insSub.run(id, subId);
          }
        }
      }
    })();
  } catch (err: any) {
    return res.status(400).json({ error: err?.message || 'Could not update student record.' });
  }

  logAudit(req.user!, 'UPDATE_STUDENT', 'student', id, {
    studentCode: targetCode,
    fullName,
    academicYear: targetYear,
    targetClass,
    targetSection,
    targetRoll,
    stream: targetStream,
    status: targetStatus,
  });
  const student = getStudentRecordById(id, targetYear);
  res.json({ success: true, academicYear: targetYear, student });
});

app.post('/api/admin/students/:id/transfer', requireAuth, requireAdmin, (req: AuthenticatedRequest, res) => {
  const id = Number(req.params.id);
  const { targetClassId, targetSectionId, newRollNumber, academicYear } = req.body as {
    targetClassId: number;
    targetSectionId?: number;
    newRollNumber?: number;
    academicYear?: string;
  };

  const resolvedTargetSectionId = targetSectionId
    ? Number(targetSectionId)
    : targetClassId
      ? resolveDefaultSectionForClass(Number(targetClassId))
      : null;
  if (!targetClassId || !resolvedTargetSectionId) {
    return res.status(400).json({ error: 'Target class and section are required.' });
  }

  const student = db.prepare(`SELECT * FROM students WHERE id = ?`).get(id) as any;
  if (!student) return res.status(404).json({ error: 'Student not found.' });

  const currentYear = getCurrentAcademicYear();
  const targetYear = academicYear || currentYear;

  const maxRollRow = db
    .prepare(
      `SELECT COALESCE(MAX(se.roll_number), 0) as max_roll
       FROM student_enrollments se
       JOIN students st ON st.id = se.student_id
       WHERE se.class_id = ? AND se.section_id = ? AND se.academic_year = ?
         AND se.status = 'active' AND COALESCE(st.is_deleted, 0) = 0`
    )
    .get(targetClassId, resolvedTargetSectionId, targetYear) as { max_roll: number };

  const assignedRoll = newRollNumber ? Number(newRollNumber) : maxRollRow.max_roll + 1;

  const conflict = db
    .prepare(
      `SELECT se.student_id
       FROM student_enrollments se
       JOIN students st ON st.id = se.student_id
       WHERE se.class_id = ? AND se.section_id = ? AND se.roll_number = ? AND se.academic_year = ?
         AND se.status = 'active' AND COALESCE(st.is_deleted, 0) = 0 AND se.student_id != ?`
    )
    .get(targetClassId, resolvedTargetSectionId, assignedRoll, targetYear, id);

  if (conflict) {
    return res.status(409).json({ error: `Roll number ${assignedRoll} already exists in target section.` });
  }

  try {
    db.transaction(() => {
      db.prepare(
        `INSERT INTO student_enrollments (student_id, academic_year, class_id, section_id, roll_number, stream, status)
         VALUES (?, ?, ?, ?, ?, ?, 'active')
         ON CONFLICT(student_id, academic_year) DO UPDATE SET
           class_id = excluded.class_id,
           section_id = excluded.section_id,
           roll_number = excluded.roll_number,
           status = 'active'`
      ).run(id, targetYear, targetClassId, resolvedTargetSectionId, assignedRoll, normalizeStudentStream(student.stream));

      if (targetYear === currentYear || targetYear === student.academic_year) {
        db.prepare(
          `UPDATE students SET class_id = ?, section_id = ?, roll_number = ?, updated_at = datetime('now') WHERE id = ?`
        ).run(targetClassId, resolvedTargetSectionId, assignedRoll, id);
      }
    })();
  } catch (err: any) {
    return res.status(400).json({ error: err?.message || 'Could not transfer student.' });
  }

  logAudit(req.user!, 'TRANSFER_STUDENT', 'student', id, {
    academicYear: targetYear,
    fromClassId: student.class_id,
    fromSectionId: student.section_id,
    toClassId: targetClassId,
    toSectionId: resolvedTargetSectionId,
    newRollNumber: assignedRoll,
  });

  const updatedStudent = getStudentRecordById(id, targetYear);
  res.json({ success: true, newRollNumber: assignedRoll, student: updatedStudent });
});

function suggestNextAcademicYearName(current: string): string {
  const match = current.match(/^(\d{4})-(\d{2,4})$/);
  if (!match) return `${current}-next`;
  const start = Number(match[1]) + 1;
  if (match[2].length === 2) {
    return `${start}-${String((start + 1) % 100).padStart(2, '0')}`;
  }
  return `${start}-${start + 1}`;
}

function verifyPromotionAccess(
  user: AuthenticatedRequest['user'],
  classId: number,
  sourceYear: string,
  requestedSectionId?: number | null
): { allowed: boolean; isAdmin: boolean; allowedSectionIds: number[] | null; error?: string } {
  if (!user) {
    return { allowed: false, isAdmin: false, allowedSectionIds: [], error: 'Authentication required.' };
  }
  if (user.roles.includes('admin')) {
    return { allowed: true, isAdmin: true, allowedSectionIds: null };
  }
  const rows = db
    .prepare(
      `SELECT section_id FROM class_teacher_assignments
       WHERE teacher_id = ? AND class_id = ? AND academic_year = ?`
    )
    .all(user.id, classId, sourceYear) as Array<{ section_id: number }>;

  if (rows.length === 0) {
    return {
      allowed: false,
      isAdmin: false,
      allowedSectionIds: [],
      error: 'Access denied: Only administrators or the assigned Class Teacher for this class and academic year can promote or undo promotions.',
    };
  }
  const allowedSectionIds = rows.map((r) => r.section_id);
  if (requestedSectionId && !allowedSectionIds.includes(requestedSectionId)) {
    return {
      allowed: false,
      isAdmin: false,
      allowedSectionIds,
      error: 'Access denied: You are not the assigned Class Teacher for the requested section.',
    };
  }
  return { allowed: true, isAdmin: false, allowedSectionIds };
}

function handleGetPromotionCandidates(req: AuthenticatedRequest, res: express.Response) {
  const {
    sourceAcademicYear,
    targetAcademicYear,
    classId,
    sectionId,
    examinationId,
  } = req.query as Record<string, string | undefined>;

  const sourceYear = (sourceAcademicYear || getCurrentAcademicYear()).trim();
  const targetYear = (targetAcademicYear || suggestNextAcademicYearName(sourceYear)).trim();
  const parsedClassId = Number(classId);

  if (!parsedClassId) {
    return res.status(400).json({ error: 'classId is required.' });
  }

  const parsedSectionId = sectionId ? Number(sectionId) : null;
  const access = verifyPromotionAccess(req.user, parsedClassId, sourceYear, parsedSectionId);
  if (!access.allowed) {
    return res.status(403).json({ error: access.error || 'Access denied.' });
  }

  const classes = db
    .prepare(`SELECT id, name, numeric_order, COALESCE(has_sections, 1) as has_sections FROM classes WHERE is_active = 1 AND COALESCE(is_deleted, 0) = 0 ORDER BY numeric_order ASC`)
    .all() as Array<{ id: number; name: string; numeric_order: number; has_sections: number }>;

  const sourceClassIdx = classes.findIndex((c) => c.id === parsedClassId);
  if (sourceClassIdx === -1) {
    return res.status(404).json({ error: 'Source class not found.' });
  }
  const sourceClass = classes[sourceClassIdx];
  const nextClass = classes[sourceClassIdx + 1] ?? null;

  const targetYearExists = Boolean(
    db.prepare(`SELECT 1 FROM academic_years WHERE name = ? AND COALESCE(is_deleted, 0) = 0`).get(targetYear)
  );

  // Determine available examinations in sourceAcademicYear (with flag indicating whether marks exist)
  const examsRaw = db
    .prepare(
      `SELECT ex.id, ex.name, ex.status, ex.passing_percentage,
              (SELECT COUNT(*) FROM marks m WHERE m.examination_id = ex.id) as mark_count
       FROM examinations ex
       WHERE ex.academic_year = ? AND COALESCE(ex.is_deleted, 0) = 0
       ORDER BY
         CASE WHEN lower(ex.name) LIKE '%annual%' THEN 0 WHEN lower(ex.name) LIKE '%half%' THEN 1 ELSE 2 END ASC,
         ex.start_date DESC, ex.id DESC`
    )
    .all(sourceYear) as Array<{
    id: number;
    name: string;
    status: string;
    passing_percentage: number;
    mark_count: number;
  }>;

  const availableExaminations = examsRaw.map((e) => ({
    id: e.id,
    name: e.name,
    status: e.status,
    passingPercentage: e.passing_percentage,
    hasMarks: Number(e.mark_count || 0) > 0,
  }));

  let selectedExamId: number | null = null;
  if (examinationId === 'none') {
    selectedExamId = null;
  } else if (examinationId && Number(examinationId)) {
    const match = availableExaminations.find((e) => e.id === Number(examinationId));
    selectedExamId = match ? match.id : null;
  } else if (availableExaminations.length > 0) {
    // Prefer an exam that already has marks entered (prioritizing Annual -> Half-Yearly -> latest)
    const withMarks = availableExaminations.find((e) => e.hasMarks);
    selectedExamId = withMarks ? withMarks.id : availableExaminations[0].id;
  }

  // Fetch source enrollments (scoped to allowed sections for Class Teacher)
  const queryParams: Array<string | number> = [sourceYear, parsedClassId];
  let sectionClause = '';
  if (parsedSectionId) {
    sectionClause = 'AND se.section_id = ?';
    queryParams.push(parsedSectionId);
  } else if (!access.isAdmin && access.allowedSectionIds && access.allowedSectionIds.length > 0) {
    sectionClause = `AND se.section_id IN (${access.allowedSectionIds.map(() => '?').join(',')})`;
    queryParams.push(...access.allowedSectionIds);
  }

  const sourceRows = db
    .prepare(
      `SELECT st.id as student_id, st.student_code, st.full_name,
              COALESCE(NULLIF(se.stream, ''), st.stream, '') as stream,
              se.roll_number, se.class_id, c.name as class_name, COALESCE(c.has_sections, 1) as has_sections,
              se.section_id, s.name as section_name
       FROM student_enrollments se
       JOIN students st ON st.id = se.student_id
       JOIN classes c ON c.id = se.class_id
       JOIN sections s ON s.id = se.section_id
       WHERE se.academic_year = ? AND se.class_id = ? AND se.status = 'active'
         AND COALESCE(st.is_deleted, 0) = 0 AND COALESCE(s.is_deleted, 0) = 0
         ${sectionClause}
       ORDER BY s.name ASC, se.roll_number ASC, st.student_code ASC`
    )
    .all(...queryParams) as Array<{
    student_id: number;
    student_code: string;
    full_name: string;
    stream: string;
    roll_number: number;
    class_id: number;
    class_name: string;
    has_sections: number;
    section_id: number;
    section_name: string;
  }>;

  // Map next class sections by section name
  const nextSections = nextClass
    ? (db
        .prepare(`SELECT id, name FROM sections WHERE class_id = ? AND COALESCE(is_deleted, 0) = 0 ORDER BY name ASC`)
        .all(nextClass.id) as Array<{ id: number; name: string }>)
    : [];
  const nextSectionByName = new Map<string, { id: number; name: string }>();
  for (const ns of nextSections) {
    nextSectionByName.set(ns.name, ns);
  }
  const fallbackNextSection = nextSections[0] ?? null;

  // Existing enrollments in targetYear
  const targetEnrollmentRows = db
    .prepare(
      `SELECT se.student_id, se.roll_number, se.status, c.name as class_name, COALESCE(c.has_sections, 1) as has_sections, s.name as section_name
       FROM student_enrollments se
       JOIN classes c ON c.id = se.class_id
       JOIN sections s ON s.id = se.section_id
       WHERE se.academic_year = ?`
    )
    .all(targetYear) as Array<{
    student_id: number;
    roll_number: number;
    status: string;
    class_name: string;
    has_sections: number;
    section_name: string;
  }>;
  const targetByStudentId = new Map<number, (typeof targetEnrollmentRows)[number]>();
  for (const tr of targetEnrollmentRows) {
    targetByStudentId.set(tr.student_id, tr);
  }

  // Compute consolidated exam status per section if an exam is selected
  const resultByStudentId = new Map<
    number,
    {
      resultStatus: 'Pass' | 'Fail' | 'Incomplete';
      grandTotal: number | null;
      totalMaxMarks: number;
      percentage: number | null;
      grade: string | null;
      missingCount: number;
    }
  >();

  if (selectedExamId) {
    const distinctSections = Array.from(new Set(sourceRows.map((r) => r.section_id)));
    for (const secId of distinctSections) {
      try {
        const report = getConsolidatedResults(selectedExamId, parsedClassId, secId);
        for (const sr of report.students) {
          resultByStudentId.set(sr.studentId, {
            resultStatus: sr.resultStatus,
            grandTotal: sr.grandTotal,
            totalMaxMarks: sr.totalMaxMarks,
            percentage: sr.percentage,
            grade: sr.grade,
            missingCount: sr.missingComponents.length,
          });
        }
      } catch {
        // Ignore if section report fails
      }
    }
  }

  let passCount = 0;
  let failCount = 0;
  let incompleteCount = 0;
  let noExamCount = 0;
  let alreadyTransferredCount = 0;
  let eligiblePassCount = 0;

  const candidates = sourceRows.map((r) => {
    const examRes = resultByStudentId.get(r.student_id);
    const resultStatus: 'Pass' | 'Fail' | 'Incomplete' | 'No Exam' = examRes
      ? examRes.resultStatus
      : 'No Exam';

    if (resultStatus === 'Pass') passCount++;
    else if (resultStatus === 'Fail') failCount++;
    else if (resultStatus === 'Incomplete') incompleteCount++;
    else noExamCount++;

    const existingTarget = targetByStudentId.get(r.student_id) ?? null;
    const alreadyInTargetYear = Boolean(existingTarget);
    if (alreadyInTargetYear) alreadyTransferredCount++;
    if (!alreadyInTargetYear && resultStatus === 'Pass') eligiblePassCount++;

    const matchedNextSec = nextClass
      ? nextSectionByName.get(r.section_name) ?? fallbackNextSection
      : null;

    return {
      studentId: r.student_id,
      studentCode: r.student_code,
      fullName: r.full_name,
      stream: r.stream || '',
      rollNumber: r.roll_number,
      classId: r.class_id,
      className: r.class_name,
      hasSections: Boolean(r.has_sections ?? 1),
      sectionId: r.section_id,
      sectionName: r.section_name,
      targetClassId: nextClass?.id ?? null,
      targetClassName: nextClass ? nextClass.name : 'Graduated (Alumni)',
      targetHasSections: nextClass ? Boolean(nextClass.has_sections ?? 1) : true,
      targetSectionId: matchedNextSec?.id ?? null,
      targetSectionName: matchedNextSec?.name ?? null,
      targetStatus: nextClass ? ('active' as const) : ('graduated' as const),
      resultStatus,
      grandTotal: examRes?.grandTotal ?? null,
      totalMaxMarks: examRes?.totalMaxMarks ?? null,
      percentage: examRes?.percentage ?? null,
      grade: examRes?.grade ?? null,
      missingCount: examRes?.missingCount ?? 0,
      alreadyInTargetYear,
      targetEnrollment: existingTarget
        ? {
            className: existingTarget.class_name,
            hasSections: Boolean(existingTarget.has_sections ?? 1),
            sectionName: existingTarget.section_name,
            rollNumber: existingTarget.roll_number,
            status: existingTarget.status,
          }
        : null,
    };
  });

  res.json({
    sourceAcademicYear: sourceYear,
    targetAcademicYear: targetYear,
    targetYearExists,
    sourceClass: {
      id: sourceClass.id,
      name: sourceClass.name,
      numericOrder: sourceClass.numeric_order,
      hasSections: Boolean(sourceClass.has_sections ?? 1),
    },
    nextClass: nextClass
      ? {
          id: nextClass.id,
          name: nextClass.name,
          numericOrder: nextClass.numeric_order,
          hasSections: Boolean(nextClass.has_sections ?? 1),
        }
      : null,
    selectedExaminationId: selectedExamId,
    availableExaminations,
    summary: {
      totalStudents: candidates.length,
      passCount,
      failCount,
      incompleteCount,
      noExamCount,
      alreadyTransferredCount,
      eligiblePassCount,
    },
    candidates,
  });
}

function handlePromoteStudents(req: AuthenticatedRequest, res: express.Response) {
  const {
    sourceAcademicYear,
    targetAcademicYear,
    classId,
    studentIds,
    examinationId,
    setAsCurrentYear = false,
    copyTeacherAssignments = false,
    copyClassTeachers = false,
  } = req.body as {
    sourceAcademicYear?: string;
    targetAcademicYear?: string;
    classId?: number;
    studentIds?: number[];
    examinationId?: number | null;
    setAsCurrentYear?: boolean;
    copyTeacherAssignments?: boolean;
    copyClassTeachers?: boolean;
  };

  const sourceYear = (sourceAcademicYear || getCurrentAcademicYear()).trim();
  const targetYear = targetAcademicYear?.trim();
  const parsedClassId = Number(classId);

  if (!targetYear) {
    return res.status(400).json({ error: 'Target academic year (e.g. 2026-27) is required.' });
  }
  if (targetYear === sourceYear) {
    return res.status(400).json({ error: 'Target academic year must be different from the source academic year.' });
  }
  if (!parsedClassId) {
    return res.status(400).json({ error: 'Source classId is required.' });
  }
  if (!Array.isArray(studentIds) || studentIds.length === 0) {
    return res.status(400).json({ error: 'Please mark/tick at least one student to transfer.' });
  }

  const access = verifyPromotionAccess(req.user, parsedClassId, sourceYear);
  if (!access.allowed) {
    return res.status(403).json({ error: access.error || 'Access denied.' });
  }

  const uniqueIds = Array.from(new Set(studentIds.map(Number).filter((n) => Number.isInteger(n) && n > 0)));
  if (uniqueIds.length === 0) {
    return res.status(400).json({ error: 'No valid student IDs provided.' });
  }

  const classes = db
    .prepare(`SELECT id, name, numeric_order FROM classes WHERE is_active = 1 AND COALESCE(is_deleted, 0) = 0 ORDER BY numeric_order ASC`)
    .all() as Array<{ id: number; name: string; numeric_order: number }>;
  const sourceClassIdx = classes.findIndex((c) => c.id === parsedClassId);
  if (sourceClassIdx === -1) {
    return res.status(404).json({ error: 'Source class not found.' });
  }
  const sourceClass = classes[sourceClassIdx];
  const nextClass = classes[sourceClassIdx + 1] ?? null;

  // Admin-only flags must never be triggered by non-admin Class Teachers
  const effectiveSetAsCurrentYear = access.isAdmin ? Boolean(setAsCurrentYear) : false;
  const effectiveCopyAssignments = access.isAdmin ? Boolean(copyTeacherAssignments) : false;
  const effectiveCopyClassTeachers = access.isAdmin ? Boolean(copyClassTeachers) : false;

  const placeholders = uniqueIds.map(() => '?').join(',');
  const scopedSectionClause =
    !access.isAdmin && access.allowedSectionIds && access.allowedSectionIds.length > 0
      ? `AND se.section_id IN (${access.allowedSectionIds.map(() => '?').join(',')})`
      : '';
  const scopedParams: Array<string | number> = [
    sourceYear,
    parsedClassId,
    ...uniqueIds,
    ...(!access.isAdmin && access.allowedSectionIds ? access.allowedSectionIds : []),
  ];

  const sourceEnrollments = db
    .prepare(
      `SELECT se.student_id, se.class_id, se.section_id, se.roll_number,
              COALESCE(NULLIF(se.stream, ''), st.stream, '') as stream
       FROM student_enrollments se
       JOIN students st ON st.id = se.student_id
       WHERE se.academic_year = ? AND se.class_id = ? AND se.status = 'active'
         AND COALESCE(st.is_deleted, 0) = 0
         AND se.student_id IN (${placeholders})
         ${scopedSectionClause}
       ORDER BY se.section_id ASC, se.roll_number ASC`
    )
    .all(...scopedParams) as Array<{
    student_id: number;
    class_id: number;
    section_id: number;
    roll_number: number;
    stream: string;
  }>;

  if (!access.isAdmin && sourceEnrollments.length !== uniqueIds.length) {
    return res.status(403).json({
      error: 'Access denied: You can only promote students enrolled in your assigned class and section.',
    });
  }

  try {
    const result = db.transaction(() => {
      db.prepare(`INSERT OR IGNORE INTO academic_years (name, is_current, is_deleted) VALUES (?, 0, 0)`).run(targetYear);

      const currentYear = getCurrentAcademicYear();
      const shouldSyncStudentPointer = effectiveSetAsCurrentYear || targetYear === currentYear;

      const sections = db
        .prepare(`SELECT id, class_id, name FROM sections WHERE COALESCE(is_deleted, 0) = 0 ORDER BY name ASC`)
        .all() as Array<{ id: number; class_id: number; name: string }>;
      const secNameById = new Map<number, string>();
      const secIdByClassAndName = new Map<string, number>();
      const firstSecByClass = new Map<number, number>();
      for (const s of sections) {
        secNameById.set(s.id, s.name);
        secIdByClassAndName.set(`${s.class_id}:${s.name}`, s.id);
        if (!firstSecByClass.has(s.class_id)) firstSecByClass.set(s.class_id, s.id);
      }

      const existingInTarget = new Set(
        (
          db
            .prepare(`SELECT student_id FROM student_enrollments WHERE academic_year = ?`)
            .all(targetYear) as Array<{ student_id: number }>
        ).map((r) => r.student_id)
      );

      const insertEnrollment = db.prepare(
        `INSERT INTO student_enrollments (student_id, academic_year, class_id, section_id, roll_number, stream, status)
         VALUES (?, ?, ?, ?, ?, ?, ?)`
      );
      const checkRollUsed = db.prepare(
        `SELECT 1 FROM student_enrollments
         WHERE academic_year = ? AND class_id = ? AND section_id = ? AND roll_number = ? AND status = 'active'`
      );
      const getMaxRoll = db.prepare(
        `SELECT COALESCE(MAX(roll_number), 0) as max_roll FROM student_enrollments
         WHERE academic_year = ? AND class_id = ? AND section_id = ? AND status = 'active'`
      );
      const updateStudentCurrent = db.prepare(
        `UPDATE students
         SET class_id = ?, section_id = ?, roll_number = ?, academic_year = ?, stream = ?, status = ?, updated_at = datetime('now')
         WHERE id = ?`
      );
      const copyElectives = db.prepare(
        `INSERT OR IGNORE INTO student_year_electives (student_id, academic_year, subject_id, component_id)
         SELECT student_id, ?, subject_id, component_id
         FROM student_year_electives
         WHERE student_id = ? AND academic_year = ?`
      );
      const copyOptOuts = db.prepare(
        `INSERT OR IGNORE INTO student_elective_opt_outs (student_id, academic_year, subject_id)
         SELECT student_id, ?, subject_id
         FROM student_elective_opt_outs
         WHERE student_id = ? AND academic_year = ?`
      );

      let promotedCount = 0;
      let graduatedCount = 0;
      let skippedCount = 0;

      for (const se of sourceEnrollments) {
        if (existingInTarget.has(se.student_id)) {
          skippedCount++;
          continue;
        }

        if (nextClass) {
          const secName = secNameById.get(se.section_id) || 'A';
          const nextSectionId =
            secIdByClassAndName.get(`${nextClass.id}:${secName}`) ??
            firstSecByClass.get(nextClass.id) ??
            se.section_id;

          const rollUsed = checkRollUsed.get(targetYear, nextClass.id, nextSectionId, se.roll_number);
          const assignedRoll = rollUsed
            ? ((getMaxRoll.get(targetYear, nextClass.id, nextSectionId) as { max_roll: number }).max_roll + 1)
            : se.roll_number;

          insertEnrollment.run(se.student_id, targetYear, nextClass.id, nextSectionId, assignedRoll, se.stream || '', 'active');
          copyElectives.run(targetYear, se.student_id, sourceYear);
          copyOptOuts.run(targetYear, se.student_id, sourceYear);
          if (shouldSyncStudentPointer) {
            updateStudentCurrent.run(nextClass.id, nextSectionId, assignedRoll, targetYear, se.stream || '', 'active', se.student_id);
          }
          promotedCount++;
        } else {
          insertEnrollment.run(se.student_id, targetYear, se.class_id, se.section_id, se.roll_number, se.stream || '', 'graduated');
          if (shouldSyncStudentPointer) {
            updateStudentCurrent.run(se.class_id, se.section_id, se.roll_number, targetYear, se.stream || '', 'graduated', se.student_id);
          }
          graduatedCount++;
        }
      }

      let copiedAssignments = 0;
      if (effectiveCopyAssignments) {
        copiedAssignments = db
          .prepare(
            `INSERT OR IGNORE INTO teacher_assignments (teacher_id, subject_id, component_id, class_id, section_id, academic_year)
             SELECT teacher_id, subject_id, component_id, class_id, section_id, ?
             FROM teacher_assignments WHERE academic_year = ?`
          )
          .run(targetYear, sourceYear).changes;
      }

      let copiedClassTeachers = 0;
      if (effectiveCopyClassTeachers) {
        copiedClassTeachers = db
          .prepare(
            `INSERT OR IGNORE INTO class_teacher_assignments (teacher_id, class_id, section_id, academic_year)
             SELECT teacher_id, class_id, section_id, ?
             FROM class_teacher_assignments WHERE academic_year = ?`
          )
          .run(targetYear, sourceYear).changes;
      }

      if (effectiveSetAsCurrentYear) {
        db.prepare(`UPDATE academic_years SET is_current = CASE WHEN name = ? THEN 1 ELSE 0 END`).run(targetYear);
        db.prepare(
          `INSERT INTO system_settings (key, value) VALUES ('current_academic_year', ?)
           ON CONFLICT(key) DO UPDATE SET value = excluded.value`
        ).run(targetYear);
      }

      return {
        sourceAcademicYear: sourceYear,
        targetAcademicYear: targetYear,
        classId: parsedClassId,
        sourceClassName: sourceClass.name,
        nextClassName: nextClass ? nextClass.name : 'Graduated (Alumni)',
        promotedCount,
        graduatedCount,
        skippedCount,
        copiedAssignments,
        copiedClassTeachers,
        setAsCurrentYear: effectiveSetAsCurrentYear,
      };
    })();

    logAudit(req.user!, 'PROMOTE_STUDENTS_NEXT_CLASS', 'student_enrollments', `${sourceYear}->${targetYear}`, {
      ...result,
      examinationId: examinationId ?? null,
      requestedCount: uniqueIds.length,
    });

    res.status(201).json({ success: true, ...result });
  } catch (err: any) {
    res.status(400).json({ error: err?.message || 'Failed to promote students.' });
  }
}

function handleUnpromoteStudents(req: AuthenticatedRequest, res: express.Response) {
  const {
    sourceAcademicYear,
    targetAcademicYear,
    classId,
    studentIds,
  } = req.body as {
    sourceAcademicYear?: string;
    targetAcademicYear?: string;
    classId?: number;
    studentIds?: number[];
  };

  const sourceYear = (sourceAcademicYear || getCurrentAcademicYear()).trim();
  const targetYear = targetAcademicYear?.trim();
  const parsedClassId = Number(classId);

  if (!targetYear) {
    return res.status(400).json({ error: 'Target academic year (e.g. 2026-27) is required.' });
  }
  if (targetYear === sourceYear) {
    return res.status(400).json({ error: 'Target academic year must be different from the source academic year.' });
  }
  if (!parsedClassId) {
    return res.status(400).json({ error: 'Source classId is required.' });
  }
  if (!Array.isArray(studentIds) || studentIds.length === 0) {
    return res.status(400).json({ error: 'Please select at least one promoted student to un-promote.' });
  }

  const access = verifyPromotionAccess(req.user, parsedClassId, sourceYear);
  if (!access.allowed) {
    return res.status(403).json({ error: access.error || 'Access denied.' });
  }

  const uniqueIds = Array.from(new Set(studentIds.map(Number).filter((n) => Number.isInteger(n) && n > 0)));
  if (uniqueIds.length === 0) {
    return res.status(400).json({ error: 'No valid student IDs provided.' });
  }

  const sourceClass = db
    .prepare(`SELECT id, name FROM classes WHERE id = ? AND is_active = 1 AND COALESCE(is_deleted, 0) = 0`)
    .get(parsedClassId) as { id: number; name: string } | undefined;
  if (!sourceClass) {
    return res.status(404).json({ error: 'Source class not found.' });
  }

  const placeholders = uniqueIds.map(() => '?').join(',');
  const scopedSectionClause =
    !access.isAdmin && access.allowedSectionIds && access.allowedSectionIds.length > 0
      ? `AND se.section_id IN (${access.allowedSectionIds.map(() => '?').join(',')})`
      : '';
  const scopedParams: Array<string | number> = [
    sourceYear,
    parsedClassId,
    ...uniqueIds,
    ...(!access.isAdmin && access.allowedSectionIds ? access.allowedSectionIds : []),
  ];

  const sourceEnrollments = db
    .prepare(
      `SELECT se.student_id, se.class_id, se.section_id, se.roll_number
       FROM student_enrollments se
       JOIN students st ON st.id = se.student_id
       WHERE se.academic_year = ? AND se.class_id = ? AND se.status = 'active'
         AND COALESCE(st.is_deleted, 0) = 0
         AND se.student_id IN (${placeholders})
         ${scopedSectionClause}`
    )
    .all(...scopedParams) as Array<{
    student_id: number;
    class_id: number;
    section_id: number;
    roll_number: number;
  }>;

  if (!access.isAdmin && sourceEnrollments.length !== uniqueIds.length) {
    return res.status(403).json({
      error: 'Access denied: You can only un-promote students from your assigned class and section.',
    });
  }

  const allowedSourceStudentIds = sourceEnrollments.map((se) => se.student_id);
  if (allowedSourceStudentIds.length === 0) {
    return res.status(404).json({ error: `No source enrollments found in ${sourceYear} for the selected students.` });
  }

  try {
    const summary = db.transaction(() => {
      const srcByStudent = new Map(sourceEnrollments.map((se) => [se.student_id, se]));
      const srcPh = allowedSourceStudentIds.map(() => '?').join(',');

      const existingTargetRows = db
        .prepare(
          `SELECT se.student_id
           FROM student_enrollments se
           WHERE se.academic_year = ? AND se.student_id IN (${srcPh})`
        )
        .all(targetYear, ...allowedSourceStudentIds) as Array<{ student_id: number }>;

      const targetIds = existingTargetRows.map((r) => r.student_id);
      if (targetIds.length === 0) {
        return {
          sourceAcademicYear: sourceYear,
          targetAcademicYear: targetYear,
          classId: parsedClassId,
          sourceClassName: sourceClass.name,
          unpromotedCount: 0,
          restoredPointerCount: 0,
          skippedCount: uniqueIds.length,
        };
      }

      const tPh = targetIds.map(() => '?').join(',');

      // Block un-promotion cleanly if target-year examination marks already exist
      const targetMarks = db
        .prepare(
          `SELECT DISTINCT st.full_name, st.student_code
           FROM marks m
           JOIN examinations e ON e.id = m.examination_id
           JOIN students st ON st.id = m.student_id
           WHERE e.academic_year = ? AND COALESCE(e.is_deleted, 0) = 0
             AND m.student_id IN (${tPh})
             AND (m.obtained_marks IS NOT NULL OR m.attendance_status = 'absent')
           LIMIT 5`
        )
        .all(targetYear, ...targetIds) as Array<{ full_name: string; student_code: string }>;

      if (targetMarks.length > 0) {
        const names = targetMarks.map((m) => `${m.full_name} (${m.student_code})`).join(', ');
        throw new Error(
          `Cannot un-promote because examination marks already exist in ${targetYear} for: ${names}. Clear target-year marks first.`
        );
      }

      const targetIaMarks = db
        .prepare(
          `SELECT DISTINCT st.full_name, st.student_code
           FROM internal_assessment_marks ia
           JOIN examinations e ON e.id = ia.examination_id
           JOIN examination_subjects es ON es.examination_id = ia.examination_id AND es.subject_id = ia.subject_id
           JOIN students st ON st.id = ia.student_id
           WHERE e.academic_year = ? AND COALESCE(e.is_deleted, 0) = 0
             AND ia.student_id IN (${tPh})
             AND (
               (es.ia_notebook_max > 0 AND ia.notebook_marks IS NOT NULL)
               OR (es.ia_unit_test_max > 0 AND ia.unit_test_marks IS NOT NULL)
               OR (es.ia_practical_max > 0 AND ia.practical_marks IS NOT NULL)
               OR (es.ia_participation_max > 0 AND ia.participation_marks IS NOT NULL)
             )
           LIMIT 5`
        )
        .all(targetYear, ...targetIds) as Array<{ full_name: string; student_code: string }>;

      if (targetIaMarks.length > 0) {
        const names = targetIaMarks.map((m) => `${m.full_name} (${m.student_code})`).join(', ');
        throw new Error(
          `Cannot un-promote because Internal Assessment marks already exist in ${targetYear} for: ${names}.`
        );
      }

      db.prepare(
        `DELETE FROM student_year_electives WHERE academic_year = ? AND student_id IN (${tPh})`
      ).run(targetYear, ...targetIds);
      db.prepare(
        `DELETE FROM student_year_subjects WHERE academic_year = ? AND student_id IN (${tPh})`
      ).run(targetYear, ...targetIds);
      db.prepare(
        `DELETE FROM student_elective_opt_outs WHERE academic_year = ? AND student_id IN (${tPh})`
      ).run(targetYear, ...targetIds);

      const deletedEnrollments = db
        .prepare(
          `DELETE FROM student_enrollments WHERE academic_year = ? AND student_id IN (${tPh})`
        )
        .run(targetYear, ...targetIds).changes;

      const studentRows = db
        .prepare(`SELECT id, academic_year FROM students WHERE id IN (${tPh})`)
        .all(...targetIds) as Array<{ id: number; academic_year: string }>;

      const restoreStudentStmt = db.prepare(
        `UPDATE students
         SET class_id = ?, section_id = ?, roll_number = ?, academic_year = ?, status = 'active', updated_at = datetime('now')
         WHERE id = ?`
      );

      let restoredPointerCount = 0;
      for (const st of studentRows) {
        const src = srcByStudent.get(st.id);
        if (src && st.academic_year === targetYear) {
          restoreStudentStmt.run(src.class_id, src.section_id, src.roll_number, sourceYear, st.id);
          restoredPointerCount++;
        }
      }

      return {
        sourceAcademicYear: sourceYear,
        targetAcademicYear: targetYear,
        classId: parsedClassId,
        sourceClassName: sourceClass.name,
        unpromotedCount: deletedEnrollments,
        restoredPointerCount,
        skippedCount: Math.max(0, uniqueIds.length - deletedEnrollments),
      };
    })();

    logAudit(req.user!, 'UNPROMOTE_STUDENTS', 'student_enrollments', `${targetYear}->${sourceYear}`, {
      ...summary,
      requestedCount: uniqueIds.length,
    });

    res.json({ success: true, ...summary });
  } catch (err: any) {
    res.status(400).json({ error: err?.message || 'Failed to un-promote selected students.' });
  }
}

app.get('/api/admin/students/promotion-candidates', requireAuth, (req: AuthenticatedRequest, res) =>
  handleGetPromotionCandidates(req, res)
);
app.get('/api/students/promotion-candidates', requireAuth, (req: AuthenticatedRequest, res) =>
  handleGetPromotionCandidates(req, res)
);

app.post('/api/admin/students/promote', requireAuth, (req: AuthenticatedRequest, res) =>
  handlePromoteStudents(req, res)
);
app.post('/api/students/promote', requireAuth, (req: AuthenticatedRequest, res) =>
  handlePromoteStudents(req, res)
);

app.post('/api/admin/students/unpromote', requireAuth, (req: AuthenticatedRequest, res) =>
  handleUnpromoteStudents(req, res)
);
app.post('/api/students/unpromote', requireAuth, (req: AuthenticatedRequest, res) =>
  handleUnpromoteStudents(req, res)
);

function permanentlyDeleteStudentsInDb(studentIds: number[]): number {
  if (studentIds.length === 0) return 0;
  const ph = studentIds.map(() => '?').join(',');
  db.prepare(`DELETE FROM marks WHERE student_id IN (${ph})`).run(...studentIds);
  db.prepare(`DELETE FROM internal_assessment_marks WHERE student_id IN (${ph})`).run(...studentIds);
  db.prepare(`DELETE FROM student_electives WHERE student_id IN (${ph})`).run(...studentIds);
  db.prepare(`DELETE FROM student_year_electives WHERE student_id IN (${ph})`).run(...studentIds);
  db.prepare(`DELETE FROM student_subjects WHERE student_id IN (${ph})`).run(...studentIds);
  db.prepare(`DELETE FROM student_year_subjects WHERE student_id IN (${ph})`).run(...studentIds);
  db.prepare(`DELETE FROM student_elective_opt_outs WHERE student_id IN (${ph})`).run(...studentIds);
  db.prepare(`DELETE FROM student_enrollments WHERE student_id IN (${ph})`).run(...studentIds);
  const res = db.prepare(`DELETE FROM students WHERE id IN (${ph})`).run(...studentIds);
  return res.changes;
}

app.delete('/api/admin/students/:id', requireAuth, requireAdmin, (req: AuthenticatedRequest, res) => {
  const id = Number(req.params.id);
  const isPermanent = req.query.permanent === '1' || req.query.permanent === 'true';
  const existing = db.prepare(`SELECT id, student_code, full_name, is_deleted FROM students WHERE id = ?`).get(id) as any;
  if (!existing) return res.status(404).json({ error: 'Student not found.' });

  try {
    if (isPermanent) {
      db.transaction(() => {
        permanentlyDeleteStudentsInDb([id]);
      })();
      checkpointWal();
      logAudit(req.user!, 'PERMANENT_DELETE_STUDENT', 'student', id, {
        studentCode: existing.student_code,
        fullName: existing.full_name,
        permanentlyDeleted: true,
      });
      return res.json({
        success: true,
        permanentlyDeleted: true,
        id,
        studentCode: existing.student_code,
        fullName: existing.full_name,
      });
    }

    // Soft-delete preserves all historical marks, attendance, and academic enrollment records
    db.transaction(() => {
      db.prepare(
        `UPDATE students
         SET is_deleted = 1, deleted_at = datetime('now'), deleted_by = ?, status = 'archived', updated_at = datetime('now')
         WHERE id = ?`
      ).run(req.user!.id, id);
    })();
  } catch (err: any) {
    return res.status(400).json({ error: err?.message || 'Could not remove student record.' });
  }

  logAudit(req.user!, 'SOFT_DELETE_STUDENT', 'student', id, {
    studentCode: existing.student_code,
    fullName: existing.full_name,
    preservedMarks: true,
  });
  res.json({ success: true, softDeleted: true, id, studentCode: existing.student_code, fullName: existing.full_name });
});

app.post('/api/admin/students/bulk-action', requireAuth, requireAdmin, (req: AuthenticatedRequest, res) => {
  const { action, ids, updates, academicYear } = req.body as {
    action?: 'delete' | 'archive' | 'permanent_delete' | 'restore' | 'activate' | 'deactivate' | 'update';
    ids?: number[];
    academicYear?: string;
    updates?: {
      classId?: number;
      sectionId?: number;
      stream?: string;
      status?: 'active' | 'inactive' | 'transferred' | 'graduated';
    };
  };

  if (!action || !Array.isArray(ids) || ids.length === 0) {
    return res.status(400).json({ error: 'Action and at least one selected student ID are required.' });
  }

  const uniqueIds = Array.from(new Set(ids.map(Number).filter((n) => Number.isInteger(n) && n > 0)));
  if (uniqueIds.length === 0) {
    return res.status(400).json({ error: 'No valid student IDs provided.' });
  }

  const placeholders = uniqueIds.map(() => '?').join(',');
  const existingRows = db
    .prepare(`SELECT id, student_code, full_name, class_id, section_id, roll_number, academic_year, COALESCE(stream, '') as stream, status, is_deleted FROM students WHERE id IN (${placeholders})`)
    .all(...uniqueIds) as Array<any>;

  if (existingRows.length === 0) {
    return res.status(404).json({ error: 'Selected students were not found.' });
  }

  const currentYear = getCurrentAcademicYear();
  const targetYear = academicYear && academicYear !== 'all' && academicYear.trim() ? academicYear.trim() : currentYear;

  let summary: { affectedCount: number; records: Array<{ id: number; studentCode: string; fullName: string }> };
  try {
    summary = db.transaction(() => {
      let affectedCount = 0;
      const targetIds = existingRows.map((r) => r.id);

      if (action === 'permanent_delete') {
        affectedCount = permanentlyDeleteStudentsInDb(targetIds);
        checkpointWal();
      } else if (action === 'delete' || action === 'archive') {
        const stmt = db.prepare(
          `UPDATE students
           SET is_deleted = 1, deleted_at = datetime('now'), deleted_by = ?, status = 'archived', updated_at = datetime('now')
           WHERE id = ?`
        );
        for (const r of existingRows) {
          stmt.run(req.user!.id, r.id);
          affectedCount++;
        }
      } else if (action === 'restore') {
        const restoreStudent = db.prepare(
          `UPDATE students
           SET is_deleted = 0, deleted_at = NULL, deleted_by = NULL, status = 'active', updated_at = datetime('now')
           WHERE id = ?`
        );
        const restoreEnrollment = db.prepare(
          `UPDATE student_enrollments SET status = 'active' WHERE student_id = ? AND status = 'archived'`
        );
        for (const r of existingRows) {
          restoreStudent.run(r.id);
          restoreEnrollment.run(r.id);
          affectedCount++;
        }
      } else if (action === 'activate' || action === 'deactivate') {
        const nextStatus = action === 'activate' ? 'active' : 'inactive';
        const upStudent = db.prepare(`UPDATE students SET status = ?, updated_at = datetime('now') WHERE id = ?`);
        const upEnr = db.prepare(`UPDATE student_enrollments SET status = ? WHERE student_id = ? AND academic_year = ?`);
        for (const r of existingRows) {
          upStudent.run(nextStatus, r.id);
          upEnr.run(nextStatus, r.id, targetYear);
          affectedCount++;
        }
      } else if (action === 'update') {
        if (!updates || (!updates.classId && !updates.sectionId && !updates.status && updates.stream === undefined)) {
          throw new Error('Provide at least one field (class, section, stream, or status) to update.');
        }
        const getEnr = db.prepare(`SELECT * FROM student_enrollments WHERE student_id = ? AND academic_year = ?`);
        const checkRoll = db.prepare(
          `SELECT 1 FROM student_enrollments se
           JOIN students st ON st.id = se.student_id
           WHERE se.academic_year = ? AND se.class_id = ? AND se.section_id = ? AND se.roll_number = ?
             AND se.status = 'active' AND COALESCE(st.is_deleted, 0) = 0 AND se.student_id != ?`
        );
        const getMaxRoll = db.prepare(
          `SELECT COALESCE(MAX(se.roll_number), 0) as max_roll FROM student_enrollments se
           JOIN students st ON st.id = se.student_id
           WHERE se.academic_year = ? AND se.class_id = ? AND se.section_id = ?
             AND se.status = 'active' AND COALESCE(st.is_deleted, 0) = 0`
        );
        const upsertEnr = db.prepare(
          `INSERT INTO student_enrollments (student_id, academic_year, class_id, section_id, roll_number, stream, status)
           VALUES (?, ?, ?, ?, ?, ?, ?)
           ON CONFLICT(student_id, academic_year) DO UPDATE SET
             class_id = excluded.class_id, section_id = excluded.section_id, roll_number = excluded.roll_number, stream = excluded.stream, status = excluded.status`
        );
        const upStudent = db.prepare(
          `UPDATE students SET class_id = ?, section_id = ?, roll_number = ?, stream = ?, status = ?, updated_at = datetime('now') WHERE id = ?`
        );

        for (const r of existingRows) {
          const enr = getEnr.get(r.id, targetYear) as any;
          const nextClassId = updates.classId ? Number(updates.classId) : Number(enr?.class_id ?? r.class_id);
          let nextSectionId = updates.sectionId ? Number(updates.sectionId) : Number(enr?.section_id ?? r.section_id);
          if (updates.classId && !updates.sectionId) {
            nextSectionId = resolveDefaultSectionForClass(nextClassId) ?? nextSectionId;
          }
          const nextStatus = updates.status ?? enr?.status ?? r.status;
          const nextStream =
            updates.stream !== undefined
              ? normalizeStudentStream(updates.stream)
              : normalizeStudentStream(enr?.stream || r.stream);
          let nextRoll = Number(enr?.roll_number ?? r.roll_number);
          if (checkRoll.get(targetYear, nextClassId, nextSectionId, nextRoll, r.id)) {
            nextRoll = (getMaxRoll.get(targetYear, nextClassId, nextSectionId) as { max_roll: number }).max_roll + 1;
          }
          upsertEnr.run(r.id, targetYear, nextClassId, nextSectionId, nextRoll, nextStream, nextStatus);
          if (targetYear === currentYear || targetYear === r.academic_year) {
            upStudent.run(nextClassId, nextSectionId, nextRoll, nextStream, nextStatus, r.id);
          }
          affectedCount++;
        }
      }

      return {
        affectedCount,
        records: existingRows.map((r) => ({ id: r.id, studentCode: r.student_code, fullName: r.full_name })),
      };
    })();
  } catch (err: any) {
    return res.status(400).json({ error: err?.message || 'Student bulk operation failed.' });
  }

  logAudit(req.user!, `BULK_${action.toUpperCase()}_STUDENTS`, 'student', uniqueIds.join(','), {
    action,
    affectedCount: summary.affectedCount,
    permanentlyDeleted: action === 'permanent_delete',
    academicYear: targetYear,
    studentCodes: summary.records.map((r) => r.studentCode),
    updates: updates || null,
  });

  res.json({
    success: true,
    action,
    permanentlyDeleted: action === 'permanent_delete',
    ...summary,
  });
});

// Users & Complete Teacher Management
app.get('/api/admin/users', requireAuth, requireAdmin, (req, res) => {
  try {
    const {
      view,
      search,
      role,
      subjectId,
      classId,
      sectionId,
      status,
      sort,
      academicYear,
    } = req.query as Record<string, string | undefined>;

    const viewMode = view === 'archived' ? 'archived' : view === 'all' ? 'all' : 'active';
    const targetYear = academicYear && academicYear !== 'all' ? academicYear : getCurrentAcademicYear();
    const useAllYears = academicYear === 'all';

    const where: string[] = [];
    const params: Array<string | number> = [];

    if (viewMode === 'active') {
      where.push(`COALESCE(u.is_deleted, 0) = 0`);
    } else if (viewMode === 'archived') {
      where.push(`COALESCE(u.is_deleted, 0) = 1`);
    }

    if (status === 'active') {
      where.push(`u.is_active = 1`);
    } else if (status === 'inactive') {
      where.push(`u.is_active = 0`);
    }

    if (search && search.trim()) {
      where.push(`(lower(u.full_name) LIKE lower(?) OR lower(u.username) LIKE lower(?) OR lower(u.employee_code) LIKE lower(?) OR lower(u.email) LIKE lower(?))`);
      const q = `%${search.trim()}%`;
      params.push(q, q, q, q);
    }

    const orderBy =
      sort === 'name_desc'
        ? `lower(u.full_name) DESC, u.id ASC`
        : sort === 'code_asc'
          ? `lower(u.employee_code) ASC, lower(u.full_name) ASC`
          : sort === 'recent'
            ? `u.id DESC`
            : `lower(u.full_name) ASC, u.id ASC`;

    const users = db
      .prepare(
        `SELECT u.id, u.username, u.full_name, u.email, u.employee_code, u.is_active, u.must_change_password,
                u.is_deleted, u.deleted_at, u.created_at
         FROM users u
         ${where.length ? 'WHERE ' + where.join(' AND ') : ''}
         ORDER BY ${orderBy}`
      )
      .all(...params) as Array<any>;

    const roles = db
      .prepare(`SELECT ur.user_id, r.name FROM user_roles ur JOIN roles r ON r.id = ur.role_id`)
      .all() as Array<{ user_id: number; name: string }>;

    const assignments = (
      useAllYears
        ? db
            .prepare(
              `SELECT ta.id, ta.teacher_id, ta.subject_id, sub.name as subject_name, sub.code as subject_code,
                      ta.component_id, sc.name as component_name,
                      ta.class_id, c.name as class_name, COALESCE(c.has_sections, 1) as has_sections, c.numeric_order,
                      ta.section_id, s.name as section_name, ta.academic_year
               FROM teacher_assignments ta
               JOIN subjects sub ON sub.id = ta.subject_id
               JOIN subject_components sc ON sc.id = ta.component_id
               JOIN classes c ON c.id = ta.class_id
               JOIN sections s ON s.id = ta.section_id
               WHERE COALESCE(sub.is_deleted, 0) = 0 AND COALESCE(c.is_deleted, 0) = 0 AND COALESCE(s.is_deleted, 0) = 0
               ORDER BY c.numeric_order ASC, s.name ASC, sub.display_order ASC`
            )
            .all()
        : db
            .prepare(
              `SELECT ta.id, ta.teacher_id, ta.subject_id, sub.name as subject_name, sub.code as subject_code,
                      ta.component_id, sc.name as component_name,
                      ta.class_id, c.name as class_name, COALESCE(c.has_sections, 1) as has_sections, c.numeric_order,
                      ta.section_id, s.name as section_name, ta.academic_year
               FROM teacher_assignments ta
               JOIN subjects sub ON sub.id = ta.subject_id
               JOIN subject_components sc ON sc.id = ta.component_id
               JOIN classes c ON c.id = ta.class_id
               JOIN sections s ON s.id = ta.section_id
               WHERE ta.academic_year = ?
                 AND COALESCE(sub.is_deleted, 0) = 0 AND COALESCE(c.is_deleted, 0) = 0 AND COALESCE(s.is_deleted, 0) = 0
               ORDER BY c.numeric_order ASC, s.name ASC, sub.display_order ASC`
            )
            .all(targetYear)
    ).map((a: any) => ({ ...a, hasSections: Boolean(a.has_sections ?? 1) })) as Array<any>;

    const ctAssignments = (
      useAllYears
        ? db
            .prepare(
              `SELECT cta.id, cta.teacher_id, cta.class_id, c.name as class_name, COALESCE(c.has_sections, 1) as has_sections, cta.section_id, s.name as section_name, cta.academic_year
               FROM class_teacher_assignments cta
               JOIN classes c ON c.id = cta.class_id
               JOIN sections s ON s.id = cta.section_id
               WHERE COALESCE(c.is_deleted, 0) = 0 AND COALESCE(s.is_deleted, 0) = 0
               ORDER BY c.numeric_order ASC, s.name ASC`
            )
            .all()
        : db
            .prepare(
              `SELECT cta.id, cta.teacher_id, cta.class_id, c.name as class_name, COALESCE(c.has_sections, 1) as has_sections, cta.section_id, s.name as section_name, cta.academic_year
               FROM class_teacher_assignments cta
               JOIN classes c ON c.id = cta.class_id
               JOIN sections s ON s.id = cta.section_id
               WHERE cta.academic_year = ? AND COALESCE(c.is_deleted, 0) = 0 AND COALESCE(s.is_deleted, 0) = 0
               ORDER BY c.numeric_order ASC, s.name ASC`
            )
            .all(targetYear)
    ).map((ct: any) => ({ ...ct, hasSections: Boolean(ct.has_sections ?? 1) })) as Array<any>;

    const marksEnteredCounts = db
      .prepare(
        `SELECT COALESCE(submitted_by, entered_by) as teacher_id, COUNT(*) as cnt
         FROM marks
         WHERE COALESCE(submitted_by, entered_by) IS NOT NULL
         GROUP BY COALESCE(submitted_by, entered_by)`
      )
      .all() as Array<{ teacher_id: number; cnt: number }>;

    let enriched = users.map((u) => {
      const userRoles = roles.filter((r) => r.user_id === u.id).map((r) => r.name);
      const userAssigns = assignments.filter((a) => a.teacher_id === u.id);
      const userCt = ctAssignments.filter((ct) => ct.teacher_id === u.id);
      const assignedSubjects = Array.from(new Set(userAssigns.map((a) => a.subject_name)));
      const assignedClasses = Array.from(new Set(userAssigns.map((a) => a.class_name)));
      const assignedSections = Array.from(new Set(userAssigns.map((a) => formatClassSectionLabel(a.class_name, a.section_name, a.hasSections))));
      const marksCount = marksEnteredCounts.find((m) => m.teacher_id === u.id)?.cnt ?? 0;

      return {
        ...u,
        isActive: Boolean(u.is_active),
        isDeleted: Boolean(u.is_deleted),
        mustChangePassword: Boolean(u.must_change_password),
        roles: userRoles,
        subjectAssignmentCount: userAssigns.length,
        assignments: userAssigns,
        assignedSubjects,
        assignedClasses,
        assignedSections,
        classTeacherAssignments: userCt,
        classTeacherSections: userCt.map((ct) => formatClassSectionLabel(ct.class_name, ct.section_name, ct.hasSections)),
        submittedMarksCount: marksCount,
      };
    });

    if (role && role !== 'all') {
      enriched = enriched.filter((u) => u.roles.includes(role));
    }
    if (subjectId) {
      const sid = Number(subjectId);
      enriched = enriched.filter((u) => u.assignments.some((a: any) => a.subject_id === sid));
    }
    if (classId) {
      const cid = Number(classId);
      enriched = enriched.filter(
        (u) =>
          u.assignments.some((a: any) => a.class_id === cid) ||
          u.classTeacherAssignments.some((ct: any) => ct.class_id === cid)
      );
    }
    if (sectionId) {
      const secId = Number(sectionId);
      enriched = enriched.filter(
        (u) =>
          u.assignments.some((a: any) => a.section_id === secId) ||
          u.classTeacherAssignments.some((ct: any) => ct.section_id === secId)
      );
    }

    res.json(enriched);
  } catch (err: any) {
    console.error('Error loading /api/admin/users:', err);
    res.status(500).json({ error: err?.message || 'Database error while loading teacher directory.' });
  }
});

function getUserRecordById(userId: number, academicYear?: string) {
  const user = db
    .prepare(
      `SELECT id, username, full_name, email, employee_code, is_active, must_change_password,
              is_deleted, deleted_at, created_at
       FROM users WHERE id = ?`
    )
    .get(userId) as any;
  if (!user) return null;

  const targetYear = academicYear && academicYear !== 'all' ? academicYear : getCurrentAcademicYear();
  const useAllYears = academicYear === 'all';

  const userRoles = (
    db
      .prepare(`SELECT r.name FROM user_roles ur JOIN roles r ON r.id = ur.role_id WHERE ur.user_id = ?`)
      .all(userId) as Array<{ name: string }>
  ).map((r) => r.name);

  const userAssigns = (
    useAllYears
      ? db
          .prepare(
            `SELECT ta.id, ta.teacher_id, ta.subject_id, sub.name as subject_name, sub.code as subject_code,
                    ta.component_id, sc.name as component_name,
                    ta.class_id, c.name as class_name, COALESCE(c.has_sections, 1) as has_sections, c.numeric_order,
                    ta.section_id, s.name as section_name, ta.academic_year
             FROM teacher_assignments ta
             JOIN subjects sub ON sub.id = ta.subject_id
             JOIN subject_components sc ON sc.id = ta.component_id
             JOIN classes c ON c.id = ta.class_id
             JOIN sections s ON s.id = ta.section_id
             WHERE ta.teacher_id = ?
               AND COALESCE(sub.is_deleted, 0) = 0 AND COALESCE(c.is_deleted, 0) = 0 AND COALESCE(s.is_deleted, 0) = 0
             ORDER BY c.numeric_order ASC, s.name ASC, sub.display_order ASC`
          )
          .all(userId)
      : db
          .prepare(
            `SELECT ta.id, ta.teacher_id, ta.subject_id, sub.name as subject_name, sub.code as subject_code,
                    ta.component_id, sc.name as component_name,
                    ta.class_id, c.name as class_name, COALESCE(c.has_sections, 1) as has_sections, c.numeric_order,
                    ta.section_id, s.name as section_name, ta.academic_year
             FROM teacher_assignments ta
             JOIN subjects sub ON sub.id = ta.subject_id
             JOIN subject_components sc ON sc.id = ta.component_id
             JOIN classes c ON c.id = ta.class_id
             JOIN sections s ON s.id = ta.section_id
             WHERE ta.teacher_id = ? AND ta.academic_year = ?
               AND COALESCE(sub.is_deleted, 0) = 0 AND COALESCE(c.is_deleted, 0) = 0 AND COALESCE(s.is_deleted, 0) = 0
             ORDER BY c.numeric_order ASC, s.name ASC, sub.display_order ASC`
          )
          .all(userId, targetYear)
  ).map((a: any) => ({ ...a, hasSections: Boolean(a.has_sections ?? 1) })) as Array<any>;

  const userCt = (
    useAllYears
      ? db
          .prepare(
            `SELECT cta.id, cta.teacher_id, cta.class_id, c.name as class_name, COALESCE(c.has_sections, 1) as has_sections, cta.section_id, s.name as section_name, cta.academic_year
             FROM class_teacher_assignments cta
             JOIN classes c ON c.id = cta.class_id
             JOIN sections s ON s.id = cta.section_id
             WHERE cta.teacher_id = ? AND COALESCE(c.is_deleted, 0) = 0 AND COALESCE(s.is_deleted, 0) = 0
             ORDER BY c.numeric_order ASC, s.name ASC`
          )
          .all(userId)
      : db
          .prepare(
            `SELECT cta.id, cta.teacher_id, cta.class_id, c.name as class_name, COALESCE(c.has_sections, 1) as has_sections, cta.section_id, s.name as section_name, cta.academic_year
             FROM class_teacher_assignments cta
             JOIN classes c ON c.id = cta.class_id
             JOIN sections s ON s.id = cta.section_id
             WHERE cta.teacher_id = ? AND cta.academic_year = ? AND COALESCE(c.is_deleted, 0) = 0 AND COALESCE(s.is_deleted, 0) = 0
             ORDER BY c.numeric_order ASC, s.name ASC`
          )
          .all(userId, targetYear)
  ).map((ct: any) => ({ ...ct, hasSections: Boolean(ct.has_sections ?? 1) })) as Array<any>;

  const marksCountRow = db
    .prepare(
      `SELECT COUNT(*) as cnt FROM marks WHERE COALESCE(submitted_by, entered_by) = ?`
    )
    .get(userId) as { cnt: number } | undefined;

  return {
    ...user,
    isActive: Boolean(user.is_active),
    isDeleted: Boolean(user.is_deleted),
    mustChangePassword: Boolean(user.must_change_password),
    roles: userRoles,
    subjectAssignmentCount: userAssigns.length,
    assignments: userAssigns,
    assignedSubjects: Array.from(new Set(userAssigns.map((a) => a.subject_name))),
    assignedClasses: Array.from(new Set(userAssigns.map((a) => a.class_name))),
    assignedSections: Array.from(new Set(userAssigns.map((a) => formatClassSectionLabel(a.class_name, a.section_name, a.hasSections)))),
    classTeacherAssignments: userCt,
    classTeacherSections: userCt.map((ct) => formatClassSectionLabel(ct.class_name, ct.section_name, ct.hasSections)),
    submittedMarksCount: marksCountRow?.cnt ?? 0,
  };
}

app.get('/api/admin/users/:id/profile', requireAuth, requireAdmin, (req, res) => {
  const id = Number(req.params.id);
  const user = db
    .prepare(
      `SELECT id, username, full_name, email, employee_code, is_active, must_change_password, is_deleted, deleted_at, created_at, updated_at
       FROM users WHERE id = ?`
    )
    .get(id) as any;
  if (!user) return res.status(404).json({ error: 'Teacher/user not found.' });

  const roles = (
    db.prepare(`SELECT r.name FROM user_roles ur JOIN roles r ON r.id = ur.role_id WHERE ur.user_id = ?`).all(id) as Array<{ name: string }>
  ).map((r) => r.name);

  const assignments = db
    .prepare(
      `SELECT ta.id, ta.subject_id, sub.name as subject_name, sub.code as subject_code,
              ta.component_id, sc.name as component_name,
              ta.class_id, c.name as class_name, c.numeric_order,
              ta.section_id, s.name as section_name, ta.academic_year
       FROM teacher_assignments ta
       JOIN subjects sub ON sub.id = ta.subject_id
       JOIN subject_components sc ON sc.id = ta.component_id
       JOIN classes c ON c.id = ta.class_id
       JOIN sections s ON s.id = ta.section_id
       WHERE ta.teacher_id = ?
       ORDER BY ta.academic_year DESC, c.numeric_order ASC, s.name ASC, sub.display_order ASC`
    )
    .all(id);

  const classTeacherAssignments = db
    .prepare(
      `SELECT cta.id, cta.class_id, c.name as class_name, cta.section_id, s.name as section_name, cta.academic_year
       FROM class_teacher_assignments cta
       JOIN classes c ON c.id = cta.class_id
       JOIN sections s ON s.id = cta.section_id
       WHERE cta.teacher_id = ?
       ORDER BY cta.academic_year DESC, c.numeric_order ASC, s.name ASC`
    )
    .all(id);

  const marksStats = db
    .prepare(
      `SELECT COUNT(*) as total_rows,
              COUNT(CASE WHEN status = 'submitted' THEN 1 END) as submitted_rows,
              MAX(updated_at) as last_activity_at
       FROM marks WHERE entered_by = ? OR submitted_by = ?`
    )
    .get(id, id) as { total_rows: number; submitted_rows: number; last_activity_at: string | null };

  const recentLogs = db
    .prepare(`SELECT id, action, entity_type, entity_id, details as details_json, created_at FROM audit_logs WHERE user_id = ? ORDER BY id DESC LIMIT 15`)
    .all(id);

  res.json({
    ...user,
    isActive: Boolean(user.is_active),
    isDeleted: Boolean(user.is_deleted),
    mustChangePassword: Boolean(user.must_change_password),
    roles,
    assignments,
    classTeacherAssignments,
    marksStats,
    recentLogs,
  });
});

app.put('/api/admin/users/:id/assignments', requireAuth, requireAdmin, (req: AuthenticatedRequest, res) => {
  const teacherId = Number(req.params.id);
  const { academicYear, subjectAssignments, classTeacherSections } = req.body as {
    academicYear?: string;
    subjectAssignments?: Array<{ subjectId: number; componentId: number; classId: number; sectionId: number }>;
    classTeacherSections?: Array<{ classId: number; sectionId: number }>;
  };

  const teacher = db.prepare(`SELECT id, full_name, username FROM users WHERE id = ? AND COALESCE(is_deleted, 0) = 0`).get(teacherId) as any;
  if (!teacher) return res.status(404).json({ error: 'Active teacher not found.' });

  const year = academicYear && academicYear !== 'all' && academicYear.trim() ? academicYear.trim() : getCurrentAcademicYear();

  try {
    const counts = db.transaction(() => {
      db.prepare(`INSERT OR IGNORE INTO academic_years (name, is_current, is_deleted) VALUES (?, ?, 0)`).run(
        year,
        year === getCurrentAcademicYear() ? 1 : 0
      );

      let subUpdated = 0;
      if (Array.isArray(subjectAssignments)) {
        db.prepare(`DELETE FROM teacher_assignments WHERE teacher_id = ? AND academic_year = ?`).run(teacherId, year);
        const findSlot = db.prepare(
          `SELECT id FROM teacher_assignments
           WHERE subject_id = ? AND component_id = ? AND class_id = ? AND section_id = ? AND academic_year = ?`
        );
        const updateSlot = db.prepare(`UPDATE teacher_assignments SET teacher_id = ? WHERE id = ?`);
        const insertSlot = db.prepare(
          `INSERT INTO teacher_assignments (teacher_id, subject_id, component_id, class_id, section_id, academic_year)
           VALUES (?, ?, ?, ?, ?, ?)`
        );

        for (const a of subjectAssignments) {
          if (!a.subjectId || !a.componentId || !a.classId || !a.sectionId) continue;
          const existing = findSlot.get(Number(a.subjectId), Number(a.componentId), Number(a.classId), Number(a.sectionId), year) as
            | { id: number }
            | undefined;
          if (existing) {
            updateSlot.run(teacherId, existing.id);
          } else {
            insertSlot.run(teacherId, Number(a.subjectId), Number(a.componentId), Number(a.classId), Number(a.sectionId), year);
          }
          subUpdated++;
        }
      }

      let ctUpdated = 0;
      if (Array.isArray(classTeacherSections)) {
        db.prepare(`DELETE FROM class_teacher_assignments WHERE teacher_id = ? AND academic_year = ?`).run(teacherId, year);
        const findCt = db.prepare(
          `SELECT id FROM class_teacher_assignments WHERE class_id = ? AND section_id = ? AND academic_year = ?`
        );
        const updateCt = db.prepare(`UPDATE class_teacher_assignments SET teacher_id = ? WHERE id = ?`);
        const insertCt = db.prepare(
          `INSERT INTO class_teacher_assignments (teacher_id, class_id, section_id, academic_year) VALUES (?, ?, ?, ?)`
        );
        for (const ct of classTeacherSections) {
          if (!ct.classId || !ct.sectionId) continue;
          const existing = findCt.get(Number(ct.classId), Number(ct.sectionId), year) as { id: number } | undefined;
          if (existing) {
            updateCt.run(teacherId, existing.id);
          } else {
            insertCt.run(teacherId, Number(ct.classId), Number(ct.sectionId), year);
          }
          ctUpdated++;
        }
      }

      return { subUpdated, ctUpdated };
    })();

    logAudit(req.user!, 'BATCH_UPDATE_TEACHER_ASSIGNMENTS', 'user', teacherId, {
      username: teacher.username,
      academicYear: year,
      subjectAssignmentsCount: counts.subUpdated,
      classTeacherCount: counts.ctUpdated,
    });

    const userRecord = getUserRecordById(teacherId, year);
    res.json({ success: true, academicYear: year, ...counts, user: userRecord });
  } catch (err: any) {
    res.status(400).json({ error: err?.message || 'Failed to save teacher assignments.' });
  }
});

app.post('/api/admin/users/:id/reset-password', requireAuth, requireAdmin, (req: AuthenticatedRequest, res) => {
  const id = Number(req.params.id);
  const { newPassword } = req.body as { newPassword?: string };
  if (!newPassword || newPassword.trim().length < 6) {
    return res.status(400).json({ error: 'New password must be at least 6 characters.' });
  }
  const existing = db.prepare(`SELECT id, username, full_name FROM users WHERE id = ?`).get(id) as any;
  if (!existing) return res.status(404).json({ error: 'User not found.' });

  try {
    db.transaction(() => {
      db.prepare(`UPDATE users SET password_hash = ?, must_change_password = 1, updated_at = datetime('now') WHERE id = ?`).run(
        hashPassword(newPassword.trim()),
        id
      );
      db.prepare(`DELETE FROM sessions WHERE user_id = ?`).run(id);
    })();
  } catch (err: any) {
    return res.status(400).json({ error: err?.message || 'Could not reset user password.' });
  }

  logAudit(req.user!, 'RESET_USER_PASSWORD', 'user', id, { username: existing.username });
  res.json({ success: true });
});

app.post('/api/admin/users', requireAuth, requireAdmin, (req: AuthenticatedRequest, res) => {
  const { username, password, fullName, email, employeeCode, role } = req.body as {
    username?: string;
    password?: string;
    fullName?: string;
    email?: string;
    employeeCode?: string;
    role?: 'admin' | 'teacher';
  };

  if (!username?.trim() || !password || !fullName?.trim()) {
    return res.status(400).json({ error: 'Username, temporary password, and full name are required.' });
  }
  if (password.trim().length < 6) {
    return res.status(400).json({ error: 'Temporary password must be at least 6 characters.' });
  }

  const existing = db.prepare(`SELECT id FROM users WHERE lower(username) = lower(?)`).get(username.trim());
  if (existing) {
    return res.status(409).json({ error: `Username "${username}" is already taken.` });
  }

  let empCode = employeeCode?.trim() || '';
  if (!empCode && role !== 'admin') {
    let nextNum = (db.prepare(`SELECT COALESCE(MAX(id), 0) as m FROM users`).get() as { m: number }).m + 1;
    empCode = `TCH-${String(nextNum).padStart(3, '0')}`;
    while (db.prepare(`SELECT 1 FROM users WHERE lower(employee_code) = lower(?)`).get(empCode)) {
      nextNum += 1;
      empCode = `TCH-${String(nextNum).padStart(3, '0')}`;
    }
  }

  const roleName = role === 'admin' ? 'admin' : 'teacher';
  const roleRow = db.prepare(`SELECT id FROM roles WHERE name = ?`).get(roleName) as { id: number };
  const passHash = hashPassword(password);

  const tx = db.transaction(() => {
    const info = db
      .prepare(
        `INSERT INTO users (username, password_hash, full_name, email, employee_code, is_active, must_change_password, is_deleted)
         VALUES (?, ?, ?, ?, ?, 1, 1, 0)`
      )
      .run(username.trim(), passHash, fullName.trim(), email?.trim() || '', empCode);
    const userId = Number(info.lastInsertRowid);
    db.prepare(`INSERT INTO user_roles (user_id, role_id) VALUES (?, ?)`).run(userId, roleRow.id);
    return userId;
  });

  try {
    const userId = tx();
    logAudit(req.user!, 'CREATE_USER', 'user', userId, {
      username: username.trim(),
      fullName: fullName.trim(),
      employeeCode: empCode,
      role: roleName,
    });
    const reqYear = typeof req.body?.academicYear === 'string' ? req.body.academicYear : undefined;
    const userRecord = getUserRecordById(userId, reqYear);
    res.status(201).json({ id: userId, employeeCode: empCode, user: userRecord });
  } catch (err: any) {
    res.status(400).json({ error: err?.message || 'Failed to create user.' });
  }
});

app.put('/api/admin/users/:id', requireAuth, requireAdmin, (req: AuthenticatedRequest, res) => {
  const id = Number(req.params.id);
  const { username, fullName, email, employeeCode, isActive, newPassword, role } = req.body as {
    username?: string;
    fullName?: string;
    email?: string;
    employeeCode?: string;
    isActive?: boolean;
    newPassword?: string;
    role?: 'admin' | 'teacher';
  };

  const existing = db.prepare(`SELECT * FROM users WHERE id = ?`).get(id) as any;
  if (!existing) return res.status(404).json({ error: 'User not found.' });

  if (id === req.user!.id && isActive === false) {
    return res.status(400).json({ error: 'You cannot deactivate your own administrator account.' });
  }

  const nextUsername = username !== undefined ? username.trim() : existing.username;
  if (!nextUsername) {
    return res.status(400).json({ error: 'Username cannot be empty.' });
  }
  if (nextUsername.toLowerCase() !== String(existing.username).toLowerCase()) {
    const conflict = db
      .prepare(`SELECT id FROM users WHERE lower(username) = lower(?) AND id != ?`)
      .get(nextUsername, id);
    if (conflict) {
      return res.status(409).json({ error: `Username "${nextUsername}" is already taken.` });
    }
  }

  try {
    db.transaction(() => {
      db.prepare(
        `UPDATE users SET username = ?, full_name = ?, email = ?, employee_code = ?, is_active = ?, updated_at = datetime('now') WHERE id = ?`
      ).run(
        nextUsername,
        fullName !== undefined ? fullName.trim() : existing.full_name,
        email !== undefined ? email.trim() : existing.email,
        employeeCode !== undefined ? employeeCode.trim() : existing.employee_code,
        isActive === undefined ? existing.is_active : isActive ? 1 : 0,
        id
      );

      if (isActive === false) {
        db.prepare(`DELETE FROM sessions WHERE user_id = ?`).run(id);
      }

      if (newPassword && newPassword.trim().length >= 6) {
        db.prepare(`UPDATE users SET password_hash = ?, must_change_password = 1 WHERE id = ?`).run(
          hashPassword(newPassword.trim()),
          id
        );
        db.prepare(`DELETE FROM sessions WHERE user_id = ?`).run(id);
      }

      if (role) {
        const roleRow = db.prepare(`SELECT id FROM roles WHERE name = ?`).get(role) as { id: number } | undefined;
        if (roleRow) {
          db.prepare(`DELETE FROM user_roles WHERE user_id = ?`).run(id);
          db.prepare(`INSERT INTO user_roles (user_id, role_id) VALUES (?, ?)`).run(id, roleRow.id);
        }
      }
    })();

    logAudit(req.user!, 'UPDATE_USER', 'user', id, {
      username: nextUsername,
      fullName,
      isActive,
      passwordReset: Boolean(newPassword),
      role,
    });
    const reqYear = typeof req.body?.academicYear === 'string' ? req.body.academicYear : undefined;
    const userRecord = getUserRecordById(id, reqYear);
    res.json({ success: true, user: userRecord });
  } catch (err: any) {
    res.status(400).json({ error: err?.message || 'Failed to update user.' });
  }
});

function countRemainingActiveAdmins(excludeUserIds: number[]): number {
  const ph = excludeUserIds.length > 0 ? excludeUserIds.map(() => '?').join(',') : '-1';
  const row = db
    .prepare(
      `SELECT COUNT(DISTINCT u.id) as cnt
       FROM users u
       JOIN user_roles ur ON ur.user_id = u.id
       JOIN roles r ON r.id = ur.role_id
       WHERE r.name = 'admin' AND u.is_active = 1 AND COALESCE(u.is_deleted, 0) = 0
         AND u.id NOT IN (${ph})`
    )
    .get(...excludeUserIds) as { cnt: number };
  return Number(row?.cnt || 0);
}

function permanentlyDeleteUsersInDb(userIds: number[]): number {
  if (userIds.length === 0) return 0;
  const ph = userIds.map(() => '?').join(',');

  // Clear attribution & audit references so previously entered student marks remain intact without dangling user IDs
  db.prepare(`UPDATE marks SET entered_by = NULL WHERE entered_by IN (${ph})`).run(...userIds);
  db.prepare(`UPDATE marks SET submitted_by = NULL WHERE submitted_by IN (${ph})`).run(...userIds);
  db.prepare(`UPDATE internal_assessment_marks SET entered_by = NULL WHERE entered_by IN (${ph})`).run(...userIds);
  db.prepare(`UPDATE internal_assessment_marks SET submitted_by = NULL WHERE submitted_by IN (${ph})`).run(...userIds);
  db.prepare(`UPDATE internal_assessment_marks SET nb_by = NULL WHERE nb_by IN (${ph})`).run(...userIds);
  db.prepare(`UPDATE internal_assessment_marks SET ut_by = NULL WHERE ut_by IN (${ph})`).run(...userIds);
  db.prepare(`UPDATE internal_assessment_marks SET pr_by = NULL WHERE pr_by IN (${ph})`).run(...userIds);
  db.prepare(`UPDATE internal_assessment_marks SET op_by = NULL WHERE op_by IN (${ph})`).run(...userIds);
  db.prepare(`UPDATE mark_correction_requests SET reviewed_by = NULL WHERE reviewed_by IN (${ph})`).run(...userIds);
  db.prepare(`UPDATE audit_logs SET user_id = NULL WHERE user_id IN (${ph})`).run(...userIds);
  db.prepare(`UPDATE students SET deleted_by = NULL WHERE deleted_by IN (${ph})`).run(...userIds);
  db.prepare(`UPDATE users SET deleted_by = NULL WHERE deleted_by IN (${ph})`).run(...userIds);
  db.prepare(`UPDATE classes SET deleted_by = NULL WHERE deleted_by IN (${ph})`).run(...userIds);
  db.prepare(`UPDATE sections SET deleted_by = NULL WHERE deleted_by IN (${ph})`).run(...userIds);
  db.prepare(`UPDATE subjects SET deleted_by = NULL WHERE deleted_by IN (${ph})`).run(...userIds);
  db.prepare(`UPDATE examinations SET deleted_by = NULL WHERE deleted_by IN (${ph})`).run(...userIds);

  // Remove teacher-owned assignments, sessions, correction requests, and role mappings
  db.prepare(`DELETE FROM mark_correction_requests WHERE requested_by IN (${ph})`).run(...userIds);
  db.prepare(`DELETE FROM ia_teacher_assignments WHERE teacher_id IN (${ph})`).run(...userIds);
  db.prepare(`DELETE FROM class_teacher_assignments WHERE teacher_id IN (${ph})`).run(...userIds);
  db.prepare(`DELETE FROM teacher_assignments WHERE teacher_id IN (${ph})`).run(...userIds);
  db.prepare(`DELETE FROM sessions WHERE user_id IN (${ph})`).run(...userIds);
  db.prepare(`DELETE FROM user_roles WHERE user_id IN (${ph})`).run(...userIds);

  const res = db.prepare(`DELETE FROM users WHERE id IN (${ph})`).run(...userIds);
  return res.changes;
}

app.delete('/api/admin/users/:id', requireAuth, requireAdmin, (req: AuthenticatedRequest, res) => {
  const id = Number(req.params.id);
  const isPermanent = req.query.permanent === '1' || req.query.permanent === 'true';
  if (id === req.user!.id) {
    return res.status(400).json({ error: 'You cannot delete your own active administrator account.' });
  }
  const existing = db.prepare(`SELECT id, username, full_name, employee_code FROM users WHERE id = ?`).get(id) as any;
  if (!existing) return res.status(404).json({ error: 'User not found.' });

  if (countRemainingActiveAdmins([id]) === 0) {
    return res.status(400).json({ error: 'Cannot remove the last active administrator account.' });
  }

  try {
    if (isPermanent) {
      db.transaction(() => {
        permanentlyDeleteUsersInDb([id]);
      })();
      checkpointWal();
      logAudit(req.user!, 'PERMANENT_DELETE_USER', 'user', id, {
        username: existing.username,
        fullName: existing.full_name,
        permanentlyDeleted: true,
      });
      return res.json({
        success: true,
        permanentlyDeleted: true,
        id,
        username: existing.username,
        fullName: existing.full_name,
      });
    }

    // Soft-delete preserves all previously submitted marks and attribution while freeing active slot assignments
    db.transaction(() => {
      const subAssigns = db
        .prepare(`SELECT subject_id, component_id, class_id, section_id, academic_year FROM teacher_assignments WHERE teacher_id = ?`)
        .all(id);
      const ctAssigns = db
        .prepare(`SELECT class_id, section_id, academic_year FROM class_teacher_assignments WHERE teacher_id = ?`)
        .all(id);

      db.prepare(
        `UPDATE users
         SET is_deleted = 1, is_active = 0, deleted_at = datetime('now'), deleted_by = ?,
             archived_assignments_json = ?, updated_at = datetime('now')
         WHERE id = ?`
      ).run(req.user!.id, JSON.stringify({ subjectAssignments: subAssigns, classTeacherAssignments: ctAssigns }), id);

      db.prepare(`DELETE FROM teacher_assignments WHERE teacher_id = ?`).run(id);
      db.prepare(`DELETE FROM class_teacher_assignments WHERE teacher_id = ?`).run(id);
      db.prepare(`DELETE FROM ia_teacher_assignments WHERE teacher_id = ?`).run(id);
      db.prepare(`DELETE FROM sessions WHERE user_id = ?`).run(id);
    })();
  } catch (err: any) {
    return res.status(400).json({ error: err?.message || 'Could not remove user account.' });
  }

  logAudit(req.user!, 'SOFT_DELETE_USER', 'user', id, {
    username: existing.username,
    fullName: existing.full_name,
    preservedMarks: true,
  });
  res.json({ success: true, softDeleted: true, id, username: existing.username, fullName: existing.full_name });
});

app.post('/api/admin/users/bulk-action', requireAuth, requireAdmin, (req: AuthenticatedRequest, res) => {
  const { action, ids } = req.body as {
    action?: 'delete' | 'archive' | 'permanent_delete' | 'restore' | 'activate' | 'deactivate';
    ids?: number[];
  };

  if (!action || !Array.isArray(ids) || ids.length === 0) {
    return res.status(400).json({ error: 'Action and at least one selected user ID are required.' });
  }

  const uniqueIds = Array.from(new Set(ids.map(Number).filter((n) => Number.isInteger(n) && n > 0)));
  if ((action === 'delete' || action === 'archive' || action === 'permanent_delete' || action === 'deactivate') && uniqueIds.includes(req.user!.id)) {
    return res.status(400).json({ error: 'You cannot archive, delete, or deactivate your own active administrator account.' });
  }

  const placeholders = uniqueIds.map(() => '?').join(',');
  const rows = db
    .prepare(`SELECT id, username, full_name, employee_code, archived_assignments_json FROM users WHERE id IN (${placeholders})`)
    .all(...uniqueIds) as Array<any>;

  if (rows.length === 0) {
    return res.status(404).json({ error: 'Selected users were not found.' });
  }

  if ((action === 'delete' || action === 'archive' || action === 'permanent_delete' || action === 'deactivate') && countRemainingActiveAdmins(rows.map((r) => r.id)) === 0) {
    return res.status(400).json({ error: 'Cannot remove or deactivate all remaining active administrator accounts.' });
  }

  let result: { affectedCount: number; records: Array<{ id: number; username: string; fullName: string; employeeCode: string }> };
  try {
    result = db.transaction(() => {
      let affectedCount = 0;

      if (action === 'permanent_delete') {
        affectedCount = permanentlyDeleteUsersInDb(rows.map((u) => u.id));
        checkpointWal();
      } else if (action === 'delete' || action === 'archive') {
        for (const u of rows) {
          const subAssigns = db
            .prepare(`SELECT subject_id, component_id, class_id, section_id, academic_year FROM teacher_assignments WHERE teacher_id = ?`)
            .all(u.id);
          const ctAssigns = db
            .prepare(`SELECT class_id, section_id, academic_year FROM class_teacher_assignments WHERE teacher_id = ?`)
            .all(u.id);
          db.prepare(
            `UPDATE users
             SET is_deleted = 1, is_active = 0, deleted_at = datetime('now'), deleted_by = ?,
                 archived_assignments_json = ?, updated_at = datetime('now')
             WHERE id = ?`
          ).run(req.user!.id, JSON.stringify({ subjectAssignments: subAssigns, classTeacherAssignments: ctAssigns }), u.id);
          db.prepare(`DELETE FROM teacher_assignments WHERE teacher_id = ?`).run(u.id);
          db.prepare(`DELETE FROM class_teacher_assignments WHERE teacher_id = ?`).run(u.id);
          db.prepare(`DELETE FROM ia_teacher_assignments WHERE teacher_id = ?`).run(u.id);
          db.prepare(`DELETE FROM sessions WHERE user_id = ?`).run(u.id);
          affectedCount++;
        }
      } else if (action === 'restore') {
        const restoreStmt = db.prepare(
          `UPDATE users
           SET is_deleted = 0, is_active = 1, deleted_at = NULL, deleted_by = NULL, updated_at = datetime('now')
           WHERE id = ?`
        );
        const restoreSub = db.prepare(
          `INSERT OR IGNORE INTO teacher_assignments (teacher_id, subject_id, component_id, class_id, section_id, academic_year)
           VALUES (?, ?, ?, ?, ?, ?)`
        );
        const restoreCt = db.prepare(
          `INSERT OR IGNORE INTO class_teacher_assignments (teacher_id, class_id, section_id, academic_year)
           VALUES (?, ?, ?, ?)`
        );
        for (const u of rows) {
          restoreStmt.run(u.id);
          if (u.archived_assignments_json) {
            try {
              const parsed = JSON.parse(u.archived_assignments_json);
              if (Array.isArray(parsed.subjectAssignments)) {
                for (const a of parsed.subjectAssignments) {
                  restoreSub.run(u.id, a.subject_id, a.component_id, a.class_id, a.section_id, a.academic_year);
                }
              }
              if (Array.isArray(parsed.classTeacherAssignments)) {
                for (const ct of parsed.classTeacherAssignments) {
                  restoreCt.run(u.id, ct.class_id, ct.section_id, ct.academic_year);
                }
              }
            } catch {
              // ignore malformed archived snapshot
            }
          }
          affectedCount++;
        }
      } else if (action === 'activate' || action === 'deactivate') {
        const nextActive = action === 'activate' ? 1 : 0;
        const stmt = db.prepare(`UPDATE users SET is_active = ?, updated_at = datetime('now') WHERE id = ?`);
        for (const u of rows) {
          stmt.run(nextActive, u.id);
          if (nextActive === 0) {
            db.prepare(`DELETE FROM sessions WHERE user_id = ?`).run(u.id);
          }
          affectedCount++;
        }
      }

      return {
        affectedCount,
        records: rows.map((u) => ({ id: u.id, username: u.username, fullName: u.full_name, employeeCode: u.employee_code })),
      };
    })();
  } catch (err: any) {
    return res.status(400).json({ error: err?.message || 'User bulk operation failed.' });
  }

  logAudit(req.user!, `BULK_${action.toUpperCase()}_USERS`, 'user', uniqueIds.join(','), {
    action,
    affectedCount: result.affectedCount,
    permanentlyDeleted: action === 'permanent_delete',
    usernames: result.records.map((r) => r.username),
  });

  res.json({
    success: true,
    action,
    permanentlyDeleted: action === 'permanent_delete',
    ...result,
  });
});

// Classes & Sections CRUD
app.get('/api/admin/classes', requireAuth, (req, res) => {
  const academicYear = (req.query.academicYear as string) || getCurrentAcademicYear();
  const viewMode = req.query.view === 'archived' ? 'archived' : req.query.view === 'all' ? 'all' : 'active';

  const classFilter =
    viewMode === 'active'
      ? `WHERE COALESCE(is_deleted, 0) = 0`
      : viewMode === 'archived'
        ? `WHERE COALESCE(is_deleted, 0) = 1`
        : '';

  const sectionFilter =
    viewMode === 'active'
      ? `WHERE COALESCE(s.is_deleted, 0) = 0`
      : viewMode === 'archived'
        ? `WHERE COALESCE(s.is_deleted, 0) = 1`
        : '';

  const classes = db
    .prepare(`SELECT id, name, numeric_order, COALESCE(has_sections, 1) as has_sections, is_active, COALESCE(is_deleted, 0) as is_deleted, deleted_at FROM classes ${classFilter} ORDER BY numeric_order ASC`)
    .all() as Array<any>;
  const sections = db
    .prepare(
      `SELECT s.id, s.class_id, s.name, s.capacity, COALESCE(s.is_deleted, 0) as is_deleted, s.deleted_at,
              (SELECT COUNT(*) FROM student_enrollments se
               JOIN students st ON st.id = se.student_id
               WHERE se.section_id = s.id AND se.academic_year = ? AND se.status = 'active' AND COALESCE(st.is_deleted, 0) = 0) as student_count
       FROM sections s ${sectionFilter} ORDER BY s.name ASC`
    )
    .all(academicYear) as Array<any>;
  res.json(
    classes.map((c) => ({
      ...c,
      hasSections: Boolean(c.has_sections ?? 1),
      isDeleted: Boolean(c.is_deleted),
      sections: sections
        .filter((s) => s.class_id === c.id)
        .map((s) => ({ ...s, isDeleted: Boolean(s.is_deleted) })),
    }))
  );
});

app.post('/api/admin/classes', requireAuth, requireAdmin, (req: AuthenticatedRequest, res) => {
  const { name, numericOrder, hasSections = true, defaultSections } = req.body as {
    name?: string;
    numericOrder?: number;
    hasSections?: boolean;
    defaultSections?: string[];
  };
  if (!name?.trim()) return res.status(400).json({ error: 'Class name is required.' });

  const hasSecFlag = hasSections !== false ? 1 : 0;

  try {
    const classId = db.transaction(() => {
      const info = db
        .prepare(`INSERT INTO classes (name, numeric_order, has_sections, is_active, is_deleted) VALUES (?, ?, ?, 1, 0)`)
        .run(name.trim(), Number(numericOrder || 10), hasSecFlag);
      const cid = Number(info.lastInsertRowid);
      if (hasSecFlag === 0) {
        db.prepare(`INSERT INTO sections (class_id, name, capacity, is_deleted) VALUES (?, 'General', 60, 0)`).run(cid);
      } else {
        const secs = defaultSections && defaultSections.length > 0 ? defaultSections : ['A', 'B'];
        for (const s of secs) {
          if (s.trim()) {
            db.prepare(`INSERT INTO sections (class_id, name, capacity, is_deleted) VALUES (?, ?, 30, 0)`).run(cid, s.trim().toUpperCase());
          }
        }
      }
      return cid;
    })();
    logAudit(req.user!, 'CREATE_CLASS', 'class', classId, { name, hasSections: Boolean(hasSecFlag) });
    res.status(201).json({ id: classId });
  } catch (err: any) {
    res.status(400).json({ error: err.message || 'Class already exists.' });
  }
});

app.put('/api/admin/classes/:id', requireAuth, requireAdmin, (req: AuthenticatedRequest, res) => {
  const id = Number(req.params.id);
  const { name, numericOrder, isActive, hasSections } = req.body as {
    name?: string;
    numericOrder?: number;
    isActive?: boolean;
    hasSections?: boolean;
  };
  const existing = db.prepare(`SELECT * FROM classes WHERE id = ?`).get(id) as any;
  if (!existing) return res.status(404).json({ error: 'Class not found.' });

  const nextHasSections = hasSections !== undefined ? (hasSections ? 1 : 0) : Number(existing.has_sections ?? 1);

  try {
    db.transaction(() => {
      db.prepare(`UPDATE classes SET name = ?, numeric_order = ?, has_sections = ?, is_active = ? WHERE id = ?`).run(
        name !== undefined ? name.trim() : existing.name,
        numericOrder !== undefined ? Number(numericOrder) : existing.numeric_order,
        nextHasSections,
        isActive !== undefined ? (isActive ? 1 : 0) : existing.is_active,
        id
      );

      // Ensure at least one active backing section exists
      const activeSecs = db
        .prepare(`SELECT id, name FROM sections WHERE class_id = ? AND COALESCE(is_deleted, 0) = 0`)
        .all(id) as Array<{ id: number; name: string }>;
      if (activeSecs.length === 0) {
        db.prepare(`INSERT INTO sections (class_id, name, capacity, is_deleted) VALUES (?, ?, 60, 0)`).run(
          id,
          nextHasSections ? 'A' : 'General'
        );
      }
    })();
    logAudit(req.user!, 'UPDATE_CLASS', 'class', id, { name, numericOrder, isActive, hasSections });
    res.json({ success: true });
  } catch (err: any) {
    res.status(400).json({ error: err.message || 'Could not update class.' });
  }
});

app.post('/api/admin/sections', requireAuth, requireAdmin, (req: AuthenticatedRequest, res) => {
  const { classId, name, capacity } = req.body as { classId: number; name: string; capacity?: number };
  if (!classId || !name?.trim()) return res.status(400).json({ error: 'Class and section name required.' });
  try {
    const info = db
      .prepare(`INSERT INTO sections (class_id, name, capacity, is_deleted) VALUES (?, ?, ?, 0)`)
      .run(Number(classId), name.trim().toUpperCase(), Number(capacity || 30));
    logAudit(req.user!, 'CREATE_SECTION', 'section', Number(info.lastInsertRowid), { classId, name });
    res.status(201).json({ id: info.lastInsertRowid });
  } catch (err: any) {
    res.status(400).json({ error: err.message || 'Section already exists in this class.' });
  }
});

app.put('/api/admin/sections/:id', requireAuth, requireAdmin, (req: AuthenticatedRequest, res) => {
  const id = Number(req.params.id);
  const { name, capacity } = req.body as { name?: string; capacity?: number };
  const existing = db.prepare(`SELECT * FROM sections WHERE id = ?`).get(id) as any;
  if (!existing) return res.status(404).json({ error: 'Section not found.' });

  try {
    db.prepare(`UPDATE sections SET name = ?, capacity = ? WHERE id = ?`).run(
      name !== undefined ? name.trim().toUpperCase() : existing.name,
      capacity !== undefined ? Number(capacity) : existing.capacity,
      id
    );
    logAudit(req.user!, 'UPDATE_SECTION', 'section', id, { name, capacity });
    res.json({ success: true });
  } catch (err: any) {
    res.status(400).json({ error: err.message || 'Could not update section.' });
  }
});

app.delete('/api/admin/sections/:id', requireAuth, requireAdmin, (req: AuthenticatedRequest, res) => {
  const id = Number(req.params.id);
  const existing = db.prepare(`SELECT id, class_id, name FROM sections WHERE id = ?`).get(id) as any;
  if (!existing) return res.status(404).json({ error: 'Section not found.' });

  const activeCount = (
    db
      .prepare(
        `SELECT COUNT(DISTINCT se.student_id) as cnt
         FROM student_enrollments se
         JOIN students st ON st.id = se.student_id
         WHERE se.section_id = ? AND se.status = 'active' AND COALESCE(st.is_deleted, 0) = 0`
      )
      .get(id) as { cnt: number }
  ).cnt;
  if (activeCount > 0) {
    return res.status(409).json({ error: `Cannot archive section with ${activeCount} active enrolled students. Transfer or archive students first.` });
  }

  db.prepare(`UPDATE sections SET is_deleted = 1, deleted_at = datetime('now'), deleted_by = ? WHERE id = ?`).run(
    req.user!.id,
    id
  );
  logAudit(req.user!, 'SOFT_DELETE_SECTION', 'section', id, existing);
  res.json({ success: true, softDeleted: true, id, name: existing.name });
});

app.post('/api/admin/sections/bulk-action', requireAuth, requireAdmin, (req: AuthenticatedRequest, res) => {
  const { action, ids } = req.body as {
    action?: 'delete' | 'archive' | 'restore';
    ids?: number[];
  };
  if (!action || !Array.isArray(ids) || ids.length === 0) {
    return res.status(400).json({ error: 'Action and at least one section ID are required.' });
  }
  const uniqueIds = Array.from(new Set(ids.map(Number).filter((n) => Number.isInteger(n) && n > 0)));
  const placeholders = uniqueIds.map(() => '?').join(',');
  const rows = db.prepare(`SELECT id, class_id, name FROM sections WHERE id IN (${placeholders})`).all(...uniqueIds) as any[];
  if (rows.length === 0) return res.status(404).json({ error: 'Selected sections were not found.' });

  if (action === 'delete' || action === 'archive') {
    for (const r of rows) {
      const cnt = (
        db
          .prepare(
            `SELECT COUNT(DISTINCT se.student_id) as cnt FROM student_enrollments se
             JOIN students st ON st.id = se.student_id
             WHERE se.section_id = ? AND se.status = 'active' AND COALESCE(st.is_deleted, 0) = 0`
          )
          .get(r.id) as { cnt: number }
      ).cnt;
      if (cnt > 0) {
        return res.status(409).json({
          error: `Section "${r.name}" has ${cnt} active students. Transfer or archive students before removing sections.`,
        });
      }
    }
  }

  try {
    db.transaction(() => {
      if (action === 'restore') {
        const st = db.prepare(`UPDATE sections SET is_deleted = 0, deleted_at = NULL, deleted_by = NULL WHERE id = ?`);
        for (const r of rows) st.run(r.id);
      } else {
        const st = db.prepare(`UPDATE sections SET is_deleted = 1, deleted_at = datetime('now'), deleted_by = ? WHERE id = ?`);
        for (const r of rows) st.run(req.user!.id, r.id);
      }
    })();
  } catch (err: any) {
    return res.status(400).json({ error: err?.message || 'Bulk section update failed.' });
  }

  logAudit(req.user!, `BULK_${action.toUpperCase()}_SECTIONS`, 'section', uniqueIds.join(','), {
    action,
    affectedCount: rows.length,
  });
  res.json({ success: true, action, affectedCount: rows.length, records: rows });
});

app.delete('/api/admin/classes/:id', requireAuth, requireAdmin, (req: AuthenticatedRequest, res) => {
  const id = Number(req.params.id);
  const existing = db.prepare(`SELECT id, name FROM classes WHERE id = ?`).get(id) as any;
  if (!existing) return res.status(404).json({ error: 'Class not found.' });

  const activeCount = (
    db
      .prepare(
        `SELECT COUNT(DISTINCT se.student_id) as cnt
         FROM student_enrollments se
         JOIN students st ON st.id = se.student_id
         WHERE se.class_id = ? AND se.status = 'active' AND COALESCE(st.is_deleted, 0) = 0`
      )
      .get(id) as { cnt: number }
  ).cnt;
  if (activeCount > 0) {
    return res.status(409).json({ error: `Cannot archive class "${existing.name}" with ${activeCount} active enrolled students.` });
  }

  try {
    db.transaction(() => {
      db.prepare(`UPDATE classes SET is_deleted = 1, is_active = 0, deleted_at = datetime('now'), deleted_by = ? WHERE id = ?`).run(
        req.user!.id,
        id
      );
      db.prepare(`UPDATE sections SET is_deleted = 1, deleted_at = datetime('now'), deleted_by = ? WHERE class_id = ?`).run(
        req.user!.id,
        id
      );
    })();
  } catch (err: any) {
    return res.status(400).json({ error: err?.message || 'Could not archive class.' });
  }
  logAudit(req.user!, 'SOFT_DELETE_CLASS', 'class', id, existing);
  res.json({ success: true, softDeleted: true, id, name: existing.name });
});

app.post('/api/admin/classes/bulk-action', requireAuth, requireAdmin, (req: AuthenticatedRequest, res) => {
  const { action, ids } = req.body as {
    action?: 'delete' | 'archive' | 'restore' | 'activate' | 'deactivate';
    ids?: number[];
  };
  if (!action || !Array.isArray(ids) || ids.length === 0) {
    return res.status(400).json({ error: 'Action and at least one class ID are required.' });
  }
  const uniqueIds = Array.from(new Set(ids.map(Number).filter((n) => Number.isInteger(n) && n > 0)));
  const placeholders = uniqueIds.map(() => '?').join(',');
  const rows = db.prepare(`SELECT id, name FROM classes WHERE id IN (${placeholders})`).all(...uniqueIds) as any[];
  if (rows.length === 0) return res.status(404).json({ error: 'Selected classes were not found.' });

  if (action === 'delete' || action === 'archive') {
    for (const r of rows) {
      const cnt = (
        db
          .prepare(
            `SELECT COUNT(DISTINCT se.student_id) as cnt FROM student_enrollments se
             JOIN students st ON st.id = se.student_id
             WHERE se.class_id = ? AND se.status = 'active' AND COALESCE(st.is_deleted, 0) = 0`
          )
          .get(r.id) as { cnt: number }
      ).cnt;
      if (cnt > 0) {
        return res.status(409).json({
          error: `Class "${r.name}" has ${cnt} active students. Transfer or archive students first.`,
        });
      }
    }
  }

  try {
    db.transaction(() => {
      if (action === 'delete' || action === 'archive') {
        const upC = db.prepare(`UPDATE classes SET is_deleted = 1, is_active = 0, deleted_at = datetime('now'), deleted_by = ? WHERE id = ?`);
        const upS = db.prepare(`UPDATE sections SET is_deleted = 1, deleted_at = datetime('now'), deleted_by = ? WHERE class_id = ?`);
        for (const r of rows) {
          upC.run(req.user!.id, r.id);
          upS.run(req.user!.id, r.id);
        }
      } else if (action === 'restore') {
        const upC = db.prepare(`UPDATE classes SET is_deleted = 0, is_active = 1, deleted_at = NULL, deleted_by = NULL WHERE id = ?`);
        const upS = db.prepare(`UPDATE sections SET is_deleted = 0, deleted_at = NULL, deleted_by = NULL WHERE class_id = ?`);
        for (const r of rows) {
          upC.run(r.id);
          upS.run(r.id);
        }
      } else if (action === 'activate' || action === 'deactivate') {
        const nextActive = action === 'activate' ? 1 : 0;
        const upC = db.prepare(`UPDATE classes SET is_active = ? WHERE id = ?`);
        for (const r of rows) upC.run(nextActive, r.id);
      }
    })();
  } catch (err: any) {
    return res.status(400).json({ error: err?.message || 'Bulk class update failed.' });
  }

  logAudit(req.user!, `BULK_${action.toUpperCase()}_CLASSES`, 'class', uniqueIds.join(','), {
    action,
    affectedCount: rows.length,
  });
  res.json({ success: true, action, affectedCount: rows.length, records: rows });
});

// Subjects & Components CRUD
function recalculateSubjectTotals(subjectId: number) {
  const sub = db.prepare(`SELECT * FROM subjects WHERE id = ?`).get(subjectId) as any;
  if (!sub) return;
  const comps = db
    .prepare(
      `SELECT default_max_marks FROM subject_components WHERE subject_id = ? ORDER BY display_order ASC, id ASC`
    )
    .all(subjectId) as Array<{ default_max_marks: number }>;
  const iaTotal = sub.has_internal_assessment
    ? Number(sub.ia_notebook_max || 0) +
      Number(sub.ia_unit_test_max || 0) +
      Number(sub.ia_practical_max || 0) +
      Number(sub.ia_participation_max || 0)
    : 0;
  const mode: string =
    sub.component_mode === 'elective'
      ? 'elective'
      : sub.component_mode === 'combined' || comps.length > 1
        ? 'combined'
        : 'single';
  const writtenMax =
    mode === 'elective'
      ? comps[0]?.default_max_marks ?? 0
      : comps.reduce((sum, c) => sum + Number(c.default_max_marks || 0), 0);
  const hasComp = mode !== 'single' || comps.length > 1 ? 1 : 0;
  db.prepare(`UPDATE subjects SET default_max_marks = ?, has_components = ?, component_mode = ? WHERE id = ?`).run(
    writtenMax + iaTotal,
    hasComp,
    mode,
    subjectId
  );
}

app.get('/api/admin/subjects', requireAuth, (req, res) => {
  const viewMode = req.query.view === 'archived' ? 'archived' : req.query.view === 'all' ? 'all' : 'active';
  const whereClause =
    viewMode === 'active'
      ? `WHERE COALESCE(is_deleted, 0) = 0`
      : viewMode === 'archived'
        ? `WHERE COALESCE(is_deleted, 0) = 1`
        : '';

  const subjects = db
    .prepare(`SELECT * FROM subjects ${whereClause} ORDER BY display_order ASC, id ASC`)
    .all() as Array<any>;
  const components = db
    .prepare(`SELECT * FROM subject_components ORDER BY display_order ASC, id ASC`)
    .all() as Array<any>;

  res.json(
    subjects.map((s) => {
      const subComps = components.filter((c) => c.subject_id === s.id);
      const componentMode =
        s.component_mode === 'elective'
          ? 'elective'
          : s.component_mode === 'combined' || Boolean(s.has_components) || subComps.length > 1
            ? 'combined'
            : 'single';
      return {
        ...s,
        isDeleted: Boolean(s.is_deleted),
        hasComponents: Boolean(s.has_components),
        componentMode,
        hasInternalAssessment: Boolean(s.has_internal_assessment),
        hasPractical: Boolean(s.has_practical),
        streamCategory: s.stream_category || '',
        applicableClassIds: parseTargetClassIds(s.applicable_class_ids),
        iaNotebookMax: Number(s.ia_notebook_max ?? 5),
        iaUnitTestMax: Number(s.ia_unit_test_max ?? 5),
        iaPracticalMax: Number(s.ia_practical_max ?? 5),
        iaParticipationMax: Number(s.ia_participation_max ?? 5),
        components: subComps,
      };
    })
  );
});

app.post('/api/admin/subjects', requireAuth, requireAdmin, (req: AuthenticatedRequest, res) => {
  const {
    code,
    name,
    defaultMaxMarks,
    hasComponents,
    componentMode,
    hasInternalAssessment = true,
    hasPractical = false,
    streamCategory = '',
    applicableClassIds = [],
    iaNotebookMax = 5,
    iaUnitTestMax = 5,
    iaPracticalMax = 5,
    iaParticipationMax = 5,
    components,
  } = req.body as {
    code: string;
    name: string;
    defaultMaxMarks: number;
    hasComponents?: boolean;
    componentMode?: 'single' | 'combined' | 'elective';
    hasInternalAssessment?: boolean;
    hasPractical?: boolean;
    streamCategory?: string;
    applicableClassIds?: number[];
    iaNotebookMax?: number;
    iaUnitTestMax?: number;
    iaPracticalMax?: number;
    iaParticipationMax?: number;
    components?: Array<{ name: string; code: string; defaultMaxMarks: number }>;
  };

  if (!code || !name) return res.status(400).json({ error: 'Subject code and name are required.' });

  const cleanSubjectCode = String(code).trim().toUpperCase();
  const cleanSubjectName = String(name).trim();
  if (!cleanSubjectCode || !cleanSubjectName) {
    return res.status(400).json({ error: 'Subject code and name are required.' });
  }

  const dupSubject = db
    .prepare(`SELECT id FROM subjects WHERE upper(trim(code)) = ? LIMIT 1`)
    .get(cleanSubjectCode) as { id: number } | undefined;
  if (dupSubject) {
    return res.status(409).json({ error: `A subject with code "${cleanSubjectCode}" already exists.` });
  }

  const cleanClassIds = parseTargetClassIds(applicableClassIds);
  const serializedClassIds = cleanClassIds.length > 0 ? JSON.stringify(cleanClassIds) : '';
  const cleanStreamCat = ['Common', 'Science', 'Humanities', 'Language'].includes(String(streamCategory || ''))
    ? String(streamCategory)
    : '';

  try {
    const subId = db.transaction(() => {
      const orderRow = db.prepare(`SELECT COALESCE(MAX(display_order), 0) + 1 as ord FROM subjects`).get() as {
        ord: number;
      };
      const hasIa = hasInternalAssessment ? 1 : 0;
      const nbMax = hasIa ? Number(iaNotebookMax ?? 5) : 0;
      const utMax = hasIa ? Number(iaUnitTestMax ?? 5) : 0;
      const prMax = hasIa ? Number(iaPracticalMax ?? 5) : 0;
      const opMax = hasIa ? Number(iaParticipationMax ?? 5) : 0;
      const iaTotal = nbMax + utMax + prMax + opMax;

      const validProvidedComps = Array.isArray(components)
        ? components
            .filter((c) => c.name?.trim() && c.code?.trim())
            .map((c) => ({
              name: c.name.trim(),
              code: c.code.trim().toUpperCase(),
              defaultMaxMarks: Number(c.defaultMaxMarks),
            }))
        : [];
      const seenNames = new Set<string>();
      for (const c of validProvidedComps) {
        const key = c.name.toLowerCase();
        if (seenNames.has(key)) {
          throw new Error(`Duplicate paper/option name "${c.name}" within this subject.`);
        }
        seenNames.add(key);
        if (!Number.isFinite(c.defaultMaxMarks) || c.defaultMaxMarks <= 0) {
          throw new Error(`Max marks for "${c.name}" must be greater than 0.`);
        }
      }

      const effectiveMode: 'single' | 'combined' | 'elective' =
        componentMode === 'elective'
          ? 'elective'
          : componentMode === 'combined' || hasComponents || validProvidedComps.length > 1
            ? 'combined'
            : 'single';

      const comps =
        validProvidedComps.length > 0
          ? validProvidedComps
          : [
              {
                name: cleanSubjectName,
                code: cleanSubjectCode,
                defaultMaxMarks: Number(defaultMaxMarks || (hasIa ? 80 : 100)),
              },
            ];
      const writtenMax =
        effectiveMode === 'elective'
          ? Number(comps[0]?.defaultMaxMarks || 0)
          : comps.reduce((s, c) => s + Number(c.defaultMaxMarks), 0);
      const totalMax = writtenMax + iaTotal;

      const info = db
        .prepare(
          `INSERT INTO subjects (code, name, default_max_marks, has_components, component_mode, has_internal_assessment, has_practical, stream_category, applicable_class_ids, ia_notebook_max, ia_unit_test_max, ia_practical_max, ia_participation_max, display_order)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
        )
        .run(
          code.trim().toUpperCase(),
          name.trim(),
          totalMax,
          effectiveMode !== 'single' || comps.length > 1 ? 1 : 0,
          effectiveMode,
          hasIa,
          hasPractical ? 1 : 0,
          cleanStreamCat,
          serializedClassIds,
          nbMax,
          utMax,
          prMax,
          opMax,
          orderRow.ord
        );
      const sid = Number(info.lastInsertRowid);
      comps.forEach((c, idx) => {
        db.prepare(
          `INSERT INTO subject_components (subject_id, name, code, default_max_marks, display_order) VALUES (?, ?, ?, ?, ?)`
        ).run(sid, c.name.trim(), c.code.trim().toUpperCase(), Number(c.defaultMaxMarks), idx + 1);
      });
      return sid;
    })();
    logAudit(req.user!, 'CREATE_SUBJECT', 'subject', subId, {
      code,
      name,
      componentMode,
      hasPractical,
      streamCategory: cleanStreamCat,
      applicableClassIds: cleanClassIds,
    });
    res.status(201).json({ id: subId });
  } catch (err: any) {
    res.status(400).json({ error: err.message || 'Could not create subject.' });
  }
});

app.put('/api/admin/subjects/:id', requireAuth, requireAdmin, (req: AuthenticatedRequest, res) => {
  const id = Number(req.params.id);
  const {
    name,
    code,
    defaultMaxMarks,
    writtenMaxMarks,
    componentMode,
    hasInternalAssessment,
    hasPractical,
    streamCategory,
    applicableClassIds,
    iaNotebookMax,
    iaUnitTestMax,
    iaPracticalMax,
    iaParticipationMax,
    isActive,
    components,
  } = req.body as {
    name?: string;
    code?: string;
    defaultMaxMarks?: number;
    writtenMaxMarks?: number;
    componentMode?: 'single' | 'combined' | 'elective';
    hasInternalAssessment?: boolean;
    hasPractical?: boolean;
    streamCategory?: string;
    applicableClassIds?: number[];
    iaNotebookMax?: number;
    iaUnitTestMax?: number;
    iaPracticalMax?: number;
    iaParticipationMax?: number;
    isActive?: boolean;
    components?: Array<{ id: number; name: string; code: string; defaultMaxMarks: number }>;
  };
  const existing = db.prepare(`SELECT * FROM subjects WHERE id = ?`).get(id) as any;
  if (!existing) return res.status(404).json({ error: 'Subject not found.' });

  const nextSubName = name !== undefined ? name.trim() : existing.name;
  const nextSubCode = code !== undefined ? code.trim().toUpperCase() : existing.code;
  if (!nextSubName || !nextSubCode) {
    return res.status(400).json({ error: 'Subject name and code cannot be empty.' });
  }
  const dupCode = db
    .prepare(`SELECT id FROM subjects WHERE upper(trim(code)) = ? AND id != ? LIMIT 1`)
    .get(nextSubCode, id) as { id: number } | undefined;
  if (dupCode) {
    return res.status(409).json({ error: `Another subject already uses code "${nextSubCode}".` });
  }

  try {
    db.transaction(() => {
      const nextHasIa =
        hasInternalAssessment !== undefined ? (hasInternalAssessment ? 1 : 0) : existing.has_internal_assessment;
      const nbMax = nextHasIa ? Number(iaNotebookMax ?? existing.ia_notebook_max ?? 5) : 0;
      const utMax = nextHasIa ? Number(iaUnitTestMax ?? existing.ia_unit_test_max ?? 5) : 0;
      const prMax = nextHasIa ? Number(iaPracticalMax ?? existing.ia_practical_max ?? 5) : 0;
      const opMax = nextHasIa ? Number(iaParticipationMax ?? existing.ia_participation_max ?? 5) : 0;
      const iaTotal = nextHasIa ? nbMax + utMax + prMax + opMax : 0;
      const nextMode = componentMode ?? existing.component_mode ?? (existing.has_components ? 'combined' : 'single');
      const nextHasPractical =
        hasPractical !== undefined ? (hasPractical ? 1 : 0) : Number(existing.has_practical ?? 0);
      const nextStreamCategory =
        streamCategory !== undefined
          ? ['Common', 'Science', 'Humanities', 'Language'].includes(String(streamCategory))
            ? String(streamCategory)
            : ''
          : (existing.stream_category || '');
      const nextApplicableClassIds =
        applicableClassIds !== undefined
          ? (() => {
              const ids = parseTargetClassIds(applicableClassIds);
              return ids.length > 0 ? JSON.stringify(ids) : '';
            })()
          : (existing.applicable_class_ids || '');

      db.prepare(
        `UPDATE subjects
         SET name = ?, code = ?, is_active = ?, component_mode = ?,
             has_internal_assessment = ?, has_practical = ?, stream_category = ?, applicable_class_ids = ?,
             ia_notebook_max = ?, ia_unit_test_max = ?, ia_practical_max = ?, ia_participation_max = ?
         WHERE id = ?`
      ).run(
        nextSubName,
        nextSubCode,
        isActive === undefined ? existing.is_active : isActive ? 1 : 0,
        nextMode,
        nextHasIa,
        nextHasPractical,
        nextStreamCategory,
        nextApplicableClassIds,
        nbMax,
        utMax,
        prMax,
        opMax,
        id
      );

      if (Array.isArray(components) && components.length > 0) {
        const seenNames = new Set<string>();
        const existingComps = db
          .prepare(`SELECT id, name FROM subject_components WHERE subject_id = ?`)
          .all(id) as Array<{ id: number; name: string }>;
        const updatedCompIds = new Set(components.map((c) => Number(c.id)));
        for (const ec of existingComps) {
          if (!updatedCompIds.has(ec.id)) seenNames.add(ec.name.trim().toLowerCase());
        }
        for (const comp of components) {
          const cleanCompName = String(comp.name || '').trim();
          const cleanCompCode = String(comp.code || '').trim().toUpperCase();
          const cleanMax = Number(comp.defaultMaxMarks);
          if (!cleanCompName || !cleanCompCode) {
            throw new Error('Component name and code cannot be empty.');
          }
          if (!Number.isFinite(cleanMax) || cleanMax <= 0) {
            throw new Error(`Max marks for "${cleanCompName}" must be greater than 0.`);
          }
          const lowerName = cleanCompName.toLowerCase();
          if (seenNames.has(lowerName)) {
            throw new Error(`Duplicate paper/option name "${cleanCompName}" in this subject.`);
          }
          seenNames.add(lowerName);

          db.prepare(
            `UPDATE subject_components SET name = ?, code = ?, default_max_marks = ? WHERE id = ? AND subject_id = ?`
          ).run(cleanCompName, cleanCompCode, cleanMax, comp.id, id);
          db.prepare(
            `UPDATE examination_components SET component_name = ? WHERE component_id = ? AND subject_id = ?`
          ).run(cleanCompName, comp.id, id);
        }
      } else if (!existing.has_components && (writtenMaxMarks !== undefined || defaultMaxMarks !== undefined)) {
        const nextWritten =
          writtenMaxMarks !== undefined
            ? Number(writtenMaxMarks)
            : Math.max(1, Number(defaultMaxMarks) - iaTotal);
        db.prepare(`UPDATE subject_components SET default_max_marks = ?, name = ?, code = ? WHERE subject_id = ?`).run(
          nextWritten,
          nextSubName,
          nextSubCode,
          id
        );
        db.prepare(`UPDATE examination_components SET component_name = ? WHERE subject_id = ?`).run(nextSubName, id);
      }

      recalculateSubjectTotals(id);
    })();

    logAudit(req.user!, 'UPDATE_SUBJECT', 'subject', id, {
      name,
      code,
      componentMode,
      hasInternalAssessment,
      hasPractical,
      streamCategory,
      applicableClassIds,
      iaNotebookMax,
      iaUnitTestMax,
      iaPracticalMax,
      iaParticipationMax,
      componentsUpdated: components?.length ?? 0,
    });
    res.json({ success: true });
  } catch (err: any) {
    res.status(400).json({ error: err.message || 'Could not update subject marks.' });
  }
});

app.delete('/api/admin/subjects/:id', requireAuth, requireAdmin, (req: AuthenticatedRequest, res) => {
  const id = Number(req.params.id);
  const existing = db.prepare(`SELECT id, code, name FROM subjects WHERE id = ?`).get(id) as any;
  if (!existing) return res.status(404).json({ error: 'Subject not found.' });

  // Soft-delete preserves all historical exam marks and report cards
  db.prepare(`UPDATE subjects SET is_deleted = 1, is_active = 0, deleted_at = datetime('now'), deleted_by = ? WHERE id = ?`).run(
    req.user!.id,
    id
  );
  logAudit(req.user!, 'SOFT_DELETE_SUBJECT', 'subject', id, existing);
  res.json({ success: true, softDeleted: true, id, code: existing.code, name: existing.name });
});

app.post('/api/admin/subjects/bulk-action', requireAuth, requireAdmin, (req: AuthenticatedRequest, res) => {
  const { action, ids } = req.body as {
    action?: 'delete' | 'archive' | 'restore' | 'activate' | 'deactivate';
    ids?: number[];
  };
  if (!action || !Array.isArray(ids) || ids.length === 0) {
    return res.status(400).json({ error: 'Action and at least one subject ID are required.' });
  }
  const uniqueIds = Array.from(new Set(ids.map(Number).filter((n) => Number.isInteger(n) && n > 0)));
  const placeholders = uniqueIds.map(() => '?').join(',');
  const rows = db.prepare(`SELECT id, code, name FROM subjects WHERE id IN (${placeholders})`).all(...uniqueIds) as any[];
  if (rows.length === 0) return res.status(404).json({ error: 'Selected subjects were not found.' });

  try {
    db.transaction(() => {
      if (action === 'delete' || action === 'archive') {
        const stmt = db.prepare(`UPDATE subjects SET is_deleted = 1, is_active = 0, deleted_at = datetime('now'), deleted_by = ? WHERE id = ?`);
        for (const r of rows) stmt.run(req.user!.id, r.id);
      } else if (action === 'restore') {
        const stmt = db.prepare(`UPDATE subjects SET is_deleted = 0, is_active = 1, deleted_at = NULL, deleted_by = NULL WHERE id = ?`);
        for (const r of rows) stmt.run(r.id);
      } else if (action === 'activate' || action === 'deactivate') {
        const nextActive = action === 'activate' ? 1 : 0;
        const stmt = db.prepare(`UPDATE subjects SET is_active = ? WHERE id = ?`);
        for (const r of rows) stmt.run(nextActive, r.id);
      }
    })();
  } catch (err: any) {
    return res.status(400).json({ error: err?.message || 'Bulk subject update failed.' });
  }

  logAudit(req.user!, `BULK_${action.toUpperCase()}_SUBJECTS`, 'subject', uniqueIds.join(','), {
    action,
    affectedCount: rows.length,
  });
  res.json({ success: true, action, affectedCount: rows.length, records: rows });
});

app.post('/api/admin/subjects/:id/components', requireAuth, requireAdmin, (req: AuthenticatedRequest, res) => {
  const subjectId = Number(req.params.id);
  const { name, code, defaultMaxMarks } = req.body as {
    name?: string;
    code?: string;
    defaultMaxMarks?: number;
  };
  const cleanName = String(name || '').trim();
  const cleanCode = String(code || '').trim().toUpperCase();
  const parsedMax = Number(defaultMaxMarks ?? 25);

  if (!cleanName || !cleanCode) {
    return res.status(400).json({ error: 'Component name and code are required.' });
  }
  if (!Number.isFinite(parsedMax) || parsedMax <= 0) {
    return res.status(400).json({ error: 'Default max marks must be a positive number.' });
  }

  const sub = db.prepare(`SELECT id, component_mode FROM subjects WHERE id = ?`).get(subjectId) as
    | { id: number; component_mode: string }
    | undefined;
  if (!sub) return res.status(404).json({ error: 'Subject not found.' });

  const dupComp = db
    .prepare(
      `SELECT id FROM subject_components
       WHERE subject_id = ? AND (lower(trim(name)) = lower(?) OR upper(trim(code)) = ?)
       LIMIT 1`
    )
    .get(subjectId, cleanName, cleanCode) as { id: number } | undefined;
  if (dupComp) {
    return res.status(409).json({
      error: `A paper or elective option with name "${cleanName}" or code "${cleanCode}" already exists under this subject.`,
    });
  }

  try {
    const cid = db.transaction(() => {
      const ordRow = db
        .prepare(`SELECT COALESCE(MAX(display_order), 0) + 1 as ord FROM subject_components WHERE subject_id = ?`)
        .get(subjectId) as { ord: number };
      const info = db
        .prepare(
          `INSERT INTO subject_components (subject_id, name, code, default_max_marks, display_order) VALUES (?, ?, ?, ?, ?)`
        )
        .run(subjectId, cleanName, cleanCode, parsedMax, ordRow.ord);
      const newCompId = Number(info.lastInsertRowid);

      if (sub.component_mode === 'single') {
        db.prepare(`UPDATE subjects SET component_mode = 'combined', has_components = 1 WHERE id = ?`).run(subjectId);
      }
      recalculateSubjectTotals(subjectId);

      // Sync the newly added paper/elective into matching examinations so marks entry works immediately
      const examSubs =
        sub.component_mode === 'elective'
          ? (db
              .prepare(
                `SELECT es.id as es_id, es.examination_id
                 FROM examination_subjects es
                 JOIN examinations e ON e.id = es.examination_id
                 WHERE es.subject_id = ? AND COALESCE(e.is_deleted, 0) = 0`
              )
              .all(subjectId) as Array<{ es_id: number; examination_id: number }>)
          : (db
              .prepare(
                `SELECT es.id as es_id, es.examination_id
                 FROM examination_subjects es
                 JOIN examinations e ON e.id = es.examination_id
                 WHERE es.subject_id = ? AND COALESCE(e.is_deleted, 0) = 0 AND e.status IN ('Upcoming', 'Active')`
              )
              .all(subjectId) as Array<{ es_id: number; examination_id: number }>);

      const getSiblingEc = db.prepare(
        `SELECT max_marks, passing_marks FROM examination_components WHERE examination_subject_id = ? ORDER BY display_order ASC, id ASC LIMIT 1`
      );
      const getEcOrder = db.prepare(
        `SELECT COALESCE(MAX(display_order), 0) + 1 as ord FROM examination_components WHERE examination_subject_id = ?`
      );
      const insertEc = db.prepare(
        `INSERT OR IGNORE INTO examination_components
         (examination_id, examination_subject_id, subject_id, component_id, component_name, max_marks, passing_marks, display_order)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?)`
      );

      for (const es of examSubs) {
        const ecOrd = (getEcOrder.get(es.es_id) as { ord: number }).ord;
        if (sub.component_mode === 'elective') {
          const sib = getSiblingEc.get(es.es_id) as { max_marks: number; passing_marks: number } | undefined;
          const ecMax = Number(sib?.max_marks ?? parsedMax);
          const ecPass = Number(sib?.passing_marks ?? Math.round(ecMax * 0.33));
          insertEc.run(es.examination_id, es.es_id, subjectId, newCompId, cleanName, ecMax, ecPass, ecOrd);
        } else {
          const examRow = db
            .prepare(`SELECT passing_percentage FROM examinations WHERE id = ?`)
            .get(es.examination_id) as { passing_percentage: number } | undefined;
          const passPct = Number(examRow?.passing_percentage ?? 33);
          const ecPass = Math.round((parsedMax * passPct) / 100);
          insertEc.run(es.examination_id, es.es_id, subjectId, newCompId, cleanName, parsedMax, ecPass, ecOrd);
          const sumRow = db
            .prepare(`SELECT COALESCE(SUM(max_marks), 0) as total_written FROM examination_components WHERE examination_subject_id = ?`)
            .get(es.es_id) as { total_written: number };
          const esMeta = db
            .prepare(
              `SELECT has_internal_assessment, ia_notebook_max, ia_unit_test_max, ia_practical_max, ia_participation_max
               FROM examination_subjects WHERE id = ?`
            )
            .get(es.es_id) as any;
          const iaSum = esMeta?.has_internal_assessment
            ? Number(esMeta.ia_notebook_max || 0) +
              Number(esMeta.ia_unit_test_max || 0) +
              Number(esMeta.ia_practical_max || 0) +
              Number(esMeta.ia_participation_max || 0)
            : 0;
          const nextTotal = Number(sumRow.total_written || 0) + iaSum;
          db.prepare(`UPDATE examination_subjects SET max_marks = ?, passing_marks = ? WHERE id = ?`).run(
            nextTotal,
            Math.round((nextTotal * passPct) / 100),
            es.es_id
          );
        }
      }

      return newCompId;
    })();
    logAudit(req.user!, 'ADD_SUBJECT_COMPONENT', 'subject_component', cid, {
      subjectId,
      name: cleanName,
      code: cleanCode,
      defaultMaxMarks: parsedMax,
    });
    res.status(201).json({ id: cid });
  } catch (err: any) {
    res.status(400).json({ error: err.message || 'Component could not be added.' });
  }
});

app.put('/api/admin/components/:id', requireAuth, requireAdmin, (req: AuthenticatedRequest, res) => {
  const id = Number(req.params.id);
  const { name, code, defaultMaxMarks } = req.body;
  const existing = db.prepare(`SELECT * FROM subject_components WHERE id = ?`).get(id) as any;
  if (!existing) return res.status(404).json({ error: 'Component not found.' });

  const cleanName = name !== undefined ? String(name).trim() : String(existing.name || '').trim();
  const cleanCode = code !== undefined ? String(code).trim().toUpperCase() : String(existing.code || '').trim().toUpperCase();
  const nextMax = defaultMaxMarks !== undefined ? Number(defaultMaxMarks) : Number(existing.default_max_marks);

  if (!cleanName || !cleanCode) {
    return res.status(400).json({ error: 'Component name and code cannot be empty.' });
  }
  if (!Number.isFinite(nextMax) || nextMax <= 0) {
    return res.status(400).json({ error: 'Default max marks must be a positive number.' });
  }

  const dupComp = db
    .prepare(
      `SELECT id FROM subject_components
       WHERE subject_id = ? AND id != ? AND (lower(trim(name)) = lower(?) OR upper(trim(code)) = ?)
       LIMIT 1`
    )
    .get(existing.subject_id, id, cleanName, cleanCode) as { id: number } | undefined;
  if (dupComp) {
    return res.status(409).json({
      error: `Another paper or elective option under this subject already uses name "${cleanName}" or code "${cleanCode}".`,
    });
  }

  try {
    db.transaction(() => {
      db.prepare(`UPDATE subject_components SET name = ?, code = ?, default_max_marks = ? WHERE id = ?`).run(
        cleanName,
        cleanCode,
        nextMax,
        id
      );
      db.prepare(`UPDATE examination_components SET component_name = ? WHERE component_id = ?`).run(cleanName, id);
      recalculateSubjectTotals(existing.subject_id);
    })();
  } catch (err: any) {
    return res.status(400).json({ error: err?.message || 'Failed to update component.' });
  }

  logAudit(req.user!, 'UPDATE_SUBJECT_COMPONENT', 'subject_component', id, {
    name: cleanName,
    code: cleanCode,
    defaultMaxMarks: nextMax,
  });
  res.json({ success: true });
});

app.delete('/api/admin/components/:id', requireAuth, requireAdmin, (req: AuthenticatedRequest, res) => {
  const id = Number(req.params.id);
  const existing = db.prepare(`SELECT * FROM subject_components WHERE id = ?`).get(id) as any;
  if (!existing) return res.status(404).json({ error: 'Component not found.' });

  const cntRow = db
    .prepare(`SELECT COUNT(*) as cnt FROM subject_components WHERE subject_id = ?`)
    .get(existing.subject_id) as { cnt: number };
  if (cntRow.cnt <= 1) {
    return res.status(400).json({ error: 'Cannot remove the last remaining paper/component. Delete the subject instead.' });
  }

  try {
    db.transaction(() => {
      db.prepare(`DELETE FROM subject_components WHERE id = ?`).run(id);
      const rem = db
        .prepare(`SELECT COUNT(*) as cnt FROM subject_components WHERE subject_id = ?`)
        .get(existing.subject_id) as { cnt: number };
      const sub = db.prepare(`SELECT component_mode FROM subjects WHERE id = ?`).get(existing.subject_id) as {
        component_mode: string;
      };
      if (rem.cnt <= 1 && sub.component_mode !== 'elective') {
        db.prepare(`UPDATE subjects SET component_mode = 'single', has_components = 0 WHERE id = ?`).run(
          existing.subject_id
        );
      }
      recalculateSubjectTotals(existing.subject_id);
    })();
  } catch (err: any) {
    return res.status(400).json({ error: err?.message || 'Failed to delete component.' });
  }

  logAudit(req.user!, 'DELETE_SUBJECT_COMPONENT', 'subject_component', id, existing);
  res.json({ success: true });
});

// Teacher-Subject Assignments
app.get('/api/admin/teacher-assignments', requireAuth, requireAdmin, (req, res) => {
  const academicYear = req.query.academicYear as string | undefined;
  const filterByYear = academicYear && academicYear !== 'all';
  const rows = (
    filterByYear
      ? db
          .prepare(
            `SELECT ta.id, ta.teacher_id, u.full_name as teacher_name, u.username,
                    ta.subject_id, sub.name as subject_name, sub.has_components,
                    ta.component_id, sc.name as component_name,
                    ta.class_id, c.name as class_name, COALESCE(c.has_sections, 1) as has_sections,
                    ta.section_id, s.name as section_name,
                    ta.academic_year
             FROM teacher_assignments ta
             JOIN users u ON u.id = ta.teacher_id
             JOIN subjects sub ON sub.id = ta.subject_id
             JOIN subject_components sc ON sc.id = ta.component_id
             JOIN classes c ON c.id = ta.class_id
             JOIN sections s ON s.id = ta.section_id
             WHERE ta.academic_year = ?
               AND COALESCE(u.is_deleted, 0) = 0 AND COALESCE(sub.is_deleted, 0) = 0
               AND COALESCE(c.is_deleted, 0) = 0 AND COALESCE(s.is_deleted, 0) = 0
             ORDER BY c.numeric_order ASC, s.name ASC, sub.display_order ASC, sc.display_order ASC`
          )
          .all(academicYear)
      : db
          .prepare(
            `SELECT ta.id, ta.teacher_id, u.full_name as teacher_name, u.username,
                    ta.subject_id, sub.name as subject_name, sub.has_components,
                    ta.component_id, sc.name as component_name,
                    ta.class_id, c.name as class_name, COALESCE(c.has_sections, 1) as has_sections,
                    ta.section_id, s.name as section_name,
                    ta.academic_year
             FROM teacher_assignments ta
             JOIN users u ON u.id = ta.teacher_id
             JOIN subjects sub ON sub.id = ta.subject_id
             JOIN subject_components sc ON sc.id = ta.component_id
             JOIN classes c ON c.id = ta.class_id
             JOIN sections s ON s.id = ta.section_id
             WHERE COALESCE(u.is_deleted, 0) = 0 AND COALESCE(sub.is_deleted, 0) = 0
               AND COALESCE(c.is_deleted, 0) = 0 AND COALESCE(s.is_deleted, 0) = 0
             ORDER BY ta.academic_year DESC, c.numeric_order ASC, s.name ASC, sub.display_order ASC, sc.display_order ASC`
          )
          .all()
  ).map((r: any) => ({ ...r, hasSections: Boolean(r.has_sections ?? 1) }));
  res.json(rows);
});

app.post('/api/admin/teacher-assignments', requireAuth, requireAdmin, (req: AuthenticatedRequest, res) => {
  const { teacherId, subjectId, componentId, classId, sectionId, academicYear } = req.body as {
    teacherId: number;
    subjectId: number;
    componentId: number;
    classId: number;
    sectionId?: number;
    academicYear?: string;
  };
  const resolvedSectionId = sectionId ? Number(sectionId) : classId ? resolveDefaultSectionForClass(Number(classId)) : null;
  if (!teacherId || !subjectId || !componentId || !classId || !resolvedSectionId) {
    return res.status(400).json({ error: 'All assignment fields are required.' });
  }
  const year = academicYear && academicYear !== 'all' ? academicYear : getCurrentAcademicYear();
  db.prepare(`INSERT OR IGNORE INTO academic_years (name, is_current, is_deleted) VALUES (?, 0, 0)`).run(year);

  const existing = db
    .prepare(
      `SELECT id FROM teacher_assignments
       WHERE subject_id = ? AND component_id = ? AND class_id = ? AND section_id = ? AND academic_year = ?`
    )
    .get(subjectId, componentId, classId, resolvedSectionId, year) as { id: number } | undefined;

  if (existing) {
    db.prepare(`UPDATE teacher_assignments SET teacher_id = ? WHERE id = ?`).run(teacherId, existing.id);
    logAudit(req.user!, 'UPDATE_TEACHER_ASSIGNMENT', 'teacher_assignment', existing.id, req.body);
    return res.json({ id: existing.id, updated: true });
  }

  const info = db
    .prepare(
      `INSERT INTO teacher_assignments (teacher_id, subject_id, component_id, class_id, section_id, academic_year)
       VALUES (?, ?, ?, ?, ?, ?)`
    )
    .run(teacherId, subjectId, componentId, classId, resolvedSectionId, year);
  logAudit(req.user!, 'CREATE_TEACHER_ASSIGNMENT', 'teacher_assignment', Number(info.lastInsertRowid), req.body);
  res.status(201).json({ id: info.lastInsertRowid });
});

app.post('/api/admin/teacher-assignments/batch', requireAuth, requireAdmin, (req: AuthenticatedRequest, res) => {
  const { teacherId, academicYear, assignments } = req.body as {
    teacherId: number;
    academicYear?: string;
    assignments: Array<{ subjectId: number; componentId: number; classId: number; sectionId?: number }>;
  };
  if (!teacherId || !Array.isArray(assignments) || assignments.length === 0) {
    return res.status(400).json({ error: 'Teacher and at least one subject/class/section mapping are required.' });
  }
  const year = academicYear && academicYear !== 'all' ? academicYear : getCurrentAcademicYear();

  let summary: { createdCount: number; updatedCount: number };
  try {
    summary = db.transaction(() => {
      db.prepare(`INSERT OR IGNORE INTO academic_years (name, is_current, is_deleted) VALUES (?, 0, 0)`).run(year);
      const findSlot = db.prepare(
        `SELECT id FROM teacher_assignments
         WHERE subject_id = ? AND component_id = ? AND class_id = ? AND section_id = ? AND academic_year = ?`
      );
      const updateSlot = db.prepare(`UPDATE teacher_assignments SET teacher_id = ? WHERE id = ?`);
      const insertSlot = db.prepare(
        `INSERT INTO teacher_assignments (teacher_id, subject_id, component_id, class_id, section_id, academic_year)
         VALUES (?, ?, ?, ?, ?, ?)`
      );
      let createdCount = 0;
      let updatedCount = 0;
      for (const a of assignments) {
        const secId = a.sectionId ? Number(a.sectionId) : a.classId ? resolveDefaultSectionForClass(Number(a.classId)) : null;
        if (!a.subjectId || !a.componentId || !a.classId || !secId) continue;
        const existing = findSlot.get(Number(a.subjectId), Number(a.componentId), Number(a.classId), secId, year) as
          | { id: number }
          | undefined;
        if (existing) {
          updateSlot.run(Number(teacherId), existing.id);
          updatedCount++;
        } else {
          insertSlot.run(Number(teacherId), Number(a.subjectId), Number(a.componentId), Number(a.classId), secId, year);
          createdCount++;
        }
      }
      return { createdCount, updatedCount };
    })();
  } catch (err: any) {
    return res.status(400).json({ error: err?.message || 'Failed to save batch teacher assignments.' });
  }

  logAudit(req.user!, 'BATCH_CREATE_TEACHER_ASSIGNMENTS', 'teacher_assignment', teacherId, {
    academicYear: year,
    ...summary,
  });
  res.status(201).json({ success: true, ...summary });
});

app.delete('/api/admin/teacher-assignments/:id', requireAuth, requireAdmin, (req: AuthenticatedRequest, res) => {
  const id = Number(req.params.id);
  db.prepare(`DELETE FROM teacher_assignments WHERE id = ?`).run(id);
  logAudit(req.user!, 'DELETE_TEACHER_ASSIGNMENT', 'teacher_assignment', id, {});
  res.json({ success: true });
});

app.post('/api/admin/teacher-assignments/bulk-delete', requireAuth, requireAdmin, (req: AuthenticatedRequest, res) => {
  const { ids } = req.body as { ids?: number[] };
  if (!Array.isArray(ids) || ids.length === 0) {
    return res.status(400).json({ error: 'Select at least one assignment to delete.' });
  }
  const uniqueIds = Array.from(new Set(ids.map(Number).filter((n) => Number.isInteger(n) && n > 0)));
  const ph = uniqueIds.map(() => '?').join(',');
  const result = db.prepare(`DELETE FROM teacher_assignments WHERE id IN (${ph})`).run(...uniqueIds);
  logAudit(req.user!, 'BULK_DELETE_TEACHER_ASSIGNMENTS', 'teacher_assignment', uniqueIds.join(','), {
    affectedCount: result.changes,
  });
  res.json({ success: true, affectedCount: result.changes });
});

// Class Teacher Assignments
app.get('/api/admin/class-teacher-assignments', requireAuth, requireAdmin, (req, res) => {
  const academicYear = req.query.academicYear as string | undefined;
  const filterByYear = academicYear && academicYear !== 'all';
  const rows = (
    filterByYear
      ? db
          .prepare(
            `SELECT cta.id, cta.teacher_id, u.full_name as teacher_name, u.username,
                    cta.class_id, c.name as class_name, COALESCE(c.has_sections, 1) as has_sections,
                    cta.section_id, s.name as section_name,
                    cta.academic_year
             FROM class_teacher_assignments cta
             JOIN users u ON u.id = cta.teacher_id
             JOIN classes c ON c.id = cta.class_id
             JOIN sections s ON s.id = cta.section_id
             WHERE cta.academic_year = ?
               AND COALESCE(u.is_deleted, 0) = 0 AND COALESCE(c.is_deleted, 0) = 0 AND COALESCE(s.is_deleted, 0) = 0
             ORDER BY c.numeric_order ASC, s.name ASC`
          )
          .all(academicYear)
      : db
          .prepare(
            `SELECT cta.id, cta.teacher_id, u.full_name as teacher_name, u.username,
                    cta.class_id, c.name as class_name, COALESCE(c.has_sections, 1) as has_sections,
                    cta.section_id, s.name as section_name,
                    cta.academic_year
             FROM class_teacher_assignments cta
             JOIN users u ON u.id = cta.teacher_id
             JOIN classes c ON c.id = cta.class_id
             JOIN sections s ON s.id = cta.section_id
             WHERE COALESCE(u.is_deleted, 0) = 0 AND COALESCE(c.is_deleted, 0) = 0 AND COALESCE(s.is_deleted, 0) = 0
             ORDER BY cta.academic_year DESC, c.numeric_order ASC, s.name ASC`
          )
          .all()
  ).map((r: any) => ({ ...r, hasSections: Boolean(r.has_sections ?? 1) }));
  res.json(rows);
});

app.post('/api/admin/class-teacher-assignments', requireAuth, requireAdmin, (req: AuthenticatedRequest, res) => {
  const { teacherId, classId, sectionId, academicYear } = req.body as {
    teacherId: number;
    classId: number;
    sectionId?: number;
    academicYear?: string;
  };
  const resolvedSectionId = sectionId ? Number(sectionId) : classId ? resolveDefaultSectionForClass(Number(classId)) : null;
  if (!teacherId || !classId || !resolvedSectionId) {
    return res.status(400).json({ error: 'Teacher, class, and section are required.' });
  }
  const year = academicYear && academicYear !== 'all' ? academicYear : getCurrentAcademicYear();
  db.prepare(`INSERT OR IGNORE INTO academic_years (name, is_current, is_deleted) VALUES (?, 0, 0)`).run(year);

  const existing = db
    .prepare(
      `SELECT id FROM class_teacher_assignments WHERE class_id = ? AND section_id = ? AND academic_year = ?`
    )
    .get(classId, resolvedSectionId, year) as { id: number } | undefined;

  if (existing) {
    db.prepare(`UPDATE class_teacher_assignments SET teacher_id = ? WHERE id = ?`).run(teacherId, existing.id);
    logAudit(req.user!, 'UPDATE_CLASS_TEACHER', 'class_teacher_assignment', existing.id, req.body);
    return res.json({ id: existing.id, updated: true });
  }

  const info = db
    .prepare(
      `INSERT INTO class_teacher_assignments (teacher_id, class_id, section_id, academic_year) VALUES (?, ?, ?, ?)`
    )
    .run(teacherId, classId, resolvedSectionId, year);
  logAudit(req.user!, 'ASSIGN_CLASS_TEACHER', 'class_teacher_assignment', Number(info.lastInsertRowid), req.body);
  res.status(201).json({ id: info.lastInsertRowid });
});

app.delete('/api/admin/class-teacher-assignments/:id', requireAuth, requireAdmin, (req: AuthenticatedRequest, res) => {
  const id = Number(req.params.id);
  db.prepare(`DELETE FROM class_teacher_assignments WHERE id = ?`).run(id);
  logAudit(req.user!, 'DELETE_CLASS_TEACHER', 'class_teacher_assignment', id, {});
  res.json({ success: true });
});

app.post('/api/admin/class-teacher-assignments/bulk-delete', requireAuth, requireAdmin, (req: AuthenticatedRequest, res) => {
  const { ids } = req.body as { ids?: number[] };
  if (!Array.isArray(ids) || ids.length === 0) {
    return res.status(400).json({ error: 'Select at least one class teacher assignment to delete.' });
  }
  const uniqueIds = Array.from(new Set(ids.map(Number).filter((n) => Number.isInteger(n) && n > 0)));
  const ph = uniqueIds.map(() => '?').join(',');
  const result = db.prepare(`DELETE FROM class_teacher_assignments WHERE id IN (${ph})`).run(...uniqueIds);
  logAudit(req.user!, 'BULK_DELETE_CLASS_TEACHERS', 'class_teacher_assignment', uniqueIds.join(','), {
    affectedCount: result.changes,
  });
  res.json({ success: true, affectedCount: result.changes });
});

// Optional IA Sub-Component Teacher Assignments (Admin can map specific teachers to NB / UT / Pr / OP)
app.get('/api/admin/ia-assignments', requireAuth, requireAdmin, (req, res) => {
  const academicYear = req.query.academicYear as string | undefined;
  const filterByYear = academicYear && academicYear !== 'all';
  const rows = (
    filterByYear
      ? db
          .prepare(
            `SELECT iaa.id, iaa.teacher_id, u.full_name as teacher_name, u.username,
                    iaa.subject_id, sub.name as subject_name,
                    iaa.class_id, c.name as class_name, COALESCE(c.has_sections, 1) as has_sections,
                    iaa.section_id, s.name as section_name,
                    iaa.ia_component, iaa.academic_year
             FROM ia_teacher_assignments iaa
             JOIN users u ON u.id = iaa.teacher_id
             JOIN subjects sub ON sub.id = iaa.subject_id
             JOIN classes c ON c.id = iaa.class_id
             JOIN sections s ON s.id = iaa.section_id
             WHERE iaa.academic_year = ?
               AND COALESCE(u.is_deleted, 0) = 0 AND COALESCE(sub.is_deleted, 0) = 0
               AND COALESCE(c.is_deleted, 0) = 0 AND COALESCE(s.is_deleted, 0) = 0
             ORDER BY c.numeric_order ASC, s.name ASC, sub.display_order ASC, iaa.ia_component ASC`
          )
          .all(academicYear)
      : db
          .prepare(
            `SELECT iaa.id, iaa.teacher_id, u.full_name as teacher_name, u.username,
                    iaa.subject_id, sub.name as subject_name,
                    iaa.class_id, c.name as class_name, COALESCE(c.has_sections, 1) as has_sections,
                    iaa.section_id, s.name as section_name,
                    iaa.ia_component, iaa.academic_year
             FROM ia_teacher_assignments iaa
             JOIN users u ON u.id = iaa.teacher_id
             JOIN subjects sub ON sub.id = iaa.subject_id
             JOIN classes c ON c.id = iaa.class_id
             JOIN sections s ON s.id = iaa.section_id
             WHERE COALESCE(u.is_deleted, 0) = 0 AND COALESCE(sub.is_deleted, 0) = 0
               AND COALESCE(c.is_deleted, 0) = 0 AND COALESCE(s.is_deleted, 0) = 0
             ORDER BY iaa.academic_year DESC, c.numeric_order ASC, s.name ASC, sub.display_order ASC`
          )
          .all()
  ).map((r: any) => ({ ...r, hasSections: Boolean(r.has_sections ?? 1) }));
  res.json(rows);
});

app.post('/api/admin/ia-assignments', requireAuth, requireAdmin, (req: AuthenticatedRequest, res) => {
  const { teacherId, subjectId, classId, sectionId, iaComponent, iaComponents, academicYear } = req.body as {
    teacherId: number;
    subjectId: number;
    classId: number;
    sectionId?: number;
    iaComponent?: 'notebook' | 'unit_test' | 'practical' | 'participation';
    iaComponents?: Array<'notebook' | 'unit_test' | 'practical' | 'participation'>;
    academicYear?: string;
  };
  const validParts: Array<'notebook' | 'unit_test' | 'practical' | 'participation'> = [
    'notebook',
    'unit_test',
    'practical',
    'participation',
  ];
  const requestedParts = Array.isArray(iaComponents) && iaComponents.length > 0
    ? Array.from(new Set(iaComponents))
    : iaComponent
      ? [iaComponent]
      : [];

  const resolvedSectionId = sectionId
    ? Number(sectionId)
    : classId
      ? resolveDefaultSectionForClass(Number(classId))
      : null;

  if (!teacherId || !subjectId || !classId || !resolvedSectionId || requestedParts.length === 0) {
    return res
      .status(400)
      .json({ error: 'Teacher, subject, class, section, and at least one IA component are required.' });
  }
  if (requestedParts.some((part) => !validParts.includes(part))) {
    return res.status(400).json({ error: 'Invalid IA component.' });
  }

  const teacherRow = db
    .prepare(`SELECT id FROM users WHERE id = ? AND COALESCE(is_deleted, 0) = 0`)
    .get(Number(teacherId)) as { id: number } | undefined;
  if (!teacherRow) {
    return res.status(404).json({ error: 'Selected teacher was not found.' });
  }

  const subjectRow = db
    .prepare(`SELECT id FROM subjects WHERE id = ? AND COALESCE(is_deleted, 0) = 0`)
    .get(Number(subjectId)) as { id: number } | undefined;
  if (!subjectRow) {
    return res.status(404).json({ error: 'Selected subject was not found.' });
  }

  const sectionRow = db
    .prepare(
      `SELECT s.id
       FROM sections s
       JOIN classes c ON c.id = s.class_id
       WHERE s.id = ? AND s.class_id = ? AND COALESCE(c.is_deleted, 0) = 0 AND COALESCE(s.is_deleted, 0) = 0`
    )
    .get(resolvedSectionId, Number(classId)) as { id: number } | undefined;
  if (!sectionRow) {
    return res.status(404).json({ error: 'Selected class & section was not found.' });
  }

  const year = academicYear && academicYear !== 'all' ? academicYear : getCurrentAcademicYear();
  db.prepare(`INSERT OR IGNORE INTO academic_years (name, is_current, is_deleted) VALUES (?, 0, 0)`).run(year);

  const findExisting = db.prepare(
    `SELECT id FROM ia_teacher_assignments
     WHERE subject_id = ? AND class_id = ? AND section_id = ? AND ia_component = ? AND academic_year = ?`
  );
  const updateAssign = db.prepare(`UPDATE ia_teacher_assignments SET teacher_id = ? WHERE id = ?`);
  const insertAssign = db.prepare(
    `INSERT INTO ia_teacher_assignments (teacher_id, subject_id, class_id, section_id, ia_component, academic_year)
     VALUES (?, ?, ?, ?, ?, ?)`
  );

  const summary = db.transaction(() => {
    let createdCount = 0;
    let updatedCount = 0;
    let lastId = 0;
    for (const part of requestedParts) {
      const existing = findExisting.get(
        Number(subjectId),
        Number(classId),
        resolvedSectionId,
        part,
        year
      ) as { id: number } | undefined;
      if (existing) {
        updateAssign.run(Number(teacherId), existing.id);
        updatedCount++;
        lastId = existing.id;
      } else {
        const info = insertAssign.run(
          Number(teacherId),
          Number(subjectId),
          Number(classId),
          resolvedSectionId,
          part,
          year
        );
        createdCount++;
        lastId = Number(info.lastInsertRowid);
      }
    }
    return { createdCount, updatedCount, lastId };
  })();

  logAudit(
    req.user!,
    requestedParts.length > 1 ? 'BATCH_IA_ASSIGNMENT' : summary.updatedCount > 0 ? 'UPDATE_IA_ASSIGNMENT' : 'CREATE_IA_ASSIGNMENT',
    'ia_teacher_assignment',
    summary.lastId,
    { teacherId, subjectId, classId, sectionId: resolvedSectionId, iaComponents: requestedParts, academicYear: year }
  );

  return res.status(summary.createdCount > 0 ? 201 : 200).json({
    id: summary.lastId,
    updated: summary.updatedCount > 0 && summary.createdCount === 0,
    createdCount: summary.createdCount,
    updatedCount: summary.updatedCount,
    components: requestedParts,
  });
});

app.post('/api/admin/ia-assignments/batch', requireAuth, requireAdmin, (req: AuthenticatedRequest, res) => {
  const { teacherId, subjectId, classId, sectionId, iaComponents, academicYear } = req.body as {
    teacherId: number;
    subjectId: number;
    classId: number;
    sectionId?: number;
    iaComponents?: Array<'notebook' | 'unit_test' | 'practical' | 'participation'>;
    academicYear?: string;
  };
  const validParts: Array<'notebook' | 'unit_test' | 'practical' | 'participation'> = [
    'notebook',
    'unit_test',
    'practical',
    'participation',
  ];
  const parts =
    Array.isArray(iaComponents) && iaComponents.length > 0
      ? Array.from(new Set(iaComponents)).filter((p) => validParts.includes(p))
      : validParts;

  const resolvedSectionId = sectionId
    ? Number(sectionId)
    : classId
      ? resolveDefaultSectionForClass(Number(classId))
      : null;

  if (!teacherId || !subjectId || !classId || !resolvedSectionId || parts.length === 0) {
    return res
      .status(400)
      .json({ error: 'Teacher, subject, class, section, and IA components are required.' });
  }

  const teacherRow = db
    .prepare(`SELECT id FROM users WHERE id = ? AND COALESCE(is_deleted, 0) = 0`)
    .get(Number(teacherId)) as { id: number } | undefined;
  const subjectRow = db
    .prepare(`SELECT id FROM subjects WHERE id = ? AND COALESCE(is_deleted, 0) = 0`)
    .get(Number(subjectId)) as { id: number } | undefined;
  const sectionRow = db
    .prepare(
      `SELECT s.id
       FROM sections s
       JOIN classes c ON c.id = s.class_id
       WHERE s.id = ? AND s.class_id = ? AND COALESCE(c.is_deleted, 0) = 0 AND COALESCE(s.is_deleted, 0) = 0`
    )
    .get(resolvedSectionId, Number(classId)) as { id: number } | undefined;

  if (!teacherRow || !subjectRow || !sectionRow) {
    return res.status(404).json({ error: 'Invalid teacher, subject, or class & section selected.' });
  }

  const year = academicYear && academicYear !== 'all' ? academicYear : getCurrentAcademicYear();
  db.prepare(`INSERT OR IGNORE INTO academic_years (name, is_current, is_deleted) VALUES (?, 0, 0)`).run(year);

  const findExisting = db.prepare(
    `SELECT id FROM ia_teacher_assignments
     WHERE subject_id = ? AND class_id = ? AND section_id = ? AND ia_component = ? AND academic_year = ?`
  );
  const updateAssign = db.prepare(`UPDATE ia_teacher_assignments SET teacher_id = ? WHERE id = ?`);
  const insertAssign = db.prepare(
    `INSERT INTO ia_teacher_assignments (teacher_id, subject_id, class_id, section_id, ia_component, academic_year)
     VALUES (?, ?, ?, ?, ?, ?)`
  );

  const result = db.transaction(() => {
    let createdCount = 0;
    let updatedCount = 0;
    for (const part of parts) {
      const existing = findExisting.get(
        Number(subjectId),
        Number(classId),
        resolvedSectionId,
        part,
        year
      ) as { id: number } | undefined;
      if (existing) {
        updateAssign.run(Number(teacherId), existing.id);
        updatedCount++;
      } else {
        insertAssign.run(Number(teacherId), Number(subjectId), Number(classId), resolvedSectionId, part, year);
        createdCount++;
      }
    }
    return { createdCount, updatedCount };
  })();

  logAudit(req.user!, 'BATCH_IA_ASSIGNMENT', 'ia_teacher_assignment', `${subjectId}:${classId}:${resolvedSectionId}`, {
    teacherId,
    subjectId,
    classId,
    sectionId: resolvedSectionId,
    iaComponents: parts,
    academicYear: year,
    ...result,
  });

  res.status(201).json({ success: true, ...result, components: parts });
});

app.delete('/api/admin/ia-assignments/:id', requireAuth, requireAdmin, (req: AuthenticatedRequest, res) => {
  const id = Number(req.params.id);
  db.prepare(`DELETE FROM ia_teacher_assignments WHERE id = ?`).run(id);
  logAudit(req.user!, 'DELETE_IA_ASSIGNMENT', 'ia_teacher_assignment', id, {});
  res.json({ success: true });
});

app.post('/api/admin/ia-assignments/bulk-delete', requireAuth, requireAdmin, (req: AuthenticatedRequest, res) => {
  const { ids } = req.body as { ids?: number[] };
  if (!Array.isArray(ids) || ids.length === 0) {
    return res.status(400).json({ error: 'Select at least one IA assignment to delete.' });
  }
  const uniqueIds = Array.from(new Set(ids.map(Number).filter((n) => Number.isInteger(n) && n > 0)));
  const ph = uniqueIds.map(() => '?').join(',');
  const result = db.prepare(`DELETE FROM ia_teacher_assignments WHERE id IN (${ph})`).run(...uniqueIds);
  logAudit(req.user!, 'BULK_DELETE_IA_ASSIGNMENTS', 'ia_teacher_assignment', uniqueIds.join(','), {
    affectedCount: result.changes,
  });
  res.json({ success: true, affectedCount: result.changes });
});

// Examinations Management (Create, Update Status, Open/Close Marks Entry, Configure Max Marks & Components)
app.post('/api/admin/examinations', requireAuth, requireAdmin, (req: AuthenticatedRequest, res) => {
  const { name, examType, academicYear, startDate, endDate, status, marksEntryOpen, passingPercentage, subjects } =
    req.body as {
      name: string;
      examType?: string;
      academicYear?: string;
      startDate: string;
      endDate: string;
      status?: string;
      marksEntryOpen?: boolean;
      passingPercentage?: number;
      subjects: Array<{
        subjectId: number;
        passingMarks: number;
        isRequired?: boolean;
        hasInternalAssessment?: boolean;
        targetClassIds?: number[];
        iaNotebookMax?: number;
        iaUnitTestMax?: number;
        iaPracticalMax?: number;
        iaParticipationMax?: number;
        components: Array<{
          componentId: number;
          componentName: string;
          maxMarks: number;
          passingMarks: number;
        }>;
      }>;
    };

  if (!name || !startDate || !endDate || !subjects || subjects.length === 0) {
    return res.status(400).json({ error: 'Examination name, dates, and at least one subject are required.' });
  }

  const pct = Number(passingPercentage ?? 33);

  try {
    const examId = db.transaction(() => {
      const examYear = academicYear?.trim() || getCurrentAcademicYear();
      db.prepare(`INSERT OR IGNORE INTO academic_years (name, is_current) VALUES (?, 0)`).run(examYear);

      const info = db
        .prepare(
          `INSERT INTO examinations (name, exam_type, academic_year, start_date, end_date, status, marks_entry_open, passing_percentage)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?)`
        )
        .run(
          name.trim(),
          examType?.trim() || 'Regular',
          examYear,
          startDate,
          endDate,
          status || 'Upcoming',
          marksEntryOpen ? 1 : 0,
          pct
        );
      const eid = Number(info.lastInsertRowid);

      const getSubMode = db.prepare(`SELECT component_mode, COALESCE(applicable_class_ids, '') as applicable_class_ids FROM subjects WHERE id = ?`);
      subjects.forEach((sub, sIdx) => {
        const subRow = getSubMode.get(sub.subjectId) as { component_mode: string; applicable_class_ids: string } | undefined;
        const isElective = subRow?.component_mode === 'elective';
        const hasIa = sub.hasInternalAssessment ? 1 : 0;
        const nbMax = hasIa ? Number(sub.iaNotebookMax ?? 5) : 0;
        const utMax = hasIa ? Number(sub.iaUnitTestMax ?? 5) : 0;
        const prMax = hasIa ? Number(sub.iaPracticalMax ?? 5) : 0;
        const opMax = hasIa ? Number(sub.iaParticipationMax ?? 5) : 0;
        const writtenMax = isElective
          ? Number(sub.components[0]?.maxMarks ?? 0)
          : sub.components.reduce((sum, c) => sum + Number(c.maxMarks), 0);
        const subMax = writtenMax + nbMax + utMax + prMax + opMax;
        const passMarks = sub.passingMarks ? Number(sub.passingMarks) : Math.round((subMax * pct) / 100);
        const targetIds =
          sub.targetClassIds !== undefined
            ? parseTargetClassIds(sub.targetClassIds)
            : parseTargetClassIds(subRow?.applicable_class_ids);
        const serializedTargetIds = targetIds.length > 0 ? JSON.stringify(targetIds) : '';
        const esInfo = db
          .prepare(
            `INSERT INTO examination_subjects (examination_id, subject_id, max_marks, passing_marks, has_internal_assessment, ia_notebook_max, ia_unit_test_max, ia_practical_max, ia_participation_max, target_class_ids, is_required, display_order)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
          )
          .run(
            eid,
            sub.subjectId,
            subMax,
            passMarks,
            hasIa,
            nbMax,
            utMax,
            prMax,
            opMax,
            serializedTargetIds,
            sub.isRequired === false ? 0 : 1,
            sIdx + 1
          );
        const esId = Number(esInfo.lastInsertRowid);

        const getCompName = db.prepare(`SELECT name FROM subject_components WHERE id = ?`);
        sub.components.forEach((comp, cIdx) => {
          const compName =
            comp.componentName?.trim() ||
            (getCompName.get(comp.componentId) as { name: string } | undefined)?.name ||
            'Main';
          db.prepare(
            `INSERT INTO examination_components (examination_id, examination_subject_id, subject_id, component_id, component_name, max_marks, passing_marks, display_order)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?)`
          ).run(
            eid,
            esId,
            sub.subjectId,
            comp.componentId,
            compName,
            Number(comp.maxMarks),
            Number(comp.passingMarks ?? Math.round((Number(comp.maxMarks) * pct) / 100)),
            cIdx + 1
          );
        });
      });

      return eid;
    })();

    logAudit(req.user!, 'CREATE_EXAMINATION', 'examination', examId, { name, examType, academicYear, subjectsCount: subjects.length });
    res.status(201).json({ id: examId });
  } catch (err: any) {
    res.status(400).json({ error: err?.message || 'Failed to create examination.' });
  }
});

app.put('/api/admin/examinations/:id', requireAuth, requireAdmin, (req: AuthenticatedRequest, res) => {
  const id = Number(req.params.id);
  const existing = db.prepare(`SELECT * FROM examinations WHERE id = ?`).get(id) as any;
  if (!existing) return res.status(404).json({ error: 'Examination not found.' });

  const {
    name,
    examType,
    academicYear,
    startDate,
    endDate,
    status,
    marksEntryOpen,
    passingPercentage,
    componentUpdates,
    subjectIaUpdates,
    addSubjects,
    removeSubjectIds,
  } = req.body as {
    name?: string;
    examType?: string;
    academicYear?: string;
    startDate?: string;
    endDate?: string;
    status?: string;
    marksEntryOpen?: boolean;
    passingPercentage?: number;
    componentUpdates?: Array<{ examComponentId: number; maxMarks: number; passingMarks: number }>;
    subjectIaUpdates?: Array<{
      examSubjectId: number;
      hasInternalAssessment: boolean;
      iaNotebookMax: number;
      iaUnitTestMax: number;
      iaPracticalMax: number;
      iaParticipationMax?: number;
      passingMarks?: number;
      targetClassIds?: number[];
    }>;
    addSubjects?: number[];
    removeSubjectIds?: number[];
  };

  try {
    db.transaction(() => {
      const nextPct = Number(passingPercentage ?? existing.passing_percentage ?? 33);
      db.prepare(
        `UPDATE examinations
         SET name = ?, exam_type = ?, academic_year = ?, start_date = ?, end_date = ?, status = ?, marks_entry_open = ?, passing_percentage = ?
         WHERE id = ?`
      ).run(
        name ?? existing.name,
        examType !== undefined ? examType.trim() || 'Regular' : (existing.exam_type || 'Regular'),
        academicYear ?? existing.academic_year,
        startDate ?? existing.start_date,
        endDate ?? existing.end_date,
        status ?? existing.status,
        marksEntryOpen === undefined ? existing.marks_entry_open : marksEntryOpen ? 1 : 0,
        nextPct,
        id
      );

      if (removeSubjectIds && removeSubjectIds.length > 0) {
        for (const sid of removeSubjectIds) {
          db.prepare(`DELETE FROM examination_subjects WHERE examination_id = ? AND subject_id = ?`).run(id, Number(sid));
        }
      }

      if (addSubjects && addSubjects.length > 0) {
        const maxOrdRow = db
          .prepare(`SELECT COALESCE(MAX(display_order), 0) as ord FROM examination_subjects WHERE examination_id = ?`)
          .get(id) as { ord: number };
        let ord = Number(maxOrdRow?.ord || 0);
        for (const sid of addSubjects) {
          const already = db
            .prepare(`SELECT id FROM examination_subjects WHERE examination_id = ? AND subject_id = ?`)
            .get(id, Number(sid));
          if (already) continue;
          const sub = db.prepare(`SELECT * FROM subjects WHERE id = ?`).get(Number(sid)) as any;
          if (!sub) continue;
          const comps = db
            .prepare(`SELECT * FROM subject_components WHERE subject_id = ? ORDER BY display_order ASC, id ASC`)
            .all(sub.id) as any[];
          const hasIa = Boolean(sub.has_internal_assessment) ? 1 : 0;
          const nbMax = hasIa ? Number(sub.ia_notebook_max ?? 5) : 0;
          const utMax = hasIa ? Number(sub.ia_unit_test_max ?? 5) : 0;
          const prMax = hasIa ? Number(sub.ia_practical_max ?? 5) : 0;
          const opMax = hasIa ? Number(sub.ia_participation_max ?? 5) : 0;
          const writtenMax =
            sub.component_mode === 'elective'
              ? Number(comps[0]?.default_max_marks ?? 0)
              : comps.reduce((sum, c) => sum + Number(c.default_max_marks || 0), 0);
          const subMax = writtenMax + nbMax + utMax + prMax + opMax;
          const passMarks = Math.round((subMax * nextPct) / 100);
          const defaultTargetIds = parseTargetClassIds(sub.applicable_class_ids);
          const serializedTargets = defaultTargetIds.length > 0 ? JSON.stringify(defaultTargetIds) : '';
          ord += 1;
          const esInfo = db
            .prepare(
              `INSERT INTO examination_subjects (examination_id, subject_id, max_marks, passing_marks, has_internal_assessment, ia_notebook_max, ia_unit_test_max, ia_practical_max, ia_participation_max, target_class_ids, is_required, display_order)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1, ?)`
            )
            .run(id, sub.id, subMax, passMarks, hasIa, nbMax, utMax, prMax, opMax, serializedTargets, ord);
          const esId = Number(esInfo.lastInsertRowid);
          comps.forEach((c, cIdx) => {
            db.prepare(
              `INSERT INTO examination_components (examination_id, examination_subject_id, subject_id, component_id, component_name, max_marks, passing_marks, display_order)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?)`
            ).run(
              id,
              esId,
              sub.id,
              c.id,
              c.name,
              Number(c.default_max_marks),
              Math.round((Number(c.default_max_marks) * nextPct) / 100),
              cIdx + 1
            );
          });
        }
      }

      if (componentUpdates && componentUpdates.length > 0) {
        for (const cu of componentUpdates) {
          db.prepare(
            `UPDATE examination_components SET max_marks = ?, passing_marks = ? WHERE id = ? AND examination_id = ?`
          ).run(Number(cu.maxMarks), Number(cu.passingMarks), cu.examComponentId, id);
        }
      }

      if (subjectIaUpdates && subjectIaUpdates.length > 0) {
        for (const si of subjectIaUpdates) {
          const hasIa = si.hasInternalAssessment ? 1 : 0;
          const nbMax = hasIa ? Number(si.iaNotebookMax ?? 5) : 0;
          const utMax = hasIa ? Number(si.iaUnitTestMax ?? 5) : 0;
          const prMax = hasIa ? Number(si.iaPracticalMax ?? 5) : 0;
          const opMax = hasIa ? Number(si.iaParticipationMax ?? 5) : 0;
          if (si.targetClassIds !== undefined) {
            const targetIds = parseTargetClassIds(si.targetClassIds);
            const serializedTargets = targetIds.length > 0 ? JSON.stringify(targetIds) : '';
            db.prepare(
              `UPDATE examination_subjects
               SET has_internal_assessment = ?, ia_notebook_max = ?, ia_unit_test_max = ?, ia_practical_max = ?, ia_participation_max = ?, target_class_ids = ?
               WHERE id = ? AND examination_id = ?`
            ).run(hasIa, nbMax, utMax, prMax, opMax, serializedTargets, si.examSubjectId, id);
          } else {
            db.prepare(
              `UPDATE examination_subjects
               SET has_internal_assessment = ?, ia_notebook_max = ?, ia_unit_test_max = ?, ia_practical_max = ?, ia_participation_max = ?
               WHERE id = ? AND examination_id = ?`
            ).run(hasIa, nbMax, utMax, prMax, opMax, si.examSubjectId, id);
          }
        }
      }

      if ((componentUpdates && componentUpdates.length > 0) || (subjectIaUpdates && subjectIaUpdates.length > 0)) {
        const examSubs = db
          .prepare(
            `SELECT es.id, es.has_internal_assessment, es.ia_notebook_max, es.ia_unit_test_max, es.ia_practical_max, es.ia_participation_max, s.component_mode
             FROM examination_subjects es
             JOIN subjects s ON s.id = es.subject_id
             WHERE es.examination_id = ?`
          )
          .all(id) as Array<{
          id: number;
          has_internal_assessment: number;
          ia_notebook_max: number;
          ia_unit_test_max: number;
          ia_practical_max: number;
          ia_participation_max: number;
          component_mode: string | null;
        }>;

        const explicitPassMap = new Map<number, number>();
        if (subjectIaUpdates) {
          for (const si of subjectIaUpdates) {
            if (si.passingMarks !== undefined) explicitPassMap.set(si.examSubjectId, Number(si.passingMarks));
          }
        }

        for (const es of examSubs) {
          const compMaxRows = db
            .prepare(`SELECT max_marks FROM examination_components WHERE examination_subject_id = ? ORDER BY display_order ASC, id ASC`)
            .all(es.id) as Array<{ max_marks: number }>;
          const writtenMax =
            es.component_mode === 'elective'
              ? (compMaxRows[0]?.max_marks ?? 0)
              : compMaxRows.reduce((s, r) => s + Number(r.max_marks || 0), 0);
          const iaSum = es.has_internal_assessment
            ? Number(es.ia_notebook_max || 0) +
              Number(es.ia_unit_test_max || 0) +
              Number(es.ia_practical_max || 0) +
              Number(es.ia_participation_max || 0)
            : 0;
          const totalMax = writtenMax + iaSum;
          const passMarks = explicitPassMap.has(es.id)
            ? explicitPassMap.get(es.id)!
            : Math.round((totalMax * nextPct) / 100);
          db.prepare(`UPDATE examination_subjects SET max_marks = ?, passing_marks = ? WHERE id = ?`).run(
            totalMax,
            passMarks,
            es.id
          );
        }
      }
    })();
  } catch (err: any) {
    return res.status(400).json({ error: err?.message || 'Failed to update examination.' });
  }

  logAudit(req.user!, 'UPDATE_EXAMINATION', 'examination', id, {
    status,
    examType,
    marksEntryOpen,
    passingPercentage,
    componentsUpdated: componentUpdates?.length ?? 0,
    iaUpdated: subjectIaUpdates?.length ?? 0,
  });
  res.json({ success: true });
});

app.delete('/api/admin/examinations/:id', requireAuth, requireAdmin, (req: AuthenticatedRequest, res) => {
  const id = Number(req.params.id);
  const existing = db.prepare(`SELECT id, name FROM examinations WHERE id = ?`).get(id) as any;
  if (!existing) return res.status(404).json({ error: 'Examination not found.' });

  // Soft-delete preserves historical examination marks and reports
  db.prepare(
    `UPDATE examinations SET is_deleted = 1, marks_entry_open = 0, deleted_at = datetime('now'), deleted_by = ? WHERE id = ?`
  ).run(req.user!.id, id);
  logAudit(req.user!, 'SOFT_DELETE_EXAMINATION', 'examination', id, existing);
  res.json({ success: true, softDeleted: true, id, name: existing.name });
});

app.post('/api/admin/examinations/bulk-action', requireAuth, requireAdmin, (req: AuthenticatedRequest, res) => {
  const { action, ids } = req.body as {
    action?: 'delete' | 'archive' | 'restore' | 'open_entry' | 'close_entry' | 'set_active' | 'set_completed' | 'set_published';
    ids?: number[];
  };
  if (!action || !Array.isArray(ids) || ids.length === 0) {
    return res.status(400).json({ error: 'Action and at least one examination ID are required.' });
  }
  const uniqueIds = Array.from(new Set(ids.map(Number).filter((n) => Number.isInteger(n) && n > 0)));
  const placeholders = uniqueIds.map(() => '?').join(',');
  const rows = db.prepare(`SELECT id, name FROM examinations WHERE id IN (${placeholders})`).all(...uniqueIds) as any[];
  if (rows.length === 0) return res.status(404).json({ error: 'Selected examinations were not found.' });

  try {
    db.transaction(() => {
      if (action === 'delete' || action === 'archive') {
        const stmt = db.prepare(
          `UPDATE examinations SET is_deleted = 1, marks_entry_open = 0, deleted_at = datetime('now'), deleted_by = ? WHERE id = ?`
        );
        for (const r of rows) stmt.run(req.user!.id, r.id);
      } else if (action === 'restore') {
        const stmt = db.prepare(`UPDATE examinations SET is_deleted = 0, deleted_at = NULL, deleted_by = NULL WHERE id = ?`);
        for (const r of rows) stmt.run(r.id);
      } else if (action === 'open_entry' || action === 'close_entry') {
        const openFlag = action === 'open_entry' ? 1 : 0;
        const stmt = db.prepare(`UPDATE examinations SET marks_entry_open = ? WHERE id = ?`);
        for (const r of rows) stmt.run(openFlag, r.id);
      } else if (action === 'set_active' || action === 'set_completed' || action === 'set_published') {
        const nextStatus = action === 'set_active' ? 'Active' : action === 'set_completed' ? 'Completed' : 'Published';
        const stmt = db.prepare(`UPDATE examinations SET status = ? WHERE id = ?`);
        for (const r of rows) stmt.run(nextStatus, r.id);
      }
    })();
  } catch (err: any) {
    return res.status(400).json({ error: err?.message || 'Bulk examination update failed.' });
  }

  logAudit(req.user!, `BULK_${action.toUpperCase()}_EXAMINATIONS`, 'examination', uniqueIds.join(','), {
    action,
    affectedCount: rows.length,
  });
  res.json({ success: true, action, affectedCount: rows.length, records: rows });
});

// Admin Monitoring & Correction Authorizations
app.get('/api/admin/monitoring', requireAuth, requireAdmin, (req, res) => {
  const examinationId = Number(req.query.examinationId);
  const classId = req.query.classId ? Number(req.query.classId) : undefined;
  const sectionId = req.query.sectionId ? Number(req.query.sectionId) : undefined;

  if (!examinationId) return res.status(400).json({ error: 'examinationId is required.' });
  const rows = getSubmissionMonitoring(examinationId, classId, sectionId);
  res.json(rows);
});

app.get('/api/admin/correction-requests', requireAuth, requireAdmin, (_req, res) => {
  const rows = db
    .prepare(
      `SELECT mcr.*, e.name as examination_name, sub.name as subject_name, ec.component_name,
              c.name as class_name, COALESCE(c.has_sections, 1) as has_sections, s.name as section_name,
              req_user.full_name as requested_by_name, rev_user.full_name as reviewed_by_name
       FROM mark_correction_requests mcr
       JOIN examinations e ON e.id = mcr.examination_id
       JOIN examination_components ec ON ec.id = mcr.examination_component_id
       JOIN subjects sub ON sub.id = ec.subject_id
       JOIN classes c ON c.id = mcr.class_id
       JOIN sections s ON s.id = mcr.section_id
       JOIN users req_user ON req_user.id = mcr.requested_by
       LEFT JOIN users rev_user ON rev_user.id = mcr.reviewed_by
       ORDER BY CASE WHEN mcr.status = 'pending' THEN 0 ELSE 1 END, mcr.created_at DESC`
    )
    .all()
    .map((r: any) => ({ ...r, hasSections: Boolean(r.has_sections ?? 1) }));
  res.json(rows);
});

function unlockComponentMarksAndIa({
  examinationId,
  examComponentId,
  classId,
  sectionId,
  requestedByUserId,
  unlockAllIaParts = false,
}: {
  examinationId: number;
  examComponentId: number;
  classId: number;
  sectionId: number;
  requestedByUserId?: number | null;
  unlockAllIaParts?: boolean;
}) {
  const examRow = db
    .prepare(`SELECT academic_year FROM examinations WHERE id = ?`)
    .get(examinationId) as { academic_year: string } | undefined;
  const examYear = examRow?.academic_year || getCurrentAcademicYear();

  const comp = db
    .prepare(
      `SELECT ec.subject_id, ec.component_id, sub.component_mode, sub.has_components
       FROM examination_components ec
       JOIN subjects sub ON sub.id = ec.subject_id
       WHERE ec.id = ?`
    )
    .get(examComponentId) as
    | { subject_id: number; component_id: number; component_mode: string | null; has_components: number }
    | undefined;

  let targetStudentIds: number[] = [];
  if (comp) {
    const mode = comp.component_mode || (comp.has_components ? 'combined' : 'single');
    targetStudentIds = getTargetStudentsForComponent(
      comp.subject_id,
      comp.component_id,
      mode,
      classId,
      sectionId,
      examYear,
      examinationId
    ).studentIds;
  }

  if (targetStudentIds.length === 0) {
    // Fallback to enrollment/students lookup when component target list is empty
    const hasYearEnrollments =
      (
        db
          .prepare(`SELECT COUNT(*) as cnt FROM student_enrollments WHERE academic_year = ?`)
          .get(examYear) as { cnt: number }
      ).cnt > 0;
    targetStudentIds = (
      hasYearEnrollments
        ? db
            .prepare(
              `SELECT student_id as id FROM student_enrollments WHERE class_id = ? AND section_id = ? AND academic_year = ? AND status = 'active'`
            )
            .all(classId, sectionId, examYear)
        : db
            .prepare(
              `SELECT id FROM students WHERE class_id = ? AND section_id = ? AND status = 'active' AND COALESCE(is_deleted, 0) = 0`
            )
            .all(classId, sectionId)
    ).map((r: any) => Number(r.id));
  }

  if (targetStudentIds.length === 0) return;

  const sPh = targetStudentIds.map(() => '?').join(',');

  db.prepare(
    `UPDATE marks SET status = 'draft', updated_at = datetime('now')
     WHERE examination_id = ? AND examination_component_id = ? AND student_id IN (${sPh})`
  ).run(examinationId, examComponentId, ...targetStudentIds);

  if (comp) {
    const perms =
      unlockAllIaParts || !requestedByUserId
        ? { notebook: true, unit_test: true, practical: true, participation: true }
        : getIaPermissionsForTeacher(
            requestedByUserId,
            false,
            comp.subject_id,
            classId,
            sectionId,
            examYear
          );

    db.prepare(
      `UPDATE internal_assessment_marks
       SET status = 'draft',
           nb_status = CASE WHEN ? = 1 AND nb_status = 'submitted' THEN 'draft' ELSE nb_status END,
           ut_status = CASE WHEN ? = 1 AND ut_status = 'submitted' THEN 'draft' ELSE ut_status END,
           pr_status = CASE WHEN ? = 1 AND pr_status = 'submitted' THEN 'draft' ELSE pr_status END,
           op_status = CASE WHEN ? = 1 AND op_status = 'submitted' THEN 'draft' ELSE op_status END,
           updated_at = datetime('now')
       WHERE examination_id = ? AND subject_id = ? AND student_id IN (${sPh})`
    ).run(
      perms.notebook ? 1 : 0,
      perms.unit_test ? 1 : 0,
      perms.practical ? 1 : 0,
      perms.participation ? 1 : 0,
      examinationId,
      comp.subject_id,
      ...targetStudentIds
    );
  }
}

app.post('/api/admin/correction-requests/:id/resolve', requireAuth, requireAdmin, (req: AuthenticatedRequest, res) => {
  const id = Number(req.params.id);
  const { decision } = req.body as { decision: 'approved' | 'rejected' };
  const reqRow = db.prepare(`SELECT * FROM mark_correction_requests WHERE id = ?`).get(id) as any;
  if (!reqRow) return res.status(404).json({ error: 'Correction request not found.' });
  if (reqRow.status !== 'pending') return res.status(400).json({ error: 'Request already resolved.' });

  try {
    db.transaction(() => {
      db.prepare(
        `UPDATE mark_correction_requests SET status = ?, reviewed_by = ?, reviewed_at = datetime('now') WHERE id = ?`
      ).run(decision, req.user!.id, id);

      if (decision === 'approved') {
        unlockComponentMarksAndIa({
          examinationId: reqRow.examination_id,
          examComponentId: reqRow.examination_component_id,
          classId: reqRow.class_id,
          sectionId: reqRow.section_id,
          requestedByUserId: reqRow.requested_by,
          unlockAllIaParts: false,
        });
      }
    })();
  } catch (err: any) {
    return res.status(400).json({ error: err?.message || 'Failed to resolve correction request.' });
  }

  logAudit(req.user!, 'RESOLVE_CORRECTION_REQUEST', 'mark_correction_request', id, {
    decision,
    examinationId: reqRow.examination_id,
    examComponentId: reqRow.examination_component_id,
    classId: reqRow.class_id,
    sectionId: reqRow.section_id,
  });
  res.json({ success: true });
});

app.post('/api/admin/marks/unlock', requireAuth, requireAdmin, (req: AuthenticatedRequest, res) => {
  const { examinationId, examComponentId, classId, sectionId, unlockIa = true } = req.body as {
    examinationId: number;
    examComponentId: number;
    classId: number;
    sectionId: number;
    unlockIa?: boolean;
  };
  try {
    db.transaction(() => {
      if (unlockIa) {
        unlockComponentMarksAndIa({
          examinationId,
          examComponentId,
          classId,
          sectionId,
          unlockAllIaParts: true,
        });
      } else {
        const examRow = db
          .prepare(`SELECT academic_year FROM examinations WHERE id = ?`)
          .get(examinationId) as { academic_year: string } | undefined;
        const examYear = examRow?.academic_year || getCurrentAcademicYear();
        db.prepare(
          `UPDATE marks SET status = 'draft', updated_at = datetime('now')
           WHERE examination_id = ? AND examination_component_id = ?
           AND student_id IN (SELECT student_id FROM student_enrollments WHERE class_id = ? AND section_id = ? AND academic_year = ? AND status = 'active')`
        ).run(examinationId, examComponentId, classId, sectionId, examYear);
      }
    })();
  } catch (err: any) {
    return res.status(400).json({ error: err?.message || 'Failed to unlock marks.' });
  }

  logAudit(req.user!, 'ADMIN_UNLOCK_MARKS', 'marks', `${examinationId}:${examComponentId}`, {
    examinationId,
    examComponentId,
    classId,
    sectionId,
    unlockIa: Boolean(unlockIa),
  });
  res.json({ success: true });
});

// Audit Logs, Settings & Database Backup
app.get('/api/admin/audit-logs', requireAuth, requireAdmin, (req, res) => {
  const limit = Math.min(300, Number(req.query.limit || 100));
  const action = req.query.action as string | undefined;
  const rows = action
    ? db
        .prepare(`SELECT * FROM audit_logs WHERE action = ? ORDER BY id DESC LIMIT ?`)
        .all(action, limit)
    : db.prepare(`SELECT * FROM audit_logs ORDER BY id DESC LIMIT ?`).all(limit);
  res.json(rows);
});

app.put('/api/admin/settings', requireAuth, requireAdmin, (req: AuthenticatedRequest, res) => {
  const {
    schoolName,
    schoolAddress,
    schoolMotto,
    schoolLogo,
    currentAcademicYear,
    defaultPassPercentage,
    gradingScale,
    themeConfig,
    siteContent,
    portalSections,
    examinationTypes,
  } = req.body;

  const upsert = db.prepare(
    `INSERT INTO system_settings (key, value) VALUES (?, ?) ON CONFLICT(key) DO UPDATE SET value = excluded.value`
  );
  try {
    db.transaction(() => {
      if (schoolName !== undefined) upsert.run('school_name', String(schoolName));
      if (schoolAddress !== undefined) upsert.run('school_address', String(schoolAddress));
      if (schoolMotto !== undefined) upsert.run('school_motto', String(schoolMotto));
      if (schoolLogo !== undefined) upsert.run('school_logo', String(schoolLogo));
      if (currentAcademicYear !== undefined) {
        const yr = String(currentAcademicYear).trim();
        if (yr) {
          upsert.run('current_academic_year', yr);
          db.prepare(`INSERT OR IGNORE INTO academic_years (name, is_current) VALUES (?, 1)`).run(yr);
          db.prepare(`UPDATE academic_years SET is_current = CASE WHEN name = ? THEN 1 ELSE 0 END`).run(yr);
        }
      }
      if (defaultPassPercentage !== undefined)
        upsert.run('default_pass_percentage', String(defaultPassPercentage));
      if (gradingScale !== undefined) upsert.run('grading_scale', JSON.stringify(gradingScale));
      if (themeConfig !== undefined) upsert.run('theme_config', JSON.stringify(themeConfig));
      if (siteContent !== undefined) upsert.run('site_content', JSON.stringify(siteContent));
      if (portalSections !== undefined) upsert.run('portal_sections', JSON.stringify(portalSections));
      if (examinationTypes !== undefined) upsert.run('examination_types', JSON.stringify(examinationTypes));
    })();
    checkpointWal();
  } catch (err: any) {
    return res.status(400).json({ error: err?.message || 'Failed to save system settings.' });
  }

  logAudit(req.user!, 'UPDATE_SETTINGS', 'system_settings', 'global', {
    schoolName,
    currentAcademicYear,
    defaultPassPercentage,
    updatedBranding: schoolLogo !== undefined || themeConfig !== undefined || siteContent !== undefined,
    updatedSections: portalSections !== undefined,
  });
  res.json({ success: true });
});

// Academic Year Management, Switching & New Session Promotion/Rollover
app.get('/api/admin/academic-years', requireAuth, requireAdmin, (req, res) => {
  const viewMode = req.query.view === 'archived' ? 'archived' : req.query.view === 'all' ? 'all' : 'active';
  res.json(getAcademicYearsSummary(viewMode));
});

app.put('/api/admin/academic-years/active', requireAuth, requireAdmin, (req: AuthenticatedRequest, res) => {
  const { academicYear } = req.body as { academicYear?: string };
  const target = academicYear?.trim();
  if (!target) {
    return res.status(400).json({ error: 'academicYear is required.' });
  }
  const exists = db.prepare(`SELECT name FROM academic_years WHERE name = ?`).get(target) as { name: string } | undefined;
  if (!exists) {
    return res.status(404).json({ error: `Academic year "${target}" does not exist.` });
  }

  try {
    db.transaction(() => {
      db.prepare(`UPDATE academic_years SET is_current = CASE WHEN name = ? THEN 1 ELSE 0 END`).run(target);
      db.prepare(
        `INSERT INTO system_settings (key, value) VALUES ('current_academic_year', ?)
         ON CONFLICT(key) DO UPDATE SET value = excluded.value`
      ).run(target);

      // Keep students summary snapshot synced with enrollments for the newly activated academic year
      const enrollments = db
        .prepare(
          `SELECT student_id, class_id, section_id, roll_number, status
           FROM student_enrollments WHERE academic_year = ?`
        )
        .all(target) as Array<{
        student_id: number;
        class_id: number;
        section_id: number;
        roll_number: number;
        status: string;
      }>;
      const syncStmt = db.prepare(
        `UPDATE students
         SET class_id = ?, section_id = ?, roll_number = ?, academic_year = ?, status = ?, updated_at = datetime('now')
         WHERE id = ?`
      );
      for (const se of enrollments) {
        syncStmt.run(se.class_id, se.section_id, se.roll_number, target, se.status, se.student_id);
      }
    })();
    checkpointWal();
  } catch (err: any) {
    return res.status(400).json({ error: err?.message || 'Failed to switch active academic year.' });
  }

  logAudit(req.user!, 'SWITCH_ACTIVE_ACADEMIC_YEAR', 'academic_year', target, { academicYear: target });
  res.json({ success: true, currentAcademicYear: target });
});

app.post('/api/admin/academic-years/bulk-action', requireAuth, requireAdmin, (req: AuthenticatedRequest, res) => {
  const { action, names } = req.body as {
    action?: 'delete' | 'archive' | 'restore';
    names?: string[];
  };
  if (!action || !Array.isArray(names) || names.length === 0) {
    return res.status(400).json({ error: 'Action and at least one academic year are required.' });
  }
  const uniqueNames = Array.from(new Set(names.map((n) => String(n).trim()).filter(Boolean)));
  const currentYear = getCurrentAcademicYear();

  if ((action === 'delete' || action === 'archive') && uniqueNames.includes(currentYear)) {
    return res.status(400).json({ error: `Cannot archive the active academic year (${currentYear}). Switch active year first.` });
  }

  try {
    db.transaction(() => {
      if (action === 'restore') {
        const stmt = db.prepare(`UPDATE academic_years SET is_deleted = 0, deleted_at = NULL WHERE name = ?`);
        for (const n of uniqueNames) stmt.run(n);
      } else {
        const stmt = db.prepare(`UPDATE academic_years SET is_deleted = 1, deleted_at = datetime('now') WHERE name = ?`);
        for (const n of uniqueNames) stmt.run(n);
      }
    })();
    checkpointWal();
  } catch (err: any) {
    return res.status(400).json({ error: err?.message || 'Bulk academic year update failed.' });
  }

  logAudit(req.user!, `BULK_${action.toUpperCase()}_ACADEMIC_YEARS`, 'academic_year', uniqueNames.join(','), {
    action,
    names: uniqueNames,
  });
  res.json({ success: true, action, affectedCount: uniqueNames.length, names: uniqueNames });
});

app.post('/api/admin/academic-years/transition', requireAuth, requireAdmin, (req: AuthenticatedRequest, res) => {
  const {
    newAcademicYear,
    sourceAcademicYear,
    promoteStudents = true,
    copyTeacherAssignments = true,
    copyClassTeachers = true,
    setAsCurrent = true,
  } = req.body as {
    newAcademicYear?: string;
    sourceAcademicYear?: string;
    promoteStudents?: boolean;
    copyTeacherAssignments?: boolean;
    copyClassTeachers?: boolean;
    setAsCurrent?: boolean;
  };

  const targetYear = newAcademicYear?.trim();
  if (!targetYear) {
    return res.status(400).json({ error: 'New academic year name (e.g. 2026-27) is required.' });
  }
  const sourceYear = sourceAcademicYear?.trim() || getCurrentAcademicYear();
  if (targetYear === sourceYear) {
    return res.status(400).json({ error: 'New academic year must be different from the source academic year.' });
  }

  let summary: {
    newAcademicYear: string;
    sourceAcademicYear: string;
    promotedCount: number;
    retainedCount: number;
    graduatedCount: number;
    copiedAssignments: number;
    copiedClassTeachers: number;
    setAsCurrent: boolean;
  };
  try {
    summary = db.transaction(() => {
      db.prepare(`INSERT OR IGNORE INTO academic_years (name, is_current, is_deleted) VALUES (?, 0, 0)`).run(targetYear);
      db.prepare(`UPDATE academic_years SET is_deleted = 0, deleted_at = NULL WHERE name = ?`).run(targetYear);

      const classes = db
        .prepare(`SELECT id, name, numeric_order FROM classes WHERE is_active = 1 AND COALESCE(is_deleted, 0) = 0 ORDER BY numeric_order ASC`)
        .all() as Array<{ id: number; name: string; numeric_order: number }>;
      const nextClassById = new Map<number, number | null>();
      for (let i = 0; i < classes.length; i++) {
        nextClassById.set(classes[i].id, classes[i + 1]?.id ?? null);
      }

      const sections = db
        .prepare(`SELECT id, class_id, name FROM sections WHERE COALESCE(is_deleted, 0) = 0 ORDER BY name ASC`)
        .all() as Array<{ id: number; class_id: number; name: string }>;
      const secNameById = new Map<number, string>();
      const secIdByClassAndName = new Map<string, number>();
      const firstSecByClass = new Map<number, number>();
      for (const s of sections) {
        secNameById.set(s.id, s.name);
        secIdByClassAndName.set(`${s.class_id}:${s.name}`, s.id);
        if (!firstSecByClass.has(s.class_id)) firstSecByClass.set(s.class_id, s.id);
      }

      const sourceEnrollments = db
        .prepare(
          `SELECT se.student_id, se.class_id, se.section_id, se.roll_number,
                  COALESCE(NULLIF(se.stream, ''), st.stream, '') as stream
           FROM student_enrollments se
           JOIN students st ON st.id = se.student_id
           WHERE se.academic_year = ? AND se.status = 'active' AND COALESCE(st.is_deleted, 0) = 0
           ORDER BY se.class_id ASC, se.section_id ASC, se.roll_number ASC`
        )
        .all(sourceYear) as Array<{
        student_id: number;
        class_id: number;
        section_id: number;
        roll_number: number;
        stream: string;
      }>;

      const existingInTarget = new Set(
        (
          db
            .prepare(`SELECT student_id FROM student_enrollments WHERE academic_year = ?`)
            .all(targetYear) as Array<{ student_id: number }>
        ).map((r) => r.student_id)
      );

      const insertEnrollment = db.prepare(
        `INSERT OR IGNORE INTO student_enrollments (student_id, academic_year, class_id, section_id, roll_number, stream, status)
         VALUES (?, ?, ?, ?, ?, ?, ?)`
      );
      const updateStudentCurrent = db.prepare(
        `UPDATE students SET class_id = ?, section_id = ?, roll_number = ?, academic_year = ?, stream = ?, status = ?, updated_at = datetime('now') WHERE id = ?`
      );

      let promotedCount = 0;
      let retainedCount = 0;
      let graduatedCount = 0;

      for (const se of sourceEnrollments) {
        if (existingInTarget.has(se.student_id)) continue;

        if (promoteStudents) {
          const nextClassId = nextClassById.get(se.class_id) ?? null;
          if (nextClassId) {
            const secName = secNameById.get(se.section_id) || 'A';
            const nextSectionId =
              secIdByClassAndName.get(`${nextClassId}:${secName}`) ?? firstSecByClass.get(nextClassId) ?? se.section_id;
            insertEnrollment.run(se.student_id, targetYear, nextClassId, nextSectionId, se.roll_number, se.stream || '', 'active');
            if (setAsCurrent) {
              updateStudentCurrent.run(nextClassId, nextSectionId, se.roll_number, targetYear, se.stream || '', 'active', se.student_id);
            }
            promotedCount++;
          } else {
            insertEnrollment.run(se.student_id, targetYear, se.class_id, se.section_id, se.roll_number, se.stream || '', 'graduated');
            if (setAsCurrent) {
              updateStudentCurrent.run(se.class_id, se.section_id, se.roll_number, targetYear, se.stream || '', 'graduated', se.student_id);
            }
            graduatedCount++;
          }
        } else {
          insertEnrollment.run(se.student_id, targetYear, se.class_id, se.section_id, se.roll_number, se.stream || '', 'active');
          if (setAsCurrent) {
            updateStudentCurrent.run(se.class_id, se.section_id, se.roll_number, targetYear, se.stream || '', 'active', se.student_id);
          }
          retainedCount++;
        }

        // Preserve student electives and opt-outs for the new academic year
        db.prepare(
          `INSERT OR IGNORE INTO student_year_electives (student_id, academic_year, subject_id, component_id)
           SELECT student_id, ?, subject_id, component_id
           FROM student_year_electives
           WHERE student_id = ? AND academic_year = ?`
        ).run(targetYear, se.student_id, sourceYear);
        db.prepare(
          `INSERT OR IGNORE INTO student_elective_opt_outs (student_id, academic_year, subject_id)
           SELECT student_id, ?, subject_id
           FROM student_elective_opt_outs
           WHERE student_id = ? AND academic_year = ?`
        ).run(targetYear, se.student_id, sourceYear);
        if (!promoteStudents) {
          db.prepare(
            `INSERT OR IGNORE INTO student_year_subjects (student_id, academic_year, subject_id)
             SELECT student_id, ?, subject_id
             FROM student_year_subjects
             WHERE student_id = ? AND academic_year = ?`
          ).run(targetYear, se.student_id, sourceYear);
        }
      }

      let copiedAssignments = 0;
      if (copyTeacherAssignments) {
        const info = db
          .prepare(
            `INSERT OR IGNORE INTO teacher_assignments (teacher_id, subject_id, component_id, class_id, section_id, academic_year)
             SELECT teacher_id, subject_id, component_id, class_id, section_id, ?
             FROM teacher_assignments WHERE academic_year = ?`
          )
          .run(targetYear, sourceYear);
        copiedAssignments = info.changes;
      }

      let copiedClassTeachers = 0;
      if (copyClassTeachers) {
        const info = db
          .prepare(
            `INSERT OR IGNORE INTO class_teacher_assignments (teacher_id, class_id, section_id, academic_year)
             SELECT teacher_id, class_id, section_id, ?
             FROM class_teacher_assignments WHERE academic_year = ?`
          )
          .run(targetYear, sourceYear);
        copiedClassTeachers = info.changes;
      }

      if (setAsCurrent) {
        db.prepare(`UPDATE academic_years SET is_current = CASE WHEN name = ? THEN 1 ELSE 0 END`).run(targetYear);
        db.prepare(
          `INSERT INTO system_settings (key, value) VALUES ('current_academic_year', ?)
           ON CONFLICT(key) DO UPDATE SET value = excluded.value`
        ).run(targetYear);
      }

      return {
        newAcademicYear: targetYear,
        sourceAcademicYear: sourceYear,
        promotedCount,
        retainedCount,
        graduatedCount,
        copiedAssignments,
        copiedClassTeachers,
        setAsCurrent,
      };
    })();
    checkpointWal();
  } catch (err: any) {
    return res.status(400).json({ error: err?.message || 'Failed to transition academic year.' });
  }

  logAudit(req.user!, 'ACADEMIC_YEAR_TRANSITION', 'academic_year', targetYear, summary);
  res.status(201).json({ success: true, ...summary });
});

app.get('/api/admin/backup', requireAuth, requireAdmin, async (req: AuthenticatedRequest, res) => {
  const format = (req.query.format as string) || 'sqlite';
  try {
    logAudit(req.user!, 'DATABASE_BACKUP', 'system', 'school.db', { format });

    if (format === 'json') {
      const tables = [
        'roles',
        'users',
        'classes',
        'sections',
        'academic_years',
        'students',
        'student_enrollments',
        'subjects',
        'subject_components',
        'student_electives',
        'student_year_electives',
        'teacher_assignments',
        'class_teacher_assignments',
        'ia_teacher_assignments',
        'examinations',
        'examination_subjects',
        'examination_components',
        'marks',
        'internal_assessment_marks',
        'student_co_scholastic_grades',
        'mark_correction_requests',
        'audit_logs',
        'system_settings',
      ];
      const snapshot: Record<string, unknown> = { exportedAt: new Date().toISOString() };
      for (const t of tables) {
        if (t === 'users') {
          snapshot[t] = db
            .prepare(`SELECT id, username, full_name, email, employee_code, is_active, created_at FROM users`)
            .all();
        } else {
          snapshot[t] = db.prepare(`SELECT * FROM ${t}`).all();
        }
      }
      res.setHeader('Content-Disposition', `attachment; filename="school-portal-backup-${Date.now()}.json"`);
      return res.json(snapshot);
    }

    const backupPath = path.join(os.tmpdir(), `school-backup-${Date.now()}-${process.pid}.db`);
    await db.backup(backupPath);
    res.download(backupPath, `emrs-gangyap-backup-${new Date().toISOString().slice(0, 10)}.db`, () => {
      try {
        fs.unlinkSync(backupPath);
      } catch {
        // ignore cleanup errors
      }
    });
  } catch (err: any) {
    res.status(500).json({ error: err?.message || 'Database backup failed.' });
  }
});

// ==========================================
// 4. TEACHER WORKSPACE & MARKS ENTRY ROUTES
// ==========================================

app.get('/api/teacher/workspace', requireAuth, (req: AuthenticatedRequest, res) => {
  try {
    const userId = req.user!.id;

    const subjectAssignments = db
      .prepare(
        `SELECT ta.id, ta.subject_id, sub.name as subject_name, sub.code as subject_code, sub.has_components, sub.component_mode,
                COALESCE(sub.stream_category, '') as stream_category, COALESCE(sub.has_practical, 0) as has_practical,
                COALESCE(sub.applicable_class_ids, '') as applicable_class_ids,
                ta.component_id, sc.name as component_name, sc.code as component_code,
                ta.class_id, c.name as class_name, c.numeric_order, COALESCE(c.has_sections, 1) as has_sections,
                ta.section_id, s.name as section_name,
                ta.academic_year
         FROM teacher_assignments ta
         JOIN subjects sub ON sub.id = ta.subject_id
         JOIN subject_components sc ON sc.id = ta.component_id
         JOIN classes c ON c.id = ta.class_id
         JOIN sections s ON s.id = ta.section_id
         WHERE ta.teacher_id = ?
           AND COALESCE(sub.is_deleted, 0) = 0 AND COALESCE(c.is_deleted, 0) = 0 AND COALESCE(s.is_deleted, 0) = 0
         ORDER BY c.numeric_order ASC, s.name ASC, sub.display_order ASC, sc.display_order ASC`
      )
      .all(userId);

    const classTeacherAssignments = db
      .prepare(
        `SELECT cta.id, cta.class_id, c.name as class_name, COALESCE(c.has_sections, 1) as has_sections,
                cta.section_id, s.name as section_name, cta.academic_year,
                (SELECT COUNT(*) FROM student_enrollments se
                 JOIN students st ON st.id = se.student_id
                 WHERE se.class_id = cta.class_id AND se.section_id = cta.section_id
                   AND se.academic_year = cta.academic_year AND se.status = 'active' AND COALESCE(st.is_deleted, 0) = 0) as student_count
         FROM class_teacher_assignments cta
         JOIN classes c ON c.id = cta.class_id
         JOIN sections s ON s.id = cta.section_id
         WHERE cta.teacher_id = ?
           AND COALESCE(c.is_deleted, 0) = 0 AND COALESCE(s.is_deleted, 0) = 0
         ORDER BY cta.academic_year DESC, c.numeric_order ASC, s.name ASC`
      )
      .all(userId);

    res.json({
      subjectAssignments,
      classTeacherAssignments,
    });
  } catch (err: any) {
    console.error('Error loading /api/teacher/workspace:', err);
    res.status(500).json({ error: err?.message || 'Database error while loading teacher workspace.' });
  }
});

function getTargetStudentsForComponent(
  subjectId: number,
  componentId: number,
  componentMode: string,
  classId: number,
  sectionId: number,
  academicYear?: string,
  examinationId?: number
): { filteredByElective: boolean; studentIds: number[] } {
  const year = academicYear || getCurrentAcademicYear();

  const subRow = db
    .prepare(`SELECT COALESCE(applicable_class_ids, '') as applicable_class_ids FROM subjects WHERE id = ?`)
    .get(subjectId) as { applicable_class_ids: string } | undefined;

  let effectiveClassScope = subRow?.applicable_class_ids || '';
  if (examinationId) {
    const examSubRow = db
      .prepare(`SELECT COALESCE(target_class_ids, '') as target_class_ids FROM examination_subjects WHERE examination_id = ? AND subject_id = ?`)
      .get(examinationId, subjectId) as { target_class_ids: string } | undefined;
    if (examSubRow && examSubRow.target_class_ids) {
      effectiveClassScope = examSubRow.target_class_ids;
    }
  }

  if (!doesSubjectApplyToClass(effectiveClassScope, classId)) {
    return { filteredByElective: false, studentIds: [] };
  }

  const hasYearEnrollments =
    (
      db
        .prepare(`SELECT COUNT(*) as cnt FROM student_enrollments WHERE academic_year = ?`)
        .get(year) as { cnt: number }
    ).cnt > 0;

  const baseStudents = (
    hasYearEnrollments
      ? db
          .prepare(
            `SELECT se.student_id as id
             FROM student_enrollments se
             JOIN students st ON st.id = se.student_id
             WHERE se.academic_year = ? AND se.class_id = ? AND se.section_id = ? AND se.status = 'active' AND COALESCE(st.is_deleted, 0) = 0
             ORDER BY se.roll_number ASC, st.student_code ASC`
          )
          .all(year, classId, sectionId)
      : db
          .prepare(
            `SELECT id FROM students WHERE class_id = ? AND section_id = ? AND status = 'active' AND COALESCE(is_deleted, 0) = 0 ORDER BY roll_number ASC, student_code ASC`
          )
          .all(classId, sectionId)
  ) as Array<{ id: number }>;

  if (baseStudents.length === 0) {
    return { filteredByElective: false, studentIds: [] };
  }

  const baseIdSet = new Set(baseStudents.map((s) => s.id));

  // Per-student custom subject combinations (year-specific overrides base student_subjects)
  const customSubjectsMap = new Map<number, Set<number>>();
  const yearSubRows = (
    db
      .prepare(`SELECT student_id, subject_id FROM student_year_subjects WHERE academic_year = ?`)
      .all(year) as Array<{ student_id: number; subject_id: number }>
  ).filter((r) => baseIdSet.has(r.student_id));
  for (const r of yearSubRows) {
    if (!customSubjectsMap.has(r.student_id)) customSubjectsMap.set(r.student_id, new Set());
    customSubjectsMap.get(r.student_id)!.add(r.subject_id);
  }
  const baseSubRows = (
    db.prepare(`SELECT student_id, subject_id FROM student_subjects`).all() as Array<{
      student_id: number;
      subject_id: number;
    }>
  ).filter((r) => baseIdSet.has(r.student_id) && !customSubjectsMap.has(r.student_id));
  for (const r of baseSubRows) {
    if (!customSubjectsMap.has(r.student_id)) customSubjectsMap.set(r.student_id, new Set());
    customSubjectsMap.get(r.student_id)!.add(r.subject_id);
  }

  // Elective opt-outs (students opting out of optional language / elective for this academic year)
  const optOutSet = new Set<number>();
  if (componentMode === 'elective') {
    const optRows = (
      db
        .prepare(`SELECT student_id FROM student_elective_opt_outs WHERE academic_year = ? AND subject_id = ?`)
        .all(year, subjectId) as Array<{ student_id: number }>
    ).filter((r) => baseIdSet.has(r.student_id));
    for (const r of optRows) {
      optOutSet.add(r.student_id);
    }
  }

  const eligibleIds = baseStudents
    .map((s) => s.id)
    .filter((sid) => {
      const customSubs = customSubjectsMap.get(sid);
      if (customSubs && customSubs.size > 0 && !customSubs.has(subjectId)) {
        return false;
      }
      if (componentMode === 'elective' && optOutSet.has(sid)) {
        return false;
      }
      return true;
    });

  if (componentMode === 'elective') {
    const electiveMap = new Map<number, number>();
    const baseElectiveRows = (
      db
        .prepare(`SELECT student_id, component_id FROM student_electives WHERE subject_id = ?`)
        .all(subjectId) as Array<{ student_id: number; component_id: number }>
    ).filter((r) => baseIdSet.has(r.student_id));
    for (const r of baseElectiveRows) {
      electiveMap.set(r.student_id, r.component_id);
    }
    const yearElectiveRows = (
      db
        .prepare(`SELECT student_id, component_id FROM student_year_electives WHERE academic_year = ? AND subject_id = ?`)
        .all(year, subjectId) as Array<{ student_id: number; component_id: number }>
    ).filter((r) => baseIdSet.has(r.student_id));
    for (const r of yearElectiveRows) {
      electiveMap.set(r.student_id, r.component_id);
    }

    const mappedEligible = eligibleIds.filter((sid) => electiveMap.has(sid));
    if (mappedEligible.length > 0) {
      return {
        filteredByElective: true,
        studentIds: mappedEligible.filter((sid) => electiveMap.get(sid) === componentId),
      };
    }
  }

  return { filteredByElective: false, studentIds: eligibleIds };
}

function getIaPermissionsForTeacher(
  userId: number,
  isAdmin: boolean,
  subjectId: number,
  classId: number,
  sectionId: number,
  academicYear: string
): { notebook: boolean; unit_test: boolean; practical: boolean; participation: boolean } {
  if (isAdmin) {
    return { notebook: true, unit_test: true, practical: true, participation: true };
  }
  const iaAssigns = db
    .prepare(
      `SELECT ia_component, teacher_id FROM ia_teacher_assignments
       WHERE subject_id = ? AND class_id = ? AND section_id = ? AND academic_year = ?`
    )
    .all(subjectId, classId, sectionId, academicYear) as Array<{ ia_component: string; teacher_id: number }>;

  const byPart = new Map<string, number>();
  for (const r of iaAssigns) byPart.set(r.ia_component, r.teacher_id);

  // If no specific IA teacher assignment exists for a sub-component, any assigned subject teacher can enter it
  const check = (part: string) => {
    if (!byPart.has(part)) return true;
    return byPart.get(part) === userId;
  };

  return {
    notebook: check('notebook'),
    unit_test: check('unit_test'),
    practical: check('practical'),
    participation: check('participation'),
  };
}

function computeSubjectIaContext(
  examinationId: number,
  examSubjectId: number,
  subjectId: number,
  componentMode: string,
  currentExamCompId: number,
  classId: number,
  sectionId: number,
  academicYear: string,
  targetStudentIds: number[]
) {
  const examSub = db
    .prepare(
      `SELECT has_internal_assessment, ia_notebook_max, ia_unit_test_max, ia_practical_max, ia_participation_max, max_marks, passing_marks
       FROM examination_subjects WHERE id = ?`
    )
    .get(examSubjectId) as
    | {
        has_internal_assessment: number;
        ia_notebook_max: number;
        ia_unit_test_max: number;
        ia_practical_max: number;
        ia_participation_max: number;
        max_marks: number;
        passing_marks: number;
      }
    | undefined;

  const hasIa = Boolean(examSub?.has_internal_assessment);
  const nbMax = hasIa ? Number(examSub?.ia_notebook_max ?? 5) : 0;
  const utMax = hasIa ? Number(examSub?.ia_unit_test_max ?? 5) : 0;
  const prMax = hasIa ? Number(examSub?.ia_practical_max ?? 5) : 0;
  const opMax = hasIa ? Number(examSub?.ia_participation_max ?? 5) : 0;
  const totalIaMax = nbMax + utMax + prMax + opMax;
  const targetIdSet = new Set(targetStudentIds);

  const iaRows = (
    db
      .prepare(
        `SELECT ia.student_id, ia.notebook_marks, ia.unit_test_marks, ia.practical_marks, ia.participation_marks, ia.status,
                ia.nb_status, ia.nb_by, ia.ut_status, ia.ut_by, ia.pr_status, ia.pr_by, ia.op_status, ia.op_by,
                ia.entered_via_component_id, u.full_name as submitted_by_name
         FROM internal_assessment_marks ia
         LEFT JOIN users u ON u.id = ia.submitted_by
         WHERE ia.examination_id = ? AND ia.subject_id = ?`
      )
      .all(examinationId, subjectId) as Array<{
      student_id: number;
      notebook_marks: number | null;
      unit_test_marks: number | null;
      practical_marks: number | null;
      participation_marks: number | null;
      status: 'draft' | 'submitted';
      nb_status: string | null;
      nb_by: number | null;
      ut_status: string | null;
      ut_by: number | null;
      pr_status: string | null;
      pr_by: number | null;
      op_status: string | null;
      op_by: number | null;
      entered_via_component_id: number | null;
      submitted_by_name: string | null;
    }>
  ).filter((r) => targetIdSet.has(r.student_id));

  const iaSubmittedCount = iaRows.filter((r) => {
    const nbOk = nbMax <= 0 || (r.notebook_marks !== null && (r.nb_status === 'submitted' || r.status === 'submitted'));
    const utOk = utMax <= 0 || (r.unit_test_marks !== null && (r.ut_status === 'submitted' || r.status === 'submitted'));
    const prOk = prMax <= 0 || (r.practical_marks !== null && (r.pr_status === 'submitted' || r.status === 'submitted'));
    const opOk = opMax <= 0 || (r.participation_marks !== null && (r.op_status === 'submitted' || r.status === 'submitted'));
    return nbOk && utOk && prOk && opOk;
  }).length;
  const iaAlreadySubmitted = targetStudentIds.length > 0 && iaSubmittedCount === targetStudentIds.length;
  const submittedByName = iaRows.find((r) => r.submitted_by_name)?.submitted_by_name ?? null;

  return {
    enabled: hasIa,
    notebookMax: nbMax,
    unitTestMax: utMax,
    practicalMax: prMax,
    participationMax: opMax,
    totalIaMax,
    subjectTotalMax: Number(examSub?.max_marks ?? totalIaMax),
    iaAlreadySubmitted,
    submittedByName,
    iaRows,
  };
}

app.get('/api/teacher/marks-sheet', requireAuth, (req: AuthenticatedRequest, res) => {
  try {
    const examinationId = Number(req.query.examinationId);
    const classId = Number(req.query.classId);
    const sectionId = Number(req.query.sectionId);
    const componentId = Number(req.query.componentId);

    if (!examinationId || !classId || !sectionId || !componentId) {
      return res.status(400).json({ error: 'examinationId, classId, sectionId, and componentId are required.' });
    }

    const exam = db.prepare(`SELECT * FROM examinations WHERE id = ? AND COALESCE(is_deleted, 0) = 0`).get(examinationId) as any;
    if (!exam) return res.status(404).json({ error: 'Examination not found.' });

    const isAdmin = req.user!.roles.includes('admin');
    if (!isAdmin) {
      const assigned = db
        .prepare(
          `SELECT id FROM teacher_assignments
           WHERE teacher_id = ? AND class_id = ? AND section_id = ? AND component_id = ? AND academic_year = ?`
        )
        .get(req.user!.id, classId, sectionId, componentId, exam.academic_year);
      if (!assigned) {
        return res.status(403).json({ error: 'Access denied: You are not assigned to this class, section, and subject component for this academic year.' });
      }
    }

    const examComp = db
      .prepare(
        `SELECT ec.*, sub.name as subject_name, sub.has_components, sub.component_mode
         FROM examination_components ec
         JOIN subjects sub ON sub.id = ec.subject_id
         WHERE ec.examination_id = ? AND ec.component_id = ?`
      )
      .get(examinationId, componentId) as any;

    if (!examComp) {
      return res.status(404).json({ error: 'This subject component is not configured for the selected examination.' });
    }

    const classSection = db
      .prepare(
        `SELECT c.name as class_name, COALESCE(c.has_sections, 1) as has_sections, s.name as section_name
         FROM classes c JOIN sections s ON s.class_id = c.id
         WHERE c.id = ? AND s.id = ?`
      )
      .get(classId, sectionId) as { class_name: string; has_sections: number; section_name: string } | undefined;
    if (!classSection) {
      return res.status(404).json({ error: 'Class or section not found.' });
    }

    const componentMode = examComp.component_mode || (examComp.has_components ? 'combined' : 'single');
    const targetMeta = getTargetStudentsForComponent(
      examComp.subject_id,
      componentId,
      componentMode,
      classId,
      sectionId,
      exam.academic_year,
      examinationId
    );
    const targetSet = new Set(targetMeta.studentIds);

    const hasYearEnrollments =
      (
        db
          .prepare(`SELECT COUNT(*) as cnt FROM student_enrollments WHERE academic_year = ?`)
          .get(exam.academic_year) as { cnt: number }
      ).cnt > 0;

    const allSectionStudents = (
      hasYearEnrollments
        ? db
            .prepare(
              `SELECT st.id as student_id, st.student_code, st.full_name, se.roll_number,
                      m.obtained_marks, m.attendance_status, m.status as mark_status, m.submitted_at, m.updated_at
               FROM student_enrollments se
               JOIN students st ON st.id = se.student_id
               LEFT JOIN marks m ON m.student_id = st.id AND m.examination_id = ? AND m.examination_component_id = ?
               WHERE se.academic_year = ? AND se.class_id = ? AND se.section_id = ? AND se.status = 'active' AND COALESCE(st.is_deleted, 0) = 0
               ORDER BY se.roll_number ASC, st.student_code ASC`
            )
            .all(examinationId, examComp.id, exam.academic_year, classId, sectionId)
        : db
            .prepare(
              `SELECT st.id as student_id, st.student_code, st.full_name, st.roll_number,
                      m.obtained_marks, m.attendance_status, m.status as mark_status, m.submitted_at, m.updated_at
               FROM students st
               LEFT JOIN marks m ON m.student_id = st.id AND m.examination_id = ? AND m.examination_component_id = ?
               WHERE st.class_id = ? AND st.section_id = ? AND st.status = 'active' AND COALESCE(st.is_deleted, 0) = 0
               ORDER BY st.roll_number ASC, st.student_code ASC`
            )
            .all(examinationId, examComp.id, classId, sectionId)
    ) as Array<any>;

    const students = allSectionStudents.filter((s) => targetSet.has(s.student_id));

    const pendingRequest = db
      .prepare(
        `SELECT id, reason, status, created_at FROM mark_correction_requests
         WHERE examination_id = ? AND examination_component_id = ? AND class_id = ? AND section_id = ?
         ORDER BY id DESC LIMIT 1`
      )
      .get(examinationId, examComp.id, classId, sectionId);

    const isRowRecorded = (s: any) => s.attendance_status === 'absent' || s.obtained_marks !== null;
    const allSubmitted =
      students.length > 0 &&
      students.every((s) => s.mark_status === 'submitted' && isRowRecorded(s));
    const anyWrittenSubmitted = students.some((s) => s.mark_status === 'submitted' && isRowRecorded(s));
    const examWindowOpen = isAdmin || (Boolean(exam.marks_entry_open) && exam.status === 'Active');

    const iaCtx = computeSubjectIaContext(
      examinationId,
      examComp.examination_subject_id,
      examComp.subject_id,
      componentMode,
      examComp.id,
      classId,
      sectionId,
      exam.academic_year,
      targetMeta.studentIds
    );

    const iaPermissions = getIaPermissionsForTeacher(
      req.user!.id,
      isAdmin,
      examComp.subject_id,
      classId,
      sectionId,
      exam.academic_year
    );

    const anyIaSubmitted =
      iaCtx.enabled &&
      iaCtx.iaRows.some(
        (r) =>
          r.status === 'submitted' ||
          (iaPermissions.notebook && iaCtx.notebookMax > 0 && r.nb_status === 'submitted' && r.notebook_marks !== null) ||
          (iaPermissions.unit_test && iaCtx.unitTestMax > 0 && r.ut_status === 'submitted' && r.unit_test_marks !== null) ||
          (iaPermissions.practical && iaCtx.practicalMax > 0 && r.pr_status === 'submitted' && r.practical_marks !== null) ||
          (iaPermissions.participation && iaCtx.participationMax > 0 && r.op_status === 'submitted' && r.participation_marks !== null)
      );
    const anySubmitted = anyWrittenSubmitted || anyIaSubmitted;

    const iaByStudent = new Map(iaCtx.iaRows.map((r) => [r.student_id, r]));
    // For combined multi-component subjects, also gather sibling components' persisted marks so live grade reflects combined subject total
    const siblingMap = new Map<number, { otherMarks: number; otherMax: number; allEntered: boolean; anyAbsent: boolean }>();
    if (componentMode === 'combined') {
      const siblingComps = db
        .prepare(
          `SELECT id, max_marks FROM examination_components
           WHERE examination_id = ? AND subject_id = ? AND id != ?`
        )
        .all(examinationId, examComp.subject_id, examComp.id) as Array<{ id: number; max_marks: number }>;
      const otherMax = siblingComps.reduce((s, c) => s + Number(c.max_marks || 0), 0);
      if (siblingComps.length > 0 && targetMeta.studentIds.length > 0) {
        const compIds = siblingComps.map((c) => c.id);
        const cPh = compIds.map(() => '?').join(',');
        const sPh = targetMeta.studentIds.map(() => '?').join(',');
        const sibMarks = db
          .prepare(
            `SELECT student_id, examination_component_id, obtained_marks, attendance_status
             FROM marks
             WHERE examination_id = ? AND examination_component_id IN (${cPh}) AND student_id IN (${sPh})`
          )
          .all(examinationId, ...compIds, ...targetMeta.studentIds) as Array<{
          student_id: number;
          examination_component_id: number;
          obtained_marks: number | null;
          attendance_status: AttendanceStatus | null;
        }>;
        const byStuComp = new Map<string, { obtained_marks: number | null; attendance_status: AttendanceStatus | null }>();
        for (const sm of sibMarks) {
          byStuComp.set(`${sm.student_id}:${sm.examination_component_id}`, sm);
        }
        for (const sid of targetMeta.studentIds) {
          let sum = 0;
          let allEntered = true;
          let anyAbsent = false;
          for (const sc of siblingComps) {
            const row = byStuComp.get(`${sid}:${sc.id}`);
            if (!row) {
              allEntered = false;
            } else if (row.attendance_status === 'absent') {
              anyAbsent = true;
            } else if (row.obtained_marks === null) {
              allEntered = false;
            } else {
              sum += Number(row.obtained_marks);
            }
          }
          siblingMap.set(sid, { otherMarks: Number(sum.toFixed(2)), otherMax, allEntered, anyAbsent });
        }
      }
    }

    // Sheet is only completely locked for non-admin teachers when EVERY student's written AND active IA parts are submitted
    const allIaSubmitted = !iaCtx.enabled || iaCtx.iaAlreadySubmitted;
    const sheetLocked = allSubmitted && allIaSubmitted && !isAdmin;

    res.json({
      examination: {
        id: exam.id,
        name: exam.name,
        academicYear: exam.academic_year,
        status: exam.status,
        marksEntryOpen: Boolean(exam.marks_entry_open),
      },
      context: {
        classId,
        className: classSection.class_name,
        hasSections: Boolean(classSection.has_sections ?? 1),
        sectionId,
        sectionName: classSection.section_name,
        subjectId: examComp.subject_id,
        subjectName: examComp.subject_name,
        hasComponents: Boolean(examComp.has_components),
        componentMode,
        filteredByElective: targetMeta.filteredByElective,
        componentId,
        examComponentId: examComp.id,
        componentName: examComp.component_name,
        maxMarks: examComp.max_marks,
        passingMarks: examComp.passing_marks,
      },
      isLocked: sheetLocked,
      anySubmitted,
      allSubmitted,
      examWindowOpen,
      latestCorrectionRequest: pendingRequest || null,
      internalAssessment: {
        enabled: iaCtx.enabled,
        canEditIa: iaCtx.enabled && examWindowOpen && (!iaCtx.iaAlreadySubmitted || isAdmin),
        iaPermissions,
        iaLocked: iaCtx.iaAlreadySubmitted && !isAdmin,
        iaAlreadySubmitted: iaCtx.iaAlreadySubmitted,
        submittedByName: iaCtx.submittedByName,
        notebookMax: iaCtx.notebookMax,
        unitTestMax: iaCtx.unitTestMax,
        practicalMax: iaCtx.practicalMax,
        participationMax: iaCtx.participationMax,
        totalIaMax: iaCtx.totalIaMax,
        subjectTotalMax: iaCtx.subjectTotalMax,
      },
      students: students.map((s) => {
        const ia = iaByStudent.get(s.student_id);
        const sib = siblingMap.get(s.student_id);
        const attStatus: AttendanceStatus =
          s.attendance_status === 'absent'
            ? 'absent'
            : s.obtained_marks !== null
              ? 'present'
              : s.attendance_status === 'present'
                ? 'present'
                : 'pending';
        const recorded = attStatus === 'absent' || (attStatus === 'present' && s.obtained_marks !== null);
        const rowStatus: 'submitted' | 'draft' | 'pending' = !recorded
          ? 'pending'
          : s.mark_status === 'submitted'
            ? 'submitted'
            : 'draft';
        const isRowLocked = rowStatus === 'submitted' && !isAdmin;

        const nbStatus = ia?.nb_status || (ia?.notebook_marks !== null && ia?.notebook_marks !== undefined ? ia.status : 'pending');
        const utStatus = ia?.ut_status || (ia?.unit_test_marks !== null && ia?.unit_test_marks !== undefined ? ia.status : 'pending');
        const prStatus = ia?.pr_status || (ia?.practical_marks !== null && ia?.practical_marks !== undefined ? ia.status : 'pending');
        const opStatus = ia?.op_status || (ia?.participation_marks !== null && ia?.participation_marks !== undefined ? ia.status : 'pending');

        return {
          studentId: s.student_id,
          studentCode: s.student_code,
          fullName: s.full_name,
          rollNumber: s.roll_number,
          obtainedMarks: attStatus === 'absent' ? null : s.obtained_marks,
          attendanceStatus: attStatus,
          status: rowStatus,
          isRowLocked,
          submittedAt: s.submitted_at,
          updatedAt: s.updated_at,
          otherComponentsMarks: sib ? sib.otherMarks : null,
          otherComponentsMax: sib ? sib.otherMax : 0,
          otherComponentsComplete: sib ? sib.allEntered : true,
          otherComponentsAbsent: sib ? sib.anyAbsent : false,
          iaNotebookMarks: ia?.notebook_marks ?? null,
          iaUnitTestMarks: ia?.unit_test_marks ?? null,
          iaPracticalMarks: ia?.practical_marks ?? null,
          iaParticipationMarks: ia?.participation_marks ?? null,
          nbStatus: ia?.notebook_marks === null || ia?.notebook_marks === undefined ? 'pending' : nbStatus,
          utStatus: ia?.unit_test_marks === null || ia?.unit_test_marks === undefined ? 'pending' : utStatus,
          prStatus: ia?.practical_marks === null || ia?.practical_marks === undefined ? 'pending' : prStatus,
          opStatus: ia?.participation_marks === null || ia?.participation_marks === undefined ? 'pending' : opStatus,
          iaStatus:
            !ia ||
            (ia.notebook_marks === null &&
              ia.unit_test_marks === null &&
              ia.practical_marks === null &&
              ia.participation_marks === null)
              ? 'pending'
              : ia.status,
        };
      }),
    });
  } catch (err: any) {
    console.error('Error loading /api/teacher/marks-sheet:', err);
    res.status(500).json({ error: err?.message || 'Database error while loading marks sheet.' });
  }
});

app.post('/api/teacher/marks-save', requireAuth, (req: AuthenticatedRequest, res) => {
  const { examinationId, classId, sectionId, componentId, mode, entries, iaEntries } = req.body as {
    examinationId: number;
    classId: number;
    sectionId: number;
    componentId: number;
    mode: 'draft' | 'submit';
    entries: Array<{
      studentId: number;
      obtainedMarks: number | null;
      attendanceStatus?: AttendanceStatus;
    }>;
    iaEntries?: Array<{
      studentId: number;
      notebookMarks: number | null;
      unitTestMarks: number | null;
      practicalMarks: number | null;
      participationMarks: number | null;
    }>;
  };

  if (!examinationId || !classId || !sectionId || !componentId || !Array.isArray(entries)) {
    return res.status(400).json({ error: 'Invalid marks payload.' });
  }

  const exam = db.prepare(`SELECT * FROM examinations WHERE id = ?`).get(examinationId) as any;
  if (!exam) return res.status(404).json({ error: 'Examination not found.' });

  const isAdmin = req.user!.roles.includes('admin');
  if (!isAdmin) {
    const assigned = db
      .prepare(
        `SELECT id FROM teacher_assignments
         WHERE teacher_id = ? AND class_id = ? AND section_id = ? AND component_id = ? AND academic_year = ?`
      )
      .get(req.user!.id, classId, sectionId, componentId, exam.academic_year);
    if (!assigned) {
      return res.status(403).json({ error: 'Access denied: You are not assigned to this class/subject for this academic year.' });
    }
  }

  if (!isAdmin && (!exam.marks_entry_open || exam.status !== 'Active')) {
    return res.status(403).json({ error: 'Marks entry is currently closed for this examination.' });
  }

  const examComp = db
    .prepare(
      `SELECT ec.*, sub.component_mode, sub.has_components
       FROM examination_components ec
       JOIN subjects sub ON sub.id = ec.subject_id
       WHERE ec.examination_id = ? AND ec.component_id = ?`
    )
    .get(examinationId, componentId) as any;
  if (!examComp) return res.status(404).json({ error: 'Component not configured in this examination.' });

  const componentMode = examComp.component_mode || (examComp.has_components ? 'combined' : 'single');
  const targetMeta = getTargetStudentsForComponent(
    examComp.subject_id,
    componentId,
    componentMode,
    classId,
    sectionId,
    exam.academic_year,
    examinationId
  );
  const validStudentIds = new Set(targetMeta.studentIds);

  for (const item of entries) {
    if (!validStudentIds.has(item.studentId)) {
      return res.status(400).json({ error: 'Entry contains a student who is not enrolled in this section/option.' });
    }
    const att: AttendanceStatus =
      item.attendanceStatus === 'absent'
        ? 'absent'
        : item.obtainedMarks !== null && item.obtainedMarks !== undefined
          ? 'present'
          : item.attendanceStatus === 'present'
            ? 'present'
            : 'pending';

    if (att === 'present' && item.obtainedMarks !== null && item.obtainedMarks !== undefined) {
      const val = Number(item.obtainedMarks);
      if (Number.isNaN(val)) {
        return res.status(400).json({ error: 'Invalid numeric mark detected.' });
      }
      if (val < 0) {
        return res.status(400).json({ error: 'Marks cannot be negative.' });
      }
      const allowedWrittenMax = Number(examComp.max_marks);
      if (val > allowedWrittenMax) {
        return res.status(400).json({
          error: `External/Written marks (${val}) cannot exceed ${allowedWrittenMax}.`,
        });
      }
    }
  }

  const iaCtx = computeSubjectIaContext(
    examinationId,
    examComp.examination_subject_id,
    examComp.subject_id,
    componentMode,
    examComp.id,
    classId,
    sectionId,
    exam.academic_year,
    targetMeta.studentIds
  );

  const iaPermissions = getIaPermissionsForTeacher(
    req.user!.id,
    isAdmin,
    examComp.subject_id,
    classId,
    sectionId,
    exam.academic_year
  );

  if (iaCtx.enabled && Array.isArray(iaEntries)) {
    const existingIaLookup = new Map(iaCtx.iaRows.map((r) => [r.student_id, r]));
    for (const ia of iaEntries) {
      if (!validStudentIds.has(ia.studentId)) {
        return res.status(400).json({ error: 'Internal assessment entry contains an invalid student.' });
      }
      const checkField = (val: number | null | undefined, max: number, label: string) => {
        if (val !== null && val !== undefined) {
          const num = Number(val);
          if (Number.isNaN(num) || num < 0 || num > max) {
            return `${label} marks (${val}) must be between 0 and ${max}.`;
          }
        }
        return null;
      };
      const err =
        (iaPermissions.notebook ? checkField(ia.notebookMarks, iaCtx.notebookMax, 'Notebook') : null) ||
        (iaPermissions.unit_test ? checkField(ia.unitTestMarks, iaCtx.unitTestMax, 'Unit Test') : null) ||
        (iaPermissions.practical ? checkField(ia.practicalMarks, iaCtx.practicalMax, 'Practical/Project') : null) ||
        (iaPermissions.participation ? checkField(ia.participationMarks, iaCtx.participationMax, 'Participation') : null);
      if (err) return res.status(400).json({ error: err });

      const prevRow = existingIaLookup.get(ia.studentId);
      const effNb = iaPermissions.notebook ? Number(ia.notebookMarks ?? 0) : Number(prevRow?.notebook_marks ?? 0);
      const effUt = iaPermissions.unit_test ? Number(ia.unitTestMarks ?? 0) : Number(prevRow?.unit_test_marks ?? 0);
      const effPr = iaPermissions.practical ? Number(ia.practicalMarks ?? 0) : Number(prevRow?.practical_marks ?? 0);
      const effOp = iaPermissions.participation ? Number(ia.participationMarks ?? 0) : Number(prevRow?.participation_marks ?? 0);
      const combinedIa = effNb + effUt + effPr + effOp;
      const allowedIaMax = Number(iaCtx.totalIaMax);
      if (combinedIa > allowedIaMax) {
        return res.status(400).json({
          error: `Total Internal Assessment/Practical marks (${combinedIa}) cannot exceed ${allowedIaMax}.`,
        });
      }
    }
  }

  // Existing written marks map to protect already-submitted rows from non-admin overwrites
  const existingWrittenRows = db
    .prepare(
      `SELECT student_id, obtained_marks, attendance_status, status, submitted_by, submitted_at
       FROM marks
       WHERE examination_id = ? AND examination_component_id = ?`
    )
    .all(examinationId, examComp.id) as Array<{
    student_id: number;
    obtained_marks: number | null;
    attendance_status: AttendanceStatus | null;
    status: 'draft' | 'submitted';
    submitted_by: number | null;
    submitted_at: string | null;
  }>;
  const existingWrittenMap = new Map(existingWrittenRows.map((r) => [r.student_id, r]));

  const existingIaRows = new Map(iaCtx.iaRows.map((r) => [r.student_id, r]));

  const upsertWritten = db.prepare(`
    INSERT INTO marks (student_id, examination_id, examination_component_id, obtained_marks, attendance_status, status, entered_by, submitted_by, submitted_at, updated_at)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, datetime('now'))
    ON CONFLICT(student_id, examination_id, examination_component_id) DO UPDATE SET
      obtained_marks = excluded.obtained_marks,
      attendance_status = excluded.attendance_status,
      status = excluded.status,
      entered_by = excluded.entered_by,
      submitted_by = COALESCE(excluded.submitted_by, marks.submitted_by),
      submitted_at = COALESCE(excluded.submitted_at, marks.submitted_at),
      updated_at = datetime('now')
  `);

  const upsertIa = db.prepare(`
    INSERT INTO internal_assessment_marks (
      student_id, examination_id, subject_id,
      notebook_marks, unit_test_marks, practical_marks, participation_marks,
      nb_status, nb_by, ut_status, ut_by, pr_status, pr_by, op_status, op_by,
      status, entered_by, entered_via_component_id, submitted_by, submitted_at, updated_at
    )
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, datetime('now'))
    ON CONFLICT(student_id, examination_id, subject_id) DO UPDATE SET
      notebook_marks = excluded.notebook_marks,
      unit_test_marks = excluded.unit_test_marks,
      practical_marks = excluded.practical_marks,
      participation_marks = excluded.participation_marks,
      nb_status = excluded.nb_status,
      nb_by = excluded.nb_by,
      ut_status = excluded.ut_status,
      ut_by = excluded.ut_by,
      pr_status = excluded.pr_status,
      pr_by = excluded.pr_by,
      op_status = excluded.op_status,
      op_by = excluded.op_by,
      status = excluded.status,
      entered_by = excluded.entered_by,
      entered_via_component_id = excluded.entered_via_component_id,
      submitted_by = COALESCE(excluded.submitted_by, internal_assessment_marks.submitted_by),
      submitted_at = COALESCE(excluded.submitted_at, internal_assessment_marks.submitted_at),
      updated_at = datetime('now')
  `);

  const nowIso = new Date().toISOString();
  let savedWrittenCount = 0;
  let savedAbsentCount = 0;
  let pendingLeftCount = 0;

  try {
    db.transaction(() => {
      for (const item of entries) {
        const existingRow = existingWrittenMap.get(item.studentId);
        // Do not overwrite already-submitted student marks for non-admin teachers
        if (existingRow?.status === 'submitted' && !isAdmin) {
          continue;
        }

        const att: AttendanceStatus =
          item.attendanceStatus === 'absent'
            ? 'absent'
            : item.obtainedMarks !== null && item.obtainedMarks !== undefined
              ? 'present'
              : 'pending';

        if (att === 'absent') {
          const nextStatus = mode === 'submit' ? 'submitted' : 'draft';
          upsertWritten.run(
            item.studentId,
            examinationId,
            examComp.id,
            null,
            'absent',
            nextStatus,
            req.user!.id,
            nextStatus === 'submitted' ? req.user!.id : null,
            nextStatus === 'submitted' ? nowIso : null
          );
          savedAbsentCount++;
        } else if (att === 'present' && item.obtainedMarks !== null && item.obtainedMarks !== undefined) {
          const nextStatus = mode === 'submit' ? 'submitted' : 'draft';
          upsertWritten.run(
            item.studentId,
            examinationId,
            examComp.id,
            Number(item.obtainedMarks),
            'present',
            nextStatus,
            req.user!.id,
            nextStatus === 'submitted' ? req.user!.id : null,
            nextStatus === 'submitted' ? nowIso : null
          );
          savedWrittenCount++;
        } else {
          // Pending / empty student: NEVER convert to 0 and NEVER lock as submitted!
          if (existingRow) {
            upsertWritten.run(
              item.studentId,
              examinationId,
              examComp.id,
              null,
              'pending',
              'draft',
              req.user!.id,
              null,
              null
            );
          }
          pendingLeftCount++;
        }
      }

      if (iaCtx.enabled && Array.isArray(iaEntries)) {
        for (const ia of iaEntries) {
          const prev = existingIaRows.get(ia.studentId);

          const resolveSubPart = (
            incoming: number | null | undefined,
            prevVal: number | null,
            prevStatusRaw: string | null | undefined,
            prevBy: number | null | undefined,
            permitted: boolean,
            maxAllowed: number
          ): { val: number | null; status: string; by: number | null } => {
            const prevStatus = prevStatusRaw || (prevVal !== null ? prev?.status || 'draft' : 'pending');
            // Disabled sub-component (max <= 0)
            if (maxAllowed <= 0) {
              return { val: 0, status: 'submitted', by: prevBy ?? req.user!.id };
            }
            // Locked sub-component or teacher lacks permission for this specific IA sub-component
            if (!permitted || (prevStatus === 'submitted' && !isAdmin)) {
              return { val: prevVal, status: prevStatus, by: prevBy ?? null };
            }
            if (incoming !== null && incoming !== undefined) {
              return {
                val: Number(incoming),
                status: mode === 'submit' ? 'submitted' : 'draft',
                by: req.user!.id,
              };
            }
            // Incoming is null: in submit mode, keep existing DB sub-component value if another teacher saved a draft, or remain pending
            if (mode === 'submit') {
              return { val: prevVal, status: prevVal !== null ? prevStatus : 'pending', by: prevBy ?? null };
            }
            // Draft mode with null clears unsubmitted draft
            return { val: null, status: 'pending', by: null };
          };

          const nb = resolveSubPart(
            ia.notebookMarks,
            prev?.notebook_marks ?? null,
            prev?.nb_status,
            prev?.nb_by,
            iaPermissions.notebook,
            iaCtx.notebookMax
          );
          const ut = resolveSubPart(
            ia.unitTestMarks,
            prev?.unit_test_marks ?? null,
            prev?.ut_status,
            prev?.ut_by,
            iaPermissions.unit_test,
            iaCtx.unitTestMax
          );
          const pr = resolveSubPart(
            ia.practicalMarks,
            prev?.practical_marks ?? null,
            prev?.pr_status,
            prev?.pr_by,
            iaPermissions.practical,
            iaCtx.practicalMax
          );
          const op = resolveSubPart(
            ia.participationMarks,
            prev?.participation_marks ?? null,
            prev?.op_status,
            prev?.op_by,
            iaPermissions.participation,
            iaCtx.participationMax
          );

          const anyValue = nb.val !== null || ut.val !== null || pr.val !== null || op.val !== null;
          if (!anyValue && !prev) {
            continue;
          }

          const allActiveSubmitted =
            (iaCtx.notebookMax <= 0 || nb.status === 'submitted') &&
            (iaCtx.unitTestMax <= 0 || ut.status === 'submitted') &&
            (iaCtx.practicalMax <= 0 || pr.status === 'submitted') &&
            (iaCtx.participationMax <= 0 || op.status === 'submitted');

          const rowIaStatus = allActiveSubmitted ? 'submitted' : 'draft';

          upsertIa.run(
            ia.studentId,
            examinationId,
            examComp.subject_id,
            nb.val,
            ut.val,
            pr.val,
            op.val,
            nb.status,
            nb.by,
            ut.status,
            ut.by,
            pr.status,
            pr.by,
            op.status,
            op.by,
            rowIaStatus,
            req.user!.id,
            examComp.id,
            rowIaStatus === 'submitted' ? req.user!.id : null,
            rowIaStatus === 'submitted' ? nowIso : null
          );
        }
      }
    })();
  } catch (err: any) {
    return res.status(400).json({ error: err?.message || 'Failed to save marks.' });
  }

  logAudit(
    req.user!,
    mode === 'submit' ? 'SUBMIT_MARKS' : 'SAVE_MARKS_DRAFT',
    'marks',
    `${examinationId}:${examComp.id}`,
    {
      examinationId,
      classId,
      sectionId,
      componentName: examComp.component_name,
      savedWrittenCount,
      savedAbsentCount,
      pendingLeftCount,
      totalStudents: targetMeta.studentIds.length,
      includedInternalAssessment: Boolean(iaCtx.enabled && Array.isArray(iaEntries)),
    }
  );

  res.json({
    success: true,
    status: mode === 'submit' ? 'submitted' : 'draft',
    savedWrittenCount,
    savedAbsentCount,
    pendingLeftCount,
  });
});

app.post('/api/teacher/correction-request', requireAuth, (req: AuthenticatedRequest, res) => {
  const { examinationId, examComponentId, classId, sectionId, reason } = req.body as {
    examinationId: number;
    examComponentId: number;
    classId: number;
    sectionId: number;
    reason: string;
  };
  if (!reason || reason.trim().length < 5) {
    return res.status(400).json({ error: 'Please provide a clear reason (at least 5 characters).' });
  }

  const isAdmin = req.user!.roles.includes('admin');
  if (!isAdmin) {
    const compRow = db
      .prepare(
        `SELECT ec.component_id, e.academic_year
         FROM examination_components ec
         JOIN examinations e ON e.id = ec.examination_id
         WHERE ec.id = ? AND ec.examination_id = ? AND COALESCE(e.is_deleted, 0) = 0`
      )
      .get(examComponentId, examinationId) as { component_id: number; academic_year: string } | undefined;
    if (!compRow) {
      return res.status(404).json({ error: 'Examination component not found.' });
    }
    const assigned = db
      .prepare(
        `SELECT id FROM teacher_assignments
         WHERE teacher_id = ? AND class_id = ? AND section_id = ? AND component_id = ? AND academic_year = ?`
      )
      .get(req.user!.id, classId, sectionId, compRow.component_id, compRow.academic_year);
    if (!assigned) {
      return res.status(403).json({ error: 'Access denied: You can only request correction for your assigned classes and subjects.' });
    }
  }

  const info = db
    .prepare(
      `INSERT INTO mark_correction_requests (examination_id, examination_component_id, class_id, section_id, requested_by, reason, status)
       VALUES (?, ?, ?, ?, ?, ?, 'pending')`
    )
    .run(examinationId, examComponentId, classId, sectionId, req.user!.id, reason.trim());

  logAudit(req.user!, 'REQUEST_MARKS_CORRECTION', 'mark_correction_request', Number(info.lastInsertRowid), {
    examinationId,
    examComponentId,
    classId,
    sectionId,
    reason: reason.trim(),
  });
  res.status(201).json({ id: info.lastInsertRowid });
});

app.get('/api/teacher/submission-history', requireAuth, (req: AuthenticatedRequest, res) => {
  const userId = req.user!.id;
  const rows = db
    .prepare(
      `SELECT e.id as examination_id, e.name as examination_name, e.academic_year,
              c.id as class_id, c.name as class_name, COALESCE(c.has_sections, 1) as has_sections,
              s.id as section_id, s.name as section_name,
              ta.subject_id, sub.name as subject_name, sub.component_mode,
              COALESCE(sub.applicable_class_ids, '') as applicable_class_ids,
              COALESCE(es.target_class_ids, '') as target_class_ids,
              ta.component_id, ec.id as exam_component_id, ec.component_name, ec.max_marks,
              MAX(m.updated_at) as last_updated_at,
              MAX(m.submitted_at) as submitted_at
       FROM teacher_assignments ta
       JOIN classes c ON c.id = ta.class_id
       JOIN sections s ON s.id = ta.section_id
       JOIN subjects sub ON sub.id = ta.subject_id
       JOIN examination_components ec ON ec.component_id = ta.component_id
       JOIN examination_subjects es ON es.id = ec.examination_subject_id
       JOIN examinations e ON e.id = ec.examination_id AND e.academic_year = ta.academic_year
       LEFT JOIN marks m ON m.examination_id = e.id AND m.examination_component_id = ec.id
         AND m.student_id IN (
           SELECT se.student_id FROM student_enrollments se
           JOIN students st ON st.id = se.student_id
           WHERE se.class_id = c.id AND se.section_id = s.id AND se.academic_year = e.academic_year
             AND se.status = 'active' AND COALESCE(st.is_deleted, 0) = 0
         )
       WHERE ta.teacher_id = ?
         AND COALESCE(e.is_deleted, 0) = 0 AND COALESCE(c.is_deleted, 0) = 0 AND COALESCE(s.is_deleted, 0) = 0 AND COALESCE(sub.is_deleted, 0) = 0
       GROUP BY e.id, c.id, s.id, ec.id
       ORDER BY e.start_date DESC, c.numeric_order ASC, s.name ASC, sub.display_order ASC`
    )
    .all(userId) as Array<any>;

  const result = rows
    .filter((r) => doesSubjectApplyToClass(r.target_class_ids || r.applicable_class_ids, r.class_id))
    .map((r) => {
      const target = getTargetStudentsForComponent(
        r.subject_id,
        r.component_id,
        r.component_mode || 'single',
        r.class_id,
        r.section_id,
        r.academic_year,
        r.examination_id
      );
      let entered = 0;
      let submitted = 0;
      if (target.studentIds.length > 0) {
        const ph = target.studentIds.map(() => '?').join(',');
        const counts = db
          .prepare(
            `SELECT COUNT(CASE WHEN obtained_marks IS NOT NULL OR attendance_status = 'absent' THEN 1 END) as entered_count,
                    COUNT(CASE WHEN status = 'submitted' AND (obtained_marks IS NOT NULL OR attendance_status = 'absent') THEN 1 END) as submitted_count
             FROM marks
             WHERE examination_id = ? AND examination_component_id = ? AND student_id IN (${ph})`
          )
          .get(r.examination_id, r.exam_component_id, ...target.studentIds) as {
          entered_count: number;
          submitted_count: number;
        };
        entered = counts.entered_count;
        submitted = counts.submitted_count;
      }
      return {
        examination_id: r.examination_id,
        examination_name: r.examination_name,
        class_id: r.class_id,
        class_name: r.class_name,
        has_sections: r.has_sections,
        hasSections: Boolean(r.has_sections ?? 1),
        section_id: r.section_id,
        section_name: r.section_name,
        subject_name: r.subject_name,
        component_name: r.component_name,
        max_marks: r.max_marks,
        entered_count: entered,
        submitted_count: submitted,
        total_students: target.studentIds.length,
        last_updated_at: r.last_updated_at,
        submitted_at: r.submitted_at,
      };
    });

  res.json(result);
});

app.get('/api/teacher/marks-export', requireAuth, (req: AuthenticatedRequest, res) => {
  try {
    const examinationId = Number(req.query.examinationId);
    const scope = req.query.scope === 'all' ? 'all' : 'single';
    const classId = Number(req.query.classId || 0);
    const sectionId = Number(req.query.sectionId || 0);
    const componentId = Number(req.query.componentId || 0);

    if (!examinationId) {
      return res.status(400).json({ error: 'examinationId is required.' });
    }

    const exam = db
      .prepare(`SELECT * FROM examinations WHERE id = ? AND COALESCE(is_deleted, 0) = 0`)
      .get(examinationId) as any;
    if (!exam) return res.status(404).json({ error: 'Examination not found.' });

    const isAdmin = req.user!.roles.includes('admin');

    type AssignmentTarget = {
      class_id: number;
      class_name: string;
      has_sections: number;
      section_id: number;
      section_name: string;
      subject_id: number;
      subject_name: string;
      subject_code: string;
      has_components: number;
      component_mode: string;
      applicable_class_ids: string;
      component_id: number;
      component_name: string;
    };

    let targets: AssignmentTarget[] = [];

    if (scope === 'single') {
      if (!classId || !sectionId || !componentId) {
        return res.status(400).json({ error: 'classId, sectionId, and componentId are required for single export.' });
      }
      if (!isAdmin) {
        const assigned = db
          .prepare(
            `SELECT ta.class_id, c.name as class_name, COALESCE(c.has_sections, 1) as has_sections,
                    ta.section_id, s.name as section_name,
                    ta.subject_id, sub.name as subject_name, sub.code as subject_code,
                    sub.has_components, sub.component_mode, COALESCE(sub.applicable_class_ids, '') as applicable_class_ids,
                    ta.component_id, sc.name as component_name
             FROM teacher_assignments ta
             JOIN classes c ON c.id = ta.class_id
             JOIN sections s ON s.id = ta.section_id
             JOIN subjects sub ON sub.id = ta.subject_id
             JOIN subject_components sc ON sc.id = ta.component_id
             WHERE ta.teacher_id = ? AND ta.class_id = ? AND ta.section_id = ? AND ta.component_id = ? AND ta.academic_year = ?
               AND COALESCE(c.is_deleted, 0) = 0 AND COALESCE(s.is_deleted, 0) = 0 AND COALESCE(sub.is_deleted, 0) = 0`
          )
          .get(req.user!.id, classId, sectionId, componentId, exam.academic_year) as AssignmentTarget | undefined;
        if (!assigned) {
          return res.status(403).json({
            error: 'Access denied: You can only download Excel marks for subjects, classes, and sections assigned to you.',
          });
        }
        targets = [assigned];
      } else {
        const adminTarget = db
          .prepare(
            `SELECT c.id as class_id, c.name as class_name, COALESCE(c.has_sections, 1) as has_sections,
                    s.id as section_id, s.name as section_name,
                    sub.id as subject_id, sub.name as subject_name, sub.code as subject_code,
                    sub.has_components, sub.component_mode, COALESCE(sub.applicable_class_ids, '') as applicable_class_ids,
                    sc.id as component_id, sc.name as component_name
             FROM classes c
             JOIN sections s ON s.class_id = c.id
             JOIN subject_components sc ON sc.id = ?
             JOIN subjects sub ON sub.id = sc.subject_id
             WHERE c.id = ? AND s.id = ?`
          )
          .get(componentId, classId, sectionId) as AssignmentTarget | undefined;
        if (!adminTarget) return res.status(404).json({ error: 'Target class/section/subject not found.' });
        targets = [adminTarget];
      }
    } else {
      targets = db
        .prepare(
          `SELECT ta.class_id, c.name as class_name, COALESCE(c.has_sections, 1) as has_sections,
                  ta.section_id, s.name as section_name,
                  ta.subject_id, sub.name as subject_name, sub.code as subject_code,
                  sub.has_components, sub.component_mode, COALESCE(sub.applicable_class_ids, '') as applicable_class_ids,
                  ta.component_id, sc.name as component_name
           FROM teacher_assignments ta
           JOIN classes c ON c.id = ta.class_id
           JOIN sections s ON s.id = ta.section_id
           JOIN subjects sub ON sub.id = ta.subject_id
           JOIN subject_components sc ON sc.id = ta.component_id
           WHERE ta.teacher_id = ? AND ta.academic_year = ?
             AND COALESCE(c.is_deleted, 0) = 0 AND COALESCE(s.is_deleted, 0) = 0 AND COALESCE(sub.is_deleted, 0) = 0
           ORDER BY c.numeric_order ASC, s.name ASC, sub.display_order ASC, sc.display_order ASC`
        )
        .all(req.user!.id, exam.academic_year) as AssignmentTarget[];

      if (targets.length === 0) {
        return res.status(404).json({ error: `No assigned subjects found for academic year ${exam.academic_year}.` });
      }
    }

    const hasYearEnrollments =
      (
        db
          .prepare(`SELECT COUNT(*) as cnt FROM student_enrollments WHERE academic_year = ?`)
          .get(exam.academic_year) as { cnt: number }
      ).cnt > 0;

    const sheets: any[] = [];

    for (const t of targets) {
      const examComp = db
        .prepare(
          `SELECT ec.*, es.max_marks as subject_total_max, COALESCE(es.target_class_ids, '') as target_class_ids
           FROM examination_components ec
           JOIN examination_subjects es ON es.id = ec.examination_subject_id
           WHERE ec.examination_id = ? AND ec.component_id = ?`
        )
        .get(examinationId, t.component_id) as any;
      if (!examComp) continue;
      if (!doesSubjectApplyToClass(examComp.target_class_ids || t.applicable_class_ids, t.class_id)) {
        continue;
      }

      const componentMode = t.component_mode || (t.has_components ? 'combined' : 'single');
      const targetMeta = getTargetStudentsForComponent(
        t.subject_id,
        t.component_id,
        componentMode,
        t.class_id,
        t.section_id,
        exam.academic_year,
        examinationId
      );
      const targetSet = new Set(targetMeta.studentIds);

      const allSectionStudents = (
        hasYearEnrollments
          ? db
              .prepare(
                `SELECT st.id as student_id, st.student_code, st.full_name, se.roll_number,
                        m.obtained_marks, m.attendance_status, m.status as mark_status
                 FROM student_enrollments se
                 JOIN students st ON st.id = se.student_id
                 LEFT JOIN marks m ON m.student_id = st.id AND m.examination_id = ? AND m.examination_component_id = ?
                 WHERE se.academic_year = ? AND se.class_id = ? AND se.section_id = ? AND se.status = 'active' AND COALESCE(st.is_deleted, 0) = 0
                 ORDER BY se.roll_number ASC, st.student_code ASC`
              )
              .all(examinationId, examComp.id, exam.academic_year, t.class_id, t.section_id)
          : db
              .prepare(
                `SELECT st.id as student_id, st.student_code, st.full_name, st.roll_number,
                        m.obtained_marks, m.attendance_status, m.status as mark_status
                 FROM students st
                 LEFT JOIN marks m ON m.student_id = st.id AND m.examination_id = ? AND m.examination_component_id = ?
                 WHERE st.class_id = ? AND st.section_id = ? AND st.status = 'active' AND COALESCE(st.is_deleted, 0) = 0
                 ORDER BY st.roll_number ASC, st.student_code ASC`
              )
              .all(examinationId, examComp.id, t.class_id, t.section_id)
      ) as Array<any>;

      const students = allSectionStudents.filter((s) => targetSet.has(s.student_id));
      const iaCtx = computeSubjectIaContext(
        examinationId,
        examComp.examination_subject_id,
        t.subject_id,
        componentMode,
        examComp.id,
        t.class_id,
        t.section_id,
        exam.academic_year,
        targetMeta.studentIds
      );
      const iaByStudent = new Map(iaCtx.iaRows.map((r) => [r.student_id, r]));

      let subjectWrittenMaxMarks = Number(examComp.max_marks);
      const siblingMap = new Map<number, { otherMarks: number | null; allEntered: boolean; anyAbsent: boolean }>();

      if (componentMode === 'combined') {
        const siblingComps = db
          .prepare(
            `SELECT id, max_marks FROM examination_components
             WHERE examination_id = ? AND subject_id = ? AND id != ?`
          )
          .all(examinationId, t.subject_id, examComp.id) as Array<{ id: number; max_marks: number }>;
        subjectWrittenMaxMarks += siblingComps.reduce((s, c) => s + Number(c.max_marks || 0), 0);

        if (siblingComps.length > 0 && targetMeta.studentIds.length > 0) {
          const compIds = siblingComps.map((c) => c.id);
          const cPh = compIds.map(() => '?').join(',');
          const sPh = targetMeta.studentIds.map(() => '?').join(',');
          const sibMarks = db
            .prepare(
              `SELECT student_id, examination_component_id, obtained_marks, attendance_status
               FROM marks
               WHERE examination_id = ? AND examination_component_id IN (${cPh}) AND student_id IN (${sPh})`
            )
            .all(examinationId, ...compIds, ...targetMeta.studentIds) as Array<{
            student_id: number;
            examination_component_id: number;
            obtained_marks: number | null;
            attendance_status: AttendanceStatus | null;
          }>;
          const byStuComp = new Map<string, { obtained_marks: number | null; attendance_status: AttendanceStatus | null }>();
          for (const sm of sibMarks) {
            byStuComp.set(`${sm.student_id}:${sm.examination_component_id}`, sm);
          }
          for (const sid of targetMeta.studentIds) {
            let sum = 0;
            let allEntered = true;
            let anyAbsent = false;
            for (const sc of siblingComps) {
              const r = byStuComp.get(`${sid}:${sc.id}`);
              if (!r) {
                allEntered = false;
              } else if (r.attendance_status === 'absent') {
                anyAbsent = true;
              } else if (r.obtained_marks === null) {
                allEntered = false;
              } else {
                sum += Number(r.obtained_marks);
              }
            }
            siblingMap.set(sid, {
              otherMarks: allEntered ? Number(sum.toFixed(2)) : null,
              allEntered,
              anyAbsent,
            });
          }
        }
      }

      const subjectTotalMaxMarks = subjectWrittenMaxMarks + (iaCtx.enabled ? iaCtx.totalIaMax : 0);

      const rows = students.map((s) => {
        const ia = iaByStudent.get(s.student_id);
        const sib = siblingMap.get(s.student_id);
        const attStatus: AttendanceStatus =
          s.attendance_status === 'absent'
            ? 'absent'
            : s.obtained_marks !== null
              ? 'present'
              : 'pending';
        const writtenMarks = attStatus === 'present' && s.obtained_marks !== null ? Number(s.obtained_marks) : null;

        const iaNb = ia?.notebook_marks !== null && ia?.notebook_marks !== undefined ? Number(ia.notebook_marks) : null;
        const iaUt = ia?.unit_test_marks !== null && ia?.unit_test_marks !== undefined ? Number(ia.unit_test_marks) : null;
        const iaPr = ia?.practical_marks !== null && ia?.practical_marks !== undefined ? Number(ia.practical_marks) : null;
        const iaOp = ia?.participation_marks !== null && ia?.participation_marks !== undefined ? Number(ia.participation_marks) : null;

        let iaTotal: number | null = null;
        if (iaCtx.enabled) {
          const nbOk = iaCtx.notebookMax <= 0 || iaNb !== null;
          const utOk = iaCtx.unitTestMax <= 0 || iaUt !== null;
          const prOk = iaCtx.practicalMax <= 0 || iaPr !== null;
          const opOk = iaCtx.participationMax <= 0 || iaOp !== null;
          if (nbOk && utOk && prOk && opOk) {
            iaTotal = Number(((iaNb ?? 0) + (iaUt ?? 0) + (iaPr ?? 0) + (iaOp ?? 0)).toFixed(2));
          }
        }

        const otherComponentsMarks = componentMode === 'combined' ? (sib?.otherMarks ?? null) : null;
        const subjectExternalMarks =
          attStatus === 'absent' || sib?.anyAbsent
            ? null
            : componentMode === 'combined'
              ? writtenMarks !== null && sib?.allEntered && otherComponentsMarks !== null
                ? Number((writtenMarks + otherComponentsMarks).toFixed(2))
                : null
              : writtenMarks;

        const isAbsent = attStatus === 'absent' || Boolean(sib?.anyAbsent);
        const totalMarks =
          isAbsent
            ? null
            : subjectExternalMarks !== null && (!iaCtx.enabled || iaTotal !== null)
              ? Number((subjectExternalMarks + (iaCtx.enabled ? iaTotal ?? 0 : 0)).toFixed(2))
              : null;

        const hasAnySavedData =
          writtenMarks !== null ||
          attStatus === 'absent' ||
          iaNb !== null ||
          iaUt !== null ||
          iaPr !== null ||
          iaOp !== null;

        const submissionStatus: 'Submitted' | 'Draft' | 'Not Submitted' | 'Absent' =
          attStatus === 'absent'
            ? 'Absent'
            : s.mark_status === 'submitted' && writtenMarks !== null
              ? 'Submitted'
              : hasAnySavedData
                ? 'Draft'
                : 'Not Submitted';

        const gradeEval = calculateSubjectGrade(totalMarks, subjectTotalMaxMarks, {
          isAbsent,
          isPending: totalMarks === null,
          isNotSubmitted: !hasAnySavedData,
        });

        return {
          rollNumber: s.roll_number,
          studentCode: s.student_code,
          studentName: s.full_name,
          className: t.class_name,
          hasSections: Boolean(t.has_sections ?? 1),
          sectionName: t.section_name,
          subjectName: t.subject_name,
          componentName: t.component_name,
          attendanceStatus: attStatus,
          writtenMarks,
          otherComponentsMarks,
          subjectExternalMarks,
          iaNotebookMarks: iaNb,
          iaUnitTestMarks: iaUt,
          iaPracticalMarks: iaPr,
          iaParticipationMarks: iaOp,
          iaTotalMarks: iaTotal,
          totalMarks,
          grade: gradeEval.grade,
          gradeStatus: gradeEval.status,
          submissionStatus,
        };
      });

      sheets.push({
        examinationId,
        examinationName: exam.name,
        academicYear: exam.academic_year,
        classId: t.class_id,
        className: t.class_name,
        hasSections: Boolean(t.has_sections ?? 1),
        sectionId: t.section_id,
        sectionName: t.section_name,
        subjectId: t.subject_id,
        subjectName: t.subject_name,
        subjectCode: t.subject_code,
        componentId: t.component_id,
        componentName: t.component_name,
        hasComponents: Boolean(t.has_components),
        componentMode,
        writtenMaxMarks: Number(examComp.max_marks),
        subjectWrittenMaxMarks,
        iaEnabled: iaCtx.enabled,
        iaNotebookMax: iaCtx.notebookMax,
        iaUnitTestMax: iaCtx.unitTestMax,
        iaPracticalMax: iaCtx.practicalMax,
        iaParticipationMax: iaCtx.participationMax,
        iaMaxMarks: iaCtx.totalIaMax,
        subjectTotalMaxMarks,
        rows,
      });
    }

    if (sheets.length === 0) {
      return res.status(404).json({
        error: 'None of your assigned subjects are configured in this examination.',
      });
    }

    logAudit(req.user!, 'EXPORT_TEACHER_MARKS_EXCEL', 'marks', `${examinationId}:${scope}`, {
      examinationId,
      scope,
      sheetCount: sheets.length,
    });

    res.json({
      examinationId,
      examinationName: exam.name,
      academicYear: exam.academic_year,
      teacherName: req.user!.fullName,
      generatedAt: new Date().toISOString(),
      sheets,
    });
  } catch (err: any) {
    console.error('Error exporting teacher marks:', err);
    res.status(500).json({ error: err?.message || 'Failed to export teacher marks.' });
  }
});

// ==========================================
// 5. CONSOLIDATED RESULTS & REPORTS (ADMIN OR CLASS TEACHER)
// ==========================================

function verifyClassResultAccess(user: AuthenticatedRequest['user'], classId: number, sectionId: number): boolean {
  if (!user) return false;
  if (user.roles.includes('admin')) return true;
  const assigned = db
    .prepare(`SELECT id FROM class_teacher_assignments WHERE teacher_id = ? AND class_id = ? AND section_id = ?`)
    .get(user.id, classId, sectionId);
  return Boolean(assigned);
}

app.get('/api/results/consolidated', requireAuth, (req: AuthenticatedRequest, res) => {
  const examinationId = Number(req.query.examinationId);
  const classId = Number(req.query.classId);
  const sectionId = Number(req.query.sectionId);

  if (!examinationId || !classId || !sectionId) {
    return res.status(400).json({ error: 'examinationId, classId, and sectionId are required.' });
  }

  if (!verifyClassResultAccess(req.user, classId, sectionId)) {
    return res.status(403).json({
      error: 'Access denied: Only administrators or the assigned Class Teacher for this section can view consolidated results.',
    });
  }

  try {
    const report = getConsolidatedResults(examinationId, classId, sectionId);
    res.json(report);
  } catch (err: any) {
    res.status(404).json({ error: err.message || 'Could not compute results.' });
  }
});

app.get('/api/results/exam-comparison', requireAuth, (req: AuthenticatedRequest, res) => {
  const classId = Number(req.query.classId);
  const sectionId = Number(req.query.sectionId);
  const academicYear = req.query.academicYear as string | undefined;
  if (!classId || !sectionId) {
    return res.status(400).json({ error: 'classId and sectionId are required.' });
  }
  if (!verifyClassResultAccess(req.user, classId, sectionId)) {
    return res.status(403).json({ error: 'Access denied.' });
  }

  const exams = (
    academicYear && academicYear !== 'all'
      ? db
          .prepare(
            `SELECT id, name, academic_year, status, start_date FROM examinations WHERE academic_year = ? AND COALESCE(is_deleted, 0) = 0 ORDER BY start_date ASC, id ASC`
          )
          .all(academicYear)
      : db
          .prepare(
            `SELECT id, name, academic_year, status, start_date FROM examinations WHERE COALESCE(is_deleted, 0) = 0 ORDER BY academic_year DESC, start_date ASC, id ASC`
          )
          .all()
  ) as Array<{ id: number; name: string; academic_year: string; status: string; start_date: string }>;

  const comparison = exams.map((e) => {
    const rep = getConsolidatedResults(e.id, classId, sectionId);
    return {
      examinationId: e.id,
      examinationName: e.name,
      academicYear: e.academic_year,
      status: e.status,
      completedCount: rep.summary.completedCount,
      totalStudents: rep.summary.totalStudents,
      classAveragePercentage: rep.summary.classAveragePercentage,
      passCount: rep.summary.passCount,
      failCount: rep.summary.failCount,
      subjectPerformance: rep.subjectPerformance,
    };
  });

  res.json(comparison);
});

app.get('/api/results/combined', requireAuth, (req: AuthenticatedRequest, res) => {
  const classId = Number(req.query.classId);
  const sectionId = Number(req.query.sectionId);
  const examinationIdParam = req.query.examinationId ? Number(req.query.examinationId) : null;
  const term1ExamId = req.query.term1ExamId ? Number(req.query.term1ExamId) : undefined;
  const term2ExamId = req.query.term2ExamId ? Number(req.query.term2ExamId) : undefined;
  let academicYear = typeof req.query.academicYear === 'string' ? req.query.academicYear.trim() : '';

  if (!classId || !sectionId) {
    return res.status(400).json({ error: 'classId and sectionId are required.' });
  }
  if (!verifyClassResultAccess(req.user, classId, sectionId)) {
    return res.status(403).json({
      error: 'Access denied: Only administrators or the assigned Class Teacher for this section can view combined marksheets.',
    });
  }

  if ((!academicYear || academicYear === 'ALL' || academicYear === 'all') && examinationIdParam) {
    const ex = db
      .prepare(`SELECT academic_year FROM examinations WHERE id = ? AND COALESCE(is_deleted, 0) = 0`)
      .get(examinationIdParam) as { academic_year: string } | undefined;
    if (ex?.academic_year) {
      academicYear = ex.academic_year;
    }
  }
  if (!academicYear || academicYear === 'ALL' || academicYear === 'all') {
    academicYear = getCurrentAcademicYear();
  }

  try {
    const combined = getCombinedTermResults(academicYear, classId, sectionId, term1ExamId, term2ExamId);
    res.json(combined);
  } catch (err: any) {
    res.status(404).json({ error: err?.message || 'Could not compute combined term results.' });
  }
});

app.get('/api/results/section-students', requireAuth, (req: AuthenticatedRequest, res) => {
  const classId = Number(req.query.classId);
  const sectionId = Number(req.query.sectionId);
  const academicYear = (req.query.academicYear as string) || getCurrentAcademicYear();
  if (!classId || !sectionId) {
    return res.status(400).json({ error: 'classId and sectionId are required.' });
  }
  if (!verifyClassResultAccess(req.user, classId, sectionId)) {
    return res.status(403).json({ error: 'Access denied.' });
  }

  const students = db
    .prepare(
      `SELECT st.id, st.student_code, st.full_name, st.gender, st.guardian_name, st.guardian_phone,
              COALESCE(st.father_name, '') as father_name,
              COALESCE(st.mother_name, '') as mother_name,
              COALESCE(st.residential_address, '') as residential_address,
              COALESCE(NULLIF(st.contact_no, ''), st.guardian_phone, '') as contact_no,
              COALESCE(st.aapaar_id, '') as aapaar_id,
              COALESCE(NULLIF(se.stream, ''), st.stream, '') as stream,
              se.roll_number, se.class_id, c.name as class_name, COALESCE(c.has_sections, 1) as has_sections,
              se.section_id, s.name as section_name,
              se.academic_year, se.status
       FROM student_enrollments se
       JOIN students st ON st.id = se.student_id
       JOIN classes c ON c.id = se.class_id
       JOIN sections s ON s.id = se.section_id
       WHERE se.class_id = ? AND se.section_id = ? AND se.academic_year = ? AND se.status = 'active'
         AND COALESCE(st.is_deleted, 0) = 0
       ORDER BY se.roll_number ASC, st.student_code ASC`
    )
    .all(classId, sectionId, academicYear);
  res.json(students);
});

app.get('/api/co-scholastic/sheet', requireAuth, (req: AuthenticatedRequest, res) => {
  const examinationId = Number(req.query.examinationId);
  const classId = Number(req.query.classId);
  const sectionId = Number(req.query.sectionId);

  if (!examinationId || !classId || !sectionId) {
    return res.status(400).json({ error: 'examinationId, classId, and sectionId are required.' });
  }
  if (!verifyClassResultAccess(req.user, classId, sectionId)) {
    return res.status(403).json({
      error: 'Access denied: Only administrators or the assigned Class Teacher for this section can access co-scholastic grades.',
    });
  }

  const termMeta = getExamCoScholasticTerm(examinationId);
  if (!termMeta.academicYear) {
    return res.status(404).json({ error: termMeta.reason || 'Examination not found.' });
  }

  const classSection = db
    .prepare(
      `SELECT c.id as class_id, c.name as class_name, COALESCE(c.has_sections, 1) as has_sections,
              s.id as section_id, s.name as section_name
       FROM classes c
       JOIN sections s ON s.class_id = c.id
       WHERE c.id = ? AND s.id = ?`
    )
    .get(classId, sectionId) as
    | { class_id: number; class_name: string; has_sections: number; section_id: number; section_name: string }
    | undefined;
  if (!classSection) {
    return res.status(404).json({ error: 'Class or Section not found.' });
  }

  const hasYearEnrollments =
    (
      db
        .prepare(`SELECT COUNT(*) as cnt FROM student_enrollments WHERE academic_year = ?`)
        .get(termMeta.academicYear) as { cnt: number }
    ).cnt > 0;

  const roster = (
    hasYearEnrollments
      ? db
          .prepare(
            `SELECT st.id as student_id, st.student_code, st.full_name, se.roll_number,
                    COALESCE(NULLIF(se.stream, ''), st.stream, '') as stream
             FROM student_enrollments se
             JOIN students st ON st.id = se.student_id
             WHERE se.academic_year = ? AND se.class_id = ? AND se.section_id = ?
               AND se.status = 'active' AND COALESCE(st.is_deleted, 0) = 0
             ORDER BY se.roll_number ASC, st.student_code ASC`
          )
          .all(termMeta.academicYear, classId, sectionId)
      : db
          .prepare(
            `SELECT id as student_id, student_code, full_name, roll_number, COALESCE(stream, '') as stream
             FROM students
             WHERE class_id = ? AND section_id = ? AND status = 'active' AND COALESCE(is_deleted, 0) = 0
             ORDER BY roll_number ASC, student_code ASC`
          )
          .all(classId, sectionId)
  ) as Array<{
    student_id: number;
    student_code: string;
    full_name: string;
    roll_number: number;
    stream: string;
  }>;

  const studentIds = new Set(roster.map((r) => r.student_id));
  const gradeRows = (
    db
      .prepare(
        `SELECT student_id, term, item_key, grade
         FROM student_co_scholastic_grades
         WHERE academic_year = ?`
      )
      .all(termMeta.academicYear) as Array<{
      student_id: number;
      term: number;
      item_key: string;
      grade: string;
    }>
  ).filter(
    (r) =>
      studentIds.has(r.student_id) &&
      CO_SCHOLASTIC_ITEM_KEYS.has(r.item_key) &&
      isValidCoScholasticGrade(r.grade)
  );

  const byStudent = new Map<
    number,
    { term1: Record<string, CoScholasticGrade>; term2: Record<string, CoScholasticGrade> }
  >();
  for (const r of gradeRows) {
    let bucket = byStudent.get(r.student_id);
    if (!bucket) {
      bucket = { term1: {}, term2: {} };
      byStudent.set(r.student_id, bucket);
    }
    if (r.term === 1) bucket.term1[r.item_key] = r.grade as CoScholasticGrade;
    else if (r.term === 2) bucket.term2[r.item_key] = r.grade as CoScholasticGrade;
  }

  const rosterStudentIds = roster.map((st) => st.student_id);
  const profileMap = getStudentExtendedProfilesMap(rosterStudentIds);
  const termRecordsMap = getStudentTermRecordsMap(termMeta.academicYear, rosterStudentIds);

  const students = roster.map((st) => {
    const bucket = byStudent.get(st.student_id) || { term1: {}, term2: {} };
    const t1 = summarizeCoScholasticGrades(bucket.term1);
    const t2 = summarizeCoScholasticGrades(bucket.term2);
    const ext = profileMap.get(st.student_id);
    const termRec = termRecordsMap.get(st.student_id) || createEmptyTermData();
    return {
      studentId: st.student_id,
      studentCode: st.student_code,
      studentName: st.full_name,
      rollNumber: st.roll_number,
      stream: st.stream === 'Science' || st.stream === 'Humanities' ? st.stream : '',
      fatherName: ext?.fatherName || '',
      motherName: ext?.motherName || '',
      residentialAddress: ext?.residentialAddress || '',
      contactNo: ext?.contactNo || '',
      aapaarId: ext?.aapaarId || '',
      termRecords: termRec,
      term1: bucket.term1,
      term2: bucket.term2,
      term1TotalPoints: t1.totalPoints,
      term2TotalPoints: t2.totalPoints,
    };
  });

  res.json({
    termMeta,
    classInfo: {
      classId: classSection.class_id,
      className: classSection.class_name,
      hasSections: Boolean(classSection.has_sections ?? 1),
      sectionId: classSection.section_id,
      sectionName: classSection.section_name,
      resultDate: getClassResultDate(classId, sectionId, termMeta.academicYear),
    },
    students,
  });
});

app.get('/api/class-teacher/result-date', requireAuth, (req: AuthenticatedRequest, res) => {
  const classId = Number(req.query.classId);
  const sectionId = Number(req.query.sectionId);
  let academicYear = typeof req.query.academicYear === 'string' ? req.query.academicYear.trim() : '';
  if (!academicYear || academicYear === 'ALL' || academicYear === 'all') {
    academicYear = getCurrentAcademicYear();
  }
  if (!classId || !sectionId) {
    return res.status(400).json({ error: 'classId and sectionId are required.' });
  }
  if (!verifyClassResultAccess(req.user, classId, sectionId)) {
    return res.status(403).json({
      error: 'Access denied: Only administrators or the assigned Class Teacher for this section can access result date settings.',
    });
  }
  res.json({
    classId,
    sectionId,
    academicYear,
    resultDate: getClassResultDate(classId, sectionId, academicYear),
  });
});

app.post('/api/class-teacher/result-date', requireAuth, (req: AuthenticatedRequest, res) => {
  const classId = Number(req.body?.classId);
  const sectionId = Number(req.body?.sectionId);
  const examinationId = req.body?.examinationId ? Number(req.body.examinationId) : null;
  let academicYear = typeof req.body?.academicYear === 'string' ? req.body.academicYear.trim() : '';
  const rawDate = typeof req.body?.resultDate === 'string' ? req.body.resultDate.trim() : '';

  if (!classId || !sectionId) {
    return res.status(400).json({ error: 'classId and sectionId are required.' });
  }
  if (!verifyClassResultAccess(req.user, classId, sectionId)) {
    return res.status(403).json({
      error: 'Access denied: Only administrators or the assigned Class Teacher for this section can set the result date.',
    });
  }

  if (!academicYear && examinationId) {
    const ex = db
      .prepare(`SELECT academic_year FROM examinations WHERE id = ? AND COALESCE(is_deleted, 0) = 0`)
      .get(examinationId) as { academic_year: string } | undefined;
    if (ex?.academic_year) academicYear = ex.academic_year;
  }
  if (!academicYear || academicYear === 'ALL' || academicYear === 'all') {
    academicYear = getCurrentAcademicYear();
  }

  if (rawDate !== '' && !/^\d{4}-\d{2}-\d{2}$/.test(rawDate)) {
    return res.status(400).json({ error: 'Result Date must be a valid YYYY-MM-DD date or left blank.' });
  }

  if (rawDate === '') {
    db.prepare(
      `DELETE FROM class_result_dates WHERE class_id = ? AND section_id = ? AND academic_year = ?`
    ).run(classId, sectionId, academicYear);
  } else {
    db.prepare(
      `INSERT INTO class_result_dates (class_id, section_id, academic_year, result_date, updated_by, updated_at)
       VALUES (?, ?, ?, ?, ?, datetime('now'))
       ON CONFLICT(class_id, section_id, academic_year) DO UPDATE SET
         result_date = excluded.result_date,
         updated_by = excluded.updated_by,
         updated_at = datetime('now')`
    ).run(classId, sectionId, academicYear, rawDate, req.user!.id);
  }

  logAudit(req.user!, 'SET_CLASS_RESULT_DATE', 'section', `${classId}:${sectionId}`, {
    academicYear,
    resultDate: rawDate || null,
  });

  res.json({
    success: true,
    classId,
    sectionId,
    academicYear,
    resultDate: rawDate || null,
  });
});

app.post('/api/co-scholastic/save', requireAuth, (req: AuthenticatedRequest, res) => {
  const examinationId = Number(req.body?.examinationId);
  const classId = Number(req.body?.classId);
  const sectionId = Number(req.body?.sectionId);
  const studentId = Number(req.body?.studentId);
  const gradesInput = req.body?.grades;

  if (!examinationId || !classId || !sectionId || !studentId || !gradesInput || typeof gradesInput !== 'object') {
    return res.status(400).json({
      error: 'examinationId, classId, sectionId, studentId, and grades are required.',
    });
  }

  if (!verifyClassResultAccess(req.user, classId, sectionId)) {
    return res.status(403).json({
      error: 'Access denied: Only administrators or the assigned Class Teacher for this section can update co-scholastic grades.',
    });
  }

  const termMeta = getExamCoScholasticTerm(examinationId);
  if (!termMeta.eligible || (termMeta.term !== 1 && termMeta.term !== 2)) {
    return res.status(400).json({
      error: termMeta.reason || 'Co-scholastic & discipline grades are restricted to the 1st and 2nd 100-mark term examinations.',
    });
  }

  const hasYearEnrollments =
    (
      db
        .prepare(`SELECT COUNT(*) as cnt FROM student_enrollments WHERE academic_year = ?`)
        .get(termMeta.academicYear) as { cnt: number }
    ).cnt > 0;

  const enrolledStudent = hasYearEnrollments
    ? db
        .prepare(
          `SELECT st.id FROM student_enrollments se
           JOIN students st ON st.id = se.student_id
           WHERE se.academic_year = ? AND se.class_id = ? AND se.section_id = ? AND se.student_id = ?
             AND COALESCE(st.is_deleted, 0) = 0`
        )
        .get(termMeta.academicYear, classId, sectionId, studentId)
    : db
        .prepare(
          `SELECT id FROM students WHERE id = ? AND class_id = ? AND section_id = ? AND COALESCE(is_deleted, 0) = 0`
        )
        .get(studentId, classId, sectionId);

  if (!enrolledStudent) {
    return res.status(404).json({ error: 'Student not found in the selected class and section.' });
  }

  for (const [k, rawVal] of Object.entries(gradesInput as Record<string, unknown>)) {
    if (!CO_SCHOLASTIC_ITEM_KEYS.has(k)) {
      return res.status(400).json({ error: `Unknown co-scholastic item: ${k}` });
    }
    if (rawVal !== null && rawVal !== undefined && rawVal !== '' && !isValidCoScholasticGrade(rawVal)) {
      return res.status(400).json({ error: `Invalid grade "${String(rawVal)}" for ${k}. Allowed values: A, B, or C.` });
    }
  }

  const upsertStmt = db.prepare(`
    INSERT INTO student_co_scholastic_grades (student_id, academic_year, term, examination_id, item_key, grade, points, entered_by, updated_at)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, datetime('now'))
    ON CONFLICT(student_id, academic_year, term, item_key) DO UPDATE SET
      examination_id = excluded.examination_id,
      grade = excluded.grade,
      points = excluded.points,
      entered_by = excluded.entered_by,
      updated_at = datetime('now')
  `);
  const deleteStmt = db.prepare(`
    DELETE FROM student_co_scholastic_grades
    WHERE student_id = ? AND academic_year = ? AND term = ? AND item_key = ?
  `);

  const saveTx = db.transaction(() => {
    for (const itemKey of CO_SCHOLASTIC_ITEM_KEYS) {
      if (!(itemKey in (gradesInput as Record<string, unknown>))) continue;
      const val = (gradesInput as Record<string, unknown>)[itemKey];
      if (isValidCoScholasticGrade(val)) {
        upsertStmt.run(
          studentId,
          termMeta.academicYear,
          termMeta.term,
          examinationId,
          itemKey,
          val,
          getCoScholasticPoints(val),
          req.user!.id
        );
      } else {
        deleteStmt.run(studentId, termMeta.academicYear, termMeta.term, itemKey);
      }
    }
  });

  saveTx();

  const updatedRows = db
    .prepare(
      `SELECT term, item_key, grade FROM student_co_scholastic_grades WHERE student_id = ? AND academic_year = ?`
    )
    .all(studentId, termMeta.academicYear) as Array<{ term: number; item_key: string; grade: string }>;

  const term1: Record<string, CoScholasticGrade> = {};
  const term2: Record<string, CoScholasticGrade> = {};
  for (const r of updatedRows) {
    if (!CO_SCHOLASTIC_ITEM_KEYS.has(r.item_key) || !isValidCoScholasticGrade(r.grade)) continue;
    if (r.term === 1) term1[r.item_key] = r.grade;
    else if (r.term === 2) term2[r.item_key] = r.grade;
  }

  logAudit(req.user!, 'SAVE_CO_SCHOLASTIC_GRADES', 'student', String(studentId), {
    examinationId,
    academicYear: termMeta.academicYear,
    term: termMeta.term,
    gradedCount: Object.keys(termMeta.term === 1 ? term1 : term2).length,
  });

  res.json({
    success: true,
    studentId,
    term: termMeta.term,
    term1,
    term2,
    term1TotalPoints: summarizeCoScholasticGrades(term1).totalPoints,
    term2TotalPoints: summarizeCoScholasticGrades(term2).totalPoints,
  });
});

function parseOptionalAttendanceCount(raw: unknown, fieldLabel: string): number | null {
  if (raw === null || raw === undefined || raw === '') return null;
  const num = Number(raw);
  if (!Number.isInteger(num) || num < 0 || num > 366) {
    throw new Error(`${fieldLabel} must be a whole number between 0 and 366.`);
  }
  return num;
}

app.post('/api/class-teacher/term-records/save', requireAuth, (req: AuthenticatedRequest, res) => {
  const classId = Number(req.body?.classId);
  const sectionId = Number(req.body?.sectionId);
  const studentId = Number(req.body?.studentId);
  const examinationId = req.body?.examinationId ? Number(req.body.examinationId) : null;
  let academicYear = typeof req.body?.academicYear === 'string' ? req.body.academicYear.trim() : '';

  if (!classId || !sectionId || !studentId) {
    return res.status(400).json({ error: 'classId, sectionId, and studentId are required.' });
  }
  if (!verifyClassResultAccess(req.user, classId, sectionId)) {
    return res.status(403).json({
      error: 'Access denied: Only administrators or the assigned Class Teacher for this section can update attendance, remarks, or optional student details.',
    });
  }

  if (!academicYear && examinationId) {
    const ex = db
      .prepare(`SELECT academic_year FROM examinations WHERE id = ? AND COALESCE(is_deleted, 0) = 0`)
      .get(examinationId) as { academic_year: string } | undefined;
    if (ex?.academic_year) academicYear = ex.academic_year;
  }
  if (!academicYear) academicYear = getCurrentAcademicYear();

  const hasYearEnrollments =
    (
      db
        .prepare(`SELECT COUNT(*) as cnt FROM student_enrollments WHERE academic_year = ?`)
        .get(academicYear) as { cnt: number }
    ).cnt > 0;

  const enrolledStudent = hasYearEnrollments
    ? db
        .prepare(
          `SELECT st.id FROM student_enrollments se
           JOIN students st ON st.id = se.student_id
           WHERE se.academic_year = ? AND se.class_id = ? AND se.section_id = ? AND se.student_id = ?
             AND COALESCE(st.is_deleted, 0) = 0`
        )
        .get(academicYear, classId, sectionId, studentId)
    : db
        .prepare(
          `SELECT id FROM students WHERE id = ? AND class_id = ? AND section_id = ? AND COALESCE(is_deleted, 0) = 0`
        )
        .get(studentId, classId, sectionId);

  if (!enrolledStudent) {
    return res.status(404).json({ error: 'Student not found in the selected class and section.' });
  }

  const termInputs: Array<{
    term: 1 | 2;
    daysAttended: number | null;
    totalDays: number | null;
    remarks: string;
  }> = [];

  try {
    for (const termNum of [1, 2] as const) {
      const rawObj = termNum === 1 ? req.body?.term1 : req.body?.term2;
      if (!rawObj || typeof rawObj !== 'object') continue;
      const daysAttended = parseOptionalAttendanceCount(rawObj.daysAttended, `Term ${termNum} Days Attended`);
      const totalDays = parseOptionalAttendanceCount(rawObj.totalDays, `Term ${termNum} Total Days`);
      if (daysAttended !== null && totalDays !== null && daysAttended > totalDays) {
        return res.status(400).json({
          error: `Term ${termNum}: Days Attended (${daysAttended}) cannot exceed Total Working Days (${totalDays}).`,
        });
      }
      const remarks = typeof rawObj.remarks === 'string' ? rawObj.remarks.trim().slice(0, 600) : '';
      termInputs.push({ term: termNum, daysAttended, totalDays, remarks });
    }
  } catch (err: any) {
    return res.status(400).json({ error: err?.message || 'Invalid attendance input.' });
  }

  const resolvedExams = resolveYearTermExams(academicYear);
  const profileInput = req.body?.profile && typeof req.body.profile === 'object' ? req.body.profile : null;

  const upsertTermStmt = db.prepare(`
    INSERT INTO student_term_records (student_id, academic_year, term, examination_id, days_attended, total_days, remarks, entered_by, updated_at)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, datetime('now'))
    ON CONFLICT(student_id, academic_year, term) DO UPDATE SET
      examination_id = COALESCE(excluded.examination_id, student_term_records.examination_id),
      days_attended = excluded.days_attended,
      total_days = excluded.total_days,
      remarks = excluded.remarks,
      entered_by = excluded.entered_by,
      updated_at = datetime('now')
  `);
  const deleteTermStmt = db.prepare(`
    DELETE FROM student_term_records
    WHERE student_id = ? AND academic_year = ? AND term = ?
  `);

  db.transaction(() => {
    for (const ti of termInputs) {
      if (ti.daysAttended === null && ti.totalDays === null && ti.remarks === '') {
        deleteTermStmt.run(studentId, academicYear, ti.term);
      } else {
        const termExamId = ti.term === 1 ? resolvedExams.term1ExamId : resolvedExams.term2ExamId;
        upsertTermStmt.run(
          studentId,
          academicYear,
          ti.term,
          termExamId,
          ti.daysAttended,
          ti.totalDays,
          ti.remarks,
          req.user!.id
        );
      }
    }

    if (profileInput) {
      const cur = db
        .prepare(
          `SELECT COALESCE(father_name, '') as father_name,
                  COALESCE(mother_name, '') as mother_name,
                  COALESCE(residential_address, '') as residential_address,
                  COALESCE(contact_no, '') as contact_no,
                  COALESCE(guardian_phone, '') as guardian_phone,
                  COALESCE(aapaar_id, '') as aapaar_id
           FROM students WHERE id = ?`
        )
        .get(studentId) as any;
      if (cur) {
        const nextFather =
          profileInput.fatherName !== undefined ? String(profileInput.fatherName || '').trim() : cur.father_name;
        const nextMother =
          profileInput.motherName !== undefined ? String(profileInput.motherName || '').trim() : cur.mother_name;
        const nextAddress =
          profileInput.residentialAddress !== undefined
            ? String(profileInput.residentialAddress || '').trim()
            : cur.residential_address;
        const nextContact =
          profileInput.contactNo !== undefined ? String(profileInput.contactNo || '').trim() : cur.contact_no;
        const nextAapaar =
          profileInput.aapaarId !== undefined ? String(profileInput.aapaarId || '').trim() : cur.aapaar_id;
        const nextGuardianPhone = cur.guardian_phone || nextContact;
        db.prepare(
          `UPDATE students
           SET father_name = ?, mother_name = ?, residential_address = ?, contact_no = ?, guardian_phone = ?, aapaar_id = ?,
               updated_at = datetime('now')
           WHERE id = ?`
        ).run(nextFather, nextMother, nextAddress, nextContact, nextGuardianPhone, nextAapaar, studentId);
      }
    }
  })();

  const termRecords = getStudentTermRecordsMap(academicYear, [studentId]).get(studentId) || createEmptyTermData();
  const profile = getStudentExtendedProfilesMap([studentId]).get(studentId) || {
    fatherName: '',
    motherName: '',
    residentialAddress: '',
    contactNo: '',
    aapaarId: '',
  };

  logAudit(req.user!, 'SAVE_STUDENT_TERM_RECORDS', 'student', String(studentId), {
    academicYear,
    termsUpdated: termInputs.map((t) => t.term),
    profileUpdated: Boolean(profileInput),
  });

  res.json({
    success: true,
    studentId,
    academicYear,
    termRecords,
    profile,
  });
});

app.post('/api/class-teacher/term-records/bulk-total-days', requireAuth, (req: AuthenticatedRequest, res) => {
  const classId = Number(req.body?.classId);
  const sectionId = Number(req.body?.sectionId);
  const term = Number(req.body?.term);
  const examinationId = req.body?.examinationId ? Number(req.body.examinationId) : null;
  let academicYear = typeof req.body?.academicYear === 'string' ? req.body.academicYear.trim() : '';

  if (!classId || !sectionId || (term !== 1 && term !== 2)) {
    return res.status(400).json({ error: 'classId, sectionId, and term (1 or 2) are required.' });
  }
  if (!verifyClassResultAccess(req.user, classId, sectionId)) {
    return res.status(403).json({
      error: 'Access denied: Only administrators or the assigned Class Teacher for this section can update working days.',
    });
  }

  let parsedTotalDays: number | null = null;
  try {
    parsedTotalDays = parseOptionalAttendanceCount(req.body?.totalDays, 'Total Working Days');
  } catch (err: any) {
    return res.status(400).json({ error: err?.message || 'Invalid totalDays.' });
  }
  if (parsedTotalDays === null) {
    return res.status(400).json({ error: 'Total Working Days is required.' });
  }

  if (!academicYear && examinationId) {
    const ex = db
      .prepare(`SELECT academic_year FROM examinations WHERE id = ? AND COALESCE(is_deleted, 0) = 0`)
      .get(examinationId) as { academic_year: string } | undefined;
    if (ex?.academic_year) academicYear = ex.academic_year;
  }
  if (!academicYear) academicYear = getCurrentAcademicYear();

  const hasYearEnrollments =
    (
      db
        .prepare(`SELECT COUNT(*) as cnt FROM student_enrollments WHERE academic_year = ?`)
        .get(academicYear) as { cnt: number }
    ).cnt > 0;

  const roster = (
    hasYearEnrollments
      ? db
          .prepare(
            `SELECT st.id as student_id, st.full_name
             FROM student_enrollments se
             JOIN students st ON st.id = se.student_id
             WHERE se.academic_year = ? AND se.class_id = ? AND se.section_id = ?
               AND se.status = 'active' AND COALESCE(st.is_deleted, 0) = 0`
          )
          .all(academicYear, classId, sectionId)
      : db
          .prepare(
            `SELECT id as student_id, full_name
             FROM students
             WHERE class_id = ? AND section_id = ? AND status = 'active' AND COALESCE(is_deleted, 0) = 0`
          )
          .all(classId, sectionId)
  ) as Array<{ student_id: number; full_name: string }>;

  if (roster.length === 0) {
    return res.status(404).json({ error: 'No active students found in this section.' });
  }

  const existingRows = db
    .prepare(
      `SELECT student_id, days_attended, COALESCE(remarks, '') as remarks
       FROM student_term_records
       WHERE academic_year = ? AND term = ?`
    )
    .all(academicYear, term) as Array<{ student_id: number; days_attended: number | null; remarks: string }>;
  const existingMap = new Map(existingRows.map((r) => [r.student_id, r]));

  for (const st of roster) {
    const ex = existingMap.get(st.student_id);
    if (ex && ex.days_attended !== null && ex.days_attended > parsedTotalDays) {
      return res.status(400).json({
        error: `Cannot set Term ${term} Total Days to ${parsedTotalDays}: ${st.full_name} already has ${ex.days_attended} days attended.`,
      });
    }
  }

  const resolvedExams = resolveYearTermExams(academicYear);
  const termExamId = term === 1 ? resolvedExams.term1ExamId : resolvedExams.term2ExamId;

  const upsertStmt = db.prepare(`
    INSERT INTO student_term_records (student_id, academic_year, term, examination_id, days_attended, total_days, remarks, entered_by, updated_at)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, datetime('now'))
    ON CONFLICT(student_id, academic_year, term) DO UPDATE SET
      examination_id = COALESCE(excluded.examination_id, student_term_records.examination_id),
      total_days = excluded.total_days,
      entered_by = excluded.entered_by,
      updated_at = datetime('now')
  `);

  db.transaction(() => {
    for (const st of roster) {
      const ex = existingMap.get(st.student_id);
      upsertStmt.run(
        st.student_id,
        academicYear,
        term,
        termExamId,
        ex?.days_attended ?? null,
        parsedTotalDays,
        ex?.remarks ?? '',
        req.user!.id
      );
    }
  })();

  logAudit(req.user!, 'BULK_SET_TERM_TOTAL_DAYS', 'section', `${classId}:${sectionId}`, {
    academicYear,
    term,
    totalDays: parsedTotalDays,
    updatedCount: roster.length,
  });

  res.json({
    success: true,
    academicYear,
    term,
    totalDays: parsedTotalDays,
    updatedCount: roster.length,
  });
});

function loadClassSectionStudentProfiles(academicYear: string, classId: number, sectionId: number) {
  const hasYearEnrollments =
    (
      db
        .prepare(`SELECT COUNT(*) as cnt FROM student_enrollments WHERE academic_year = ?`)
        .get(academicYear) as { cnt: number }
    ).cnt > 0;

  const rows = (
    hasYearEnrollments
      ? db
          .prepare(
            `SELECT st.id as studentId,
                    st.student_code as studentCode,
                    st.full_name as fullName,
                    se.roll_number as rollNumber,
                    COALESCE(NULLIF(se.stream, ''), st.stream, '') as stream,
                    COALESCE(st.father_name, '') as fatherName,
                    COALESCE(st.mother_name, '') as motherName,
                    COALESCE(st.residential_address, '') as residentialAddress,
                    COALESCE(NULLIF(st.contact_no, ''), st.guardian_phone, '') as contactNo,
                    COALESCE(st.aapaar_id, '') as aapaarId,
                    COALESCE(st.photo_url, '') as photoUrl
             FROM student_enrollments se
             JOIN students st ON st.id = se.student_id
             WHERE se.academic_year = ? AND se.class_id = ? AND se.section_id = ?
               AND se.status = 'active' AND COALESCE(st.is_deleted, 0) = 0
             ORDER BY se.roll_number ASC, st.student_code ASC`
          )
          .all(academicYear, classId, sectionId)
      : db
          .prepare(
            `SELECT id as studentId,
                    student_code as studentCode,
                    full_name as fullName,
                    roll_number as rollNumber,
                    COALESCE(stream, '') as stream,
                    COALESCE(father_name, '') as fatherName,
                    COALESCE(mother_name, '') as motherName,
                    COALESCE(residential_address, '') as residentialAddress,
                    COALESCE(NULLIF(contact_no, ''), guardian_phone, '') as contactNo,
                    COALESCE(aapaar_id, '') as aapaarId,
                    COALESCE(photo_url, '') as photoUrl
             FROM students
             WHERE class_id = ? AND section_id = ? AND status = 'active' AND COALESCE(is_deleted, 0) = 0
             ORDER BY roll_number ASC, student_code ASC`
          )
          .all(classId, sectionId)
  ) as Array<{
    studentId: number;
    studentCode: string;
    fullName: string;
    rollNumber: number;
    stream: string;
    fatherName: string;
    motherName: string;
    residentialAddress: string;
    contactNo: string;
    aapaarId: string;
    photoUrl: string;
  }>;

  return rows;
}

app.get('/api/class-teacher/student-profiles', requireAuth, (req: AuthenticatedRequest, res) => {
  const classId = Number(req.query.classId);
  const sectionId = Number(req.query.sectionId);
  let academicYear = typeof req.query.academicYear === 'string' ? req.query.academicYear.trim() : '';
  if (!academicYear || academicYear === 'ALL' || academicYear === 'all') {
    academicYear = getCurrentAcademicYear();
  }

  if (!classId || !sectionId) {
    return res.status(400).json({ error: 'classId and sectionId are required.' });
  }
  if (!verifyClassResultAccess(req.user, classId, sectionId)) {
    return res.status(403).json({
      error: 'Access denied: Only administrators or the assigned Class Teacher for this section can view student details.',
    });
  }

  const classSection = db
    .prepare(
      `SELECT c.id as classId, c.name as className, COALESCE(c.has_sections, 1) as hasSections,
              s.id as sectionId, s.name as sectionName
       FROM classes c
       JOIN sections s ON s.class_id = c.id
       WHERE c.id = ? AND s.id = ?`
    )
    .get(classId, sectionId) as
    | { classId: number; className: string; hasSections: number; sectionId: number; sectionName: string }
    | undefined;
  if (!classSection) {
    return res.status(404).json({ error: 'Class or Section not found.' });
  }

  const students = loadClassSectionStudentProfiles(academicYear, classId, sectionId);
  res.json({
    academicYear,
    classInfo: {
      classId: classSection.classId,
      className: classSection.className,
      hasSections: Boolean(classSection.hasSections ?? 1),
      sectionId: classSection.sectionId,
      sectionName: classSection.sectionName,
    },
    students,
  });
});

app.post('/api/class-teacher/student-profiles/save', requireAuth, (req: AuthenticatedRequest, res) => {
  const classId = Number(req.body?.classId);
  const sectionId = Number(req.body?.sectionId);
  let academicYear = typeof req.body?.academicYear === 'string' ? req.body.academicYear.trim() : '';
  if (!academicYear || academicYear === 'ALL' || academicYear === 'all') {
    academicYear = getCurrentAcademicYear();
  }
  const records = req.body?.records;

  if (!classId || !sectionId || !Array.isArray(records) || records.length === 0) {
    return res.status(400).json({ error: 'classId, sectionId, and a non-empty records array are required.' });
  }
  if (!verifyClassResultAccess(req.user, classId, sectionId)) {
    return res.status(403).json({
      error: 'Access denied: Only administrators or the assigned Class Teacher for this section can update student details.',
    });
  }

  const hasYearEnrollments =
    (
      db
        .prepare(`SELECT COUNT(*) as cnt FROM student_enrollments WHERE academic_year = ?`)
        .get(academicYear) as { cnt: number }
    ).cnt > 0;

  const allowedIds = new Set(
    (
      (hasYearEnrollments
        ? db
            .prepare(
              `SELECT st.id as id FROM student_enrollments se
               JOIN students st ON st.id = se.student_id
               WHERE se.academic_year = ? AND se.class_id = ? AND se.section_id = ? AND COALESCE(st.is_deleted, 0) = 0`
            )
            .all(academicYear, classId, sectionId)
        : db
            .prepare(
              `SELECT id FROM students WHERE class_id = ? AND section_id = ? AND COALESCE(is_deleted, 0) = 0`
            )
            .all(classId, sectionId)) as Array<{ id: number }>
    ).map((r) => r.id)
  );

  for (const rec of records) {
    const sid = Number(rec?.studentId);
    if (!sid || !allowedIds.has(sid)) {
      return res.status(400).json({
        error: `Student #${rec?.studentId ?? '?'} does not belong to the selected class and section.`,
      });
    }
    if (rec?.photoUrl !== undefined) {
      const rawPhoto = String(rec.photoUrl ?? '').trim();
      if (rawPhoto !== '') {
        const isSafeDataImage = /^data:image\/(jpeg|jpg|png|webp);base64,[A-Za-z0-9+/=]+$/i.test(rawPhoto);
        const isSafePathOrHttp = /^(\/assets\/|https?:\/\/)/i.test(rawPhoto);
        if (!isSafeDataImage && !isSafePathOrHttp) {
          return res.status(400).json({
            error: 'Invalid student photo format. Please upload a JPG, PNG, or WebP image.',
          });
        }
        if (rawPhoto.length > 700000) {
          return res.status(400).json({
            error: 'Student photo is too large after processing. Please select a smaller image.',
          });
        }
      }
    }
  }

  const readStudentStmt = db.prepare(
    `SELECT COALESCE(father_name, '') as father_name,
            COALESCE(mother_name, '') as mother_name,
            COALESCE(residential_address, '') as residential_address,
            COALESCE(contact_no, '') as contact_no,
            COALESCE(guardian_phone, '') as guardian_phone,
            COALESCE(aapaar_id, '') as aapaar_id,
            COALESCE(photo_url, '') as photo_url
     FROM students WHERE id = ?`
  );
  const updateStudentStmt = db.prepare(
    `UPDATE students
     SET father_name = ?, mother_name = ?, residential_address = ?, contact_no = ?, guardian_phone = ?, aapaar_id = ?, photo_url = ?,
         updated_at = datetime('now')
     WHERE id = ?`
  );

  let updatedCount = 0;
  db.transaction(() => {
    for (const rec of records) {
      const sid = Number(rec.studentId);
      const cur = readStudentStmt.get(sid) as
        | {
            father_name: string;
            mother_name: string;
            residential_address: string;
            contact_no: string;
            guardian_phone: string;
            aapaar_id: string;
            photo_url: string;
          }
        | undefined;
      if (!cur) continue;

      const nextFather =
        rec.fatherName !== undefined ? String(rec.fatherName ?? '').trim().slice(0, 150) : cur.father_name;
      const nextMother =
        rec.motherName !== undefined ? String(rec.motherName ?? '').trim().slice(0, 150) : cur.mother_name;
      const nextAddress =
        rec.residentialAddress !== undefined
          ? String(rec.residentialAddress ?? '').trim().slice(0, 300)
          : cur.residential_address;
      const nextContact =
        rec.contactNo !== undefined ? String(rec.contactNo ?? '').trim().slice(0, 40) : cur.contact_no;
      const nextAapaar =
        rec.aapaarId !== undefined ? String(rec.aapaarId ?? '').trim().slice(0, 40) : cur.aapaar_id;
      const nextPhotoUrl =
        rec.photoUrl !== undefined ? String(rec.photoUrl ?? '').trim() : cur.photo_url;

      const shouldSyncGuardianPhone =
        !cur.guardian_phone || cur.guardian_phone === cur.contact_no;
      const nextGuardianPhone = shouldSyncGuardianPhone ? nextContact : cur.guardian_phone;

      updateStudentStmt.run(
        nextFather,
        nextMother,
        nextAddress,
        nextContact,
        nextGuardianPhone,
        nextAapaar,
        nextPhotoUrl,
        sid
      );
      updatedCount++;
    }
  })();

  logAudit(req.user!, 'SAVE_STUDENT_PROFILES', 'section', `${classId}:${sectionId}`, {
    academicYear,
    updatedCount,
  });

  const students = loadClassSectionStudentProfiles(academicYear, classId, sectionId);
  res.json({
    success: true,
    academicYear,
    updatedCount,
    students,
  });
});

app.get('/api/admin/results/subject-excel', requireAuth, requireAdmin, (req: AuthenticatedRequest, res) => {
  try {
    const examinationId = Number(req.query.examinationId);
    const subjectId = req.query.subjectId ? Number(req.query.subjectId) : null;
    const filterClassId = req.query.classId ? Number(req.query.classId) : null;
    const filterSectionId = req.query.sectionId ? Number(req.query.sectionId) : null;

    if (!examinationId) {
      return res.status(400).json({ error: 'examinationId is required.' });
    }

    const exam = db
      .prepare(`SELECT * FROM examinations WHERE id = ? AND COALESCE(is_deleted, 0) = 0`)
      .get(examinationId) as any;
    if (!exam) return res.status(404).json({ error: 'Examination not found.' });

    const classSections = db
      .prepare(
        `SELECT c.id as class_id, c.name as class_name, COALESCE(c.has_sections, 1) as has_sections,
                s.id as section_id, s.name as section_name
         FROM classes c
         JOIN sections s ON s.class_id = c.id
         WHERE COALESCE(c.is_deleted, 0) = 0 AND COALESCE(s.is_deleted, 0) = 0 AND c.is_active = 1
         ORDER BY c.numeric_order ASC, s.name ASC`
      )
      .all() as Array<{ class_id: number; class_name: string; has_sections: number; section_id: number; section_name: string }>;

    const matchedSections = classSections.filter(
      (cs) =>
        (!filterClassId || cs.class_id === filterClassId) &&
        (!filterSectionId || cs.section_id === filterSectionId)
    );

    const sectionsOut: any[] = [];
    let resolvedSubjectName = 'All Subjects';

    for (const cs of matchedSections) {
      const report = getConsolidatedResults(examinationId, cs.class_id, cs.section_id);
      if (report.students.length === 0) continue;

      const subjectsToInclude = subjectId
        ? report.subjects.filter((s) => s.subjectId === subjectId)
        : report.subjects;

      for (const subMeta of subjectsToInclude) {
        if (subjectId) resolvedSubjectName = subMeta.subjectName;
        const enrolledStudents = report.students
          .map((st) => ({
            rollNumber: st.rollNumber,
            studentCode: st.studentCode,
            studentName: st.studentName,
            stream: st.stream || '',
            result: st.subjects.find((sr) => sr.subjectId === subMeta.subjectId)!,
          }))
          .filter((entry) => entry.result && entry.result.gradeStatus !== 'not_applicable' && entry.result.isEnrolled !== false);
        if (enrolledStudents.length === 0) continue;
        sectionsOut.push({
          classId: cs.class_id,
          className: cs.class_name,
          hasSections: Boolean(cs.has_sections ?? 1),
          sectionId: cs.section_id,
          sectionName: cs.section_name,
          subject: subMeta,
          students: enrolledStudents,
        });
      }
    }

    if (sectionsOut.length === 0) {
      return res.status(404).json({ error: 'No matching subject results found for this selection.' });
    }

    logAudit(req.user!, 'EXPORT_ADMIN_SUBJECT_EXCEL', 'examination', String(examinationId), {
      examinationId,
      subjectId,
      filterClassId,
      filterSectionId,
      sectionSheets: sectionsOut.length,
    });

    res.json({
      examinationId,
      examinationName: exam.name,
      academicYear: exam.academic_year,
      subjectId,
      subjectName: resolvedSubjectName,
      generatedAt: new Date().toISOString(),
      sections: sectionsOut,
    });
  } catch (err: any) {
    console.error('Error building admin subject excel payload:', err);
    res.status(500).json({ error: err?.message || 'Failed to build subject-wise Excel data.' });
  }
});

// Return JSON 404 for unknown /api routes instead of falling through to SPA HTML
app.all('/api/*', (_req, res) => {
  res.status(404).json({ error: 'API endpoint not found.' });
});

// Return JSON errors for /api failures instead of Express HTML error pages
app.use((err: any, req: express.Request, res: express.Response, next: express.NextFunction) => {
  if (res.headersSent) return next(err);
  if (req.path.startsWith('/api/')) {
    console.error('API Error:', err);
    return res.status(err?.status || 500).json({ error: err?.message || 'Internal server error.' });
  }
  return next(err);
});

// ==========================================
// VITE / STATIC SERVING
// ==========================================

async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.resolve(process.cwd(), 'dist');
    const publicPath = path.resolve(process.cwd(), 'public');
    const imagesPath = path.resolve(process.cwd(), 'src/assets/images');
    const officialLogoPath = path.resolve(publicPath, 'assets/aistudio/logo_emrs_1d5c0342.jpg');

    app.get('/school-emblem.jpg', (_req, res, next) => {
      const distOfficialLogo = path.join(distPath, 'assets/aistudio/logo_emrs_1d5c0342.jpg');
      const target = fs.existsSync(officialLogoPath)
        ? officialLogoPath
        : fs.existsSync(distOfficialLogo)
          ? distOfficialLogo
          : path.join(publicPath, 'school-emblem.jpg');
      if (!fs.existsSync(target)) return next();
      res.setHeader('Cache-Control', 'public, max-age=86400');
      return res.sendFile(target);
    });

    if (fs.existsSync(publicPath)) {
      app.use(express.static(publicPath, { maxAge: '1d' }));
    }
    if (fs.existsSync(imagesPath)) {
      app.use('/src/assets/images', express.static(imagesPath, { maxAge: '1d' }));
    }
    app.use(
      express.static(distPath, {
        setHeaders: (res, filePath) => {
          if (filePath.endsWith('index.html')) {
            res.setHeader('Cache-Control', 'no-store, no-cache, must-revalidate, proxy-revalidate');
          }
        },
      })
    );
    app.get('*', (_req, res) => {
      const indexHtml = path.join(distPath, 'index.html');
      if (!fs.existsSync(indexHtml)) {
        return res
          .status(503)
          .send('Production frontend build (dist/index.html) is missing. Run npm run build.');
      }
      res.setHeader('Cache-Control', 'no-store, no-cache, must-revalidate, proxy-revalidate');
      res.sendFile(indexHtml);
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`School Examination Portal server running on http://0.0.0.0:${PORT}`);
  });
}

if (!process.env.VERCEL && process.env.DISABLE_AUTO_LISTEN !== '1') {
  startServer();
}

export { app };
export default app;
