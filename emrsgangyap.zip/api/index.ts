import type { IncomingMessage, ServerResponse } from 'node:http';
import { app } from '../server.ts';

export default function handler(req: IncomingMessage & { url?: string }, res: ServerResponse) {
  if (req.url) {
    try {
      const parsed = new URL(req.url, 'http://localhost');
      const vPath = parsed.searchParams.get('__vercel_path');
      if (vPath) {
        parsed.searchParams.delete('__vercel_path');
        const qs = parsed.searchParams.toString();
        req.url = vPath + (qs ? `?${qs}` : '');
      }
    } catch {
      // keep original req.url if parsing fails
    }
  }
  return app(req as any, res as any);
}
